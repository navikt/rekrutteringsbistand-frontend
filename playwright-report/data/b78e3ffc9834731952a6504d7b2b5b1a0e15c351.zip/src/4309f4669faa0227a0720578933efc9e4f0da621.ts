import { expect, lagringsstatus, test, åpneVurdering } from './oppsett';
import type { Page } from '@playwright/test';

const vurderingsrad = (page: Page, navn: string) =>
  page
    .getByRole('region', { name: 'Eksempelbakeriet AS' })
    .getByRole('listitem')
    .filter({ hasText: navn });

const registrerIntervjudato = async (page: Page) => {
  await åpneVurdering(page);
  const rad = vurderingsrad(page, 'Marius Etternavn01');
  const status = lagringsstatus(page, 'Vurdering og oppfølging');
  await rad.getByRole('checkbox', { name: '2. intervju' }).check();
  await expect(status).toContainText('Lagret');
  const dato = rad.getByRole('textbox', { name: /Dato for 2\. intervju/ });
  await dato.fill('14.09.2026');
  await dato.blur();
  await expect(status).toContainText('Lagret');
  return { rad, dato, status };
};

test('beholder lagret intervjudato når en ugyldig dato skrives inn', async ({
  page,
}) => {
  const { rad, dato } = await registrerIntervjudato(page);
  await dato.fill('31.02.2026');
  await dato.blur();
  await expect(
    rad.getByText(
      'Oppgi en gyldig dato som dd.mm.åååå. Endringen er ikke lagret.',
    ),
  ).toBeVisible();
  await expect(dato).toHaveValue('31.02.2026');
  await expect(dato).toHaveAttribute('aria-invalid', 'true');
  await page.reload();
  await expect(dato).toHaveValue('14.09.2026');
});

test('viser datofeil først når feltet forlates', async ({ page }) => {
  const { rad, dato } = await registrerIntervjudato(page);
  const feil = rad.getByText(
    'Oppgi en gyldig dato som dd.mm.åååå. Endringen er ikke lagret.',
  );
  await dato.fill('');
  await dato.pressSequentially('15.0');
  await expect(feil).toHaveCount(0);
  await expect(dato).not.toHaveAttribute('aria-invalid', 'true');
  await dato.blur();
  await expect(feil).toBeVisible();
  await dato.focus();
  await dato.press('End');
  await dato.pressSequentially('9.2026');
  await expect(dato).toHaveValue('15.09.2026');
  await expect(feil).toHaveCount(0);
});

test('lagrer ikke gyldige mellomverdier mens intervjudato skrives inn', async ({
  page,
}) => {
  const { rad, dato, status } = await registrerIntervjudato(page);
  const datoerTilServer: string[] = [];
  await page.route('**/oppfolging/vurderinger', async (route) => {
    datoerTilServer.push(route.request().postDataJSON().avtaltIntervjuDato);
    await route.continue();
  });

  // «10.1.2026» er en gyldig mellomverdi før «3» gjør måneden ugyldig.
  await dato.fill('');
  await dato.pressSequentially('10.1.2026');
  await dato.press('Home');
  for (let i = 0; i < 4; i++) await dato.press('ArrowRight');
  await dato.press('3');
  await expect(dato).toHaveValue('10.13.2026');
  await dato.blur();
  await expect(
    rad.getByText(
      'Oppgi en gyldig dato som dd.mm.åååå. Endringen er ikke lagret.',
    ),
  ).toBeVisible();

  await page
    .getByRole('button', { name: 'Intervjufordeling', exact: true })
    .click();
  await page
    .getByRole('button', { name: 'Vurdering og oppfølging', exact: true })
    .click();
  await expect(dato).toHaveValue('14.09.2026');
  expect(datoerTilServer).toEqual([]);

  await dato.fill('');
  await dato.pressSequentially('15.09.2026');
  await dato.blur();
  await expect(status).toContainText('Lagret');
  expect(datoerTilServer).toEqual(['2026-09-15']);
  await page.reload();
  await expect(dato).toHaveValue('15.09.2026');
});

for (const { navn, verdi } of [
  { navn: 'endring', verdi: '15.09.2026' },
  { navn: 'sletting', verdi: '' },
]) {
  test(`tilbakestiller intervjudato i feltet når ${navn} ikke kan lagres`, async ({
    page,
  }) => {
    const { rad, dato, status } = await registrerIntervjudato(page);
    await page.route('**/oppfolging/vurderinger', (route) =>
      route.fulfill({ status: 500, json: { feil: 'Testfeil' } }),
    );
    await dato.fill(verdi);
    await dato.blur();
    await expect(rad.getByText(/Kunne ikke lagre vurderingen/)).toBeVisible();
    await expect(dato).toHaveValue('14.09.2026');
    await page.unroute('**/oppfolging/vurderinger');
    await dato.fill(verdi);
    await dato.blur();
    await expect(status).toContainText('Lagret');
    await page.reload();
    await expect(dato).toHaveValue(verdi);
  });
}

test('beholder en nyere intervjudato når en tidligere datoendring i køen feiler', async ({
  page,
}) => {
  const { dato, status } = await registrerIntervjudato(page);
  let slippFørsteLagring!: () => void;
  const vent = new Promise<void>((resolve) => {
    slippFørsteLagring = resolve;
  });
  const datoerTilServer: string[] = [];
  await page.route('**/oppfolging/vurderinger', async (route) => {
    datoerTilServer.push(route.request().postDataJSON().avtaltIntervjuDato);
    if (datoerTilServer.length === 1) {
      await vent;
      await route.fulfill({
        status: 500,
        json: { feil: 'Syntetisk skrivefeil' },
      });
    } else {
      await route.continue();
    }
  });

  try {
    await dato.fill('15.09.2026');
    await dato.blur();
    await expect.poll(() => datoerTilServer).toEqual(['2026-09-15']);
    await dato.fill('16.09.2026');
    await dato.blur();
    await expect(dato).toHaveValue('16.09.2026');
    await expect(status).toContainText('Lagrer');
  } finally {
    slippFørsteLagring();
  }

  await expect(status).toContainText('Lagret');
  expect(datoerTilServer).toEqual(['2026-09-15', '2026-09-16']);
  await expect(dato).toHaveValue('16.09.2026');
  await page.reload();
  await expect(dato).toHaveValue('16.09.2026');
});

test('lagrer ikke skjult inntasting etter at feltet er tilbakestilt av en lagringsfeil', async ({
  page,
}) => {
  const { rad, dato, status } = await registrerIntervjudato(page);
  let slippFørsteLagring!: () => void;
  const vent = new Promise<void>((resolve) => {
    slippFørsteLagring = resolve;
  });
  const datoerTilServer: string[] = [];
  await page.route('**/oppfolging/vurderinger', async (route) => {
    datoerTilServer.push(route.request().postDataJSON().avtaltIntervjuDato);
    if (datoerTilServer.length === 1) {
      await vent;
      await route.fulfill({
        status: 500,
        json: { feil: 'Syntetisk skrivefeil' },
      });
    } else {
      await route.continue();
    }
  });

  try {
    await dato.fill('15.09.2026');
    await dato.blur();
    await expect.poll(() => datoerTilServer).toEqual(['2026-09-15']);
    await dato.fill('16.09.2026');
    await expect(dato).toBeFocused();
  } finally {
    slippFørsteLagring();
  }

  await expect(rad.getByText(/Kunne ikke lagre vurderingen/)).toBeVisible();
  await expect(dato).toHaveValue('14.09.2026');
  await dato.blur();
  // Køen er sekvensiell, så en senere lagring viser om blur sendte noe.
  await rad.getByRole('checkbox', { name: 'Jobbtilbud' }).check();
  await expect(status).toContainText('Lagret');
  expect(datoerTilServer).toEqual(['2026-09-15', '2026-09-14']);
  await page.reload();
  await expect(dato).toHaveValue('14.09.2026');
});

test('beholder lagringsfeil ved ny endring på samme rad mens bekreftet tilstand hentes', async ({
  page,
}) => {
  await åpneVurdering(page);
  const rad = vurderingsrad(page, 'Marius Etternavn01');
  const vurdering = rad.getByRole('combobox', { name: 'Vurdering' });
  const status = lagringsstatus(page, 'Vurdering og oppfølging');
  const verdierTilServer: string[] = [];
  await page.route('**/oppfolging/vurderinger', async (route) => {
    verdierTilServer.push(route.request().postDataJSON().vurderingsstatus);
    if (verdierTilServer.length === 1) {
      await route.fulfill({
        status: 500,
        json: { feil: 'Syntetisk skrivefeil' },
      });
    } else await route.continue();
  });
  let slippHenting!: () => void;
  const ventPåHenting = new Promise<void>((resolve) => {
    slippHenting = resolve;
  });
  let tillatOppfriskning = false;
  await page.route(
    '**/workop/treffgjennomforing-og-oppfolging',
    async (route) => {
      if (tillatOppfriskning) await route.continue();
      else {
        await ventPåHenting;
        await route.fulfill({
          status: 500,
          json: { feil: 'Syntetisk hentefeil' },
        });
      }
    },
  );
  try {
    await vurdering.selectOption('AKTUELL');
    await expect(status).toContainText('Ikke lagret');
    await expect(vurdering).toBeEnabled();
    await vurdering.selectOption('KANSKJE');
    await expect(vurdering).toHaveValue('KANSKJE');
    await expect(rad.getByText(/Kunne ikke lagre vurderingen/)).toBeVisible();
    await expect(status).toContainText('Ikke lagret');
    expect(verdierTilServer).toEqual(['AKTUELL']);
  } finally {
    slippHenting();
  }
  await expect(
    page.getByText('Tilstanden er ubekreftet', { exact: true }),
  ).toBeVisible();
  await expect(status).toContainText('Ikke lagret');
  await expect(vurdering).toBeDisabled();
  expect(verdierTilServer).toEqual(['AKTUELL']);
  tillatOppfriskning = true;
  await page.getByRole('button', { name: 'Hent på nytt', exact: true }).click();
  await expect(status).toContainText('Lagret');
  await expect(rad.getByText(/Kunne ikke lagre vurderingen/)).toHaveCount(0);
  expect(verdierTilServer).toEqual(['AKTUELL', 'KANSKJE']);
  await expect(vurdering).toBeEnabled();
  await page.reload();
  await expect(vurdering).toHaveValue('KANSKJE');
});

test('lukker datovelgeren med Escape og lagrer dato valgt i kalenderen', async ({
  page,
}) => {
  const { rad, dato, status } = await registrerIntervjudato(page);
  const åpneKalender = rad.getByRole('button', { name: 'Åpne datovelger' });
  const kalender = page.getByRole('grid', { name: 'september 2026' });
  await åpneKalender.click();
  await expect(kalender).toBeVisible();
  await page.keyboard.press('Escape');
  await expect(kalender).toBeHidden();
  await expect(åpneKalender).toBeFocused();
  await expect(dato).toHaveValue('14.09.2026');
  await åpneKalender.click();
  await kalender
    .getByRole('gridcell', { name: 'tirsdag 15', exact: true })
    .getByRole('button')
    .click();
  await expect(kalender).toBeHidden();
  await expect(status).toContainText('Lagret');
  await page.reload();
  await expect(dato).toHaveValue('15.09.2026');
});

test('fjerner intervjudato når valgt dag klikkes i kalenderen', async ({
  page,
}) => {
  const { rad, dato, status } = await registrerIntervjudato(page);
  const datoerTilServer: (string | null)[] = [];
  await page.route('**/oppfolging/vurderinger', async (route) => {
    datoerTilServer.push(route.request().postDataJSON().avtaltIntervjuDato);
    await route.continue();
  });
  const kalender = page.getByRole('grid', { name: 'september 2026' });
  await rad.getByRole('button', { name: 'Åpne datovelger' }).click();
  await kalender
    .getByRole('gridcell', { name: 'mandag 14', exact: true })
    .getByRole('button')
    .click();
  await expect(dato).toHaveValue('');
  await expect.poll(() => datoerTilServer).toEqual([null]);
  await expect(status).toContainText('Lagret');
  await page.keyboard.press('Escape');
  await expect(kalender).toBeHidden();
  await dato.focus();
  await dato.blur();
  expect(datoerTilServer).toEqual([null]);
  await page.reload();
  await expect(dato).toHaveValue('');
});

test('beholder raske vurderingsendringer på flere rader etter ny lasting', async ({
  page,
}) => {
  await åpneVurdering(page);
  const første = vurderingsrad(page, 'Marius Etternavn01');
  const andre = vurderingsrad(page, 'Emilie Etternavn02');
  const vurdering = første.getByRole('combobox', { name: 'Vurdering' });
  const intervju = første.getByRole('checkbox', { name: '2. intervju' });
  const jobbtilbud = første.getByRole('checkbox', { name: 'Jobbtilbud' });
  const andreVurdering = andre.getByRole('combobox', { name: 'Vurdering' });
  const status = lagringsstatus(page, 'Vurdering og oppfølging');
  let slippLagring!: () => void;
  const vent = new Promise<void>((resolve) => {
    slippLagring = resolve;
  });
  await page.route('**/oppfolging/vurderinger', async (route) => {
    await vent;
    await route.continue();
  });
  try {
    await vurdering.selectOption('AKTUELL');
    await expect(status).toContainText('Lagrer');
    await intervju.check();
    await jobbtilbud.check();
    await andreVurdering.selectOption('KANSKJE');
    await expect(intervju).toBeChecked();
    await expect(jobbtilbud).toBeChecked();
    await expect(andreVurdering).toHaveValue('KANSKJE');
    await expect(
      page.getByRole('button', { name: 'Tilbake', exact: true }),
    ).toBeDisabled();
  } finally {
    slippLagring();
  }
  await expect(status).toContainText('Lagret');
  await expect(
    page.getByRole('button', { name: 'Tilbake', exact: true }),
  ).toBeEnabled();
  await page.reload();
  await expect(vurdering).toHaveValue('AKTUELL');
  await expect(intervju).toBeChecked();
  await expect(jobbtilbud).toBeChecked();
  await expect(andreVurdering).toHaveValue('KANSKJE');
});

test('viser lagringsfeil bare på berørt rad og lar brukeren prøve igjen', async ({
  page,
}) => {
  await åpneVurdering(page);
  const første = vurderingsrad(page, 'Marius Etternavn01');
  const andre = vurderingsrad(page, 'Emilie Etternavn02');
  const vurdering = første.getByRole('combobox', { name: 'Vurdering' });
  await vurdering.selectOption('AKTUELL');
  await expect(lagringsstatus(page, 'Vurdering og oppfølging')).toContainText(
    'Lagret',
  );
  await page.route('**/oppfolging/vurderinger', (route) =>
    route.fulfill({ status: 500, json: { feil: 'Testfeil' } }),
  );
  await vurdering.selectOption('KANSKJE');
  await expect(første.getByText(/Kunne ikke lagre vurderingen/)).toBeVisible();
  await expect(andre.getByText(/Kunne ikke lagre vurderingen/)).toHaveCount(0);
  await expect(vurdering).toHaveValue('AKTUELL');
  await page.unroute('**/oppfolging/vurderinger');
  await vurdering.selectOption('KANSKJE');
  await expect(lagringsstatus(page, 'Vurdering og oppfølging')).toContainText(
    'Lagret',
  );
  await expect(første.getByText(/Kunne ikke lagre vurderingen/)).toHaveCount(0);
  await page.reload();
  await expect(vurdering).toHaveValue('KANSKJE');
});

test('lar vurderinger lagres selv om formidlinger ikke kan hentes', async ({
  page,
}) => {
  await page.route('**/formidling/liste/alle**', (route) =>
    route.fulfill({ status: 500, json: { feil: 'Testfeil' } }),
  );
  await åpneVurdering(page);
  await expect(
    page.getByText(
      'Fikk ikke hentet «Formidlet» fra Formidlinger. Du kan fortsatt registrere andre statuser.',
    ),
  ).toBeVisible();
  const vurdering = vurderingsrad(page, 'Marius Etternavn01').getByRole(
    'combobox',
    { name: 'Vurdering' },
  );
  await vurdering.selectOption('KANSKJE');
  await expect(lagringsstatus(page, 'Vurdering og oppfølging')).toContainText(
    'Lagret',
  );
  await page.reload();
  await expect(vurdering).toHaveValue('KANSKJE');
});

test('beholder notater fra begge parter uavhengig av vurderingen', async ({
  page,
}) => {
  await åpneVurdering(page);
  const rad = vurderingsrad(page, 'Marius Etternavn01');
  const vurdering = rad.getByRole('combobox', { name: 'Vurdering' });
  await expect(vurdering).toHaveValue('');
  await rad.getByRole('button', { name: /^Notat/ }).click();
  await page.getByRole('checkbox', { name: 'Godt inntrykk' }).check();
  await page.getByRole('checkbox', { name: 'Reisevei' }).check();
  await page.keyboard.press('Escape');
  const arbeidsgiverensNotater = rad.getByRole('group', {
    name: /^Notater fra arbeidsgiveren/,
  });
  const jobbsøkerensNotater = rad.getByRole('group', {
    name: /^Notater fra jobbsøkeren/,
  });
  await expect(arbeidsgiverensNotater).toContainText('Godt inntrykk');
  await expect(arbeidsgiverensNotater).not.toContainText('Reisevei');
  await expect(jobbsøkerensNotater).toContainText('Reisevei');
  await expect(jobbsøkerensNotater).not.toContainText('Godt inntrykk');
  await vurdering.selectOption('AKTUELL');
  await vurdering.selectOption('IKKE_AKTUELL');
  await expect(lagringsstatus(page, 'Vurdering og oppfølging')).toContainText(
    'Lagret',
  );
  await page.reload();
  await expect(vurdering).toHaveValue('IKKE_AKTUELL');
  await expect(arbeidsgiverensNotater).toContainText('Godt inntrykk');
  await expect(jobbsøkerensNotater).toContainText('Reisevei');

  await arbeidsgiverensNotater
    .getByRole('button', { name: /Godt inntrykk/ })
    .click();
  await expect(lagringsstatus(page, 'Vurdering og oppfølging')).toContainText(
    'Lagret',
  );
  await page.reload();
  await expect(arbeidsgiverensNotater).toHaveCount(0);
  await expect(jobbsøkerensNotater).toContainText('Reisevei');
});

test('viser ikke notatet når lagringen feiler', async ({ page }) => {
  await åpneVurdering(page);
  const rad = vurderingsrad(page, 'Marius Etternavn01');
  const status = lagringsstatus(page, 'Vurdering og oppfølging');
  await expect(status).toContainText('Lagret');

  await page.route('**/oppfolging/vurderinger', (route) =>
    route.fulfill({ status: 500, json: { feil: 'Syntetisk skrivefeil' } }),
  );
  await rad.getByRole('button', { name: /^Notat/ }).click();
  const godtInntrykk = page.getByRole('checkbox', {
    name: 'Godt inntrykk',
  });
  await godtInntrykk.check();

  await expect(rad.getByText(/Kunne ikke lagre vurderingen/)).toBeVisible();
  await expect(godtInntrykk).not.toBeChecked();
  await godtInntrykk.focus();
  await page.keyboard.press('Escape');
  await expect(
    page.getByRole('group', { name: 'Arbeidsgiveren sier' }),
  ).toBeHidden();
  await expect(
    rad.getByRole('group', { name: /^Notater fra arbeidsgiveren/ }),
  ).toHaveCount(0);
});

test('støtter tastaturnavigasjon og hurtigklikking i to-kolonners notatvelger', async ({
  page,
}) => {
  await åpneVurdering(page);
  const rad = vurderingsrad(page, 'Marius Etternavn01');
  const notatknapp = rad.getByRole('button', { name: /^Notat/ });
  await notatknapp.click();

  const agGruppe = page.getByRole('group', { name: 'Arbeidsgiveren sier' });
  const jsGruppe = page.getByRole('group', { name: 'Jobbsøkeren sier' });
  await expect(agGruppe).toBeVisible();
  await expect(jsGruppe).toBeVisible();

  // Hurtigklikking på flere notater på rad
  const notat1 = agGruppe.getByRole('checkbox', { name: 'Godt inntrykk' });
  const notat2 = jsGruppe.getByRole('checkbox', { name: 'Vil tenke seg om' });
  const notat3 = jsGruppe.getByRole('checkbox', {
    name: 'Ønsker mer informasjon',
  });
  await notat1.check();
  await notat2.check();
  await notat3.check();
  await expect(notat1).toBeChecked();
  await expect(notat2).toBeChecked();
  await expect(notat3).toBeChecked();

  // Klikk direkte på etikett-teksten skal krysse av og beholde boksen åpen
  const tekstLabel = agGruppe.getByText('Vil invitere til besøk');
  await tekstLabel.click();
  await expect(agGruppe).toBeVisible();
  const notat4 = agGruppe.getByRole('checkbox', {
    name: 'Vil invitere til besøk',
  });
  await expect(notat4).toBeChecked();

  await page.keyboard.press('Escape');
  await expect(lagringsstatus(page, 'Vurdering og oppfølging')).toContainText(
    'Lagret',
  );
  await expect(rad).toContainText('Godt inntrykk');
  await expect(rad).toContainText('Vil tenke seg om');
  await expect(rad).toContainText('Ønsker mer informasjon');
  await expect(rad).toContainText('Vil invitere til besøk');

  // Tastaturnavigasjon: åpne med tastatur og naviger med Tab
  await notatknapp.focus();
  await page.keyboard.press('Enter');
  await expect(agGruppe).toBeVisible();

  // Tab inn til første boks i Arbeidsgiveren sier
  await page.keyboard.press('Tab');
  await expect(notat1).toBeFocused();

  // Tab gjennom resten av arbeidsgivergruppen frem til første boks i Jobbsøkeren sier
  const førsteJsBoks = jsGruppe.getByRole('checkbox', {
    name: 'Positiv til stillingen',
  });
  // Ett Tab-trykk per boks i AG-gruppen: forbi de resterende og inn på første i JS-gruppen
  const antallAgBokser = await agGruppe.getByRole('checkbox').count();
  for (let i = 0; i < antallAgBokser; i++) {
    await page.keyboard.press('Tab');
  }
  await expect(førsteJsBoks).toBeFocused();
  await page.keyboard.press('Space');
  await expect(førsteJsBoks).toBeChecked();

  await page.keyboard.press('Escape');
  await expect(lagringsstatus(page, 'Vurdering og oppfølging')).toContainText(
    'Lagret',
  );
  await expect(rad).toContainText('Positiv til stillingen');
});

test('lagrer valgfri intervjudato og fjerner den sammen med intervjuavtalen', async ({
  page,
}) => {
  await åpneVurdering(page);
  const rad = vurderingsrad(page, 'Marius Etternavn01');
  const intervju = rad.getByRole('checkbox', { name: '2. intervju' });
  const dato = rad.getByRole('textbox', { name: /Dato for 2\. intervju/ });
  const status = lagringsstatus(page, 'Vurdering og oppfølging');
  await expect(dato).toHaveCount(0);
  await intervju.check();
  await expect(dato).toHaveValue('');
  await dato.fill('14.09.2026');
  await dato.blur();
  await expect(status).toContainText('Lagret');
  await page.reload();
  await expect(dato).toHaveValue('14.09.2026');
  await dato.fill('');
  await dato.blur();
  await expect(status).toContainText('Lagret');
  await page.reload();
  await expect(intervju).toBeChecked();
  await expect(dato).toHaveValue('');

  await dato.fill('14.09.2026');
  await dato.blur();
  await expect(status).toContainText('Lagret');
  await intervju.uncheck();
  await expect(status).toContainText('Lagret');
  await expect(dato).toHaveCount(0);
  await intervju.check();
  await expect(dato).toHaveValue('');
});

test('åpner formidlinger filtrert på arbeidsgiveren fra vurderingsraden', async ({
  page,
}) => {
  await åpneVurdering(page);
  await vurderingsrad(page, 'Marius Etternavn01')
    .getByRole('link', { name: 'Vis formidling' })
    .click();
  await expect(page).toHaveURL(
    /visFane=formidlinger.*formidlingArbeidsgivere=TEST-ORG-WORKOP-1/,
  );
  await expect(page.getByRole('tab', { name: /Formidlinger/ })).toHaveAttribute(
    'aria-selected',
    'true',
  );
  await expect(
    page.getByText('Etternavn01, Marius', { exact: true }),
  ).toBeVisible();
  await expect(
    page.getByText('Etternavn02, Emilie', { exact: true }),
  ).toBeVisible();
  await expect(page.getByText('Testetternavn formidling')).toHaveCount(0);
});
