import { gotoApp } from '@/tests/gotoApp';
import { slåPåMørkModus } from '@/tests/mørkModus';
import { snapshotTest } from '@/tests/snapshotTest';
import { tilgjengelighetstest } from '@navikt/toi-next-frontend/a11y';
import { expect, Page, test } from '@playwright/test';

test.use({ storageState: 'tests/.auth/arbeigsgiverrettet.json' });

test.describe('Varseltag for jobbsøkere i rekrutteringstreff', () => {
  test.beforeEach(async ({ page }) => {
    await gotoApp(page, '/rekrutteringstreff/publisert');
    await page.getByRole('tab', { name: /Jobbsøkere/ }).click();
  });

  test('Viser Min side-tooltip når jobbsøker ikke har telefonnummer eller e-post i KRR', async ({
    page,
  }) => {
    const kandidatkort = page
      .locator('li')
      .filter({ hasText: 'Etternavn07, Nina' });
    await expect(kandidatkort).toBeVisible();

    const tag = kandidatkort.getByText('Invitert');
    await tag.hover();

    await expect(
      page.getByText(/ikke registrert e-post eller mobilnummer/),
    ).toBeVisible();
  });

  test('Viser SMS-tooltip for jobbsøker med SMS levert', async ({ page }) => {
    const kandidatkort = page
      .locator('li')
      .filter({ hasText: 'Etternavn04, Håkon' });
    await expect(kandidatkort).toBeVisible();

    const tag = kandidatkort.getByText('Invitert');
    await tag.hover();

    await expect(
      page.getByText(/Jobbsøker invitert via Min Side \/ SMS/),
    ).toBeVisible();
  });

  test('Viser Varsling feilet-tooltip når varsling har feilet uten levering via Min side', async ({
    page,
  }) => {
    const kandidatkort = page
      .locator('li')
      .filter({ hasText: 'Etternavn10, Nora' });
    await expect(kandidatkort).toBeVisible();

    const tag = kandidatkort.getByText('Invitert');
    await tag.hover();

    await expect(
      page.getByText(/Teknisk feil, invitasjon ble ikke sendt/),
    ).toBeVisible();
  });

  test('Viser epost-tooltip for jobbsøker invitert via e-post', async ({
    page,
  }) => {
    const kandidatkort = page
      .locator('li')
      .filter({ hasText: 'Etternavn22, Live' });
    await expect(kandidatkort).toBeVisible();

    const tag = kandidatkort.getByText('Invitert');
    await tag.hover();

    await expect(
      page.getByText(/Jobbsøker invitert via Min Side \/ e-post/),
    ).toBeVisible();
  });
});

test.describe('Republiser-dialog varslings-UI', () => {
  const endreNavnOgÅpneModal = async (page: Page) => {
    const tittelInput = page.getByLabel('Navn på treffet');
    await tittelInput.clear();
    await tittelInput.fill('Nytt navn på treff');
    await page.locator('#tittel-ki-sjekk-knapp').click();
    await page.getByRole('button', { name: 'Bruk likevel' }).first().click();
    await page.getByRole('button', { name: 'Publiser på nytt' }).click();
  };

  test('Viser ikke varslings-UI når ingen jobbsøkere har svart ja', async ({
    page,
  }) => {
    await gotoApp(page, '/rekrutteringstreff/ingen-svart-ja/rediger');
    await endreNavnOgÅpneModal(page);

    await expect(
      page.getByRole('heading', { name: 'Lagre endringer' }),
    ).toBeVisible();

    await expect(
      page.getByText('Du har gjort endringer du kan varsle om'),
    ).not.toBeVisible();

    await expect(
      page.getByText('Velg hva du vil ha med i varslet'),
    ).not.toBeVisible();
  });

  test('Viser "Lagre"-knapp når ingen jobbsøkere har svart ja', async ({
    page,
  }) => {
    await gotoApp(page, '/rekrutteringstreff/ingen-svart-ja/rediger');
    await endreNavnOgÅpneModal(page);

    const modal = page.getByRole('dialog', { name: 'Lagre endringer' });
    await expect(modal).toBeVisible();

    await expect(
      modal.getByRole('button', { name: 'Lagre', exact: true }),
    ).toBeVisible();

    await expect(
      modal.getByRole('button', { name: 'Lagre uten å varsle' }),
    ).not.toBeVisible();

    await expect(
      modal.getByRole('button', { name: 'Lagre og varsle' }),
    ).not.toBeVisible();
  });

  test('Viser "Lagre uten å varsle"-knapp når noen har svart ja men ingen varsling er valgt', async ({
    page,
  }) => {
    await gotoApp(page, '/rekrutteringstreff/publisert/rediger');
    await endreNavnOgÅpneModal(page);

    const modal = page.getByRole('dialog', { name: 'Lagre endringer' });
    await expect(modal).toBeVisible();

    await expect(
      modal.getByRole('button', { name: 'Lagre uten å varsle' }),
    ).toBeVisible();

    await expect(
      modal.getByText('Du har gjort endringer du kan varsle om'),
    ).toBeVisible();

    await expect(
      modal.getByText('Velg hva du vil ha med i varslet'),
    ).toBeVisible();
  });

  test('Viser "Lagre og varsle"-knapp når varsling er aktivert', async ({
    page,
  }) => {
    await gotoApp(page, '/rekrutteringstreff/publisert/rediger');
    await endreNavnOgÅpneModal(page);

    const modal = page.getByRole('dialog', { name: 'Lagre endringer' });
    await expect(modal).toBeVisible();

    const navnSwitch = modal.getByRole('checkbox', {
      name: /Varsle om nytt navn/i,
    });
    await navnSwitch.click();

    await expect(
      modal.getByRole('button', { name: 'Lagre og varsle' }),
    ).toBeVisible();

    await expect(
      modal.getByRole('button', { name: 'Lagre uten å varsle' }),
    ).not.toBeVisible();
  });
});

test.describe('Publiser på nytt – ingen har svart ja', () => {
  test.beforeEach(async ({ page }) => {
    await gotoApp(page, '/rekrutteringstreff/ingen-svart-ja/rediger');
  });

  const endreNavn = async (page: Page) => {
    const tittelInput = page.getByLabel('Navn på treffet');
    await tittelInput.clear();
    await tittelInput.fill('Treff uten ja-svars');
    await page.locator('#tittel-ki-sjekk-knapp').click();
    await page.getByRole('button', { name: 'Bruk likevel' }).first().click();
  };

  test('Viser info-alert om at ingen blir varslet', async ({ page }) => {
    await endreNavn(page);
    await page.getByRole('button', { name: 'Publiser på nytt' }).click();

    const modal = page.getByRole('dialog', { name: 'Lagre endringer' });
    await expect(modal).toBeVisible();

    await expect(
      modal.getByText(
        'Ingen jobbsøkere har svart ja til treffet, så ingen blir varslet om endringene.',
      ),
    ).toBeVisible();
  });

  test('Viser endringer uten varslings-switcher', async ({ page }) => {
    await endreNavn(page);
    await page.getByRole('button', { name: 'Publiser på nytt' }).click();

    const modal = page.getByRole('dialog', { name: 'Lagre endringer' });
    await expect(modal).toBeVisible();

    await expect(modal.getByText('Nytt navn')).toBeVisible();
    await expect(modal.getByText('Før:')).toBeVisible();
    await expect(modal.getByText('Nå:')).toBeVisible();

    await expect(modal.getByRole('switch')).toHaveCount(0);
  });

  test('Skjuler meldingsmal-seksjonen', async ({ page }) => {
    await endreNavn(page);
    await page.getByRole('button', { name: 'Publiser på nytt' }).click();

    const modal = page.getByRole('dialog', { name: 'Lagre endringer' });
    await expect(modal).toBeVisible();

    await expect(modal.getByText('Meldingen')).not.toBeVisible();
    await expect(
      modal.getByText('Velg hva du vil ha med i varslet'),
    ).not.toBeVisible();
  });

  test('Viser kun "Lagre"-knapp', async ({ page }) => {
    await endreNavn(page);
    await page.getByRole('button', { name: 'Publiser på nytt' }).click();

    const modal = page.getByRole('dialog', { name: 'Lagre endringer' });
    await expect(modal).toBeVisible();

    await expect(
      modal.getByRole('button', { name: 'Lagre', exact: true }),
    ).toBeVisible();
    await expect(
      modal.getByRole('button', { name: 'Lagre uten å varsle' }),
    ).not.toBeVisible();
    await expect(
      modal.getByRole('button', { name: 'Lagre og varsle' }),
    ).not.toBeVisible();
  });

  test('Skjuler bell-ikon og varslings-tekst', async ({ page }) => {
    await endreNavn(page);
    await page.getByRole('button', { name: 'Publiser på nytt' }).click();

    const modal = page.getByRole('dialog', { name: 'Lagre endringer' });
    await expect(modal).toBeVisible();

    await expect(
      modal.getByText('Du har gjort endringer du kan varsle om'),
    ).not.toBeVisible();
  });

  snapshotTest(test);
  tilgjengelighetstest(test, { utvidet: true, mørkModus: slåPåMørkModus });
});
