(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_api_2e750764._.js",
  "static/chunks/app_stilling__ui_0a1d844b._.js",
  "static/chunks/app_stilling_[stillingsId]_kandidatliste_2447fa1b._.js",
  "static/chunks/app_stilling_[stillingsId]__ui_f5a1f26a._.js",
  "static/chunks/app_stilling_[stillingsId]_14882a6c._.js",
  "static/chunks/app_stilling_5f8dda08._.js",
  "static/chunks/app_kandidat_8169b9af._.js",
  "static/chunks/app_6d85dcc1._.js",
  "static/chunks/components_0685214a._.js",
  "static/chunks/_7a6f8426._.js",
  "static/chunks/4722a_@navikt_ds-react_esm_form_740b2a03._.js",
  "static/chunks/4722a_@navikt_ds-react_esm_date_25c5823b._.js",
  "static/chunks/4722a_@navikt_ds-react_esm_0bd29425._.js",
  "static/chunks/fd9db_@navikt_aksel-icons_dist_react_esm_d4dd3aae._.js",
  "static/chunks/68e94_next_bc315bc2._.js",
  "static/chunks/88efd_lodash_886159fa._.js",
  "static/chunks/cd136_react-dnd_dist_0d959663._.js",
  "static/chunks/658b9_react-day-picker_dist_esm_72750d5f._.js",
  "static/chunks/34fd2_react-hook-form_dist_index_esm_mjs_628f1414._.js",
  "static/chunks/node_modules__pnpm_847d9ace._.js",
  "static/chunks/b33f8_stilling_[stillingsId]_kandidatliste__ui_SendSMS_SendSmsModal_module_6d8899e4.css"
],
    source: "dynamic"
});
