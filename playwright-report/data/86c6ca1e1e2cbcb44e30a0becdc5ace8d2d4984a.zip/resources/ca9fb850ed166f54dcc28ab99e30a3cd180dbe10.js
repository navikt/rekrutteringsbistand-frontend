(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/checkbox/CheckboxGroup.js [app-client] (ecmascript) <export default as CheckboxGroup>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CheckboxGroup",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$checkbox$2f$CheckboxGroup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$checkbox$2f$CheckboxGroup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/checkbox/CheckboxGroup.js [app-client] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/search/context.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SearchContext",
    ()=>SearchContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
const SearchContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(null); //# sourceMappingURL=context.js.map
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/search/SearchButton.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$MagnifyingGlass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MagnifyingGlassIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/MagnifyingGlass.js [app-client] (ecmascript) <export default as MagnifyingGlassIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$composeEventHandlers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/composeEventHandlers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$i18n$2f$i18n$2e$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/i18n/i18n.hooks.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$search$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/search/context.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
;
;
;
;
const SearchButton = /*#__PURE__*/ _s((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = _s((_a, ref)=>{
    _s();
    var _b;
    var { className, children, disabled, onClick } = _a, rest = __rest(_a, [
        "className",
        "children",
        "disabled",
        "onClick"
    ]);
    const translate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$i18n$2f$i18n$2e$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useI18n"])("Search");
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$search$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SearchContext"]);
    if (context === null) {
        console.warn("<Search.Button> has to be wrapped in <Search />");
        return null;
    }
    const { size, variant, handleClick } = context;
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], Object.assign({
        type: "submit"
    }, rest, {
        ref: ref,
        size: size,
        variant: variant === "secondary" ? "secondary" : "primary",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-search__button-search", className),
        disabled: (_b = context === null || context === void 0 ? void 0 : context.disabled) !== null && _b !== void 0 ? _b : disabled,
        onClick: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$composeEventHandlers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["composeEventHandlers"])(onClick, handleClick),
        icon: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$MagnifyingGlass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MagnifyingGlassIcon$3e$__["MagnifyingGlassIcon"], Object.assign({}, children ? {
            "aria-hidden": true
        } : {
            title: translate("search")
        }))
    }), children);
}, "Uwu249lz6bF2tZppOj+VXgciXZg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$i18n$2f$i18n$2e$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useI18n"]
    ];
})), "Uwu249lz6bF2tZppOj+VXgciXZg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$i18n$2f$i18n$2e$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useI18n"]
    ];
});
_c1 = SearchButton;
const __TURBOPACK__default__export__ = SearchButton;
var _c, _c1;
__turbopack_context__.k.register(_c, "SearchButton$forwardRef");
__turbopack_context__.k.register(_c1, "SearchButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=SearchButton.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/search/Search.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Search",
    ()=>Search,
    "default",
    ()=>__TURBOPACK__default__export__
]);
/* eslint-disable jsx-a11y/no-static-element-interactions */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$MagnifyingGlass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MagnifyingGlassIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/MagnifyingGlass.js [app-client] (ecmascript) <export default as MagnifyingGlassIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$XMark$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XMarkIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/XMark.js [app-client] (ecmascript) <export default as XMarkIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/BodyShort.js [app-client] (ecmascript) <export default as BodyShort>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$ErrorMessage$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ErrorMessage$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/ErrorMessage.js [app-client] (ecmascript) <export default as ErrorMessage>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$Label$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Label$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/Label.js [app-client] (ecmascript) <export default as Label>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$omit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/omit.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useMergeRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/useMergeRefs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$i18n$2f$i18n$2e$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/i18n/i18n.hooks.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$useFormField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/useFormField.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$search$2f$SearchButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/search/SearchButton.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$search$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/search/context.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
;
;
;
;
;
;
;
;
const Search = /*#__PURE__*/ _s((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = _s((props, ref)=>{
    _s();
    const { inputProps, size = "medium", inputDescriptionId, errorId, showErrorMsg, hasError } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$useFormField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFormField"])(props, "searchfield");
    const { className, hideLabel = true, label, description, value, clearButtonLabel, onClear, clearButton = true, children, variant = "primary", defaultValue, onChange, onSearchClick, htmlSize, "data-color": dataColor } = props, rest = __rest(props, [
        "className",
        "hideLabel",
        "label",
        "description",
        "value",
        "clearButtonLabel",
        "onClear",
        "clearButton",
        "children",
        "variant",
        "defaultValue",
        "onChange",
        "onSearchClick",
        "htmlSize",
        "data-color"
    ]);
    const searchRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const mergedRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useMergeRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMergeRefs"])(searchRef, ref);
    const [internalValue, setInternalValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(defaultValue !== null && defaultValue !== void 0 ? defaultValue : "");
    const handleChange = (newValue)=>{
        value === undefined && setInternalValue(newValue);
        onChange === null || onChange === void 0 ? void 0 : onChange(newValue);
    };
    const handleClear = (clearEvent)=>{
        var _a, _b;
        onClear === null || onClear === void 0 ? void 0 : onClear(clearEvent);
        handleChange("");
        (_b = (_a = searchRef.current) === null || _a === void 0 ? void 0 : _a.focus) === null || _b === void 0 ? void 0 : _b.call(_a);
    };
    const handleClick = ()=>{
        onSearchClick === null || onSearchClick === void 0 ? void 0 : onSearchClick(`${value !== null && value !== void 0 ? value : internalValue}`);
    };
    const showClearButton = clearButton && !inputProps.disabled && (value !== null && value !== void 0 ? value : internalValue);
    return(// biome-ignore lint/a11y/noStaticElementInteractions: Escape key handler for clearing input
    /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", {
        onKeyDown: (event)=>{
            var _a;
            if (event.key !== "Escape") {
                return;
            }
            ((_a = searchRef.current) === null || _a === void 0 ? void 0 : _a.value) && event.preventDefault();
            handleClear({
                trigger: "Escape",
                event
            });
        },
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])(className, "aksel-form-field", `aksel-form-field--${size}`, "aksel-search", {
            "aksel-search--error": hasError,
            "aksel-search--disabled": inputProps.disabled,
            "aksel-search--with-size": htmlSize
        }),
        "data-color": dataColor
    }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$Label$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Label$3e$__["Label"], {
        htmlFor: inputProps.id,
        size: size,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-form-field__label", {
            "aksel-sr-only": hideLabel
        })
    }, label), !!description && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__["BodyShort"], {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-form-field__description", {
            "aksel-sr-only": hideLabel
        }),
        id: inputDescriptionId,
        size: size,
        as: "div"
    }, description), /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", {
        className: "aksel-search__wrapper"
    }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", {
        className: "aksel-search__wrapper-inner"
    }, variant === "simple" && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$MagnifyingGlass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MagnifyingGlassIcon$3e$__["MagnifyingGlassIcon"], {
        "aria-hidden": true,
        className: "aksel-search__search-icon"
    }), /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("input", Object.assign({
        ref: mergedRef
    }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$omit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["omit"])(rest, [
        "error",
        "errorId",
        "size",
        "readOnly"
    ]), inputProps, {
        value: value !== null && value !== void 0 ? value : internalValue,
        onChange: (e)=>handleChange(e.target.value),
        type: "search",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])(className, "aksel-search__input", `aksel-search__input--${variant}`, "aksel-text-field__input", "aksel-body-short", `aksel-body-short--${size}`)
    }, htmlSize ? {
        size: Number(htmlSize)
    } : {})), showClearButton && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(ClearButton, {
        handleClear: handleClear,
        size: size,
        clearButtonLabel: clearButtonLabel
    })), /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$search$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SearchContext"].Provider, {
        value: {
            size,
            disabled: inputProps.disabled,
            variant,
            handleClick
        }
    }, children ? children : variant !== "simple" && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$search$2f$SearchButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        "data-color": dataColor
    }))), /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", {
        className: "aksel-form-field__error",
        id: errorId,
        "aria-relevant": "additions removals",
        "aria-live": "polite"
    }, showErrorMsg && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$ErrorMessage$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ErrorMessage$3e$__["ErrorMessage"], {
        size: size,
        showIcon: true
    }, props.error))));
}, "qTuCQFdeHXLy3CsIkh0M5K1OXos=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$useFormField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFormField"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useMergeRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMergeRefs"]
    ];
})), "qTuCQFdeHXLy3CsIkh0M5K1OXos=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$useFormField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFormField"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useMergeRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMergeRefs"]
    ];
});
_c1 = Search;
function ClearButton({ size, clearButtonLabel, handleClear }) {
    _s1();
    const translate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$i18n$2f$i18n$2e$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useI18n"])("Search");
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
        className: "aksel-search__button-clear",
        variant: "tertiary",
        "data-color": "neutral",
        size: size === "medium" ? "small" : "xsmall",
        icon: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$XMark$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XMarkIcon$3e$__["XMarkIcon"], {
            "aria-hidden": true
        }),
        title: clearButtonLabel || translate("clear"),
        onClick: (event)=>handleClear({
                trigger: "Click",
                event
            }),
        type: "button"
    });
}
_s1(ClearButton, "KV87nYrn2zW6QxQP1Zrr/rEPoM0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$i18n$2f$i18n$2e$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useI18n"]
    ];
});
_c2 = ClearButton;
Search.Button = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$search$2f$SearchButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
const __TURBOPACK__default__export__ = Search;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "Search$forwardRef");
__turbopack_context__.k.register(_c1, "Search");
__turbopack_context__.k.register(_c2, "ClearButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=Search.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/search/Search.js [app-client] (ecmascript) <export default as Search>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Search",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$search$2f$Search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$search$2f$Search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/search/Search.js [app-client] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/radio/RadioGroup.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RadioGroup",
    ()=>RadioGroup,
    "RadioGroupContext",
    ()=>RadioGroupContext,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/useId.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$fieldset$2f$Fieldset$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Fieldset$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/fieldset/Fieldset.js [app-client] (ecmascript) <export default as Fieldset>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$fieldset$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/fieldset/context.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
;
;
const RadioGroupContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createContext(null);
const RadioGroup = /*#__PURE__*/ _s((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = _s((_a, ref)=>{
    _s();
    var _b, _c;
    var { children, className, name, defaultValue, value, onChange = ()=>{}, required, readOnly } = _a, rest = __rest(_a, [
        "children",
        "className",
        "name",
        "defaultValue",
        "value",
        "onChange",
        "required",
        "readOnly"
    ]);
    const fieldset = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$fieldset$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FieldsetContext"]);
    const nameId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])();
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$fieldset$2f$Fieldset$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Fieldset$3e$__["Fieldset"], Object.assign({}, rest, {
        readOnly: readOnly,
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])(className, "aksel-radio-group", `aksel-radio-group--${(_c = (_b = rest.size) !== null && _b !== void 0 ? _b : fieldset === null || fieldset === void 0 ? void 0 : fieldset.size) !== null && _c !== void 0 ? _c : "medium"}`),
        nativeReadOnly: false
    }), /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(RadioGroupContext.Provider, {
        value: {
            name: name !== null && name !== void 0 ? name : `radioGroupName-${nameId}`,
            defaultValue,
            value,
            onChange,
            required
        }
    }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", {
        className: "aksel-radio-buttons"
    }, children)));
}, "OFkFASklW0Q2eaLWoLAFznyXzJQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"]
    ];
})), "OFkFASklW0Q2eaLWoLAFznyXzJQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"]
    ];
});
_c1 = RadioGroup;
const __TURBOPACK__default__export__ = RadioGroup;
var _c, _c1;
__turbopack_context__.k.register(_c, "RadioGroup$forwardRef");
__turbopack_context__.k.register(_c1, "RadioGroup");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=RadioGroup.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/radio/useRadio.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useRadio",
    ()=>useRadio
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$omit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/omit.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$useFormField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/useFormField.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$radio$2f$RadioGroup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/radio/RadioGroup.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
;
const useRadio = (props)=>{
    _s();
    const radioGroup = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$radio$2f$RadioGroup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RadioGroupContext"]);
    const _a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$useFormField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFormField"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$omit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["omit"])(props, [
        "description"
    ]), "radio"), { inputProps, readOnly } = _a, rest = __rest(_a, [
        "inputProps",
        "readOnly"
    ]);
    if (!radioGroup) {
        console.warn("<Radio> must be used inside <RadioGroup>.");
    }
    if ((props === null || props === void 0 ? void 0 : props.required) !== undefined) {
        console.warn("required is only supported on <RadioGroup>.");
    }
    return Object.assign(Object.assign({}, rest), {
        readOnly,
        inputProps: Object.assign(Object.assign({}, inputProps), {
            name: radioGroup === null || radioGroup === void 0 ? void 0 : radioGroup.name,
            defaultChecked: (radioGroup === null || radioGroup === void 0 ? void 0 : radioGroup.defaultValue) === undefined ? undefined : (radioGroup === null || radioGroup === void 0 ? void 0 : radioGroup.defaultValue) === props.value,
            checked: (radioGroup === null || radioGroup === void 0 ? void 0 : radioGroup.value) === undefined ? undefined : (radioGroup === null || radioGroup === void 0 ? void 0 : radioGroup.value) === props.value,
            onChange: (event)=>{
                var _a, _b;
                if (readOnly) {
                    return;
                }
                (_a = props.onChange) === null || _a === void 0 ? void 0 : _a.call(props, event);
                (_b = radioGroup === null || radioGroup === void 0 ? void 0 : radioGroup.onChange) === null || _b === void 0 ? void 0 : _b.call(radioGroup, props.value);
            },
            onClick: (event)=>{
                var _a;
                if (readOnly) {
                    event.preventDefault();
                    return;
                }
                (_a = props === null || props === void 0 ? void 0 : props.onClick) === null || _a === void 0 ? void 0 : _a.call(props, event);
            },
            required: radioGroup === null || radioGroup === void 0 ? void 0 : radioGroup.required,
            type: "radio"
        })
    });
}; //# sourceMappingURL=useRadio.js.map
_s(useRadio, "fgf0CoByU+fDT1N+6vzKfNT/pxo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$useFormField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFormField"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$useFormField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFormField"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$useFormField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFormField"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/radio/Radio.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Radio",
    ()=>Radio,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/BodyShort.js [app-client] (ecmascript) <export default as BodyShort>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$omit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/omit.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/useId.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$radio$2f$useRadio$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/radio/useRadio.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
const Radio = /*#__PURE__*/ _s((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = _s((props, ref)=>{
    _s();
    const { inputProps, size, hasError, readOnly } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$radio$2f$useRadio$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRadio"])(props);
    const descriptionId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])();
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])(props.className, "aksel-radio", `aksel-radio--${size}`, {
            "aksel-radio--error": hasError,
            "aksel-radio--disabled": inputProps.disabled,
            "aksel-radio--readonly": readOnly
        }),
        "data-color": hasError ? "danger" : props["data-color"]
    }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("input", Object.assign({}, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$omit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["omit"])(props, [
        "children",
        "size",
        "description",
        "readOnly"
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$omit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["omit"])(inputProps, [
        "aria-invalid",
        "aria-describedby"
    ]), {
        "aria-describedby": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])(inputProps["aria-describedby"], {
            [descriptionId]: props.description
        }) || undefined,
        className: "aksel-radio__input",
        ref: ref
    })), /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__["BodyShort"], {
        as: "label",
        htmlFor: inputProps.id,
        className: "aksel-radio__label",
        size: size
    }, props.children), props.description && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__["BodyShort"], {
        id: descriptionId,
        size: size,
        className: "aksel-form-field__subdescription aksel-radio__description"
    }, props.description));
}, "PDAvXNSs8/+WaknL00h1AI6uvfo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$radio$2f$useRadio$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRadio"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"]
    ];
})), "PDAvXNSs8/+WaknL00h1AI6uvfo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$radio$2f$useRadio$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRadio"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"]
    ];
});
_c1 = Radio;
const __TURBOPACK__default__export__ = Radio;
var _c, _c1;
__turbopack_context__.k.register(_c, "Radio$forwardRef");
__turbopack_context__.k.register(_c1, "Radio");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=Radio.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/radio/Radio.js [app-client] (ecmascript) <export default as Radio>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Radio",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$radio$2f$Radio$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$radio$2f$Radio$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/radio/Radio.js [app-client] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/radio/RadioGroup.js [app-client] (ecmascript) <export default as RadioGroup>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RadioGroup",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$radio$2f$RadioGroup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$radio$2f$RadioGroup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/radio/RadioGroup.js [app-client] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/textfield/TextField.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TextField",
    ()=>TextField,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/BodyShort.js [app-client] (ecmascript) <export default as BodyShort>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$ErrorMessage$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ErrorMessage$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/ErrorMessage.js [app-client] (ecmascript) <export default as ErrorMessage>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$Label$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Label$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/Label.js [app-client] (ecmascript) <export default as Label>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$omit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/omit.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$ReadOnlyIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/ReadOnlyIcon.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$useFormField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/useFormField.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
;
;
;
const TextField = /*#__PURE__*/ _s((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = _s((props, ref)=>{
    _s();
    const { inputProps, errorId, showErrorMsg, hasError, size, inputDescriptionId } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$useFormField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFormField"])(props, "textField");
    const { label, className, description, htmlSize, hideLabel = false, type = "text", readOnly } = props, rest = __rest(props, [
        "label",
        "className",
        "description",
        "htmlSize",
        "hideLabel",
        "type",
        "readOnly"
    ]);
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])(className, "aksel-form-field", `aksel-form-field--${size}`, {
            "aksel-text-field--error": hasError,
            "aksel-text-field--disabled": !!inputProps.disabled,
            "aksel-form-field--disabled": !!inputProps.disabled,
            "aksel-form-field--readonly": readOnly,
            "aksel-text-field--readonly": readOnly
        })
    }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$Label$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Label$3e$__["Label"], {
        htmlFor: inputProps.id,
        size: size,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-form-field__label", {
            "aksel-sr-only": hideLabel
        })
    }, readOnly && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$ReadOnlyIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ReadOnlyIcon"], null), label), !!description && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__["BodyShort"], {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-form-field__description", {
            "aksel-sr-only": hideLabel
        }),
        id: inputDescriptionId,
        size: size,
        as: "div"
    }, description), /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("input", Object.assign({}, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$omit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["omit"])(rest, [
        "error",
        "errorId",
        "size"
    ]), inputProps, {
        ref: ref,
        type: type,
        readOnly: readOnly,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-text-field__input", "aksel-body-short", `aksel-body-short--${size !== null && size !== void 0 ? size : "medium"}`),
        size: htmlSize
    })), /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", {
        className: "aksel-form-field__error",
        id: errorId,
        "aria-relevant": "additions removals",
        "aria-live": "polite"
    }, showErrorMsg && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$ErrorMessage$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ErrorMessage$3e$__["ErrorMessage"], {
        size: size,
        showIcon: true
    }, props.error)));
}, "0jVe0CjTiHdjI/djO+LPFpWNtpc=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$useFormField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFormField"]
    ];
})), "0jVe0CjTiHdjI/djO+LPFpWNtpc=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$useFormField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFormField"]
    ];
});
_c1 = TextField;
const __TURBOPACK__default__export__ = TextField;
var _c, _c1;
__turbopack_context__.k.register(_c, "TextField$forwardRef");
__turbopack_context__.k.register(_c1, "TextField");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=TextField.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/textfield/TextField.js [app-client] (ecmascript) <export default as TextField>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TextField",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$textfield$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$textfield$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/textfield/TextField.js [app-client] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/switch/Switch.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Switch",
    ()=>Switch,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$loader$2f$Loader$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/loader/Loader.js [app-client] (ecmascript) <export default as Loader>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/BodyShort.js [app-client] (ecmascript) <export default as BodyShort>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$omit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/omit.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$ReadOnlyIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/ReadOnlyIcon.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$useFormField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/useFormField.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
;
;
;
;
const Switch = /*#__PURE__*/ _s((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = _s((props, ref)=>{
    _s();
    var _a, _b, _c;
    const { inputProps, size, readOnly } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$useFormField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFormField"])(props, "switch");
    const { children, className, description, hideLabel = false, loading, checked: checkedProp, defaultChecked, position = "left" } = props, rest = __rest(props, [
        "children",
        "className",
        "description",
        "hideLabel",
        "loading",
        "checked",
        "defaultChecked",
        "position"
    ]);
    const [_checked, setChecked] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])((_a = defaultChecked !== null && defaultChecked !== void 0 ? defaultChecked : checkedProp) !== null && _a !== void 0 ? _a : false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Switch.useEffect": ()=>{
            checkedProp !== undefined && setChecked(checkedProp);
        }
    }["Switch.useEffect"], [
        checkedProp
    ]);
    const checked = checkedProp !== null && checkedProp !== void 0 ? checkedProp : _checked;
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-switch", props.className, `aksel-switch--${size}`, `aksel-switch--${position}`, {
            "aksel-switch--loading": loading,
            "aksel-switch--disabled": (_b = inputProps.disabled) !== null && _b !== void 0 ? _b : loading,
            "aksel-switch--readonly": readOnly,
            "aksel-switch--standalone": hideLabel
        })
    }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("input", Object.assign({}, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$omit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["omit"])(rest, [
        "size",
        "readOnly"
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$omit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["omit"])(inputProps, [
        "aria-invalid",
        "aria-describedby"
    ]), {
        disabled: (_c = inputProps.disabled) !== null && _c !== void 0 ? _c : loading,
        checked: checkedProp,
        defaultChecked: defaultChecked,
        ref: ref,
        type: "checkbox",
        onChange: (event)=>{
            var _a;
            if (readOnly) {
                return;
            }
            setChecked(event.target.checked);
            (_a = props.onChange) === null || _a === void 0 ? void 0 : _a.call(props, event);
        },
        onClick: (event)=>{
            var _a;
            if (readOnly) {
                event.preventDefault();
                return;
            }
            (_a = props.onClick) === null || _a === void 0 ? void 0 : _a.call(props, event);
        },
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])(className, "aksel-switch__input")
    })), /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("span", {
        className: "aksel-switch__track"
    }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("span", {
        className: "aksel-switch__thumb"
    }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(SwitchIcon, {
        size: size,
        checked: checked,
        loading: loading
    }))), /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("label", {
        htmlFor: inputProps.id,
        className: "aksel-switch__label-wrapper"
    }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("span", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-switch__content", {
            "aksel-sr-only": hideLabel,
            "aksel-switch--with-description": description && !hideLabel
        })
    }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__["BodyShort"], {
        as: "span",
        size: size,
        className: "aksel-switch__label"
    }, readOnly && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$ReadOnlyIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ReadOnlyIconWithTitle"], null), children), description && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__["BodyShort"], {
        size: size,
        as: "span",
        className: "aksel-form-field__subdescription aksel-switch__description"
    }, description))));
}, "ONeOdSuUpQ0BM/kcMskZxDjo2TU=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$useFormField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFormField"]
    ];
})), "ONeOdSuUpQ0BM/kcMskZxDjo2TU=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$useFormField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFormField"]
    ];
});
_c1 = Switch;
const SwitchIcon = ({ size, checked, loading })=>{
    if (loading) {
        let baseSize = 16;
        if (size === "small") {
            baseSize = 12;
        }
        if (checked) {
            baseSize += 2;
        }
        return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$loader$2f$Loader$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader$3e$__["Loader"], {
            size: "small",
            "aria-live": "polite",
            variant: checked ? "interaction" : "inverted",
            width: `${baseSize / 16}rem`,
            height: `${baseSize / 16}rem`
        });
    }
    if (!checked) {
        return null;
    }
    if (size === "small") {
        return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("svg", {
            width: "11",
            height: "8",
            viewBox: "0 0 11 8",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            focusable: false,
            role: "img",
            "aria-hidden": true
        }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("path", {
            fillRule: "evenodd",
            clipRule: "evenodd",
            d: "M9.62013 0.530226C10.1194 0.952686 10.1817 1.6999 9.7592 2.19917L5.4171 7.33075C5.20318 7.58356 4.89318 7.73525 4.5623 7.74901C4.23142 7.76277 3.90989 7.63735 3.67572 7.40318L1.3073 5.03476C0.844833 4.5723 0.844833 3.8225 1.3073 3.36003C1.76976 2.89757 2.51956 2.89757 2.98202 3.36003L4.4404 4.81841L7.95118 0.669304C8.37364 0.170033 9.12085 0.107765 9.62013 0.530226Z",
            fill: "currentColor"
        }));
    }
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("svg", {
        width: "12",
        height: "10",
        viewBox: "0 0 12 10",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        focusable: false,
        role: "img",
        "aria-hidden": true
    }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("path", {
        fillRule: "evenodd",
        clipRule: "evenodd",
        d: "M11.2674 0.647802C11.8762 1.20971 11.9141 2.1587 11.3522 2.76743L5.35221 9.26743C5.07531 9.56739 4.68813 9.74155 4.27998 9.74971C3.87184 9.75787 3.478 9.59933 3.18934 9.31067L0.68934 6.81067C0.103553 6.22488 0.103553 5.27513 0.68934 4.68935C1.27513 4.10356 2.22487 4.10356 2.81066 4.68935L4.20673 6.08541L9.14779 0.732587C9.7097 0.123856 10.6587 0.0858967 11.2674 0.647802Z",
        fill: "currentColor"
    }));
};
_c2 = SwitchIcon;
const __TURBOPACK__default__export__ = Switch;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "Switch$forwardRef");
__turbopack_context__.k.register(_c1, "Switch");
__turbopack_context__.k.register(_c2, "SwitchIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=Switch.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/switch/Switch.js [app-client] (ecmascript) <export default as Switch>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Switch",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$switch$2f$Switch$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$switch$2f$Switch$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/switch/Switch.js [app-client] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/Input/Input.context.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "InputContextProvider",
    ()=>InputProvider,
    "useInputContext",
    ()=>useInputContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$create$2d$strict$2d$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/create-strict-context.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useClientLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/useClientLayoutEffect.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$useFormField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/useFormField.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
;
const { Provider: InputContextProvider, useContext: useInputContext } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$create$2d$strict$2d$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createStrictContext"])({
    name: "InputContext",
    errorMessage: "useInputContext must be used within an InputContextProvider"
});
const InputProvider = ({ children, value: props })=>{
    _s();
    const { defaultValue = "", description, disabled, readOnly, error, errorId, id: externalId, value: externalValue, onChange: externalOnChange, onClear, shouldAutocomplete, size } = props;
    const formFieldProps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$useFormField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFormField"])({
        description,
        disabled,
        readOnly,
        error,
        errorId,
        id: externalId,
        size
    }, "comboboxfield");
    const inputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const toggleOpenButtonRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [internalValue, setInternalValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(defaultValue);
    const [hideCaret, setHideCaret] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [anchorRef, setAnchorRef] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "InputProvider.useMemo[value]": ()=>String(externalValue !== null && externalValue !== void 0 ? externalValue : internalValue)
    }["InputProvider.useMemo[value]"], [
        externalValue,
        internalValue
    ]);
    const [searchTerm, setSearchTerm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(value);
    const onChange = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "InputProvider.useCallback[onChange]": (newValue)=>{
            externalValue !== null && externalValue !== void 0 ? externalValue : setInternalValue(newValue);
            setSearchTerm(newValue);
            externalOnChange === null || externalOnChange === void 0 ? void 0 : externalOnChange(newValue);
        }
    }["InputProvider.useCallback[onChange]"], [
        externalValue,
        externalOnChange
    ]);
    const clearInput = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "InputProvider.useCallback[clearInput]": (event)=>{
            onClear === null || onClear === void 0 ? void 0 : onClear(event);
            externalOnChange === null || externalOnChange === void 0 ? void 0 : externalOnChange("");
            setInternalValue("");
            setSearchTerm("");
        }
    }["InputProvider.useCallback[clearInput]"], [
        externalOnChange,
        onClear
    ]);
    const focusInput = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "InputProvider.useCallback[focusInput]": ()=>{
            var _a, _b;
            (_b = (_a = inputRef.current) === null || _a === void 0 ? void 0 : _a.focus) === null || _b === void 0 ? void 0 : _b.call(_a);
        }
    }["InputProvider.useCallback[focusInput]"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useClientLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useClientLayoutEffect"])({
        "InputProvider.useClientLayoutEffect": ()=>{
            var _a, _b;
            if (shouldAutocomplete && inputRef && value !== searchTerm) {
                (_b = (_a = inputRef.current) === null || _a === void 0 ? void 0 : _a.setSelectionRange) === null || _b === void 0 ? void 0 : _b.call(_a, searchTerm.length, value.length);
            }
        }
    }["InputProvider.useClientLayoutEffect"], [
        value,
        searchTerm,
        shouldAutocomplete
    ]);
    const contextValue = Object.assign(Object.assign({}, formFieldProps), {
        clearInput,
        error,
        focusInput,
        inputRef,
        value,
        setValue: setInternalValue,
        onChange,
        searchTerm,
        setSearchTerm,
        shouldAutocomplete,
        toggleOpenButtonRef,
        hideCaret,
        setHideCaret,
        anchorRef,
        setAnchorRef
    });
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(InputContextProvider, Object.assign({}, contextValue), children);
};
_s(InputProvider, "rpTY7Cu81rcTAT/DYFBnRyQXKzg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$useFormField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFormField"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useClientLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useClientLayoutEffect"]
    ];
});
_c = InputProvider;
;
var _c;
__turbopack_context__.k.register(_c, "InputProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=Input.context.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/ComboboxWrapper.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/Input/Input.context.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
const ComboboxWrapper = ({ children, className, hasError, inputProps, inputSize })=>{
    _s();
    const { toggleOpenButtonRef, clearInput, readOnly } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInputContext"])();
    const wrapperRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [hasFocusWithin, setHasFocusWithin] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    function onFocusInsideWrapper(event) {
        var _a;
        if (!((_a = wrapperRef.current) === null || _a === void 0 ? void 0 : _a.contains(event.relatedTarget)) && (toggleOpenButtonRef === null || toggleOpenButtonRef === void 0 ? void 0 : toggleOpenButtonRef.current) !== event.target) {
            setHasFocusWithin(true);
        }
    }
    function onBlurWrapper(event) {
        var _a;
        if (!((_a = wrapperRef.current) === null || _a === void 0 ? void 0 : _a.contains(event.relatedTarget))) {
            setHasFocusWithin(false);
            clearInput(event);
        }
    }
    return(// biome-ignore lint/a11y/noStaticElementInteractions: Wrapper for combobox input and chips.
    /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", {
        ref: wrapperRef,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])(className, "aksel-form-field", `aksel-form-field--${inputSize}`, {
            "aksel-combobox--error": hasError,
            "aksel-combobox--disabled": !!inputProps.disabled,
            "aksel-combobox--focused": hasFocusWithin,
            "aksel-combobox--readonly": readOnly,
            "aksel-form-field--readonly": readOnly
        }),
        onFocus: onFocusInsideWrapper,
        onBlur: onBlurWrapper
    }, children));
};
_s(ComboboxWrapper, "YZSLUXRUatELdR09dxB5wRhHwbM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInputContext"]
    ];
});
_c = ComboboxWrapper;
const __TURBOPACK__default__export__ = ComboboxWrapper;
var _c;
__turbopack_context__.k.register(_c, "ComboboxWrapper");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=ComboboxWrapper.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/combobox-utils.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isInList",
    ()=>isInList,
    "mapToComboboxOptionArray",
    ()=>mapToComboboxOptionArray,
    "toComboboxOption",
    ()=>toComboboxOption
]);
/**
 *
 * @param option ComboboxOption will be compared by both label and value, while a string option is checked if it matches either the label or value in the list.
 * @param list
 */ const isInList = (option, list)=>{
    if (typeof option === "string") {
        return list.some((listItem)=>listItem.label === option || listItem.value === option);
    }
    return list.some((listItem)=>listItem.label === option.label && listItem.value === option.value);
};
const toComboboxOption = (value)=>({
        label: value,
        value
    });
const mapToComboboxOptionArray = (options)=>{
    return options === null || options === void 0 ? void 0 : options.map((option)=>typeof option === "string" ? toComboboxOption(option) : option);
};
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=combobox-utils.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/customOptionsContext.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CustomOptionsProvider",
    ()=>CustomOptionsProvider,
    "useComboboxCustomOptions",
    ()=>useComboboxCustomOptions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$create$2d$strict$2d$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/create-strict-context.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/Input/Input.context.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
const { Provider: ComboboxCustomOptionsProvider, useContext: useComboboxCustomOptions } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$create$2d$strict$2d$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createStrictContext"])({
    name: "ComboboxCustomOptions",
    errorMessage: "useComboboxCustomOptions must be used within a ComboboxCustomOptionsProvider"
});
const CustomOptionsProvider = ({ children, value })=>{
    _s();
    const [customOptions, setCustomOptions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const { focusInput } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInputContext"])();
    const { isMultiSelect } = value;
    const removeCustomOption = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CustomOptionsProvider.useCallback[removeCustomOption]": (option)=>{
            setCustomOptions({
                "CustomOptionsProvider.useCallback[removeCustomOption]": (prevCustomOptions)=>prevCustomOptions.filter({
                        "CustomOptionsProvider.useCallback[removeCustomOption]": (o)=>o.label !== option.label
                    }["CustomOptionsProvider.useCallback[removeCustomOption]"])
            }["CustomOptionsProvider.useCallback[removeCustomOption]"]);
            focusInput();
        }
    }["CustomOptionsProvider.useCallback[removeCustomOption]"], [
        focusInput
    ]);
    const addCustomOption = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CustomOptionsProvider.useCallback[addCustomOption]": (option)=>{
            if (isMultiSelect) {
                setCustomOptions({
                    "CustomOptionsProvider.useCallback[addCustomOption]": (prevOptions)=>[
                            ...prevOptions,
                            option
                        ]
                }["CustomOptionsProvider.useCallback[addCustomOption]"]);
            } else {
                setCustomOptions([
                    option
                ]);
            }
            focusInput();
        }
    }["CustomOptionsProvider.useCallback[addCustomOption]"], [
        focusInput,
        isMultiSelect
    ]);
    const customOptionsState = {
        customOptions,
        removeCustomOption,
        addCustomOption,
        setCustomOptions
    };
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(ComboboxCustomOptionsProvider, Object.assign({}, customOptionsState), children);
};
_s(CustomOptionsProvider, "qvHoMoi5ugX71ZyHyYBUEJfiY4A=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInputContext"]
    ];
});
_c = CustomOptionsProvider;
;
var _c;
__turbopack_context__.k.register(_c, "CustomOptionsProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=customOptionsContext.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/SelectedOptions/selectedOptionsContext.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SelectedOptionsProvider",
    ()=>SelectedOptionsProvider,
    "useSelectedOptionsContext",
    ()=>useSelectedOptionsContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$create$2d$strict$2d$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/create-strict-context.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$usePrevious$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/usePrevious.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/Input/Input.context.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$combobox$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/combobox-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$customOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/customOptionsContext.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
const { Provider: SelectedOptionsContextProvider, useContext: useSelectedOptionsContext } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$create$2d$strict$2d$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createStrictContext"])({
    name: "SelectedOptionsContext"
});
const SelectedOptionsProvider = ({ children, value })=>{
    _s();
    const { clearInput, focusInput, setHideCaret } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInputContext"])();
    const { customOptions, removeCustomOption, addCustomOption, setCustomOptions } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$customOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useComboboxCustomOptions"])();
    const { allowNewValues, isMultiSelect, selectedOptions: externalSelectedOptions, onToggleSelected, options, maxSelected } = value;
    const [internalSelectedOptions, setSelectedOptions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const selectedOptions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "SelectedOptionsProvider.useMemo[selectedOptions]": ()=>externalSelectedOptions !== null && externalSelectedOptions !== void 0 ? externalSelectedOptions : [
                ...customOptions,
                ...internalSelectedOptions
            ]
    }["SelectedOptionsProvider.useMemo[selectedOptions]"], [
        customOptions,
        externalSelectedOptions,
        internalSelectedOptions
    ]);
    const addSelectedOption = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "SelectedOptionsProvider.useCallback[addSelectedOption]": (option)=>{
            const isCustomOption = !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$combobox$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isInList"])(option, options);
            if (isCustomOption) {
                allowNewValues && addCustomOption(option);
                !isMultiSelect && setSelectedOptions([]);
            } else if (isMultiSelect) {
                setSelectedOptions({
                    "SelectedOptionsProvider.useCallback[addSelectedOption]": (oldSelectedOptions)=>[
                            ...oldSelectedOptions,
                            option
                        ]
                }["SelectedOptionsProvider.useCallback[addSelectedOption]"]);
            } else {
                setSelectedOptions([
                    option
                ]);
                setCustomOptions([]);
            }
            onToggleSelected === null || onToggleSelected === void 0 ? void 0 : onToggleSelected(option.value, true, isCustomOption);
        }
    }["SelectedOptionsProvider.useCallback[addSelectedOption]"], [
        addCustomOption,
        allowNewValues,
        isMultiSelect,
        onToggleSelected,
        options,
        setCustomOptions
    ]);
    const removeSelectedOption = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "SelectedOptionsProvider.useCallback[removeSelectedOption]": (option)=>{
            const isCustomOption = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$combobox$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isInList"])(option, customOptions);
            if (isCustomOption) {
                removeCustomOption(option);
            } else {
                setSelectedOptions({
                    "SelectedOptionsProvider.useCallback[removeSelectedOption]": (oldSelectedOptions)=>oldSelectedOptions.filter({
                            "SelectedOptionsProvider.useCallback[removeSelectedOption]": (selectedOption)=>selectedOption !== option
                        }["SelectedOptionsProvider.useCallback[removeSelectedOption]"])
                }["SelectedOptionsProvider.useCallback[removeSelectedOption]"]);
            }
            onToggleSelected === null || onToggleSelected === void 0 ? void 0 : onToggleSelected(option.value, false, isCustomOption);
        }
    }["SelectedOptionsProvider.useCallback[removeSelectedOption]"], [
        customOptions,
        onToggleSelected,
        removeCustomOption
    ]);
    const maxSelectedLimit = typeof maxSelected === "object" ? maxSelected.limit : maxSelected;
    const isLimitReached = !!maxSelectedLimit && selectedOptions.length >= maxSelectedLimit;
    const newHideCaret = isLimitReached || !isMultiSelect && selectedOptions.length > 0;
    // biome-ignore lint/correctness/useExhaustiveDependencies: We explicitly want to run this effect when selectedOptions changes to match the view with the selected options.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SelectedOptionsProvider.useEffect": ()=>{
            setHideCaret(newHideCaret);
        }
    }["SelectedOptionsProvider.useEffect"], [
        newHideCaret,
        selectedOptions,
        setHideCaret
    ]);
    const toggleOption = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "SelectedOptionsProvider.useCallback[toggleOption]": (option, event)=>{
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$combobox$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isInList"])(option.value, selectedOptions)) {
                removeSelectedOption(option);
            } else if (isMultiSelect && isLimitReached) {
                return;
            } else {
                addSelectedOption(option);
            }
            clearInput(event);
            focusInput();
        }
    }["SelectedOptionsProvider.useCallback[toggleOption]"], [
        addSelectedOption,
        clearInput,
        focusInput,
        removeSelectedOption,
        selectedOptions,
        isLimitReached,
        isMultiSelect
    ]);
    const prevSelectedOptions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$usePrevious$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePrevious"])(selectedOptions);
    const selectedOptionsState = {
        addSelectedOption,
        isMultiSelect,
        removeSelectedOption,
        prevSelectedOptions,
        selectedOptions,
        setSelectedOptions,
        toggleOption,
        maxSelected: {
            limit: maxSelectedLimit,
            isLimitReached
        }
    };
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(SelectedOptionsContextProvider, Object.assign({}, selectedOptionsState), children);
};
_s(SelectedOptionsProvider, "1RCqnbDiJobhZN+p4l9Tnk0Z8ww=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInputContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$customOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useComboboxCustomOptions"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$usePrevious$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePrevious"]
    ];
});
_c = SelectedOptionsProvider;
;
var _c;
__turbopack_context__.k.register(_c, "SelectedOptionsProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=selectedOptionsContext.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/FilteredOptions/filtered-options-util.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
const normalizeText = (text)=>typeof text === "string" ? text.toLocaleLowerCase().trim() : "";
const isPartOfText = (value, text)=>normalizeText(text).includes(normalizeText(value !== null && value !== void 0 ? value : ""));
const getMatchingValuesFromList = (value, list)=>list.filter((listItem)=>isPartOfText(value, listItem.label));
const getFirstValueStartingWith = (text, list)=>{
    return list.find((listItem)=>normalizeText(listItem.label).startsWith(text.toLocaleLowerCase()));
};
const getFilteredOptionsId = (comboboxId)=>`${comboboxId}-filtered-options`;
const getOptionId = (comboboxId, option)=>`${comboboxId}-option-${option}`.replace(/\s/g, "-").toLocaleLowerCase();
const getAddNewOptionId = (comboboxId)=>`${comboboxId}-combobox-new-option`;
const getIsLoadingId = (comboboxId)=>`${comboboxId}-is-loading`;
const getNoHitsId = (comboboxId)=>`${comboboxId}-no-hits`;
const getMaxSelectedOptionsId = (comboboxId)=>`${comboboxId}-max-selected-options`;
const __TURBOPACK__default__export__ = {
    normalizeText,
    isPartOfText,
    getMatchingValuesFromList,
    getFilteredOptionsId,
    getAddNewOptionId,
    getOptionId,
    getIsLoadingId,
    getNoHitsId,
    getMaxSelectedOptionsId,
    getFirstValueStartingWith
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=filtered-options-util.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/FilteredOptions/useVirtualFocus.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
const useVirtualFocus = (containerRef)=>{
    _s();
    const [activeElement, setActiveElement] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(undefined);
    const getListOfAllChildren = ()=>{
        var _a;
        return Array.from((_a = containerRef === null || containerRef === void 0 ? void 0 : containerRef.children) !== null && _a !== void 0 ? _a : []);
    };
    const getElementsAbleToReceiveFocus = ()=>getListOfAllChildren().filter((child)=>child.getAttribute("data-no-focus") !== "true");
    const getElementById = (id)=>getListOfAllChildren().find((element)=>element.id === id);
    const isFocusOnTheTop = ()=>activeElement ? getElementsAbleToReceiveFocus().indexOf(activeElement) === 0 : false;
    const isFocusOnTheBottom = ()=>{
        const elementsAbleToReceiveFocus = getElementsAbleToReceiveFocus();
        return activeElement ? elementsAbleToReceiveFocus.indexOf(activeElement) === elementsAbleToReceiveFocus.length - 1 : false;
    };
    const setActiveAndScrollToElement = (element)=>{
        var _a;
        setActiveElement(element);
        (_a = element === null || element === void 0 ? void 0 : element.scrollIntoView) === null || _a === void 0 ? void 0 : _a.call(element, {
            block: "nearest"
        });
    };
    const moveFocusUp = ()=>{
        if (!activeElement) {
            return;
        }
        const elementsAbleToReceiveFocus = getElementsAbleToReceiveFocus();
        const _currentIndex = elementsAbleToReceiveFocus.indexOf(activeElement);
        const elementAbove = elementsAbleToReceiveFocus[_currentIndex - 1];
        if (_currentIndex === 0) {
            setActiveElement(undefined);
        } else {
            setActiveAndScrollToElement(elementAbove);
        }
    };
    const moveFocusDown = ()=>{
        const elementsAbleToReceiveFocus = getElementsAbleToReceiveFocus();
        if (!activeElement) {
            setActiveAndScrollToElement(elementsAbleToReceiveFocus[0]);
            return;
        }
        const _currentIndex = elementsAbleToReceiveFocus.indexOf(activeElement);
        if (_currentIndex === elementsAbleToReceiveFocus.length - 1) {
            return;
        }
        setActiveAndScrollToElement(elementsAbleToReceiveFocus[_currentIndex + 1]);
    };
    const resetFocus = ()=>setActiveElement(undefined);
    const moveFocusToTop = ()=>{
        const elementsAbleToReceiveFocus = getElementsAbleToReceiveFocus();
        setActiveAndScrollToElement(elementsAbleToReceiveFocus[0]);
    };
    const moveFocusToBottom = ()=>{
        const elementsAbleToReceiveFocus = getElementsAbleToReceiveFocus();
        setActiveAndScrollToElement(elementsAbleToReceiveFocus[elementsAbleToReceiveFocus.length - 1]);
    };
    const moveFocusToElement = (id)=>{
        const _element = getElementsAbleToReceiveFocus().find((_focusableElement)=>_focusableElement.getAttribute("id") === id);
        if (_element) {
            setActiveElement(_element);
        }
    };
    const moveFocusUpBy = (numberOfElements)=>{
        if (!activeElement) {
            return;
        }
        const elementsAbleToReceiveFocus = getElementsAbleToReceiveFocus();
        const currentIndex = elementsAbleToReceiveFocus.indexOf(activeElement);
        const newIndex = Math.max(currentIndex - numberOfElements, 0);
        setActiveAndScrollToElement(elementsAbleToReceiveFocus[newIndex]);
    };
    const moveFocusDownBy = (numberOfElements)=>{
        const elementsAbleToReceiveFocus = getElementsAbleToReceiveFocus();
        const currentIndex = activeElement ? elementsAbleToReceiveFocus.indexOf(activeElement) : -1;
        const newIndex = Math.min(currentIndex + numberOfElements, elementsAbleToReceiveFocus.length - 1);
        setActiveAndScrollToElement(elementsAbleToReceiveFocus[newIndex]);
    };
    return {
        activeElement,
        getElementById,
        isFocusOnTheTop,
        isFocusOnTheBottom,
        moveFocusUp,
        moveFocusDown,
        moveFocusToElement,
        moveFocusToTop,
        moveFocusToBottom,
        moveFocusUpBy,
        moveFocusDownBy,
        resetFocus
    };
};
_s(useVirtualFocus, "RkJWbsHLg8KBr4Cr4+i2XUiHS6w=");
const __TURBOPACK__default__export__ = useVirtualFocus;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=useVirtualFocus.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/FilteredOptions/filteredOptionsContext.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FilteredOptionsProvider",
    ()=>FilteredOptionsProvider,
    "useFilteredOptionsContext",
    ()=>useFilteredOptionsContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$create$2d$strict$2d$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/create-strict-context.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useClientLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/useClientLayoutEffect.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$usePrevious$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/usePrevious.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/Input/Input.context.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$SelectedOptions$2f$selectedOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/SelectedOptions/selectedOptionsContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$combobox$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/combobox-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$customOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/customOptionsContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filtered$2d$options$2d$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/FilteredOptions/filtered-options-util.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$useVirtualFocus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/FilteredOptions/useVirtualFocus.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
const { Provider: FilteredOptionsContextProvider, useContext: useFilteredOptionsContext } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$create$2d$strict$2d$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createStrictContext"])({
    name: "FilteredOptionsContext",
    errorMessage: "useFilteredOptionsContext must be used within a FilteredOptionsProvider"
});
const FilteredOptionsProvider = ({ children, value: props })=>{
    _s();
    const { allowNewValues, filteredOptions: externalFilteredOptions, isListOpen: isExternalListOpen, isLoading, options } = props;
    const [filteredOptionsRef, setFilteredOptionsRef] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const virtualFocus = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$useVirtualFocus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(filteredOptionsRef);
    const { inputProps: { "aria-describedby": partialAriaDescribedBy, id, disabled }, readOnly, value, searchTerm, setValue, setSearchTerm, shouldAutocomplete, setHideCaret } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInputContext"])();
    const { maxSelected } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$SelectedOptions$2f$selectedOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSelectedOptionsContext"])();
    const [isInternalListOpen, setInternalListOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const { customOptions } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$customOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useComboboxCustomOptions"])();
    const filteredOptions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "FilteredOptionsProvider.useMemo[filteredOptions]": ()=>{
            if (externalFilteredOptions) {
                return externalFilteredOptions;
            }
            const opts = [
                ...customOptions,
                ...options
            ];
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filtered$2d$options$2d$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].getMatchingValuesFromList(searchTerm, opts);
        }
    }["FilteredOptionsProvider.useMemo[filteredOptions]"], [
        customOptions,
        externalFilteredOptions,
        options,
        searchTerm
    ]);
    const previousSearchTerm = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$usePrevious$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePrevious"])(searchTerm);
    const [isMouseLastUsedInputDevice, setIsMouseLastUsedInputDevice] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const filteredOptionsMap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "FilteredOptionsProvider.useMemo[filteredOptionsMap]": ()=>{
            const initialMap = Object.assign({
                [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filtered$2d$options$2d$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].getAddNewOptionId(id)]: allowNewValues ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$combobox$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toComboboxOption"])(value) : undefined
            }, customOptions.reduce({
                "FilteredOptionsProvider.useMemo[filteredOptionsMap].initialMap": (acc, customOption)=>{
                    const _id = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filtered$2d$options$2d$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].getOptionId(id, customOption.value);
                    acc[_id] = customOption;
                    return acc;
                }
            }["FilteredOptionsProvider.useMemo[filteredOptionsMap].initialMap"], {}));
            // Add the options to the map
            const finalMap = options.reduce({
                "FilteredOptionsProvider.useMemo[filteredOptionsMap].finalMap": (map, _option)=>{
                    const _id = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filtered$2d$options$2d$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].getOptionId(id, _option.value);
                    map[_id] = _option;
                    return map;
                }
            }["FilteredOptionsProvider.useMemo[filteredOptionsMap].finalMap"], initialMap);
            return finalMap;
        }
    }["FilteredOptionsProvider.useMemo[filteredOptionsMap]"], [
        allowNewValues,
        customOptions,
        id,
        options,
        value
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useClientLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useClientLayoutEffect"])({
        "FilteredOptionsProvider.useClientLayoutEffect": ()=>{
            var _a;
            const autoCompleteCandidate = (_a = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filtered$2d$options$2d$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].getFirstValueStartingWith(searchTerm, filteredOptions)) === null || _a === void 0 ? void 0 : _a.label;
            if (shouldAutocomplete && autoCompleteCandidate && ((previousSearchTerm === null || previousSearchTerm === void 0 ? void 0 : previousSearchTerm.length) || 0) < searchTerm.length) {
                setValue(`${searchTerm}${autoCompleteCandidate.substring(searchTerm.length)}`);
            }
        }
    }["FilteredOptionsProvider.useClientLayoutEffect"], [
        filteredOptions,
        previousSearchTerm,
        searchTerm,
        setSearchTerm,
        setValue,
        shouldAutocomplete
    ]);
    const isListOpen = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "FilteredOptionsProvider.useMemo[isListOpen]": ()=>{
            return isExternalListOpen !== null && isExternalListOpen !== void 0 ? isExternalListOpen : isInternalListOpen;
        }
    }["FilteredOptionsProvider.useMemo[isListOpen]"], [
        isExternalListOpen,
        isInternalListOpen
    ]);
    const toggleIsListOpen = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "FilteredOptionsProvider.useCallback[toggleIsListOpen]": (newState)=>{
            if (disabled || readOnly) {
                return;
            }
            virtualFocus.resetFocus();
            if (newState !== null && newState !== void 0 ? newState : !isInternalListOpen) {
                setHideCaret(maxSelected.isLimitReached);
            }
            setInternalListOpen({
                "FilteredOptionsProvider.useCallback[toggleIsListOpen]": (oldState)=>newState !== null && newState !== void 0 ? newState : !oldState
            }["FilteredOptionsProvider.useCallback[toggleIsListOpen]"]);
        }
    }["FilteredOptionsProvider.useCallback[toggleIsListOpen]"], [
        virtualFocus,
        maxSelected.isLimitReached,
        isInternalListOpen,
        setHideCaret,
        disabled,
        readOnly
    ]);
    const isValueNew = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "FilteredOptionsProvider.useMemo[isValueNew]": ()=>Boolean(searchTerm) && !filteredOptionsMap[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filtered$2d$options$2d$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].getOptionId(id, searchTerm)]
    }["FilteredOptionsProvider.useMemo[isValueNew]"], [
        filteredOptionsMap,
        id,
        searchTerm
    ]);
    const ariaDescribedBy = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "FilteredOptionsProvider.useMemo[ariaDescribedBy]": ()=>{
            let activeOption = "";
            if (!isLoading && filteredOptions.length === 0 && !allowNewValues) {
                activeOption = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filtered$2d$options$2d$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].getNoHitsId(id);
            } else if (value || isLoading) {
                if (shouldAutocomplete && filteredOptions[0]) {
                    activeOption = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filtered$2d$options$2d$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].getOptionId(id, filteredOptions[0].value);
                } else if (isListOpen && isLoading) {
                    activeOption = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filtered$2d$options$2d$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].getIsLoadingId(id);
                }
            }
            const maybeMaxSelectedOptionsId = maxSelected.isLimitReached && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filtered$2d$options$2d$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].getMaxSelectedOptionsId(id);
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])(activeOption, maybeMaxSelectedOptionsId, partialAriaDescribedBy) || undefined;
        }
    }["FilteredOptionsProvider.useMemo[ariaDescribedBy]"], [
        isListOpen,
        isLoading,
        maxSelected.isLimitReached,
        value,
        partialAriaDescribedBy,
        shouldAutocomplete,
        filteredOptions,
        id,
        allowNewValues
    ]);
    const currentOption = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "FilteredOptionsProvider.useMemo[currentOption]": ()=>{
            var _a;
            return filteredOptionsMap[((_a = virtualFocus.activeElement) === null || _a === void 0 ? void 0 : _a.getAttribute("id")) || -1];
        }
    }["FilteredOptionsProvider.useMemo[currentOption]"], [
        filteredOptionsMap,
        virtualFocus
    ]);
    const activeDecendantId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "FilteredOptionsProvider.useMemo[activeDecendantId]": ()=>{
            var _a;
            return ((_a = virtualFocus.activeElement) === null || _a === void 0 ? void 0 : _a.getAttribute("id")) || undefined;
        }
    }["FilteredOptionsProvider.useMemo[activeDecendantId]"], [
        virtualFocus.activeElement
    ]);
    const filteredOptionsState = {
        activeDecendantId,
        allowNewValues,
        setFilteredOptionsRef,
        shouldAutocomplete,
        isListOpen,
        isLoading,
        filteredOptions,
        isMouseLastUsedInputDevice,
        setIsMouseLastUsedInputDevice,
        isValueNew,
        toggleIsListOpen,
        currentOption,
        virtualFocus,
        ariaDescribedBy
    };
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(FilteredOptionsContextProvider, Object.assign({}, filteredOptionsState), children);
};
_s(FilteredOptionsProvider, "+4sD8ew7HW9Y/bUpl2VVM53hTyE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$useVirtualFocus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInputContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$SelectedOptions$2f$selectedOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSelectedOptionsContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$customOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useComboboxCustomOptions"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$usePrevious$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePrevious"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useClientLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useClientLayoutEffect"]
    ];
});
_c = FilteredOptionsProvider;
;
var _c;
__turbopack_context__.k.register(_c, "FilteredOptionsProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=filteredOptionsContext.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/FilteredOptions/AddNewOption.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$Plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PlusIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/Plus.js [app-client] (ecmascript) <export default as PlusIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/BodyShort.js [app-client] (ecmascript) <export default as BodyShort>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$Label$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Label$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/Label.js [app-client] (ecmascript) <export default as Label>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$i18n$2f$i18n$2e$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/i18n/i18n.hooks.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/Input/Input.context.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$SelectedOptions$2f$selectedOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/SelectedOptions/selectedOptionsContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$combobox$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/combobox-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filtered$2d$options$2d$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/FilteredOptions/filtered-options-util.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filteredOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/FilteredOptions/filteredOptionsContext.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
const AddNewOption = ()=>{
    _s();
    const { inputProps: { id }, size, searchTerm } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInputContext"])();
    const { setIsMouseLastUsedInputDevice, toggleIsListOpen, activeDecendantId, virtualFocus } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filteredOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilteredOptionsContext"])();
    const { isMultiSelect, selectedOptions, toggleOption } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$SelectedOptions$2f$selectedOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSelectedOptionsContext"])();
    const translate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$i18n$2f$i18n$2e$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useI18n"])("Combobox");
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("li", {
        tabIndex: -1,
        onMouseMove: ()=>{
            if (activeDecendantId !== __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filtered$2d$options$2d$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].getAddNewOptionId(id)) {
                virtualFocus.moveFocusToElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filtered$2d$options$2d$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].getAddNewOptionId(id));
                setIsMouseLastUsedInputDevice(true);
            }
        },
        onPointerUp: (event)=>{
            toggleOption((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$combobox$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toComboboxOption"])(searchTerm), event);
            if (!isMultiSelect && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$combobox$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isInList"])(searchTerm, selectedOptions)) toggleIsListOpen(false);
        },
        id: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filtered$2d$options$2d$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].getAddNewOptionId(id),
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-combobox__list-item aksel-combobox__list-item--new-option", {
            "aksel-combobox__list-item--new-option--focus": activeDecendantId === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filtered$2d$options$2d$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].getAddNewOptionId(id)
        }),
        role: "option",
        "aria-selected": false
    }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$Plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PlusIcon$3e$__["PlusIcon"], {
        "aria-hidden": true
    }), /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__["BodyShort"], {
        size: size
    }, translate("addOption"), " ", /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$Label$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Label$3e$__["Label"], {
        as: "span",
        size: size
    }, "\u201C", searchTerm, "\u201D")));
};
_s(AddNewOption, "9jhPXvdrPlf3/LgPH9dqDR36aCY=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInputContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filteredOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilteredOptionsContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$SelectedOptions$2f$selectedOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSelectedOptionsContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$i18n$2f$i18n$2e$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useI18n"]
    ];
});
_c = AddNewOption;
const __TURBOPACK__default__export__ = AddNewOption;
var _c;
__turbopack_context__.k.register(_c, "AddNewOption");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=AddNewOption.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/FilteredOptions/FilteredOptionsItem.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$Checkmark$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckmarkIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/Checkmark.js [app-client] (ecmascript) <export default as CheckmarkIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/BodyShort.js [app-client] (ecmascript) <export default as BodyShort>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/Input/Input.context.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$SelectedOptions$2f$selectedOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/SelectedOptions/selectedOptionsContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$combobox$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/combobox-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filtered$2d$options$2d$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/FilteredOptions/filtered-options-util.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filteredOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/FilteredOptions/filteredOptionsContext.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
const useTextHighlight = (text, searchTerm)=>{
    const indexOfHighlightedText = text.toLowerCase().indexOf(searchTerm.toLowerCase());
    if (indexOfHighlightedText === -1) {
        // This can happen if the consumer has implemented their own filtering logic
        return [
            text,
            "",
            ""
        ];
    }
    const start = text.substring(0, indexOfHighlightedText);
    const highlight = text.substring(indexOfHighlightedText, indexOfHighlightedText + searchTerm.length);
    const end = text.substring(indexOfHighlightedText + searchTerm.length);
    return [
        start,
        highlight,
        end
    ];
};
const FilteredOptionsItem = ({ option })=>{
    _s();
    const { inputProps: { id }, size, searchTerm } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInputContext"])();
    const { setIsMouseLastUsedInputDevice, toggleIsListOpen, activeDecendantId, virtualFocus } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filteredOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilteredOptionsContext"])();
    const { isMultiSelect, maxSelected, selectedOptions, toggleOption } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$SelectedOptions$2f$selectedOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSelectedOptionsContext"])();
    const [start, highlight, end] = useTextHighlight(option.label, searchTerm);
    const isDisabled = (_option)=>maxSelected.isLimitReached && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$combobox$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isInList"])(_option.value, selectedOptions);
    const optionId = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filtered$2d$options$2d$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].getOptionId(id, option.value);
    const isActive = activeDecendantId === optionId;
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("li", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-combobox__list-item", {
            "aksel-combobox__list-item--focus": isActive,
            "aksel-combobox__list-item--selected": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$combobox$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isInList"])(option.value, selectedOptions)
        }),
        "data-no-focus": isDisabled(option) || undefined,
        id: optionId,
        key: optionId,
        tabIndex: -1,
        onMouseMove: ()=>{
            if (!isActive) {
                virtualFocus.moveFocusToElement(optionId);
                setIsMouseLastUsedInputDevice(true);
            }
        },
        onPointerUp: (event)=>{
            if (isDisabled(option)) {
                return;
            }
            toggleOption(option, event);
            if (!isMultiSelect && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$combobox$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isInList"])(option.value, selectedOptions)) {
                toggleIsListOpen(false);
            }
        },
        role: "option",
        "aria-selected": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$combobox$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isInList"])(option.value, selectedOptions),
        "aria-disabled": isDisabled(option) || undefined
    }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__["BodyShort"], {
        size: size,
        "aria-label": option.label
    }, start, highlight && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("mark", null, highlight), end), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$combobox$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isInList"])(option.value, selectedOptions) && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$Checkmark$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckmarkIcon$3e$__["CheckmarkIcon"], null));
};
_s(FilteredOptionsItem, "5zGvRI9cVJFIknJyQgV2wGtk4eo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInputContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filteredOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilteredOptionsContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$SelectedOptions$2f$selectedOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSelectedOptionsContext"],
        useTextHighlight
    ];
});
_c = FilteredOptionsItem;
const __TURBOPACK__default__export__ = FilteredOptionsItem;
var _c;
__turbopack_context__.k.register(_c, "FilteredOptionsItem");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=FilteredOptionsItem.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/FilteredOptions/LoadingMessage.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$loader$2f$Loader$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/loader/Loader.js [app-client] (ecmascript) <export default as Loader>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$i18n$2f$i18n$2e$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/i18n/i18n.hooks.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/Input/Input.context.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filtered$2d$options$2d$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/FilteredOptions/filtered-options-util.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
const LoadingMessage = ()=>{
    _s();
    const { inputProps: { id } } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInputContext"])();
    const translate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$i18n$2f$i18n$2e$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useI18n"])("Combobox");
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", {
        className: "aksel-combobox__list-item--loading",
        id: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filtered$2d$options$2d$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].getIsLoadingId(id)
    }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$loader$2f$Loader$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader$3e$__["Loader"], {
        title: translate("loading")
    }));
};
_s(LoadingMessage, "5PoNWHjk5+gT9yZo1s5KSwzOtxM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInputContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$i18n$2f$i18n$2e$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useI18n"]
    ];
});
_c = LoadingMessage;
const __TURBOPACK__default__export__ = LoadingMessage;
var _c;
__turbopack_context__.k.register(_c, "LoadingMessage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=LoadingMessage.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/FilteredOptions/MaxSelectedMessage.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$i18n$2f$i18n$2e$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/i18n/i18n.hooks.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/Input/Input.context.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$SelectedOptions$2f$selectedOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/SelectedOptions/selectedOptionsContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filtered$2d$options$2d$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/FilteredOptions/filtered-options-util.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
const MaxSelectedMessage = ()=>{
    _s();
    const { inputProps: { id } } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInputContext"])();
    const { maxSelected, selectedOptions } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$SelectedOptions$2f$selectedOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSelectedOptionsContext"])();
    const translate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$i18n$2f$i18n$2e$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useI18n"])("Combobox");
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", {
        className: "aksel-combobox__list-item--max-selected",
        id: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filtered$2d$options$2d$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].getMaxSelectedOptionsId(id)
    }, translate("maxSelected", {
        selected: selectedOptions.length,
        limit: maxSelected.limit || 0
    }));
};
_s(MaxSelectedMessage, "1TjCzIZ4X4tpuNxouDzfrerTFY8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInputContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$SelectedOptions$2f$selectedOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSelectedOptionsContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$i18n$2f$i18n$2e$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useI18n"]
    ];
});
_c = MaxSelectedMessage;
const __TURBOPACK__default__export__ = MaxSelectedMessage;
var _c;
__turbopack_context__.k.register(_c, "MaxSelectedMessage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=MaxSelectedMessage.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/FilteredOptions/NoSearchHitsMessage.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$i18n$2f$i18n$2e$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/i18n/i18n.hooks.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/Input/Input.context.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filtered$2d$options$2d$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/FilteredOptions/filtered-options-util.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
;
const NoSearchHitsMessage = ()=>{
    _s();
    const translate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$i18n$2f$i18n$2e$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useI18n"])("Combobox");
    const { inputProps: { id } } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInputContext"])();
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", {
        className: "aksel-combobox__list-item--no-options",
        id: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filtered$2d$options$2d$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].getNoHitsId(id)
    }, translate("noMatches"));
};
_s(NoSearchHitsMessage, "vWH1rh+jbjiMk8qa7F8qKWLfxMA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$i18n$2f$i18n$2e$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useI18n"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInputContext"]
    ];
});
_c = NoSearchHitsMessage;
const __TURBOPACK__default__export__ = NoSearchHitsMessage;
var _c;
__turbopack_context__.k.register(_c, "NoSearchHitsMessage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=NoSearchHitsMessage.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/FilteredOptions/FilteredOptions.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$overlays$2f$dismissablelayer$2f$DismissableLayer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/overlays/dismissablelayer/DismissableLayer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$overlays$2f$floating$2f$Floating$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/overlays/floating/Floating.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useClientLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/useClientLayoutEffect.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/Input/Input.context.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$SelectedOptions$2f$selectedOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/SelectedOptions/selectedOptionsContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$AddNewOption$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/FilteredOptions/AddNewOption.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$FilteredOptionsItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/FilteredOptions/FilteredOptionsItem.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$LoadingMessage$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/FilteredOptions/LoadingMessage.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$MaxSelectedMessage$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/FilteredOptions/MaxSelectedMessage.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$NoSearchHitsMessage$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/FilteredOptions/NoSearchHitsMessage.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filtered$2d$options$2d$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/FilteredOptions/filtered-options-util.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filteredOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/FilteredOptions/filteredOptionsContext.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const FilteredOptions = ()=>{
    _s();
    const { inputProps: { id }, anchorRef } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInputContext"])();
    const { allowNewValues, isLoading, isListOpen, filteredOptions, setFilteredOptionsRef, isMouseLastUsedInputDevice, isValueNew, toggleIsListOpen } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filteredOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilteredOptionsContext"])();
    const [localOpen, setLocalOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(isListOpen);
    const floatingRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    /**
     * This is a dirty hack to make the positioning-logic in Floating base the "flip" on the static 290px max-height,
     * instead of the dynamic one based on available space. Without this, the list won't flip to top when there's
     * not enough space below the input.
     */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useClientLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useClientLayoutEffect"])({
        "FilteredOptions.useClientLayoutEffect": ()=>{
            queueMicrotask({
                "FilteredOptions.useClientLayoutEffect": ()=>setLocalOpen(isListOpen)
            }["FilteredOptions.useClientLayoutEffect"]);
        }
    }["FilteredOptions.useClientLayoutEffect"], [
        isListOpen
    ]);
    const { maxSelected, isMultiSelect } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$SelectedOptions$2f$selectedOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSelectedOptionsContext"])();
    const shouldRenderNonSelectables = isMultiSelect && maxSelected.limit || // Render maxSelected message
    isLoading || !isLoading && filteredOptions.length === 0 && !allowNewValues; // Render no hits message
    const shouldRenderFilteredOptionsList = allowNewValues && isValueNew && !maxSelected.isLimitReached || // Render add new option
    filteredOptions.length > 0; // Render filtered options
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$overlays$2f$dismissablelayer$2f$DismissableLayer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DismissableLayer"], {
        asChild: true,
        safeZone: {
            anchor: anchorRef
        },
        onDismiss: ()=>localOpen && toggleIsListOpen(false),
        onEscapeKeyDown: (event)=>{
            /* We handle this manually in Input */ event.preventDefault();
        },
        enabled: localOpen
    }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$overlays$2f$floating$2f$Floating$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Floating"].Content, {
        ref: floatingRef,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-combobox__list", {
            "aksel-combobox__list--closed": !isListOpen,
            "aksel-combobox__list--with-hover": isMouseLastUsedInputDevice
        }),
        id: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filtered$2d$options$2d$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].getFilteredOptionsId(id),
        tabIndex: -1,
        sideOffset: 8,
        side: "bottom",
        fallbackPlacements: [
            "top"
        ],
        enabled: isListOpen,
        style: {
            maxHeight: localOpen ? `min(316px, var(--__axc-floating-available-height))` : `316px`
        },
        autoUpdateWhileMounted: false
    }, shouldRenderNonSelectables && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", {
        className: "aksel-combobox__list_non-selectables",
        role: "status"
    }, isMultiSelect && maxSelected.limit && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$MaxSelectedMessage$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], null), isLoading && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$LoadingMessage$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], null), !isLoading && filteredOptions.length === 0 && !allowNewValues && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$NoSearchHitsMessage$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], null)), shouldRenderFilteredOptionsList && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("ul", {
        ref: setFilteredOptionsRef,
        role: "listbox",
        className: "aksel-combobox__list-options"
    }, isValueNew && !maxSelected.isLimitReached && allowNewValues && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$AddNewOption$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], null), filteredOptions.map((option)=>/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$FilteredOptionsItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            key: option.value,
            option: option
        })))));
};
_s(FilteredOptions, "5UM6d5ds0NNblhMsDhg+ohvYHIo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInputContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filteredOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilteredOptionsContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useClientLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useClientLayoutEffect"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$SelectedOptions$2f$selectedOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSelectedOptionsContext"]
    ];
});
_c = FilteredOptions;
const __TURBOPACK__default__export__ = FilteredOptions;
var _c;
__turbopack_context__.k.register(_c, "FilteredOptions");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=FilteredOptions.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/SelectedOptions/SelectedOptions.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$chips$2f$Chips$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chips$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/chips/Chips.js [app-client] (ecmascript) <export default as Chips>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/Input/Input.context.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$SelectedOptions$2f$selectedOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/SelectedOptions/selectedOptionsContext.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
;
;
;
;
const Option = ({ option })=>{
    _s();
    const { isMultiSelect, removeSelectedOption } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$SelectedOptions$2f$selectedOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSelectedOptionsContext"])();
    const { focusInput, readOnly, inputProps } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInputContext"])();
    if (!isMultiSelect) {
        return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", {
            className: "aksel-combobox__selected-options--no-bg"
        }, option.label);
    }
    if (readOnly || inputProps.disabled) {
        return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$chips$2f$Chips$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chips$3e$__["Chips"].Toggle, {
            "data-color": "neutral",
            checkmark: false,
            as: "div"
        }, option.label);
    }
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$chips$2f$Chips$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chips$3e$__["Chips"].Removable, {
        onClick: (event)=>{
            event.stopPropagation();
            removeSelectedOption(option);
            focusInput();
        }
    }, option.label);
};
_s(Option, "tqYSu5k5CyptFGX0REMcaeC6lmA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$SelectedOptions$2f$selectedOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSelectedOptionsContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInputContext"]
    ];
});
_c = Option;
const SelectedOptions = ({ selectedOptions = [], size, children })=>{
    _s1();
    const { value } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInputContext"])();
    const { isMultiSelect } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$SelectedOptions$2f$selectedOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSelectedOptionsContext"])();
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$chips$2f$Chips$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chips$3e$__["Chips"], {
        className: "aksel-combobox__selected-options",
        size: size,
        "data-type": isMultiSelect ? "multiple" : "single"
    }, value.length === 0 || isMultiSelect && selectedOptions.length ? selectedOptions.map((option, i)=>/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(Option, {
            key: option.label + i,
            option: option
        })) : [], children);
};
_s1(SelectedOptions, "O3zzRCe+2c125h2esv5yIiMAfQc=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInputContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$SelectedOptions$2f$selectedOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSelectedOptionsContext"]
    ];
});
_c1 = SelectedOptions;
const __TURBOPACK__default__export__ = SelectedOptions;
var _c, _c1;
__turbopack_context__.k.register(_c, "Option");
__turbopack_context__.k.register(_c1, "SelectedOptions");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=SelectedOptions.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/Input/Input.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$omit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/omit.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$composeEventHandlers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/composeEventHandlers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useMergeRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/useMergeRefs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filtered$2d$options$2d$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/FilteredOptions/filtered-options-util.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filteredOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/FilteredOptions/filteredOptionsContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$SelectedOptions$2f$selectedOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/SelectedOptions/selectedOptionsContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/Input/Input.context.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
;
;
;
;
;
;
const Input = /*#__PURE__*/ _s((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = _s((_a, ref)=>{
    _s();
    var { inputClassName, shouldShowSelectedOptions, placeholder, onBlur } = _a, rest = __rest(_a, [
        "inputClassName",
        "shouldShowSelectedOptions",
        "placeholder",
        "onBlur"
    ]);
    const internalRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const mergedRefs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useMergeRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMergeRefs"])(ref, internalRef);
    const { clearInput, inputProps, onChange, size, value, searchTerm, setValue, hideCaret, setHideCaret, readOnly } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInputContext"])();
    const { selectedOptions, removeSelectedOption, toggleOption, isMultiSelect, maxSelected } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$SelectedOptions$2f$selectedOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSelectedOptionsContext"])();
    const { activeDecendantId, allowNewValues, currentOption, filteredOptions, isValueNew, toggleIsListOpen, isListOpen, ariaDescribedBy, setIsMouseLastUsedInputDevice, shouldAutocomplete, virtualFocus } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filteredOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilteredOptionsContext"])();
    const onEnter = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Input.useCallback[onEnter]": (event)=>{
            var _a;
            const isSelected = {
                "Input.useCallback[onEnter].isSelected": (text)=>selectedOptions.some({
                        "Input.useCallback[onEnter].isSelected": (option)=>option.label.toLocaleLowerCase() === text.toLocaleLowerCase()
                    }["Input.useCallback[onEnter].isSelected"])
            }["Input.useCallback[onEnter].isSelected"];
            if (currentOption) {
                event.preventDefault();
                // Selecting a value from the dropdown / FilteredOptions
                toggleOption(currentOption, event);
                if (!isMultiSelect && !isSelected(currentOption.label)) {
                    toggleIsListOpen(false);
                }
            } else if (isSelected(value)) {
                event.preventDefault();
                // Trying to set the same value that is already set, so just clearing the input
                clearInput(event);
            } else if ((allowNewValues || shouldAutocomplete) && value !== "") {
                event.preventDefault();
                const autoCompletedOption = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filtered$2d$options$2d$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].getFirstValueStartingWith(value, filteredOptions);
                /*
             * User can have matching results, while not using the autocomplete result
             * E.g. User types "Oslo", list has is "Oslo kommune", but user hits backspace, canceling autocomplete.
             */ const autoCompleteMatchesValue = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filtered$2d$options$2d$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].normalizeText(value) === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filtered$2d$options$2d$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].normalizeText((_a = autoCompletedOption === null || autoCompletedOption === void 0 ? void 0 : autoCompletedOption.label) !== null && _a !== void 0 ? _a : "");
                let optionToToggle;
                if (shouldAutocomplete && autoCompletedOption && autoCompleteMatchesValue) {
                    optionToToggle = autoCompletedOption;
                } else if (allowNewValues && isValueNew) {
                    optionToToggle = {
                        label: value,
                        value
                    };
                }
                if (!optionToToggle) {
                    return;
                }
                toggleOption(optionToToggle, event);
                if (!isMultiSelect && !isSelected(optionToToggle.label)) {
                    toggleIsListOpen(false);
                }
            }
        }
    }["Input.useCallback[onEnter]"], [
        allowNewValues,
        clearInput,
        currentOption,
        filteredOptions,
        isMultiSelect,
        isValueNew,
        selectedOptions,
        shouldAutocomplete,
        toggleIsListOpen,
        toggleOption,
        value
    ]);
    const handleKeyUp = (e)=>{
        e.preventDefault();
        switch(e.key){
            case "Enter":
            case "Accept":
                onEnter(e);
                break;
            default:
                break;
        }
    };
    const handleKeyDown = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Input.useCallback[handleKeyDown]": (e)=>{
            setIsMouseLastUsedInputDevice(false);
            if (readOnly) {
                return;
            }
            if (e.key === "Backspace") {
                if (value === "" && shouldShowSelectedOptions) {
                    const lastSelectedOption = selectedOptions[selectedOptions.length - 1];
                    if (lastSelectedOption) {
                        removeSelectedOption(lastSelectedOption);
                    }
                }
            } else if (e.key === "Enter" || e.key === "Accept") {
                if (activeDecendantId || value) {
                    e.preventDefault();
                }
            } else if (e.key === "Escape") {
                if (isListOpen || value) {
                    e.preventDefault(); // Prevents closing an encasing Modal, as Combobox reacts on keyup.
                    clearInput(e);
                    toggleIsListOpen(false);
                }
            } else if ([
                "ArrowLeft",
                "ArrowRight"
            ].includes(e.key)) {
                /**
             * In case user has an active selection and 'completes' the selection with ArrowLeft or ArrowRight
             * we need to make sure to update the filter.
             */ if (value !== "" && value !== searchTerm) {
                    onChange(value);
                }
            } else if (e.key === "ArrowDown") {
                // Reset the value to the search term to cancel autocomplete
                // if the user moves focus down to the FilteredOptions
                if (value !== searchTerm) {
                    setValue(searchTerm);
                }
                if (!isListOpen) {
                    toggleIsListOpen(true);
                    setTimeout(virtualFocus.moveFocusDown, 0); // Wait until list is visible so that scrollIntoView works
                } else {
                    virtualFocus.moveFocusDown();
                }
            } else if (e.key === "ArrowUp") {
                if (value !== "" && value !== searchTerm) {
                    onChange(value);
                }
                // Check that the FilteredOptions list is open and has virtual focus.
                // Otherwise ignore keystrokes, so it doesn't interfere with text editing
                if (isListOpen && activeDecendantId) {
                    e.preventDefault();
                    if (virtualFocus.isFocusOnTheTop()) {
                        toggleIsListOpen(false);
                    }
                    virtualFocus.moveFocusUp();
                }
            } else if (e.key === "Home") {
                e.preventDefault();
                virtualFocus.moveFocusToTop();
            } else if (e.key === "End") {
                e.preventDefault();
                if (!isListOpen) {
                    toggleIsListOpen(true);
                    setTimeout(virtualFocus.moveFocusToBottom, 0); // Wait until list is visible so that scrollIntoView works
                } else {
                    virtualFocus.moveFocusToBottom();
                }
            } else if (e.key === "PageUp") {
                e.preventDefault();
                virtualFocus.moveFocusUpBy(6);
            } else if (e.key === "PageDown") {
                e.preventDefault();
                if (!isListOpen) {
                    toggleIsListOpen(true);
                    setTimeout({
                        "Input.useCallback[handleKeyDown]": ()=>virtualFocus.moveFocusDownBy(6)
                    }["Input.useCallback[handleKeyDown]"], 0); // Wait until list is visible so that scrollIntoView works
                } else {
                    virtualFocus.moveFocusDownBy(6);
                }
            }
        }
    }["Input.useCallback[handleKeyDown]"], [
        value,
        selectedOptions,
        removeSelectedOption,
        isListOpen,
        activeDecendantId,
        setIsMouseLastUsedInputDevice,
        clearInput,
        toggleIsListOpen,
        onChange,
        virtualFocus,
        setValue,
        searchTerm,
        shouldShowSelectedOptions,
        readOnly
    ]);
    const onChangeHandler = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Input.useCallback[onChangeHandler]": (event)=>{
            const newValue = event.target.value;
            if (newValue && newValue !== "") {
                toggleIsListOpen(true);
            } else if (filteredOptions.length === 0) {
                toggleIsListOpen(false);
            }
            onChange(newValue);
        }
    }["Input.useCallback[onChangeHandler]"], [
        filteredOptions.length,
        onChange,
        toggleIsListOpen
    ]);
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("input", Object.assign({}, rest, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$omit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["omit"])(inputProps, [
        "aria-invalid"
    ]), {
        ref: mergedRefs,
        type: "text",
        role: "combobox",
        value: value,
        onBlur: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$composeEventHandlers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["composeEventHandlers"])(onBlur, virtualFocus.resetFocus),
        onClick: ()=>{
            setHideCaret(maxSelected.isLimitReached);
            value !== searchTerm && onChange(value);
        },
        onInput: onChangeHandler,
        onKeyUp: handleKeyUp,
        onKeyDown: handleKeyDown,
        autoComplete: "off",
        placeholder: selectedOptions.length ? undefined : placeholder,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])(inputClassName, "aksel-combobox__input", "aksel-body-short", `aksel-body-short--${size}`, {
            "aksel-combobox__input--hide-caret": hideCaret
        }),
        "aria-controls": __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filtered$2d$options$2d$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].getFilteredOptionsId(inputProps.id),
        "aria-expanded": !!isListOpen,
        "aria-autocomplete": shouldAutocomplete ? "both" : "list",
        "aria-activedescendant": activeDecendantId,
        "aria-describedby": ariaDescribedBy,
        "aria-invalid": inputProps["aria-invalid"],
        readOnly: readOnly
    }));
}, "HKrRQTguTvRo6FKJfikvL0ALnNg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useMergeRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMergeRefs"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInputContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$SelectedOptions$2f$selectedOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSelectedOptionsContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filteredOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilteredOptionsContext"]
    ];
})), "HKrRQTguTvRo6FKJfikvL0ALnNg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useMergeRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMergeRefs"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInputContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$SelectedOptions$2f$selectedOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSelectedOptionsContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filteredOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilteredOptionsContext"]
    ];
});
_c1 = Input;
const __TURBOPACK__default__export__ = Input;
var _c, _c1;
__turbopack_context__.k.register(_c, "Input$forwardRef");
__turbopack_context__.k.register(_c1, "Input");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=Input.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/Input/ToggleListButton.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ToggleListButton",
    ()=>ToggleListButton,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$ChevronDown$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDownIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/ChevronDown.js [app-client] (ecmascript) <export default as ChevronDownIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$ChevronUp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronUpIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/ChevronUp.js [app-client] (ecmascript) <export default as ChevronUpIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filteredOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/FilteredOptions/filteredOptionsContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/Input/Input.context.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
;
const ToggleListButton = /*#__PURE__*/ _s((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = _s((_, ref)=>{
    _s();
    const { isListOpen, toggleIsListOpen } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filteredOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilteredOptionsContext"])();
    const { focusInput } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInputContext"])();
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", {
        ref: ref,
        onClick: (event)=>{
            event.stopPropagation();
            toggleIsListOpen();
            focusInput();
        },
        className: "aksel-combobox__button-toggle-list",
        "aria-hidden": true
    }, isListOpen ? /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$ChevronUp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronUpIcon$3e$__["ChevronUpIcon"], null) : /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$ChevronDown$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDownIcon$3e$__["ChevronDownIcon"], null));
}, "9AJF/7Qp7dxJ5J99Avt31OwDBFo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filteredOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilteredOptionsContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInputContext"]
    ];
})), "9AJF/7Qp7dxJ5J99Avt31OwDBFo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filteredOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilteredOptionsContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInputContext"]
    ];
});
_c1 = ToggleListButton;
const __TURBOPACK__default__export__ = ToggleListButton;
var _c, _c1;
__turbopack_context__.k.register(_c, "ToggleListButton$forwardRef");
__turbopack_context__.k.register(_c1, "ToggleListButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=ToggleListButton.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/Input/InputController.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "InputController",
    ()=>InputController
]);
/* eslint-disable jsx-a11y/no-static-element-interactions */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$overlays$2f$floating$2f$Floating$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/overlays/floating/Floating.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useMergeRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/useMergeRefs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filteredOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/FilteredOptions/filteredOptionsContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$SelectedOptions$2f$SelectedOptions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/SelectedOptions/SelectedOptions.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$SelectedOptions$2f$selectedOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/SelectedOptions/selectedOptionsContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/Input/Input.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/Input/Input.context.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$ToggleListButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/Input/ToggleListButton.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
/* eslint-disable jsx-a11y/click-events-have-key-events */ var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
;
;
;
;
;
;
;
const InputController = /*#__PURE__*/ _s((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = _s((props, ref)=>{
    _s();
    const { // eslint-disable-next-line @typescript-eslint/no-unused-vars -- Remove when prop has been removed from ComboboxProps.
    clearButton, // eslint-disable-next-line @typescript-eslint/no-unused-vars -- Remove when prop has been removed from ComboboxProps.
    clearButtonLabel, toggleListButton = true, inputClassName, shouldShowSelectedOptions = true } = props, rest = __rest(props, [
        "clearButton",
        "clearButtonLabel",
        "toggleListButton",
        "inputClassName",
        "shouldShowSelectedOptions"
    ]);
    const { focusInput, inputProps, size = "medium", inputRef, toggleOpenButtonRef, readOnly, setAnchorRef } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInputContext"])();
    const { activeDecendantId, toggleIsListOpen } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filteredOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilteredOptionsContext"])();
    const { selectedOptions } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$SelectedOptions$2f$selectedOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSelectedOptionsContext"])();
    const mergedInputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useMergeRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMergeRefs"])(inputRef, ref);
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$overlays$2f$floating$2f$Floating$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Floating"].Anchor, {
        asChild: true,
        ref: setAnchorRef
    }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-combobox__wrapper-inner aksel-text-field__input", {
            "aksel-combobox__wrapper-inner--virtually-unfocused": activeDecendantId !== undefined
        }),
        onClick: ()=>{
            if (inputProps.disabled || readOnly) {
                return;
            }
            toggleIsListOpen(true);
            focusInput();
        }
    }, !shouldShowSelectedOptions ? /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], Object.assign({
        id: inputProps.id,
        ref: mergedInputRef,
        inputClassName: inputClassName,
        readOnly: readOnly
    }, rest)) : /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$SelectedOptions$2f$SelectedOptions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        selectedOptions: selectedOptions,
        size: size
    }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], Object.assign({
        id: inputProps.id,
        ref: mergedInputRef,
        inputClassName: inputClassName,
        shouldShowSelectedOptions: shouldShowSelectedOptions,
        readOnly: readOnly
    }, rest))), toggleListButton && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$ToggleListButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        ref: toggleOpenButtonRef
    })));
}, "u512uIhhO1x0uht92VUbSxcHAw0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInputContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filteredOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilteredOptionsContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$SelectedOptions$2f$selectedOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSelectedOptionsContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useMergeRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMergeRefs"]
    ];
})), "u512uIhhO1x0uht92VUbSxcHAw0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInputContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filteredOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilteredOptionsContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$SelectedOptions$2f$selectedOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSelectedOptionsContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useMergeRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMergeRefs"]
    ];
}); //# sourceMappingURL=InputController.js.map
_c1 = InputController;
var _c, _c1;
__turbopack_context__.k.register(_c, "InputController$forwardRef");
__turbopack_context__.k.register(_c1, "InputController");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/Combobox.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Combobox",
    ()=>Combobox,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$overlays$2f$floating$2f$Floating$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/overlays/floating/Floating.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/BodyShort.js [app-client] (ecmascript) <export default as BodyShort>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$ErrorMessage$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ErrorMessage$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/ErrorMessage.js [app-client] (ecmascript) <export default as ErrorMessage>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$Label$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Label$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/Label.js [app-client] (ecmascript) <export default as Label>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$ReadOnlyIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/ReadOnlyIcon.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$ComboboxWrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/ComboboxWrapper.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$FilteredOptions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/FilteredOptions/FilteredOptions.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/Input/Input.context.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$InputController$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/Input/InputController.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
;
;
;
;
;
;
const Combobox = /*#__PURE__*/ _s((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = _s((props, ref)=>{
    _s();
    const { className, hideLabel = false, description, label } = props, rest = __rest(props, [
        "className",
        "hideLabel",
        "description",
        "label"
    ]);
    const { error, errorId, hasError, inputDescriptionId, inputProps, showErrorMsg, size = "medium", readOnly } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInputContext"])();
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$overlays$2f$floating$2f$Floating$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Floating"], null, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$ComboboxWrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        className: className,
        hasError: hasError,
        inputProps: inputProps,
        inputSize: size
    }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$Label$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Label$3e$__["Label"], {
        htmlFor: inputProps.id,
        size: size,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-form-field__label", {
            "aksel-sr-only": hideLabel
        })
    }, readOnly && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$ReadOnlyIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ReadOnlyIconWithTitle"], null), label), !!description && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__["BodyShort"], {
        as: "div",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-form-field__description", {
            "aksel-sr-only": hideLabel
        }),
        id: inputDescriptionId,
        size: size
    }, description), /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", {
        className: "aksel-combobox__wrapper"
    }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$InputController$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InputController"], Object.assign({
        ref: ref
    }, rest)), /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$FilteredOptions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], null)), /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", {
        className: "aksel-form-field__error",
        id: errorId,
        "aria-relevant": "additions removals",
        "aria-live": "polite"
    }, showErrorMsg && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$ErrorMessage$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ErrorMessage$3e$__["ErrorMessage"], {
        size: size,
        showIcon: true
    }, error))));
}, "RXlSOy2MLKz1R3m5c6ErJkICw6I=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInputContext"]
    ];
})), "RXlSOy2MLKz1R3m5c6ErJkICw6I=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInputContext"]
    ];
});
_c1 = Combobox;
const __TURBOPACK__default__export__ = Combobox;
var _c, _c1;
__turbopack_context__.k.register(_c, "Combobox$forwardRef");
__turbopack_context__.k.register(_c1, "Combobox");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=Combobox.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/ComboboxProvider.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Combobox$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/Combobox.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filteredOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/FilteredOptions/filteredOptionsContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/Input/Input.context.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$SelectedOptions$2f$selectedOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/SelectedOptions/selectedOptionsContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$combobox$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/combobox-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$customOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/customOptionsContext.js [app-client] (ecmascript)");
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
;
;
;
;
/**
 * A component that allows the user to search in a list of options
 *
 * Has options for allowing only one or multiple options to be selected,
 * or adding new, user-submitted values.
 *
 * @see [📝 Documentation](https://aksel.nav.no/komponenter/core/combobox)
 *
 * @example
 * ```jsx
 * const options = ["apple", "banana", "orange"];
 *
 * return (
 *    <Combobox
 *      label="Velg en verdi"
 *      options={options}
 *      id="my-combobox"
 *      shouldAutoComplete
 *    />
 * )
 * ```
 */ const ComboboxProvider = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = (props, ref)=>{
    const { allowNewValues = false, children, defaultValue, disabled, readOnly, error, errorId, filteredOptions: externalFilteredOptions, id, isListOpen, isLoading = false, isMultiSelect, onToggleSelected, selectedOptions: externalSelectedOptions, maxSelected, options: externalOptions, value, onChange, onClear, shouldAutocomplete: externalShouldAutocomplete, size } = props, rest = __rest(props, [
        "allowNewValues",
        "children",
        "defaultValue",
        "disabled",
        "readOnly",
        "error",
        "errorId",
        "filteredOptions",
        "id",
        "isListOpen",
        "isLoading",
        "isMultiSelect",
        "onToggleSelected",
        "selectedOptions",
        "maxSelected",
        "options",
        "value",
        "onChange",
        "onClear",
        "shouldAutocomplete",
        "size"
    ]);
    const options = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$combobox$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mapToComboboxOptionArray"])(externalOptions) || [];
    const filteredOptions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$combobox$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mapToComboboxOptionArray"])(externalFilteredOptions);
    const selectedOptions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$combobox$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mapToComboboxOptionArray"])(externalSelectedOptions);
    const userAgent = typeof navigator === "undefined" ? "" : navigator.userAgent;
    const isFirefoxOnAndroid = userAgent.includes("Android") && userAgent.includes("Firefox/");
    const shouldAutocomplete = !isFirefoxOnAndroid && externalShouldAutocomplete;
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Input$2f$Input$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InputContextProvider"], {
        value: {
            defaultValue,
            description: rest.description,
            disabled,
            readOnly,
            error,
            errorId,
            id,
            value,
            onChange,
            onClear,
            shouldAutocomplete,
            size
        }
    }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$customOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CustomOptionsProvider"], {
        value: {
            isMultiSelect
        }
    }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$SelectedOptions$2f$selectedOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectedOptionsProvider"], {
        value: {
            allowNewValues,
            isMultiSelect,
            selectedOptions,
            maxSelected,
            onToggleSelected,
            options
        }
    }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$FilteredOptions$2f$filteredOptionsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FilteredOptionsProvider"], {
        value: {
            allowNewValues,
            filteredOptions,
            isListOpen,
            isLoading,
            options
        }
    }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$Combobox$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], Object.assign({
        ref: ref
    }, rest), children)))));
});
_c1 = ComboboxProvider;
const __TURBOPACK__default__export__ = ComboboxProvider;
var _c, _c1;
__turbopack_context__.k.register(_c, "ComboboxProvider$forwardRef");
__turbopack_context__.k.register(_c1, "ComboboxProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=ComboboxProvider.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/ComboboxProvider.js [app-client] (ecmascript) <export default as UNSAFE_Combobox>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "UNSAFE_Combobox",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$ComboboxProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$ComboboxProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/ComboboxProvider.js [app-client] (ecmascript)");
}),
]);

//# sourceMappingURL=4722a_%40navikt_ds-react_esm_form_740b2a03._.js.map