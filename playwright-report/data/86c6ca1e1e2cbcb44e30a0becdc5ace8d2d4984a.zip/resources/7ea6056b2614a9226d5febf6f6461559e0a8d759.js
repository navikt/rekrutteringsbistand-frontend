(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/public/arbeidsplassen.png (static in ecmascript, tag client)", ((__turbopack_context__) => {

__turbopack_context__.v("/_next/static/media/arbeidsplassen.94266e8a.png");}),
"[project]/public/arbeidsplassen.png.mjs { IMAGE => \"[project]/public/arbeidsplassen.png (static in ecmascript, tag client)\" } [app-client] (structured image object with data url, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$arbeidsplassen$2e$png__$28$static__in__ecmascript$2c$__tag__client$29$__ = __turbopack_context__.i("[project]/public/arbeidsplassen.png (static in ecmascript, tag client)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$arbeidsplassen$2e$png__$28$static__in__ecmascript$2c$__tag__client$29$__["default"],
    width: 192,
    height: 192,
    blurWidth: 8,
    blurHeight: 8,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAvUlEQVR42l2PwQoBURSG7zCys7DxAiKxGSNqbNxGpNmibEwmZK2UsZQVJVE0SsqLzHt4EJa/e+7VFItTp/N/5z//YUzTYiyV5ixfCZnBX7JyZihnpMmmaD1Z2cZP0Yw0SYtBxunD2azRWPoouBMFkStZxqstuNcTuL9Cd7/FMDgqwOBvCei1Nsb3C7KDEerzhYQ1s6kgaSOakjfD9BHAu53RO+xASwr4htRMG0mrg4QQdHEyChu9SWHp5t83Hz9jXN1n0UvZAAAAAElFTkSuQmCC"
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/public/nav.svg (static in ecmascript, tag client)", ((__turbopack_context__) => {

__turbopack_context__.v("/_next/static/media/nav.ecfc4da9.svg");}),
"[project]/public/nav.svg.mjs { IMAGE => \"[project]/public/nav.svg (static in ecmascript, tag client)\" } [app-client] (structured image object with data url, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$nav$2e$svg__$28$static__in__ecmascript$2c$__tag__client$29$__ = __turbopack_context__.i("[project]/public/nav.svg (static in ecmascript, tag client)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$nav$2e$svg__$28$static__in__ecmascript$2c$__tag__client$29$__["default"],
    width: 22,
    height: 22,
    blurWidth: 0,
    blurHeight: 0
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/public/illustrasjoner/figur-med-verktøy.svg (static in ecmascript, tag client)", ((__turbopack_context__) => {

__turbopack_context__.v("/_next/static/media/figur-med-verktøy.82d08e36.svg");}),
"[project]/public/illustrasjoner/figur-med-verktøy.svg.mjs { IMAGE => \"[project]/public/illustrasjoner/figur-med-verktøy.svg (static in ecmascript, tag client)\" } [app-client] (structured image object with data url, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$illustrasjoner$2f$figur$2d$med$2d$verkt$f8$y$2e$svg__$28$static__in__ecmascript$2c$__tag__client$29$__ = __turbopack_context__.i("[project]/public/illustrasjoner/figur-med-verktøy.svg (static in ecmascript, tag client)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$illustrasjoner$2f$figur$2d$med$2d$verkt$f8$y$2e$svg__$28$static__in__ecmascript$2c$__tag__client$29$__["default"],
    width: 158,
    height: 188,
    blurWidth: 0,
    blurHeight: 0
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/util/tekst.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>formaterMedStoreOgSmåBokstaver
]);
const skalVæreMedSmåBokstaver = [
    'i',
    'og',
    'for',
    'på',
    'avd',
    'av'
];
const skalVæreMedStoreBokstaver = [
    'as',
    'ab',
    'asa',
    'ba',
    'sa'
];
function formaterMedStoreOgSmåBokstaver(tekst) {
    if (!tekst) return undefined;
    let formatert = tekst.toLowerCase();
    formatert = gjørFørsteBokstavEtterSeparatorStor(formatert, ' ');
    formatert = gjørFørsteBokstavEtterSeparatorStor(formatert, '-');
    formatert = gjørFørsteBokstavEtterSeparatorStor(formatert, '(');
    formatert = gjørFørsteBokstavEtterSeparatorStor(formatert, '/');
    return formatert;
}
const gjørFørsteBokstavEtterSeparatorStor = (setning, separator)=>{
    const splittet = setning.split(separator);
    return splittet.map(formaterOrd).join(separator);
};
const formaterOrd = (ord)=>{
    if (skalVæreMedStoreBokstaver.includes(ord)) {
        return ord.toUpperCase();
    } else if (!skalVæreMedSmåBokstaver.includes(ord)) {
        const førsteBokstav = ord[0];
        return førsteBokstav === undefined ? ord : førsteBokstav.toUpperCase() + ord.substring(1);
    } else {
        return ord;
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/util/fylkeOgKommuneMapping.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "aggregateKommunebuckets",
    ()=>aggregateKommunebuckets,
    "expandKommunekoder",
    ()=>expandKommunekoder,
    "formaterStedsnavn",
    ()=>formaterStedsnavn,
    "fylkesnavnTilKode",
    ()=>fylkesnavnTilKode,
    "getNummerFraSted",
    ()=>getNummerFraSted,
    "lagKandidatsøkstreng",
    ()=>lagKandidatsøkstreng,
    "normaliserKommunekode",
    ()=>normaliserKommunekode,
    "stedmappingFraGammeltNavn",
    ()=>stedmappingFraGammeltNavn,
    "stedmappingFraGammeltNummer",
    ()=>stedmappingFraGammeltNummer,
    "stedmappingFraNyttNavn",
    ()=>stedmappingFraNyttNavn,
    "stedmappingFraNyttNummer",
    ()=>stedmappingFraNyttNummer
]);
// Bruk dennne i steden for gammel fil, som skal bort på grunn av uoptimal kompleksitet.
const stedmappingRaw = new Map([
    // Oslo
    [
        'Oslo.0301',
        [
            'Oslo.03'
        ]
    ],
    // Kontinentalsokkelen
    // Vestland
    [
        'Vestland.46',
        [
            'Hordaland.12',
            'Sogn og Fjordane.14'
        ]
    ],
    [
        'Bergen.4601',
        [
            'Bergen.1201'
        ]
    ],
    [
        'Kinn.4602',
        [
            'Flora.1401',
            'Vågsøy.1439'
        ]
    ],
    [
        'Etne.4611',
        [
            'Etne.1211'
        ]
    ],
    [
        'Sveio.4612',
        [
            'Sveio.1216'
        ]
    ],
    [
        'Bømlo.4613',
        [
            'Bømlo.1219'
        ]
    ],
    [
        'Stord.4614',
        [
            'Stord.1221'
        ]
    ],
    [
        'Fitjar.4615',
        [
            'Fitjar.1222'
        ]
    ],
    [
        'Tysnes.4616',
        [
            'Tysnes.1223'
        ]
    ],
    [
        'Kvinnherad.4617',
        [
            'Kvinnherad.1224'
        ]
    ],
    [
        'Ullensvang.4618',
        [
            'Jondal.1227',
            'Odda.1228',
            'Ullensvang.1231'
        ]
    ],
    [
        'Ulvik.4620',
        [
            'Ulvik.1233'
        ]
    ],
    [
        'Voss.4621',
        [
            'Voss.1235',
            'Granvin.1234'
        ]
    ],
    [
        'Eidfjord.4619',
        [
            'Eidfjord.1232'
        ]
    ],
    [
        'Kvam.4622',
        [
            'Kvam.1238'
        ]
    ],
    [
        'Samnanger.4623',
        [
            'Samnanger.1242'
        ]
    ],
    [
        'Bjørnafjorden.4624',
        [
            'Os.1243',
            'Fusa.1241'
        ]
    ],
    [
        'Austevoll.4625',
        [
            'Austevoll.1244'
        ]
    ],
    [
        'Øygarden.4626',
        [
            'Sund.1245',
            'Fjell.1246',
            'Øygarden.1259'
        ]
    ],
    [
        'Askøy.4627',
        [
            'Askøy.1247'
        ]
    ],
    [
        'Vaksdal.4628',
        [
            'Vaksdal.1251'
        ]
    ],
    [
        'Modalen.4629',
        [
            'Modalen.1252'
        ]
    ],
    [
        'Osterøy.4630',
        [
            'Osterøy.1253'
        ]
    ],
    [
        'Alver.4631',
        [
            'Lindås.1263',
            'Meland.1256',
            'Radøy.1260'
        ]
    ],
    [
        'Austrheim.4632',
        [
            'Austrheim.1264'
        ]
    ],
    [
        'Fedje.4633',
        [
            'Fedje.1265'
        ]
    ],
    [
        'Masfjorden.4634',
        [
            'Masfjorden.1266'
        ]
    ],
    [
        'Gulen.4635',
        [
            'Gulen.1411'
        ]
    ],
    [
        'Solund.4636',
        [
            'Solund.1412'
        ]
    ],
    [
        'Hyllestad.4637',
        [
            'Hyllestad.1413'
        ]
    ],
    [
        'Høyanger.4638',
        [
            'Høyanger.1416'
        ]
    ],
    [
        'Vik.4639',
        [
            'Vik.1417'
        ]
    ],
    [
        'Sogndal.4640',
        [
            'Balestrand.1418',
            'Leikanger.1419',
            'Sogndal.1420'
        ]
    ],
    [
        'Aurland.4641',
        [
            'Aurland.1421'
        ]
    ],
    [
        'Lærdal.4642',
        [
            'Lærdal.1422'
        ]
    ],
    [
        'Luster.4644',
        [
            'Luster.1426'
        ]
    ],
    [
        'Askvoll.4645',
        [
            'Askvoll.1428'
        ]
    ],
    [
        'Fjaler.4646',
        [
            'Fjaler.1429'
        ]
    ],
    [
        'Sunnfjord.4647',
        [
            'Førde.1432',
            'Gaular.1430',
            'Jølster.1431',
            'Naustdal.1433'
        ]
    ],
    [
        'Bremanger.4648',
        [
            'Bremanger.1438'
        ]
    ],
    [
        'Stad.4649',
        [
            'Selje.1441',
            'Eid.1443'
        ]
    ],
    [
        'Gloppen.4650',
        [
            'Gloppen.1445'
        ]
    ],
    [
        'Stryn.4651',
        [
            'Stryn.1449'
        ]
    ],
    [
        'Årdal.4643',
        [
            'Årdal.1424'
        ]
    ],
    // Akershus
    [
        'Akershus.32',
        [
            'Akershus.02',
            'Viken.30'
        ]
    ],
    [
        'Bærum.3201',
        [
            'Bærum.0219',
            'Bærum.3024'
        ]
    ],
    [
        'Lillestrøm.3205',
        [
            'Skedsmo.0231',
            'Sørum.0226',
            'Fet.0227',
            'Lillestrøm.3030'
        ]
    ],
    [
        'Asker.3203',
        [
            'Asker.0220',
            'Asker.3025',
            'Røyken.0627',
            'Hurum.0628'
        ]
    ],
    [
        'Nordre Follo.3207',
        [
            'Ski.0213',
            'Oppegård.0217',
            'Nordre Follo.3020'
        ]
    ],
    [
        'Ullensaker.3209',
        [
            'Ullensaker.0235',
            'Ullensaker.3033'
        ]
    ],
    [
        'Nesodden.3212',
        [
            'Nesodden.0216',
            'Nesodden.3023'
        ]
    ],
    [
        'Frogn.3214',
        [
            'Frogn.0215',
            'Frogn.3022'
        ]
    ],
    [
        'Vestby.3216',
        [
            'Vestby.0211',
            'Vestby.3019'
        ]
    ],
    [
        'Ås.3218',
        [
            'Ås.0214',
            'Ås.3021'
        ]
    ],
    [
        'Enebakk.3220',
        [
            'Enebakk.0229',
            'Enebakk.3028'
        ]
    ],
    [
        'Lørenskog.3222',
        [
            'Lørenskog.0230',
            'Lørenskog.3029'
        ]
    ],
    [
        'Rælingen.3224',
        [
            'Rælingen.0228',
            'Rælingen.3027'
        ]
    ],
    [
        'Nes.3228',
        [
            'Nes.0236',
            'Nes.3034'
        ]
    ],
    [
        'Gjerdrum.3230',
        [
            'Gjerdrum.0234',
            'Gjerdrum.3032'
        ]
    ],
    [
        'Nittedal.3232',
        [
            'Nittedal.0233',
            'Nittedal.3031'
        ]
    ],
    [
        'Aurskog-Høland.3226',
        [
            'Aurskog-Høland.0221',
            'Aurskog-Høland.3026',
            'Rømskog.0121'
        ]
    ],
    [
        'Lunner.3234',
        [
            'Lunner.0533',
            'Lunner.3054'
        ]
    ],
    [
        'Jevnaker.3236',
        [
            'Jevnaker.0532',
            'Jevnaker.3053'
        ]
    ],
    [
        'Nannestad.3238',
        [
            'Nannestad.0238',
            'Nannestad.3036'
        ]
    ],
    [
        'Eidsvoll.3240',
        [
            'Eidsvoll.0237',
            'Eidsvoll.3035'
        ]
    ],
    [
        'Hurdal.3242',
        [
            'Hurdal.0239',
            'Hurdal.3037'
        ]
    ],
    // Buskerud
    [
        'Buskerud.33',
        [
            'Buskerud.06',
            'Viken.30'
        ]
    ],
    [
        'Drammen.3301',
        [
            'Drammen.0602',
            'Svelvik.0711',
            'Nedre Eiker.0625',
            'Drammen.3005'
        ]
    ],
    [
        'Kongsberg.3303',
        [
            'Kongsberg.0604',
            'Kongsberg.3006'
        ]
    ],
    [
        'Ringerike.3305',
        [
            'Ringerike.0605',
            'Ringerike.3007'
        ]
    ],
    [
        'Hole.3310',
        [
            'Hole.0612',
            'Hole.3038'
        ]
    ],
    [
        'Lier.3312',
        [
            'Lier.0626',
            'Lier.3049'
        ]
    ],
    [
        'Øvre Eiker.3314',
        [
            'Øvre Eiker.0624',
            'Øvre Eiker.3048'
        ]
    ],
    [
        'Modum.3316',
        [
            'Modum.0623',
            'Modum.3047'
        ]
    ],
    [
        'Krødsherad.3318',
        [
            'Krødsherad.0622',
            'Krødsherad.3046'
        ]
    ],
    [
        'Flå.3320',
        [
            'Flå.0615',
            'Flå.3039'
        ]
    ],
    [
        'Nesbyen.3322',
        [
            'Nes.0616',
            'Nesbyen.3040'
        ]
    ],
    [
        'Gol.3324',
        [
            'Gol.0617',
            'Gol.3041'
        ]
    ],
    [
        'Hemsedal.3326',
        [
            'Hemsedal.0618',
            'Hemsedal.3042'
        ]
    ],
    [
        'Ål.3328',
        [
            'Ål.0619',
            'Ål.3043'
        ]
    ],
    [
        'Hol.3330',
        [
            'Hol.0620',
            'Hol.3044'
        ]
    ],
    [
        'Sigdal.3332',
        [
            'Sigdal.0621',
            'Sigdal.3045'
        ]
    ],
    [
        'Flesberg.3334',
        [
            'Flesberg.0631',
            'Flesberg.3050'
        ]
    ],
    [
        'Rollag.3336',
        [
            'Rollag.0632',
            'Rollag.3051'
        ]
    ],
    [
        'Nore og Uvdal.3338',
        [
            'Nore og Uvdal.0633',
            'Nore og Uvdal.3052'
        ]
    ],
    // Innlandet
    [
        'Innlandet.34',
        [
            'Hedmark.04',
            'Oppland.05'
        ]
    ],
    [
        'Kongsvinger.3401',
        [
            'Kongsvinger.0402'
        ]
    ],
    [
        'Hamar.3403',
        [
            'Hamar.0403'
        ]
    ],
    [
        'Lillehammer.3405',
        [
            'Lillehammer.0501'
        ]
    ],
    [
        'Gjøvik.3407',
        [
            'Gjøvik.0502'
        ]
    ],
    [
        'Ringsaker.3411',
        [
            'Ringsaker.0412'
        ]
    ],
    [
        'Løten.3412',
        [
            'Løten.0415'
        ]
    ],
    [
        'Stange.3413',
        [
            'Stange.0417'
        ]
    ],
    [
        'Nord-Odal.3414',
        [
            'Nord-Odal.0418'
        ]
    ],
    [
        'Sør-Odal.3415',
        [
            'Sør-Odal.0419'
        ]
    ],
    [
        'Eidskog.3416',
        [
            'Eidskog.0420'
        ]
    ],
    [
        'Grue.3417',
        [
            'Grue.0423'
        ]
    ],
    [
        'Åsnes.3418',
        [
            'Åsnes.0425'
        ]
    ],
    [
        'Våler.3419',
        [
            'Våler.0426'
        ]
    ],
    [
        'Elverum.3420',
        [
            'Elverum.0427'
        ]
    ],
    [
        'Trysil.3421',
        [
            'Trysil.0428'
        ]
    ],
    [
        'Åmot.3422',
        [
            'Åmot.0429'
        ]
    ],
    [
        'Stor-Elvdal.3423',
        [
            'Stor-Elvdal.0430'
        ]
    ],
    [
        'Rendalen.3424',
        [
            'Rendalen.0432'
        ]
    ],
    [
        'Engerdal.3425',
        [
            'Engerdal.0434'
        ]
    ],
    [
        'Tolga.3426',
        [
            'Tolga.0436'
        ]
    ],
    [
        'Tynset.3427',
        [
            'Tynset.0437'
        ]
    ],
    [
        'Alvdal.3428',
        [
            'Alvdal.0438'
        ]
    ],
    [
        'Folldal.3429',
        [
            'Folldal.0439'
        ]
    ],
    [
        'Os.3430',
        [
            'Os.0441'
        ]
    ],
    [
        'Dovre.3431',
        [
            'Dovre.0511'
        ]
    ],
    [
        'Lesja.3432',
        [
            'Lesja.0512'
        ]
    ],
    [
        'Skjåk.3433',
        [
            'Skjåk.0513'
        ]
    ],
    [
        'Lom.3434',
        [
            'Lom.0514'
        ]
    ],
    [
        'Vågå.3435',
        [
            'Vågå.0515'
        ]
    ],
    [
        'Nord-Fron.3436',
        [
            'Nord-Fron.0516'
        ]
    ],
    [
        'Sel.3437',
        [
            'Sel.0517'
        ]
    ],
    [
        'Sør-Fron.3438',
        [
            'Sør-Fron.0519'
        ]
    ],
    [
        'Ringebu.3439',
        [
            'Ringebu.0520'
        ]
    ],
    [
        'Øyer.3440',
        [
            'Øyer.0521'
        ]
    ],
    [
        'Gausdal.3441',
        [
            'Gausdal.0522'
        ]
    ],
    [
        'Østre Toten.3442',
        [
            'Østre Toten.0528'
        ]
    ],
    [
        'Vestre Toten.3443',
        [
            'Vestre Toten.0529'
        ]
    ],
    [
        'Gran.3446',
        [
            'Gran.0534'
        ]
    ],
    [
        'Søndre Land.3447',
        [
            'Søndre Land.0536'
        ]
    ],
    [
        'Nordre Land.3448',
        [
            'Nordre Land.0538'
        ]
    ],
    [
        'Sør-Aurdal.3449',
        [
            'Sør-Aurdal.0540'
        ]
    ],
    [
        'Etnedal.3450',
        [
            'Etnedal.0541'
        ]
    ],
    [
        'Nord-Aurdal.3451',
        [
            'Nord-Aurdal.0542'
        ]
    ],
    [
        'Vestre Slidre.3452',
        [
            'Vestre Slidre.0543'
        ]
    ],
    [
        'Øystre Slidre.3453',
        [
            'Øystre Slidre.0544'
        ]
    ],
    [
        'Vang.3454',
        [
            'Vang.0545'
        ]
    ],
    // Møre og Romsdal
    [
        'Molde.1506',
        [
            'Molde.1502',
            'Midsund.1545',
            'Nesset.1543'
        ]
    ],
    [
        'Ålesund.1508',
        [
            'Ålesund.1504',
            'Haram.1534',
            'Sandøy.1546',
            'Skodje.1529',
            'Ørskog.1523',
            'Ålesund.1507'
        ]
    ],
    [
        'Volda.1577',
        [
            'Volda.1519',
            'Hornindal.1444'
        ]
    ],
    [
        'Fjord.1578',
        [
            'Norddal.1524',
            'Stordal.1526'
        ]
    ],
    [
        'Hustadvika.1579',
        [
            'Fræna.1548',
            'Eide.1551'
        ]
    ],
    [
        'Haram.1580',
        [
            'Haram.1534',
            'Ålesund.1507'
        ]
    ],
    // Telemark
    [
        'Telemark.40',
        [
            'Telemark.08',
            'Vestfold og Telemark.38'
        ]
    ],
    [
        'Porsgrunn.4001',
        [
            'Porsgrunn.0805',
            'Porsgrunn.3806'
        ]
    ],
    [
        'Skien.4003',
        [
            'Skien.0806',
            'Skien.3807'
        ]
    ],
    [
        'Notodden.4005',
        [
            'Notodden.0807',
            'Notodden.3808'
        ]
    ],
    [
        'Siljan.4010',
        [
            'Siljan.0811',
            'Siljan.3812'
        ]
    ],
    [
        'Bamble.4012',
        [
            'Bamble.0814',
            'Bamble.3813'
        ]
    ],
    [
        'Kragerø.4014',
        [
            'Kragerø.0815',
            'Kragerø.3814'
        ]
    ],
    [
        'Drangedal.4016',
        [
            'Drangedal.0817',
            'Drangedal.3815'
        ]
    ],
    [
        'Nome.4018',
        [
            'Nome.0819',
            'Nome.3816'
        ]
    ],
    [
        'Midt-Telemark.4020',
        [
            'Bø (Telemark).0821',
            'Sauherad.0822',
            'Midt-Telemark.3817'
        ]
    ],
    [
        'Seljord.4022',
        [
            'Seljord.0828',
            'Seljord.3820'
        ]
    ],
    [
        'Hjartdal.4024',
        [
            'Hjartdal.0827',
            'Hjartdal.3819'
        ]
    ],
    [
        'Tinn.4026',
        [
            'Tinn.0826',
            'Tinn.3818'
        ]
    ],
    [
        'Kviteseid.4028',
        [
            'Kviteseid.0829',
            'Kviteseid.3821'
        ]
    ],
    [
        'Nissedal.4030',
        [
            'Nissedal.0830',
            'Nissedal.3822'
        ]
    ],
    [
        'Fyresdal.4032',
        [
            'Fyresdal.0831',
            'Fyresdal.3823'
        ]
    ],
    [
        'Tokke.4034',
        [
            'Tokke.0833',
            'Tokke.3824'
        ]
    ],
    [
        'Vinje.4036',
        [
            'Vinje.0834',
            'Vinje.3825'
        ]
    ],
    // Rogaland
    [
        'Stavanger.1103',
        [
            'Finnøy.1141',
            'Rennesøy.1142'
        ]
    ],
    [
        'Sandnes.1108',
        [
            'Sandnes.1102',
            'Forsand.1129'
        ]
    ],
    // Nordland
    [
        'Narvik.1806',
        [
            'Narvik.1805',
            'Ballangen.1854',
            'Tysfjord.1850'
        ]
    ],
    [
        'Hamarøy.1875',
        [
            'Hamarøy.1849',
            'Tysfjord.1850'
        ]
    ],
    // Trøndelag
    [
        'Trøndelag.50',
        [
            'Sør-Trøndelag.16',
            'Nord-Trøndelag.17'
        ]
    ],
    [
        'Trondheim.5001',
        [
            'Trondheim.1601',
            'Klæbu.1662',
            'Klæbu.5030'
        ]
    ],
    [
        'Steinkjer.5006',
        [
            'Steinkjer.1702',
            'Verran.1724',
            'Steinkjer.5004',
            'Verran.5039'
        ]
    ],
    [
        'Namsos.5007',
        [
            'Namsos.1703',
            'Namdalseid.1725',
            'Fosnes.1748',
            'Namsos.5005',
            'Namdalseid.5040',
            'Fosnes.5048'
        ]
    ],
    [
        'Frøya.5014',
        [
            'Frøya.1620'
        ]
    ],
    [
        'Osen.5020',
        [
            'Osen.1633'
        ]
    ],
    [
        'Oppdal.5021',
        [
            'Oppdal.1634'
        ]
    ],
    [
        'Rennebu.5022',
        [
            'Rennebu.1635'
        ]
    ],
    [
        'Røros.5025',
        [
            'Røros.1640'
        ]
    ],
    [
        'Holtålen.5026',
        [
            'Holtålen.1644'
        ]
    ],
    [
        'Midtre Gauldal.5027',
        [
            'Midtre Gauldal.1648'
        ]
    ],
    [
        'Melhus.5028',
        [
            'Melhus.1653'
        ]
    ],
    [
        'Skaun.5029',
        [
            'Skaun.1657'
        ]
    ],
    [
        'Malvik.5031',
        [
            'Malvik.1663'
        ]
    ],
    [
        'Selbu.5032',
        [
            'Selbu.1664'
        ]
    ],
    [
        'Tydal.5033',
        [
            'Tydal.1665'
        ]
    ],
    [
        'Meråker.5034',
        [
            'Meråker.1711'
        ]
    ],
    [
        'Stjørdal.5035',
        [
            'Stjørdal.1714'
        ]
    ],
    [
        'Frosta.5036',
        [
            'Frosta.1717'
        ]
    ],
    [
        'Levanger.5037',
        [
            'Levanger.1719'
        ]
    ],
    [
        'Verdal.5038',
        [
            'Verdal.1721'
        ]
    ],
    [
        'Snåase - Snåsa.5041',
        [
            'Snåase - Snåsa.1736'
        ]
    ],
    [
        'Lierne.5042',
        [
            'Lierne.1738'
        ]
    ],
    [
        'Raarvihke - Røyrvik.5043',
        [
            'Raarvihke - Røyrvik.1739'
        ]
    ],
    [
        'Namsskogan.5044',
        [
            'Namsskogan.1740'
        ]
    ],
    [
        'Grong.5045',
        [
            'Grong.1742'
        ]
    ],
    [
        'Høylandet.5046',
        [
            'Høylandet.1743'
        ]
    ],
    [
        'Overhalla.5047',
        [
            'Overhalla.1744'
        ]
    ],
    [
        'Flatanger.5049',
        [
            'Flatanger.1749'
        ]
    ],
    [
        'Leka.5052',
        [
            'Leka.1755'
        ]
    ],
    [
        'Inderøy.5053',
        [
            'Inderøy.1756',
            'Mosvik.1723',
            'Sandvollan.1729'
        ]
    ],
    [
        'Indre Fosen.5054',
        [
            'Rissa.1624',
            'Leksvik.1718'
        ]
    ],
    [
        'Heim.5055',
        [
            'Hemne.1612',
            'Halsa.1571',
            'Snillfjord.1613',
            'Hemne.5011',
            'Snillfjord.5012'
        ]
    ],
    [
        'Hitra.5056',
        [
            'Hitra.1617',
            'Snillfjord.1613',
            'Hitra.5013',
            'Snillfjord.5012'
        ]
    ],
    [
        'Ørland.5057',
        [
            'Ørland.1621',
            'Bjugn.1627',
            'Ørland.5015',
            'Bjugn.5017'
        ]
    ],
    [
        'Åfjord.5058',
        [
            'Åfjord.1630',
            'Roan.1632',
            'Åfjord.5018',
            'Roan.5019'
        ]
    ],
    [
        'Orkland.5059',
        [
            'Orkdal.1638',
            'Agdenes.1622',
            'Meldal.1636',
            'Snillfjord.1613',
            'Orkdal.5024',
            'Agdenes.5016',
            'Meldal.5023',
            'Snillfjord.5012'
        ]
    ],
    [
        'Nærøysund.5060',
        [
            'Vikna.1750',
            'Nærøy.1751',
            'Vikna.5050',
            'Nærøy.5051'
        ]
    ],
    [
        'Rindal.5061',
        [
            'Rindal.1567',
            'Rindal.5061'
        ]
    ],
    // Finnmark
    [
        'Finnmark.56',
        [
            'Finnmark.20',
            'Troms og Finnmark.54'
        ]
    ],
    [
        'Alta.5601',
        [
            'Alta.2012',
            'Alta.5403'
        ]
    ],
    [
        'Hammerfest.5603',
        [
            'Hammerfest.2004',
            'Kvalsund.2017',
            'Hammerfest.5406',
            'Hammerfest.2001',
            'Hammerfest.2016'
        ]
    ],
    [
        'Sør-Varanger.5605',
        [
            'Sør-Varanger.2030',
            'Sør-Varanger.5444'
        ]
    ],
    [
        'Vadsø.5607',
        [
            'Vadsø.2003',
            'Vadsø.5405'
        ]
    ],
    [
        'Karasjok.5610',
        [
            'Karasjok.2021',
            'Karasjok.5437'
        ]
    ],
    [
        'Kautokeino.5612',
        [
            'Kautokeino.2011',
            'Kautokeino.5430'
        ]
    ],
    [
        'Loppa.5614',
        [
            'Loppa.2014',
            'Loppa.5432'
        ]
    ],
    [
        'Hasvik.5616',
        [
            'Hasvik.2015',
            'Hasvik.5433'
        ]
    ],
    [
        'Måsøy.5618',
        [
            'Måsøy.2018',
            'Måsøy.5434'
        ]
    ],
    [
        'Nordkapp.5620',
        [
            'Nordkapp.2019',
            'Nordkapp.5435'
        ]
    ],
    [
        'Porsanger.5622',
        [
            'Porsanger.2020',
            'Porsanger.5436'
        ]
    ],
    [
        'Lebesby.5624',
        [
            'Lebesby.2022',
            'Lebesby.5438'
        ]
    ],
    [
        'Gamvik.5626',
        [
            'Gamvik.2023',
            'Gamvik.5439'
        ]
    ],
    [
        'Tana.5628',
        [
            'Tana.2025',
            'Tana.5441'
        ]
    ],
    [
        'Berlevåg.5630',
        [
            'Berlevåg.2024',
            'Berlevåg.5440'
        ]
    ],
    [
        'Båtsfjord.5632',
        [
            'Båtsfjord.2028',
            'Båtsfjord.5443'
        ]
    ],
    [
        'Vardø.5634',
        [
            'Vardø.2002',
            'Vardø.5404'
        ]
    ],
    [
        'Nesseby.5636',
        [
            'Nesseby.2027',
            'Nesseby.5442'
        ]
    ],
    // Østfold
    [
        'Østfold.31',
        [
            'Østfold.01',
            'Viken.30'
        ]
    ],
    [
        'Halden.3101',
        [
            'Halden.0101',
            'Halden.3001'
        ]
    ],
    [
        'Moss.3103',
        [
            'Moss.0104',
            'Rygge.0136',
            'Moss.3002'
        ]
    ],
    [
        'Sarpsborg.3105',
        [
            'Sarpsborg.0105',
            'Sarpsborg.3003'
        ]
    ],
    [
        'Fredrikstad.3107',
        [
            'Fredrikstad.0106',
            'Fredrikstad.3004'
        ]
    ],
    [
        'Hvaler.3110',
        [
            'Hvaler.0111',
            'Hvaler.3011'
        ]
    ],
    [
        'Råde.3112',
        [
            'Råde.0135',
            'Råde.3017'
        ]
    ],
    [
        'Våler.3114',
        [
            'Våler.0137',
            'Våler.3018'
        ]
    ],
    [
        'Skiptvet.3116',
        [
            'Skiptvet.0127',
            'Skiptvet.3015'
        ]
    ],
    [
        'Indre Østfold.3118',
        [
            'Trøgstad.0122',
            'Spydeberg.0123',
            'Askim.0124',
            'Eidsberg.0125',
            'Hobøl.0138',
            'Indre Østfold.3014'
        ]
    ],
    [
        'Rakkestad.3120',
        [
            'Rakkestad.0128',
            'Rakkestad.3016'
        ]
    ],
    [
        'Marker.3122',
        [
            'Marker.0119',
            'Marker.3013'
        ]
    ],
    [
        'Aremark.3124',
        [
            'Aremark.0118',
            'Aremark.3012'
        ]
    ],
    // Agder
    [
        'Agder.42',
        [
            'Aust-Agder.09',
            'Vest-Agder.10'
        ]
    ],
    [
        'Risør.4201',
        [
            'Risør.0901'
        ]
    ],
    [
        'Grimstad.4202',
        [
            'Grimstad.0904'
        ]
    ],
    [
        'Arendal.4203',
        [
            'Arendal.0906'
        ]
    ],
    [
        'Kristiansand.4204',
        [
            'Kristiansand.1001',
            'Songdalen.1017',
            'Søgne.1018'
        ]
    ],
    [
        'Lindesnes.4205',
        [
            'Mandal.1002',
            'Marnardal.1021',
            'Lindesnes.1029'
        ]
    ],
    [
        'Farsund.4206',
        [
            'Farsund.1003'
        ]
    ],
    [
        'Flekkefjord.4207',
        [
            'Flekkefjord.1004'
        ]
    ],
    [
        'Gjerstad.4211',
        [
            'Gjerstad.0911'
        ]
    ],
    [
        'Vegårshei.4212',
        [
            'Vegårshei.0912'
        ]
    ],
    [
        'Tvedestrand.4213',
        [
            'Tvedestrand.0914'
        ]
    ],
    [
        'Froland.4214',
        [
            'Froland.0919'
        ]
    ],
    [
        'Lillesand.4215',
        [
            'Lillesand.0926'
        ]
    ],
    [
        'Birkenes.4216',
        [
            'Birkenes.0928'
        ]
    ],
    [
        'Åmli.4217',
        [
            'Åmli.0929'
        ]
    ],
    [
        'Iveland.4218',
        [
            'Iveland.0935'
        ]
    ],
    [
        'Evje og Hornnes.4219',
        [
            'Evje og Hornnes.0937'
        ]
    ],
    [
        'Bygland.4220',
        [
            'Bygland.0938'
        ]
    ],
    [
        'Valle.4221',
        [
            'Valle.0940'
        ]
    ],
    [
        'Bykle.4222',
        [
            'Bykle.0941'
        ]
    ],
    [
        'Vennesla.4223',
        [
            'Vennesla.1014'
        ]
    ],
    [
        'Åseral.4224',
        [
            'Åseral.1026'
        ]
    ],
    [
        'Lyngdal.4225',
        [
            'Audnedal.1027',
            'Lyngdal.1032'
        ]
    ],
    [
        'Hægebostad.4226',
        [
            'Hægebostad.1034'
        ]
    ],
    [
        'Kvinesdal.4227',
        [
            'Kvinesdal.1037'
        ]
    ],
    [
        'Sirdal.4228',
        [
            'Sirdal.1046'
        ]
    ],
    // Vestfold
    [
        'Vestfold.39',
        [
            'Vestfold.07',
            'Vestfold og Telemark.38'
        ]
    ],
    [
        'Horten.3901',
        [
            'Horten.0701',
            'Horten.3801'
        ]
    ],
    [
        'Holmestrand.3903',
        [
            'Holmestrand.0715',
            'Holmestrand.3802',
            'Sande (Vestfold).0713',
            'Holmestrand.0702',
            'Hof.0714'
        ]
    ],
    [
        'Tønsberg.3905',
        [
            'Tønsberg.0704',
            'Tønsberg.3803',
            'Re.0716'
        ]
    ],
    [
        'Sandefjord.3907',
        [
            'Sandefjord.0710',
            'Sandefjord.3804',
            'Sandefjord.0706',
            'Andebu.0719',
            'Stokke.0720'
        ]
    ],
    [
        'Larvik.3909',
        [
            'Larvik.0712',
            'Larvik.3805',
            'Larvik.0709',
            'Lardal.0728'
        ]
    ],
    [
        'Færder.3911',
        [
            'Færder.0729',
            'Færder.3811',
            'Nøtterøy.0722',
            'Tjøme.0723'
        ]
    ],
    // Troms
    [
        'Troms.55',
        [
            'Troms.19',
            'Troms og Finnmark.54'
        ]
    ],
    [
        'Tromsø.5501',
        [
            'Tromsø.1902',
            'Tromsø.5401'
        ]
    ],
    [
        'Harstad.5503',
        [
            'Harstad.1903',
            'Harstad.5402',
            'Harstad.1901',
            'Bjarkøy.1915'
        ]
    ],
    [
        'Kvæfjord.5510',
        [
            'Kvæfjord.1911',
            'Kvæfjord.5411'
        ]
    ],
    [
        'Tjeldsund.5512',
        [
            'Skånland.1913',
            'Tjeldsund.1852',
            'Tjeldsund.5412'
        ]
    ],
    [
        'Ibestad.5514',
        [
            'Ibestad.1917',
            'Ibestad.5413'
        ]
    ],
    [
        'Gratangen.5516',
        [
            'Gratangen.1919',
            'Gratangen.5414'
        ]
    ],
    [
        'Lavangen.5518',
        [
            'Lavangen.1920',
            'Lavangen.5415'
        ]
    ],
    [
        'Bardu.5520',
        [
            'Bardu.1922',
            'Bardu.5416'
        ]
    ],
    [
        'Salangen.5522',
        [
            'Salangen.1923',
            'Salangen.5417'
        ]
    ],
    [
        'Målselv.5524',
        [
            'Målselv.1924',
            'Målselv.5418'
        ]
    ],
    [
        'Sørreisa.5526',
        [
            'Sørreisa.1925',
            'Sørreisa.5419'
        ]
    ],
    [
        'Dyrøy.5528',
        [
            'Dyrøy.1926',
            'Dyrøy.5420'
        ]
    ],
    [
        'Senja.5530',
        [
            'Tranøy.1927',
            'Torsken.1928',
            'Berg.1929',
            'Lenvik.1931',
            'Senja.5421'
        ]
    ],
    [
        'Balsfjord.5532',
        [
            'Balsfjord.1933',
            'Balsfjord.5422'
        ]
    ],
    [
        'Karlsøy.5534',
        [
            'Karlsøy.1936',
            'Karlsøy.5423'
        ]
    ],
    [
        'Lyngen.5536',
        [
            'Lyngen.1938',
            'Lyngen.5424'
        ]
    ],
    [
        'Storfjord.5538',
        [
            'Storfjord.1939',
            'Storfjord.5425'
        ]
    ],
    [
        'Kåfjord.5540',
        [
            'Kåfjord.1940',
            'Kåfjord.5426'
        ]
    ],
    [
        'Skjervøy.5542',
        [
            'Skjervøy.1941',
            'Skjervøy.5427'
        ]
    ],
    [
        'Nordreisa.5544',
        [
            'Nordreisa.1942',
            'Nordreisa.5428'
        ]
    ],
    [
        'Kvænangen.5546',
        [
            'Kvænangen.5429',
            'Kvænangen.1943'
        ]
    ]
]);
// Hjelpefunksjoner for geografistrenger
function lagStedFraSting(input) {
    const parts = input.split('.');
    return {
        navn: parts[0],
        nummer: parts[1]
    };
}
const getNummerFraSted = (sted)=>{
    const match = sted.split('.').pop()?.match(/\d+$/);
    return match ? match[0] : '';
};
function lagKandidatsøkstreng(sted) {
    return sted.nummer.length === 2 ? `${sted.navn}.NO${sted.nummer}` : `${sted.navn}.NO${sted.nummer.substring(0, 2)}.${sted.nummer}`;
}
const formaterStedsnavn = (stedsnavn)=>stedsnavn.split(' ').map((s)=>s !== 'i' ? s.charAt(0).toUpperCase() + s.substring(1).toLowerCase() : s).join(' ');
// Oppretter map med Sted objekter fra rådata
const stedmappingNyTilGammel = new Map(Array.from(stedmappingRaw).map(([key, values])=>{
    return [
        lagStedFraSting(key),
        values.map(lagStedFraSting)
    ];
}));
const stedmappingGammelTilNy = new Map(Array.from(stedmappingNyTilGammel).flatMap(([key, values])=>values.map((value)=>[
            value,
            key
        ])));
const stedmappingFraNyttNavn = new Map(Array.from(stedmappingNyTilGammel.entries()).map(([key, values])=>{
    return [
        key.navn,
        values
    ];
}));
const stedmappingFraNyttNummer = new Map(Array.from(stedmappingNyTilGammel.entries()).map(([key, values])=>{
    return [
        key.nummer,
        values
    ];
}));
const stedmappingFraGammeltNavn = new Map(Array.from(stedmappingGammelTilNy.entries()).map(([key, value])=>{
    return [
        key.navn,
        value
    ];
}));
const stedmappingFraGammeltNummer = new Map(Array.from(stedmappingGammelTilNy.entries()).map(([key, value])=>{
    return [
        key.nummer,
        value
    ];
}));
const normaliserKommunekode = (nummer)=>stedmappingFraGammeltNummer.get(nummer)?.nummer || nummer;
const expandKommunekoder = (nye)=>{
    const sett = new Set();
    for (const ny of nye){
        sett.add(ny);
        const gamle = stedmappingFraNyttNummer.get(ny);
        if (gamle) {
            for (const g of gamle)sett.add(g.nummer);
        }
    }
    return Array.from(sett);
};
function aggregateKommunebuckets(buckets = []) {
    const acc = new Map();
    for (const b of buckets){
        const ny = normaliserKommunekode(b.key);
        acc.set(ny, (acc.get(ny) ?? 0) + b.count);
    }
    return Array.from(acc.entries()).map(([key, count])=>({
            key,
            count
        }));
}
// --- Fylkesnavn -> kode mapping (inkluderer historiske / alternative navn) ---
// Kilde: interne administrative endringer + tidligere fylkesnavn.
// Ambiguous "VESTFOLD OG TELEMARK" (historisk sammenslåing) mappes her til TELEMARK (40) for konsistens – juster hvis behov.
const fylkesnavnKodeTabell = [
    [
        [
            'AGDER',
            'AUST-AGDER',
            'VEST-AGDER'
        ],
        '42'
    ],
    [
        [
            'OSLO'
        ],
        '03'
    ],
    [
        [
            'AKERSHUS',
            'VIKEN'
        ],
        '32'
    ],
    [
        [
            'ØSTFOLD'
        ],
        '31'
    ],
    [
        [
            'BUSKERUD'
        ],
        '33'
    ],
    [
        [
            'INNLANDET',
            'HEDMARK',
            'OPPLAND'
        ],
        '34'
    ],
    [
        [
            'TELEMARK',
            'VESTFOLD OG TELEMARK (TELEMARK DEL)',
            'VESTFOLD OG TELEMARK'
        ],
        '40'
    ],
    [
        [
            'VESTFOLD'
        ],
        '39'
    ],
    [
        [
            'ROGALAND'
        ],
        '11'
    ],
    [
        [
            'VESTLAND',
            'HORDALAND',
            'SOGN OG FJORDANE'
        ],
        '46'
    ],
    [
        [
            'MØRE OG ROMSDAL',
            'MORE OG ROMSDAL'
        ],
        '15'
    ],
    [
        [
            'TRØNDELAG',
            'SØR-TRØNDELAG',
            'NORD-TRØNDELAG',
            'TRONDELAG',
            'SOR-TRONDELAG',
            'NORD-TRONDELAG'
        ],
        '50'
    ],
    [
        [
            'NORDLAND'
        ],
        '18'
    ],
    [
        [
            'TROMS',
            'TROMS OG FINNMARK (TROMS DEL)'
        ],
        '55'
    ],
    [
        [
            'FINNMARK',
            'TROMS OG FINNMARK'
        ],
        '56'
    ]
];
const fylkesnavnTilKodeMap = new Map(fylkesnavnKodeTabell.flatMap(([navnListe, kode])=>navnListe.map((n)=>[
            n.toUpperCase(),
            kode
        ])));
function fylkesnavnTilKode(navn) {
    if (!navn) return undefined;
    const key = navn.trim().toUpperCase();
    return fylkesnavnTilKodeMap.get(key);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/util/locationUtil.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>capitalizeLocation,
    "getWorkLocationAsString",
    ()=>getWorkLocationAsString,
    "getWorkLocationsAsString",
    ()=>getWorkLocationsAsString
]);
function getWorkLocationAsString(location) {
    const workLocations = [];
    if (!location) {
        return '';
    }
    if (location.postalCode) {
        let tmp = location.address ? `${location.address}, ` : '';
        tmp += `${location.postalCode} ${capitalizeLocation(location.city ?? '')}`;
        workLocations.push(tmp);
    } else if (location.municipal) {
        workLocations.push(capitalizeLocation(location.municipal));
    } else if (location.county) {
        workLocations.push(capitalizeLocation(location.county));
    } else if (location.country) {
        workLocations.push(capitalizeLocation(location.country));
    }
    const arbeidsSteder = workLocations.join(', ');
    return arbeidsSteder;
}
function getWorkLocationsAsString(locationList) {
    const workLocations = [];
    if (!locationList) {
        return '';
    }
    locationList.forEach((location)=>{
        workLocations.push(getWorkLocationAsString(location));
    });
    const arbeidsSteder = workLocations.join(', ');
    return arbeidsSteder;
}
function capitalizeLocation(text) {
    const separators = [
        ' ',
        '-',
        '('
    ];
    const ignore = [
        'i',
        'og'
    ];
    if (text) {
        let capitalized = text.toLowerCase();
        for(let i = 0, len = separators.length; i < len; i += 1){
            const fragments = capitalized.split(separators[i]);
            for(let j = 0, x = fragments.length; j < x; j += 1){
                if (!ignore.includes(fragments[j])) {
                    fragments[j] = (fragments[j][0] || '').toUpperCase() + fragments[j].substr(1);
                }
            }
            capitalized = fragments.join(separators[i]);
        }
        return capitalized;
    }
    return text;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/util/validerEpost.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "validerEpost",
    ()=>validerEpost
]);
const validerEpost = (epost)=>{
    const emailRegex = /^[\p{L}\p{N}._%+-]+@[\p{L}\p{N}.-]+\.\p{L}{2,}$/u;
    const trimmetEpost = epost.trim();
    return trimmetEpost === '' ? {
        erGodkjent: false,
        feilmelding: 'E-post kan ikke være tom'
    } : emailRegex.test(trimmetEpost) ? {
        erGodkjent: true,
        feilmelding: ''
    } : {
        erGodkjent: false,
        feilmelding: 'Ugyldig e-postadresse'
    };
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/mocks/kandidat.mock.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Make sure these specific DTOs are correctly defined and imported if they are distinct
// For now, I'll assume they are part of KandidatDataSchemaDTO's array definitions
__turbopack_context__.s([
    "createFullKandidatMock",
    ()=>createFullKandidatMock,
    "getSammendragForAktorId",
    ()=>getSammendragForAktorId,
    "getSingleKandidatDataSchema",
    ()=>getSingleKandidatDataSchema,
    "getSingleKandidatSammendrag",
    ()=>getSingleKandidatSammendrag,
    "getSingleKandidatStillingssøk",
    ()=>getSingleKandidatStillingssøk,
    "kandidatSeedCounter",
    ()=>kandidatSeedCounter,
    "mapToKandidatSokKandidat",
    ()=>mapToKandidatSokKandidat,
    "mapToKandidatStillingssøk",
    ()=>mapToKandidatStillingssøk,
    "mockKandidatDataList",
    ()=>mockKandidatDataList
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$kandidat$2f$_ui$2f$innsatsgrupper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/kandidat/_ui/innsatsgrupper.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$KERBADJJ$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a__as__en$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@faker-js+faker@9.9.0/node_modules/@faker-js/faker/dist/chunk-KERBADJJ.js [app-client] (ecmascript) <export a as en>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$YQYVFZYE$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__n__as__Faker$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@faker-js+faker@9.9.0/node_modules/@faker-js/faker/dist/chunk-YQYVFZYE.js [app-client] (ecmascript) <export n as Faker>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a__as__nb_NO$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@faker-js+faker@9.9.0/node_modules/@faker-js/faker/dist/chunk-RHFAIXC4.js [app-client] (ecmascript) <export a as nb_NO>");
;
;
// import * as fs from 'fs'; // Removed as per previous instructions to not save to JSON
// import * as path from 'path'; // Removed
// Central Faker instances
const coreDataFaker = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$YQYVFZYE$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__n__as__Faker$3e$__["Faker"]({
    locale: [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a__as__nb_NO$3e$__["nb_NO"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$KERBADJJ$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a__as__en$3e$__["en"]
    ]
});
const coreDecisionFaker = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$YQYVFZYE$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__n__as__Faker$3e$__["Faker"]({
    locale: [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a__as__nb_NO$3e$__["nb_NO"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$KERBADJJ$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a__as__en$3e$__["en"]
    ]
});
let kandidatSeedCounter = 0;
// --- Helper functions using coreDecisionFaker ---
function optionalNullable(generator, pValue = 0.8, pNull = 0.1) {
    if (coreDecisionFaker.number.float({
        min: 0,
        max: 1
    }) > pValue) return undefined;
    if (coreDecisionFaker.number.float({
        min: 0,
        max: 1
    }) < pNull) return null;
    return generator();
}
function optional(generator, pValue = 0.8) {
    if (coreDecisionFaker.number.float({
        min: 0,
        max: 1
    }) > pValue) return undefined;
    return generator();
}
function nullable(generator, pNull = 0.1) {
    if (coreDecisionFaker.number.float({
        min: 0,
        max: 1
    }) < pNull) return null;
    return generator();
}
// --- End Helper functions ---
// Removed CoreKandidatRawData interface
// Renamed and refactored function to directly return KandidatDataSchemaDTO
function generateKandidatData(seed) {
    // This function now directly generates all fields for KandidatDataSchemaDTO
    // It uses the helper functions for optional/nullable logic.
    // The order of coreDataFaker calls within generators matters for consistency if values are shared.
    // Generate "raw" values that might be used in multiple places or for the summary
    const rawFornavn = coreDataFaker.person.firstName();
    const rawEtternavn = coreDataFaker.person.lastName();
    const rawFodselsdato = coreDataFaker.date.birthdate();
    const rawEpostadresse = coreDataFaker.internet.email();
    const rawMobiltelefon = coreDataFaker.phone.number();
    const rawTelefon = coreDataFaker.phone.number();
    const rawAdresselinje1 = coreDataFaker.location.streetAddress();
    const rawPostnummer = coreDataFaker.location.zipCode('####');
    const rawPoststed = coreDataFaker.location.city();
    const rawKommuneNavn = coreDataFaker.location.city();
    const rawFylkeNavn = coreDataFaker.location.state();
    const rawOrgenhet = coreDataFaker.string.numeric(4);
    const rawVeilederIdent = `Z${coreDataFaker.string.numeric(6)}`;
    const rawVeilederEpost = coreDataFaker.internet.email();
    const rawVeilederVisningsnavn = coreDataFaker.person.fullName();
    return {
        fritekst: optionalNullable(()=>coreDataFaker.lorem.paragraph()),
        aktorId: optionalNullable(()=>`kandidat-aktorId-${seed}`),
        fodselsnummer: optionalNullable(()=>`kandidat-fnr-${seed}`),
        fornavn: rawFornavn,
        etternavn: rawEtternavn,
        fodselsdato: optionalNullable(()=>rawFodselsdato.toISOString()),
        fodselsdatoErDnr: optionalNullable(()=>coreDataFaker.datatype.boolean()),
        formidlingsgruppekode: optionalNullable(()=>coreDataFaker.helpers.arrayElement([
                'ARBS',
                'IARBS',
                'ISERV',
                'PARBS',
                'RARBS'
            ])),
        epostadresse: optionalNullable(()=>rawEpostadresse),
        mobiltelefon: optionalNullable(()=>rawMobiltelefon),
        harKontaktinformasjon: optional(()=>coreDataFaker.datatype.boolean(), 0.9) ?? false,
        telefon: optionalNullable(()=>rawTelefon),
        statsborgerskap: optionalNullable(()=>'Norsk'),
        kandidatnr: optionalNullable(()=>`kandidat-kandidatnr-${seed}`),
        arenaKandidatnr: `kandidat-arenaKandidatnr-${seed}`,
        beskrivelse: optionalNullable(()=>coreDataFaker.lorem.sentences(coreDataFaker.number.int({
                min: 1,
                max: 3
            }))),
        samtykkeStatus: optionalNullable(()=>coreDataFaker.helpers.arrayElement([
                'GODKJENT',
                'AVBRUTT',
                'SLETTET'
            ])),
        samtykkeDato: optionalNullable(()=>coreDataFaker.date.past().toISOString()),
        adresselinje1: rawAdresselinje1,
        adresselinje2: coreDataFaker.location.secondaryAddress(),
        adresselinje3: optionalNullable(()=>coreDataFaker.lorem.words(3)),
        postnummer: rawPostnummer,
        poststed: rawPoststed,
        landkode: optionalNullable(()=>coreDataFaker.helpers.arrayElement([
                'NO'
            ])),
        kommunenummer: optionalNullable(()=>parseInt(coreDataFaker.string.numeric(4), 10)),
        kommunenummerkw: optionalNullable(()=>parseInt(coreDataFaker.string.numeric(4), 10)),
        kommunenummerstring: optionalNullable(()=>coreDataFaker.string.numeric(4)),
        fylkeNavn: optionalNullable(()=>rawFylkeNavn),
        kommuneNavn: optionalNullable(()=>rawKommuneNavn),
        disponererBil: optionalNullable(()=>coreDataFaker.datatype.boolean()),
        tidsstempel: optionalNullable(()=>coreDataFaker.date.recent().toISOString()),
        doed: optionalNullable(()=>coreDataFaker.datatype.boolean(0.05)),
        frKode: optionalNullable(()=>coreDataFaker.string.alphanumeric(3)),
        innsatsgruppe: optional(()=>coreDataFaker.helpers.arrayElement(Object.values(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$kandidat$2f$_ui$2f$innsatsgrupper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Innsatsgruppe"]))),
        orgenhet: optionalNullable(()=>rawOrgenhet),
        navkontor: optionalNullable(()=>`NAV ${coreDataFaker.location.city()}`),
        fritattKandidatsok: optionalNullable(()=>coreDataFaker.datatype.boolean()),
        fritattAgKandidatsok: optionalNullable(()=>coreDataFaker.datatype.boolean()),
        utdanning: optionalNullable(()=>coreDataFaker.helpers.multiple(()=>({}), {
                count: {
                    min: 0,
                    max: 1
                }
            })),
        fagdokumentasjon: optionalNullable(()=>coreDataFaker.helpers.multiple(()=>({}), {
                count: {
                    min: 0,
                    max: 1
                }
            })),
        yrkeserfaring: optionalNullable(()=>coreDataFaker.helpers.multiple(()=>({
                    yrkeserfaringManeder: coreDataFaker.number.int({
                        min: 1,
                        max: 120
                    })
                }), {
                count: {
                    min: 0,
                    max: 3
                }
            })),
        kompetanseObj: optionalNullable(()=>coreDataFaker.helpers.multiple(()=>({}), {
                count: {
                    min: 0,
                    max: 5
                }
            })),
        annenerfaringObj: optionalNullable(()=>coreDataFaker.helpers.multiple(()=>({}), {
                count: {
                    min: 0,
                    max: 2
                }
            })),
        sertifikatObj: optionalNullable(()=>coreDataFaker.helpers.multiple(()=>({}), {
                count: {
                    min: 0,
                    max: 3
                }
            })),
        forerkort: optionalNullable(()=>coreDataFaker.helpers.multiple(()=>({
                    fraDato: coreDataFaker.date.past().toISOString(),
                    tilDato: coreDataFaker.date.future().toISOString(),
                    utsteder: coreDataFaker.company.name(),
                    forerkortKode: coreDataFaker.string.alphanumeric(3),
                    forerkortKodeKlasse: coreDataFaker.vehicle.type(),
                    alternativKlasse: coreDataFaker.vehicle.vin().substring(0, 3)
                }), {
                count: {
                    min: 0,
                    max: 2
                }
            })),
        sprak: optionalNullable(()=>coreDataFaker.helpers.multiple(()=>({
                    sprakKodeTekst: coreDataFaker.lorem.word()
                }), {
                count: {
                    min: 0,
                    max: 2
                }
            })),
        kursObj: optionalNullable(()=>coreDataFaker.helpers.multiple(()=>({}), {
                count: {
                    min: 0,
                    max: 2
                }
            })),
        vervObj: optionalNullable(()=>coreDataFaker.helpers.multiple(()=>({}), {
                count: {
                    min: 0,
                    max: 1
                }
            })),
        geografiJobbonsker: optionalNullable(()=>coreDataFaker.helpers.multiple(()=>({
                    geografiKodeTekst: coreDataFaker.location.city(),
                    geografiKode: `NO${coreDataFaker.string.numeric(2)}.${coreDataFaker.string.numeric(4)}`
                }), {
                count: {
                    min: 1,
                    max: 3
                }
            })),
        yrkeJobbonskerObj: optionalNullable(()=>coreDataFaker.helpers.multiple(()=>{
                const jobTitle = coreDataFaker.person.jobTitle();
                return {
                    styrkBeskrivelse: jobTitle,
                    sokeTitler: coreDataFaker.helpers.multiple(()=>coreDataFaker.person.jobTitle(), {
                        count: {
                            min: 1,
                            max: 5
                        }
                    }).concat([
                        jobTitle
                    ]),
                    primaertJobbonske: coreDataFaker.datatype.boolean(0.3),
                    styrkKode: null
                };
            }, {
                count: {
                    min: 1,
                    max: 3
                }
            })),
        omfangJobbonskerObj: optionalNullable(()=>coreDataFaker.helpers.multiple(()=>({}), {
                count: {
                    min: 0,
                    max: 1
                }
            })),
        ansettelsesformJobbonskerObj: optionalNullable(()=>coreDataFaker.helpers.multiple(()=>({}), {
                count: {
                    min: 0,
                    max: 1
                }
            })),
        arbeidstidsordningJobbonskerObj: optionalNullable(()=>coreDataFaker.helpers.multiple(()=>({}), {
                count: {
                    min: 0,
                    max: 1
                }
            })),
        arbeidsdagerJobbonskerObj: optionalNullable(()=>coreDataFaker.helpers.multiple(()=>({}), {
                count: {
                    min: 0,
                    max: 1
                }
            })),
        arbeidstidJobbonskerObj: optionalNullable(()=>coreDataFaker.helpers.multiple(()=>({}), {
                count: {
                    min: 0,
                    max: 1
                }
            })),
        samletKompetanseObj: optionalNullable(()=>coreDataFaker.helpers.multiple(()=>({}), {
                count: {
                    min: 0,
                    max: 1
                }
            })),
        totalLengdeYrkeserfaring: optional(()=>coreDataFaker.number.int({
                min: 0,
                max: 300
            })) ?? 0,
        synligForArbeidsgiverSok: optionalNullable(()=>coreDataFaker.datatype.boolean()),
        synligForVeilederSok: optional(()=>coreDataFaker.datatype.boolean()),
        oppstartKode: optionalNullable(()=>coreDataFaker.helpers.arrayElement([
                'LEDIG_NAA',
                'ETTER_AVTALE',
                'SNAREST'
            ])),
        veileder: optionalNullable(()=>rawVeilederVisningsnavn),
        veilederIdent: optionalNullable(()=>rawVeilederIdent),
        veilederVisningsnavn: optionalNullable(()=>rawVeilederVisningsnavn),
        veilederEpost: optionalNullable(()=>rawVeilederEpost),
        godkjenninger: optionalNullable(()=>coreDataFaker.helpers.multiple(()=>({}), {
                count: {
                    min: 0,
                    max: 1
                }
            }))
    };
}
function mapToKandidatSokKandidat(fullKandidat) {
    const arenaKandidatnr = fullKandidat.arenaKandidatnr || `fallback-arenaKandidatnr-${fullKandidat.aktorId || 'unknown'}`;
    if (!fullKandidat.fodselsnummer) {
        return null;
    }
    return {
        yrkeJobbonskerObj: fullKandidat.yrkeJobbonskerObj?.map((yrke)=>({
                styrkBeskrivelse: yrke.styrkBeskrivelse || undefined,
                sokeTitler: yrke.sokeTitler,
                primaertJobbonske: yrke.primaertJobbonske,
                styrkKode: yrke.styrkKode || undefined
            })) || [],
        etternavn: fullKandidat.etternavn || 'Mangler etternavn',
        postnummer: fullKandidat.postnummer || '0000',
        arenaKandidatnr: arenaKandidatnr,
        kommuneNavn: fullKandidat.kommuneNavn || 'Mangler kommune',
        geografiJobbonsker: fullKandidat.geografiJobbonsker?.map((geo)=>({
                geografiKodeTekst: geo.geografiKodeTekst || '',
                geografiKode: geo.geografiKode || ''
            })) || [],
        innsatsgruppe: fullKandidat.innsatsgruppe || __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$kandidat$2f$_ui$2f$innsatsgrupper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Innsatsgruppe"].STANDARD_INNSATS,
        fornavn: fullKandidat.fornavn || 'Mangler fornavn',
        fodselsnummer: fullKandidat.fodselsnummer,
        poststed: fullKandidat.poststed || 'Mangler poststed'
    };
}
// mapToKandidatSammendrag now takes KandidatDataSchemaDTO as input
function mapToKandidatSammendrag(kandidatData) {
    // Use values from kandidatData, providing defaults if they are null/undefined
    // and the sammendrag requires them to be non-nullable.
    return {
        fornavn: kandidatData.fornavn || 'Ukjent',
        etternavn: kandidatData.etternavn || 'Ukjent',
        fodselsdato: kandidatData.fodselsdato ? kandidatData.fodselsdato.split('T')[0] : new Date().toISOString().split('T')[0],
        epostadresse: kandidatData.epostadresse ?? null,
        telefon: kandidatData.telefon ?? null,
        adresselinje1: kandidatData.adresselinje1 ?? null,
        postnummer: kandidatData.postnummer ?? null,
        poststed: kandidatData.poststed ?? null,
        orgenhet: kandidatData.orgenhet ?? null,
        veilederIdent: kandidatData.veilederIdent ?? null,
        veilederEpost: kandidatData.veilederEpost ?? null,
        veilederVisningsnavn: kandidatData.veilederVisningsnavn ?? null,
        arenaKandidatnr: kandidatData.arenaKandidatnr ?? '',
        fodselsnummer: kandidatData.fodselsnummer || '00000000000'
    };
}
function createFullKandidatMock(seed) {
    coreDataFaker.seed(seed);
    coreDecisionFaker.seed(seed); // Seed decision faker for consistent optional/nullable choices
    const kandidatData = generateKandidatData(seed); // Step 1: Generate full DTO
    // Re-seed decision faker for summary mapping if it involves different optional/nullable logic
    // For now, mapToKandidatSammendrag primarily uses fallbacks or direct mapping of nullable fields.
    // If it were to use optionalNullable helpers with different probabilities, re-seeding would be important.
    // coreDecisionFaker.seed(seed);
    const kandidatSammendrag = mapToKandidatSammendrag(kandidatData);
    return {
        kandidatData,
        kandidatSammendrag
    };
}
const mockKandidatDataList = [];
const mockKandidatSammendragMap = new Map();
for(let i = 1; i <= 20; i++){
    kandidatSeedCounter = i;
    const { kandidatData, kandidatSammendrag } = createFullKandidatMock(kandidatSeedCounter);
    mockKandidatDataList.push(kandidatData);
    if (kandidatData.aktorId) {
        mockKandidatSammendragMap.set(kandidatData.aktorId, kandidatSammendrag);
    }
}
function getSammendragForAktorId(aktorId) {
    // This function could also generate on the fly if needed,
    // but currently uses the pre-generated map.
    // To generate on the fly based on aktorId (if seed can be derived):
    // const seed = parseInt(aktorId.split('-').pop() || "0", 10);
    // if (isNaN(seed)) return undefined;
    // return createFullKandidatMock(seed).kandidatSammendrag;
    return mockKandidatSammendragMap.get(aktorId);
}
function getSingleKandidatDataSchema(seed) {
    coreDataFaker.seed(seed);
    coreDecisionFaker.seed(seed);
    return generateKandidatData(seed);
}
function getSingleKandidatSammendrag(seed) {
    coreDataFaker.seed(seed);
    coreDecisionFaker.seed(seed);
    const kandidatData = generateKandidatData(seed);
    return mapToKandidatSammendrag(kandidatData);
}
function mapToKandidatStillingssøk(fullKandidat) {
    return {
        yrkeJobbonskerObj: fullKandidat.yrkeJobbonskerObj?.map((yrke)=>({
                styrkBeskrivelse: yrke.styrkBeskrivelse || '',
                sokeTitler: yrke.sokeTitler || [],
                primaertJobbonske: yrke.primaertJobbonske || false,
                styrkKode: yrke.styrkKode ?? null
            })) || [],
        geografiJobbonsker: fullKandidat.geografiJobbonsker?.map((geo)=>({
                geografiKodeTekst: geo.geografiKodeTekst || '',
                geografiKode: geo.geografiKode || ''
            })) || [],
        kommunenummerstring: fullKandidat.kommunenummerstring ?? null,
        kommuneNavn: fullKandidat.kommuneNavn ?? null
    };
}
function getSingleKandidatStillingssøk(seed) {
    const kandidatData = getSingleKandidatDataSchema(seed);
    return mapToKandidatStillingssøk(kandidatData);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/mocks/kandidatliste.mock.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "mapKandidatDataToKandidatListeKandidat",
    ()=>mapKandidatDataToKandidatListeKandidat,
    "mockKandidatliste",
    ()=>mockKandidatliste
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$mocks$2f$kandidat$2e$mock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/mocks/kandidat.mock.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$kandidat$2f$_ui$2f$innsatsgrupper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/kandidat/_ui/innsatsgrupper.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/KandidatTyper.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$YQYVFZYE$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__n__as__Faker$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@faker-js+faker@9.9.0/node_modules/@faker-js/faker/dist/chunk-YQYVFZYE.js [app-client] (ecmascript) <export n as Faker>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$KERBADJJ$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a__as__en$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@faker-js+faker@9.9.0/node_modules/@faker-js/faker/dist/chunk-KERBADJJ.js [app-client] (ecmascript) <export a as en>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a__as__nb_NO$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@faker-js+faker@9.9.0/node_modules/@faker-js/faker/dist/chunk-RHFAIXC4.js [app-client] (ecmascript) <export a as nb_NO>");
;
;
;
;
// Assuming kandidatSeedCounter is exported and you want to use/mutate the global one
// Central Faker instances for this mock file
const listDataFaker = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$YQYVFZYE$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__n__as__Faker$3e$__["Faker"]({
    locale: [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a__as__nb_NO$3e$__["nb_NO"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$KERBADJJ$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a__as__en$3e$__["en"]
    ]
});
const listDecisionFaker = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$YQYVFZYE$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__n__as__Faker$3e$__["Faker"]({
    locale: [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a__as__nb_NO$3e$__["nb_NO"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$KERBADJJ$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a__as__en$3e$__["en"]
    ]
});
// If you prefer an independent seed counter for this file:
// let localKandidatSeedCounter = 0;
// Mock enum for InternKandidatstatus
// This should ideally align with the actual InternKandidatstatus enum values
// Helper to generate a single Utfallsendring
// The type is implicitly defined by utfallsendringerSchema in app/api/kandidat/schema.zod.ts
function generateMockUtfallsendring() {
    return {
        utfall: listDataFaker.helpers.arrayElement([
            __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatutfallTyper"].IKKE_PRESENTERT,
            __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatutfallTyper"].FATT_JOBBEN,
            __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatutfallTyper"].PRESENTERT
        ]),
        registrertAvIdent: `Z${listDataFaker.string.numeric(6)}`,
        tidspunkt: listDataFaker.date.past({
            years: 1
        }).toISOString(),
        sendtTilArbeidsgiversKandidatliste: listDecisionFaker.datatype.boolean()
    };
}
function mapKandidatDataToKandidatListeKandidat(kandidatData, idNummer) {
    const erArkivert = listDecisionFaker.datatype.boolean(0.1); // 10% chance of being archived
    return {
        kandidatId: `kandidat-arenaKandidatnr-${idNummer}`,
        kandidatnr: `kandidat-aktorId-${idNummer}`,
        status: listDataFaker.helpers.arrayElement(Object.values(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InternKandidatstatus"])),
        lagtTilTidspunkt: listDataFaker.date.past({
            years: 1
        }).toISOString(),
        lagtTilAv: {
            ident: kandidatData.veilederIdent || `Z${listDataFaker.string.numeric(6)}`,
            navn: kandidatData.veilederVisningsnavn || listDataFaker.person.fullName()
        },
        fornavn: kandidatData.fornavn || 'Fornavn mangler',
        etternavn: kandidatData.etternavn || 'Etternavn mangler',
        fodselsdato: kandidatData.fodselsdato || listDataFaker.date.birthdate().toISOString(),
        fodselsnr: kandidatData.fodselsnummer ?? null,
        utfall: listDataFaker.helpers.arrayElement([
            __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatutfallTyper"].IKKE_PRESENTERT,
            __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatutfallTyper"].FATT_JOBBEN,
            __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatutfallTyper"].PRESENTERT
        ]),
        telefon: kandidatData.mobiltelefon || kandidatData.telefon || null,
        epost: kandidatData.epostadresse ?? null,
        innsatsgruppe: kandidatData.innsatsgruppe || __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$kandidat$2f$_ui$2f$innsatsgrupper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Innsatsgruppe"].STANDARD_INNSATS,
        antallNotater: listDataFaker.number.int({
            min: 0,
            max: 7
        }),
        arkivert: erArkivert,
        arkivertTidspunkt: erArkivert ? listDataFaker.date.past({
            years: 1
        }).toISOString() : null,
        arkivertAv: erArkivert ? {
            ident: `Z${listDataFaker.string.numeric(6)}`,
            navn: listDataFaker.person.fullName()
        } : null,
        aktørid: kandidatData.aktorId ?? null,
        utfallsendringer: listDataFaker.helpers.multiple(generateMockUtfallsendring, {
            count: {
                min: 0,
                max: 3
            }
        })
    };
}
function generateMockKandidatlisteKandidater(count = 100) {
    const kandidater = [];
    for(let i = 0; i < count; i++){
        // Example: Incrementing a global counter. Adjust if your seed management is different.
        // It's often better to manage state like this more explicitly if possible.
        const currentSeed = (__TURBOPACK__imported__module__$5b$project$5d2f$mocks$2f$kandidat$2e$mock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["kandidatSeedCounter"] || 0) + i + 1;
        const baseKandidatData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$mocks$2f$kandidat$2e$mock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSingleKandidatDataSchema"])(currentSeed);
        kandidater.push(mapKandidatDataToKandidatListeKandidat(baseKandidatData, i + 1));
    }
    // If globalKandidatSeedCounter is indeed global and mutable:
    // if (typeof globalKandidatSeedCounter === 'number') {
    //   (globalKandidatSeedCounter as any) += count; // Be careful with direct mutation of imported primitives
    // }
    return kandidater;
}
const mockKandidatliste = {
    kandidatlisteId: 'minStilling',
    tittel: null,
    organisasjonReferanse: '312113341',
    organisasjonNavn: 'ORDKNAPP BLOMSTRETE TIGER AS',
    stillingId: '05ed6a01-d55c-4b9c-98d6-e6d40a3b6fc7',
    opprettetAv: {
        ident: 'Z993141',
        navn: 'F_Z993141 E_Z993141'
    },
    opprettetTidspunkt: '2025-05-07T13:06:42.301',
    kandidater: generateMockKandidatlisteKandidater(),
    kanEditere: true,
    erEier: true,
    kanSlette: 'HAR_STILLING',
    formidlingerAvUsynligKandidat: [
        {
            id: '199',
            fornavn: 'FORSIKTIG',
            mellomnavn: null,
            etternavn: 'BLOKKFLØYTE',
            utfall: 'IKKE_PRESENTERT',
            lagtTilAvIdent: 'Z993141',
            lagtTilAvNavn: 'F_Z993141 E_Z993141',
            lagtTilTidspunkt: '2025-05-08T15:05:41.567',
            arkivert: false,
            arkivertAvIdent: null,
            arkivertAvNavn: null,
            arkivertTidspunkt: null
        }
    ],
    status: 'ÅPEN',
    antallStillinger: 1,
    stillingskategori: 'STILLING'
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/mocks/forespurteOmDelingAvCv.mock.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "generateMockForespurteOmDelingAvCv",
    ()=>generateMockForespurteOmDelingAvCv
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/KandidatTyper.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$YQYVFZYE$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__n__as__Faker$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@faker-js+faker@9.9.0/node_modules/@faker-js/faker/dist/chunk-YQYVFZYE.js [app-client] (ecmascript) <export n as Faker>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a__as__nb_NO$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@faker-js+faker@9.9.0/node_modules/@faker-js/faker/dist/chunk-RHFAIXC4.js [app-client] (ecmascript) <export a as nb_NO>");
;
;
const faker = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$YQYVFZYE$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__n__as__Faker$3e$__["Faker"]({
    locale: [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a__as__nb_NO$3e$__["nb_NO"]
    ]
});
faker.seed(123);
function generateSvarfrist() {
    let date;
    // Generate a past date roughly 1/3 of the time
    if (faker.number.int({
        min: 1,
        max: 3
    }) === 1) {
        date = faker.date.recent({
            days: 10
        }); // Generates a date in the last 10 days
    } else {
        date = faker.date.soon({
            days: 3
        }); // Generates a date in the next 3 days
    }
    const isoDate = date.toISOString().split('T')[0];
    const isSummerTime = date.getMonth() > 2 && date.getMonth() < 10;
    const timezone = isSummerTime ? '+02:00' : '+01:00';
    return `${isoDate}T00:00:00${timezone}`;
}
function generateNavKontor() {
    return faker.helpers.arrayElement([
        '0321',
        '0403',
        '0300',
        '0402',
        '0219'
    ]);
}
function generateNavIdent() {
    return faker.helpers.arrayElement([
        'Z993141',
        'Z994440',
        'Z994886',
        'Z995512'
    ]);
}
function generateMockForespurteOmDelingAvCv() {
    const mockData = {};
    const tilstander = Object.values(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TilstandPåForespørsel"]);
    const stillingsId = 'minStilling';
    const aktørIdList = [
        '22',
        '23',
        '24',
        '25',
        '27',
        '28',
        '29'
    ];
    let kandidatIndex = 0;
    // Create one entry for each tilstand
    tilstander.forEach((originalTilstand)=>{
        const aktørId = aktørIdList[kandidatIndex % aktørIdList.length];
        kandidatIndex++;
        const deltAv = generateNavIdent();
        const currentSvarfrist = generateSvarfrist();
        let finalTilstand = originalTilstand;
        let svar = null; // Initialize svar to null
        // Check if svarfrist is due
        const svarfristDate = new Date(currentSvarfrist); // new Date() can parse full ISO 8601 string
        const now = new Date();
        if (svarfristDate < now) {
            // If deadline passed, set tilstand to AVBRUTT,
            // unless it's a state that shouldn't be overridden by a past deadline.
            if (originalTilstand !== __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TilstandPåForespørsel"].HAR_SVART && originalTilstand !== __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TilstandPåForespørsel"].IKKE_SENDT && originalTilstand !== __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TilstandPåForespørsel"].AVBRUTT // Avoid re-setting if already AVBRUTT from enum
            ) {
                finalTilstand = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TilstandPåForespørsel"].AVBRUTT;
            }
        }
        // Determine deltStatus based on the finalTilstand
        let deltStatus;
        if (finalTilstand === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TilstandPåForespørsel"].IKKE_SENDT) {
            deltStatus = 'IKKE_SENDT';
        } else {
            // Covers SENDT, HAR_SVART, and AVBRUTT (if it was sent and deadline passed)
            deltStatus = 'SENDT';
        }
        // Generate svar object only if the finalTilstand is HAR_SVART
        if (finalTilstand === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TilstandPåForespørsel"].HAR_SVART) {
            const harSvartJa = faker.datatype.boolean();
            svar = {
                harSvartJa,
                svarTidspunkt: faker.date.recent().toISOString(),
                svartAv: {
                    ident: deltAv,
                    identType: 'NAV_IDENT'
                }
            };
        }
        // If finalTilstand is AVBRUTT (due to deadline or from enum), svar remains null unless explicitly set above.
        mockData['kandidat-aktorId-' + aktørId] = [
            {
                aktørId: 'kandidat-aktorId-' + aktørId,
                stillingsId,
                deltStatus,
                deltTidspunkt: faker.date.recent().toISOString(),
                deltAv,
                svarfrist: currentSvarfrist,
                tilstand: finalTilstand,
                svar,
                begrunnelseForAtAktivitetIkkeBleOpprettet: null,
                navKontor: generateNavKontor()
            }
        ];
    });
    // Ensure the next aktørId is different from the ones used for tilstander, if possible
    const aktørIdForExtraEntry = aktørIdList[kandidatIndex % aktørIdList.length];
    kandidatIndex++; // Increment for potential future use, though not strictly needed here
    const deltAvForExtraEntry = generateNavIdent();
    const extraEntrySvarfrist = generateSvarfrist();
    let extraEntryTilstand = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TilstandPåForespørsel"].HAR_SVART; // Original tilstand for this entry
    let extraEntrySvar = null; // Initialize
    // Apply deadline logic for the extra entry as well, though HAR_SVART won't be overridden
    const extraSvarfristDate = new Date(extraEntrySvarfrist);
    const nowForExtra = new Date();
    if (extraSvarfristDate < nowForExtra) {
        if (extraEntryTilstand !== __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TilstandPåForespørsel"].HAR_SVART && extraEntryTilstand !== __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TilstandPåForespørsel"].IKKE_SENDT && extraEntryTilstand !== __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TilstandPåForespørsel"].AVBRUTT) {
            extraEntryTilstand = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TilstandPåForespørsel"].AVBRUTT;
        }
    }
    const extraEntryDeltStatus = 'SENDT'; // Default for HAR_SVART
    if (extraEntryTilstand === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TilstandPåForespørsel"].HAR_SVART) {
        extraEntrySvar = {
            harSvartJa: !(Object.entries(mockData).find(([key, arr])=>arr[0].tilstand === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TilstandPåForespørsel"].HAR_SVART && key !== 'kandidat-aktorId-' + aktørIdForExtraEntry)?.[1][0].svar?.harSvartJa ?? true),
            svarTidspunkt: faker.date.recent().toISOString(),
            svartAv: {
                ident: deltAvForExtraEntry,
                identType: 'NAV_IDENT'
            }
        };
    } else {
        extraEntrySvar = null; // Ensure svar is null if tilstand changed from HAR_SVART
    }
    mockData['kandidat-aktorId-' + aktørIdForExtraEntry] = [
        {
            aktørId: 'kandidat-aktorId-' + aktørIdForExtraEntry,
            stillingsId,
            deltStatus: extraEntryDeltStatus,
            deltTidspunkt: faker.date.recent().toISOString(),
            deltAv: deltAvForExtraEntry,
            svarfrist: extraEntrySvarfrist,
            tilstand: extraEntryTilstand,
            svar: extraEntrySvar,
            begrunnelseForAtAktivitetIkkeBleOpprettet: null,
            navKontor: generateNavKontor()
        }
    ];
    return mockData;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=_7a6f8426._.js.map