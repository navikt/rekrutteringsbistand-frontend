(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/passthrough.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "passthrough",
    ()=>passthrough
]);
function passthrough() {
    return new Response(null, {
        status: 302,
        statusText: "Passthrough",
        headers: {
            "x-msw-intention": "passthrough"
        }
    });
}
;
 //# sourceMappingURL=passthrough.mjs.map
}),
"[project]/node_modules/.pnpm/styled-jsx@5.1.6_@babel+core@7.28.6_react@19.2.1/node_modules/styled-jsx/dist/index/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
__turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/client-only/index.js [app-client] (ecmascript)");
var React = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
function _interopDefaultLegacy(e) {
    return e && typeof e === 'object' && 'default' in e ? e : {
        'default': e
    };
}
var React__default = /*#__PURE__*/ _interopDefaultLegacy(React);
/*
Based on Glamor's sheet
https://github.com/threepointone/glamor/blob/667b480d31b3721a905021b26e1290ce92ca2879/src/sheet.js
*/ function _defineProperties(target, props) {
    for(var i = 0; i < props.length; i++){
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}
function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
}
var isProd = typeof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] !== "undefined" && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env && ("TURBOPACK compile-time value", "development") === "production";
var isString = function(o) {
    return Object.prototype.toString.call(o) === "[object String]";
};
var StyleSheet = /*#__PURE__*/ function() {
    function StyleSheet(param) {
        var ref = param === void 0 ? {} : param, _name = ref.name, name = _name === void 0 ? "stylesheet" : _name, _optimizeForSpeed = ref.optimizeForSpeed, optimizeForSpeed = _optimizeForSpeed === void 0 ? isProd : _optimizeForSpeed;
        invariant$1(isString(name), "`name` must be a string");
        this._name = name;
        this._deletedRulePlaceholder = "#" + name + "-deleted-rule____{}";
        invariant$1(typeof optimizeForSpeed === "boolean", "`optimizeForSpeed` must be a boolean");
        this._optimizeForSpeed = optimizeForSpeed;
        this._serverSheet = undefined;
        this._tags = [];
        this._injected = false;
        this._rulesCount = 0;
        var node = typeof window !== "undefined" && document.querySelector('meta[property="csp-nonce"]');
        this._nonce = node ? node.getAttribute("content") : null;
    }
    var _proto = StyleSheet.prototype;
    _proto.setOptimizeForSpeed = function setOptimizeForSpeed(bool) {
        invariant$1(typeof bool === "boolean", "`setOptimizeForSpeed` accepts a boolean");
        invariant$1(this._rulesCount === 0, "optimizeForSpeed cannot be when rules have already been inserted");
        this.flush();
        this._optimizeForSpeed = bool;
        this.inject();
    };
    _proto.isOptimizeForSpeed = function isOptimizeForSpeed() {
        return this._optimizeForSpeed;
    };
    _proto.inject = function inject() {
        var _this = this;
        invariant$1(!this._injected, "sheet already injected");
        this._injected = true;
        if (typeof window !== "undefined" && this._optimizeForSpeed) {
            this._tags[0] = this.makeStyleTag(this._name);
            this._optimizeForSpeed = "insertRule" in this.getSheet();
            if (!this._optimizeForSpeed) {
                if ("TURBOPACK compile-time truthy", 1) {
                    console.warn("StyleSheet: optimizeForSpeed mode not supported falling back to standard mode.");
                }
                this.flush();
                this._injected = true;
            }
            return;
        }
        this._serverSheet = {
            cssRules: [],
            insertRule: function(rule, index) {
                if (typeof index === "number") {
                    _this._serverSheet.cssRules[index] = {
                        cssText: rule
                    };
                } else {
                    _this._serverSheet.cssRules.push({
                        cssText: rule
                    });
                }
                return index;
            },
            deleteRule: function(index) {
                _this._serverSheet.cssRules[index] = null;
            }
        };
    };
    _proto.getSheetForTag = function getSheetForTag(tag) {
        if (tag.sheet) {
            return tag.sheet;
        }
        // this weirdness brought to you by firefox
        for(var i = 0; i < document.styleSheets.length; i++){
            if (document.styleSheets[i].ownerNode === tag) {
                return document.styleSheets[i];
            }
        }
    };
    _proto.getSheet = function getSheet() {
        return this.getSheetForTag(this._tags[this._tags.length - 1]);
    };
    _proto.insertRule = function insertRule(rule, index) {
        invariant$1(isString(rule), "`insertRule` accepts only strings");
        if (typeof window === "undefined") {
            if (typeof index !== "number") {
                index = this._serverSheet.cssRules.length;
            }
            this._serverSheet.insertRule(rule, index);
            return this._rulesCount++;
        }
        if (this._optimizeForSpeed) {
            var sheet = this.getSheet();
            if (typeof index !== "number") {
                index = sheet.cssRules.length;
            }
            // this weirdness for perf, and chrome's weird bug
            // https://stackoverflow.com/questions/20007992/chrome-suddenly-stopped-accepting-insertrule
            try {
                sheet.insertRule(rule, index);
            } catch (error) {
                if ("TURBOPACK compile-time truthy", 1) {
                    console.warn("StyleSheet: illegal rule: \n\n" + rule + "\n\nSee https://stackoverflow.com/q/20007992 for more info");
                }
                return -1;
            }
        } else {
            var insertionPoint = this._tags[index];
            this._tags.push(this.makeStyleTag(this._name, rule, insertionPoint));
        }
        return this._rulesCount++;
    };
    _proto.replaceRule = function replaceRule(index, rule) {
        if (this._optimizeForSpeed || typeof window === "undefined") {
            var sheet = typeof window !== "undefined" ? this.getSheet() : this._serverSheet;
            if (!rule.trim()) {
                rule = this._deletedRulePlaceholder;
            }
            if (!sheet.cssRules[index]) {
                // @TBD Should we throw an error?
                return index;
            }
            sheet.deleteRule(index);
            try {
                sheet.insertRule(rule, index);
            } catch (error) {
                if ("TURBOPACK compile-time truthy", 1) {
                    console.warn("StyleSheet: illegal rule: \n\n" + rule + "\n\nSee https://stackoverflow.com/q/20007992 for more info");
                }
                // In order to preserve the indices we insert a deleteRulePlaceholder
                sheet.insertRule(this._deletedRulePlaceholder, index);
            }
        } else {
            var tag = this._tags[index];
            invariant$1(tag, "old rule at index `" + index + "` not found");
            tag.textContent = rule;
        }
        return index;
    };
    _proto.deleteRule = function deleteRule(index) {
        if (typeof window === "undefined") {
            this._serverSheet.deleteRule(index);
            return;
        }
        if (this._optimizeForSpeed) {
            this.replaceRule(index, "");
        } else {
            var tag = this._tags[index];
            invariant$1(tag, "rule at index `" + index + "` not found");
            tag.parentNode.removeChild(tag);
            this._tags[index] = null;
        }
    };
    _proto.flush = function flush() {
        this._injected = false;
        this._rulesCount = 0;
        if (typeof window !== "undefined") {
            this._tags.forEach(function(tag) {
                return tag && tag.parentNode.removeChild(tag);
            });
            this._tags = [];
        } else {
            // simpler on server
            this._serverSheet.cssRules = [];
        }
    };
    _proto.cssRules = function cssRules() {
        var _this = this;
        if (typeof window === "undefined") {
            return this._serverSheet.cssRules;
        }
        return this._tags.reduce(function(rules, tag) {
            if (tag) {
                rules = rules.concat(Array.prototype.map.call(_this.getSheetForTag(tag).cssRules, function(rule) {
                    return rule.cssText === _this._deletedRulePlaceholder ? null : rule;
                }));
            } else {
                rules.push(null);
            }
            return rules;
        }, []);
    };
    _proto.makeStyleTag = function makeStyleTag(name, cssString, relativeToTag) {
        if (cssString) {
            invariant$1(isString(cssString), "makeStyleTag accepts only strings as second parameter");
        }
        var tag = document.createElement("style");
        if (this._nonce) tag.setAttribute("nonce", this._nonce);
        tag.type = "text/css";
        tag.setAttribute("data-" + name, "");
        if (cssString) {
            tag.appendChild(document.createTextNode(cssString));
        }
        var head = document.head || document.getElementsByTagName("head")[0];
        if (relativeToTag) {
            head.insertBefore(tag, relativeToTag);
        } else {
            head.appendChild(tag);
        }
        return tag;
    };
    _createClass(StyleSheet, [
        {
            key: "length",
            get: function get() {
                return this._rulesCount;
            }
        }
    ]);
    return StyleSheet;
}();
function invariant$1(condition, message) {
    if (!condition) {
        throw new Error("StyleSheet: " + message + ".");
    }
}
function hash(str) {
    var _$hash = 5381, i = str.length;
    while(i){
        _$hash = _$hash * 33 ^ str.charCodeAt(--i);
    }
    /* JavaScript does bitwise operations (like XOR, above) on 32-bit signed
   * integers. Since we want the results to be always positive, convert the
   * signed int to an unsigned by doing an unsigned bitshift. */ return _$hash >>> 0;
}
var stringHash = hash;
var sanitize = function(rule) {
    return rule.replace(/\/style/gi, "\\/style");
};
var cache = {};
/**
 * computeId
 *
 * Compute and memoize a jsx id from a basedId and optionally props.
 */ function computeId(baseId, props) {
    if (!props) {
        return "jsx-" + baseId;
    }
    var propsToString = String(props);
    var key = baseId + propsToString;
    if (!cache[key]) {
        cache[key] = "jsx-" + stringHash(baseId + "-" + propsToString);
    }
    return cache[key];
}
/**
 * computeSelector
 *
 * Compute and memoize dynamic selectors.
 */ function computeSelector(id, css) {
    var selectoPlaceholderRegexp = /__jsx-style-dynamic-selector/g;
    // Sanitize SSR-ed CSS.
    // Client side code doesn't need to be sanitized since we use
    // document.createTextNode (dev) and the CSSOM api sheet.insertRule (prod).
    if (typeof window === "undefined") {
        css = sanitize(css);
    }
    var idcss = id + css;
    if (!cache[idcss]) {
        cache[idcss] = css.replace(selectoPlaceholderRegexp, id);
    }
    return cache[idcss];
}
function mapRulesToStyle(cssRules, options) {
    if (options === void 0) options = {};
    return cssRules.map(function(args) {
        var id = args[0];
        var css = args[1];
        return /*#__PURE__*/ React__default["default"].createElement("style", {
            id: "__" + id,
            // Avoid warnings upon render with a key
            key: "__" + id,
            nonce: options.nonce ? options.nonce : undefined,
            dangerouslySetInnerHTML: {
                __html: css
            }
        });
    });
}
var StyleSheetRegistry = /*#__PURE__*/ function() {
    function StyleSheetRegistry(param) {
        var ref = param === void 0 ? {} : param, _styleSheet = ref.styleSheet, styleSheet = _styleSheet === void 0 ? null : _styleSheet, _optimizeForSpeed = ref.optimizeForSpeed, optimizeForSpeed = _optimizeForSpeed === void 0 ? false : _optimizeForSpeed;
        this._sheet = styleSheet || new StyleSheet({
            name: "styled-jsx",
            optimizeForSpeed: optimizeForSpeed
        });
        this._sheet.inject();
        if (styleSheet && typeof optimizeForSpeed === "boolean") {
            this._sheet.setOptimizeForSpeed(optimizeForSpeed);
            this._optimizeForSpeed = this._sheet.isOptimizeForSpeed();
        }
        this._fromServer = undefined;
        this._indices = {};
        this._instancesCounts = {};
    }
    var _proto = StyleSheetRegistry.prototype;
    _proto.add = function add(props) {
        var _this = this;
        if (undefined === this._optimizeForSpeed) {
            this._optimizeForSpeed = Array.isArray(props.children);
            this._sheet.setOptimizeForSpeed(this._optimizeForSpeed);
            this._optimizeForSpeed = this._sheet.isOptimizeForSpeed();
        }
        if (typeof window !== "undefined" && !this._fromServer) {
            this._fromServer = this.selectFromServer();
            this._instancesCounts = Object.keys(this._fromServer).reduce(function(acc, tagName) {
                acc[tagName] = 0;
                return acc;
            }, {});
        }
        var ref = this.getIdAndRules(props), styleId = ref.styleId, rules = ref.rules;
        // Deduping: just increase the instances count.
        if (styleId in this._instancesCounts) {
            this._instancesCounts[styleId] += 1;
            return;
        }
        var indices = rules.map(function(rule) {
            return _this._sheet.insertRule(rule);
        }) // Filter out invalid rules
        .filter(function(index) {
            return index !== -1;
        });
        this._indices[styleId] = indices;
        this._instancesCounts[styleId] = 1;
    };
    _proto.remove = function remove(props) {
        var _this = this;
        var styleId = this.getIdAndRules(props).styleId;
        invariant(styleId in this._instancesCounts, "styleId: `" + styleId + "` not found");
        this._instancesCounts[styleId] -= 1;
        if (this._instancesCounts[styleId] < 1) {
            var tagFromServer = this._fromServer && this._fromServer[styleId];
            if (tagFromServer) {
                tagFromServer.parentNode.removeChild(tagFromServer);
                delete this._fromServer[styleId];
            } else {
                this._indices[styleId].forEach(function(index) {
                    return _this._sheet.deleteRule(index);
                });
                delete this._indices[styleId];
            }
            delete this._instancesCounts[styleId];
        }
    };
    _proto.update = function update(props, nextProps) {
        this.add(nextProps);
        this.remove(props);
    };
    _proto.flush = function flush() {
        this._sheet.flush();
        this._sheet.inject();
        this._fromServer = undefined;
        this._indices = {};
        this._instancesCounts = {};
    };
    _proto.cssRules = function cssRules() {
        var _this = this;
        var fromServer = this._fromServer ? Object.keys(this._fromServer).map(function(styleId) {
            return [
                styleId,
                _this._fromServer[styleId]
            ];
        }) : [];
        var cssRules = this._sheet.cssRules();
        return fromServer.concat(Object.keys(this._indices).map(function(styleId) {
            return [
                styleId,
                _this._indices[styleId].map(function(index) {
                    return cssRules[index].cssText;
                }).join(_this._optimizeForSpeed ? "" : "\n")
            ];
        }) // filter out empty rules
        .filter(function(rule) {
            return Boolean(rule[1]);
        }));
    };
    _proto.styles = function styles(options) {
        return mapRulesToStyle(this.cssRules(), options);
    };
    _proto.getIdAndRules = function getIdAndRules(props) {
        var css = props.children, dynamic = props.dynamic, id = props.id;
        if (dynamic) {
            var styleId = computeId(id, dynamic);
            return {
                styleId: styleId,
                rules: Array.isArray(css) ? css.map(function(rule) {
                    return computeSelector(styleId, rule);
                }) : [
                    computeSelector(styleId, css)
                ]
            };
        }
        return {
            styleId: computeId(id),
            rules: Array.isArray(css) ? css : [
                css
            ]
        };
    };
    /**
   * selectFromServer
   *
   * Collects style tags from the document with id __jsx-XXX
   */ _proto.selectFromServer = function selectFromServer() {
        var elements = Array.prototype.slice.call(document.querySelectorAll('[id^="__jsx-"]'));
        return elements.reduce(function(acc, element) {
            var id = element.id.slice(2);
            acc[id] = element;
            return acc;
        }, {});
    };
    return StyleSheetRegistry;
}();
function invariant(condition, message) {
    if (!condition) {
        throw new Error("StyleSheetRegistry: " + message + ".");
    }
}
var StyleSheetContext = /*#__PURE__*/ React.createContext(null);
StyleSheetContext.displayName = "StyleSheetContext";
function createStyleRegistry() {
    return new StyleSheetRegistry();
}
function StyleRegistry(param) {
    var configuredRegistry = param.registry, children = param.children;
    var rootRegistry = React.useContext(StyleSheetContext);
    var ref = React.useState({
        "StyleRegistry.useState[ref]": function() {
            return rootRegistry || configuredRegistry || createStyleRegistry();
        }
    }["StyleRegistry.useState[ref]"]), registry = ref[0];
    return /*#__PURE__*/ React__default["default"].createElement(StyleSheetContext.Provider, {
        value: registry
    }, children);
}
function useStyleRegistry() {
    return React.useContext(StyleSheetContext);
}
// Opt-into the new `useInsertionEffect` API in React 18, fallback to `useLayoutEffect`.
// https://github.com/reactwg/react-18/discussions/110
var useInsertionEffect = React__default["default"].useInsertionEffect || React__default["default"].useLayoutEffect;
var defaultRegistry = typeof window !== "undefined" ? createStyleRegistry() : undefined;
function JSXStyle(props) {
    var registry = defaultRegistry ? defaultRegistry : useStyleRegistry();
    // If `registry` does not exist, we do nothing here.
    if (!registry) {
        return null;
    }
    if (typeof window === "undefined") {
        registry.add(props);
        return null;
    }
    useInsertionEffect({
        "JSXStyle.useInsertionEffect": function() {
            registry.add(props);
            return ({
                "JSXStyle.useInsertionEffect": function() {
                    registry.remove(props);
                }
            })["JSXStyle.useInsertionEffect"];
        // props.children can be string[], will be striped since id is identical
        }
    }["JSXStyle.useInsertionEffect"], [
        props.id,
        String(props.dynamic)
    ]);
    return null;
}
JSXStyle.dynamic = function(info) {
    return info.map(function(tagInfo) {
        var baseId = tagInfo[0];
        var props = tagInfo[1];
        return computeId(baseId, props);
    }).join(" ");
};
exports.StyleRegistry = StyleRegistry;
exports.createStyleRegistry = createStyleRegistry;
exports.style = JSXStyle;
exports.useStyleRegistry = useStyleRegistry;
}),
"[project]/node_modules/.pnpm/styled-jsx@5.1.6_@babel+core@7.28.6_react@19.2.1/node_modules/styled-jsx/style.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = __turbopack_context__.r("[project]/node_modules/.pnpm/styled-jsx@5.1.6_@babel+core@7.28.6_react@19.2.1/node_modules/styled-jsx/dist/index/index.js [app-client] (ecmascript)").style;
}),
"[project]/node_modules/.pnpm/zustand@5.0.10_@types+react@19.2.9_react@19.2.1_use-sync-external-store@1.6.0_react@19.2.1_/node_modules/zustand/esm/vanilla.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createStore",
    ()=>createStore
]);
const createStoreImpl = (createState)=>{
    let state;
    const listeners = /* @__PURE__ */ new Set();
    const setState = (partial, replace)=>{
        const nextState = typeof partial === "function" ? partial(state) : partial;
        if (!Object.is(nextState, state)) {
            const previousState = state;
            state = (replace != null ? replace : typeof nextState !== "object" || nextState === null) ? nextState : Object.assign({}, state, nextState);
            listeners.forEach((listener)=>listener(state, previousState));
        }
    };
    const getState = ()=>state;
    const getInitialState = ()=>initialState;
    const subscribe = (listener)=>{
        listeners.add(listener);
        return ()=>listeners.delete(listener);
    };
    const api = {
        setState,
        getState,
        getInitialState,
        subscribe
    };
    const initialState = state = createState(setState, getState, api);
    return api;
};
const createStore = (createState)=>createState ? createStoreImpl(createState) : createStoreImpl;
;
}),
"[project]/node_modules/.pnpm/zustand@5.0.10_@types+react@19.2.9_react@19.2.1_use-sync-external-store@1.6.0_react@19.2.1_/node_modules/zustand/esm/react.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "create",
    ()=>create,
    "useStore",
    ()=>useStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zustand$40$5$2e$0$2e$10_$40$types$2b$react$40$19$2e$2$2e$9_react$40$19$2e$2$2e$1_use$2d$sync$2d$external$2d$store$40$1$2e$6$2e$0_react$40$19$2e$2$2e$1_$2f$node_modules$2f$zustand$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zustand@5.0.10_@types+react@19.2.9_react@19.2.1_use-sync-external-store@1.6.0_react@19.2.1_/node_modules/zustand/esm/vanilla.mjs [app-client] (ecmascript)");
;
;
const identity = (arg)=>arg;
function useStore(api, selector = identity) {
    const slice = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useSyncExternalStore(api.subscribe, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "useStore.useSyncExternalStore[slice]": ()=>selector(api.getState())
    }["useStore.useSyncExternalStore[slice]"], [
        api,
        selector
    ]), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "useStore.useSyncExternalStore[slice]": ()=>selector(api.getInitialState())
    }["useStore.useSyncExternalStore[slice]"], [
        api,
        selector
    ]));
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useDebugValue(slice);
    return slice;
}
const createImpl = (createState)=>{
    const api = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zustand$40$5$2e$0$2e$10_$40$types$2b$react$40$19$2e$2$2e$9_react$40$19$2e$2$2e$1_use$2d$sync$2d$external$2d$store$40$1$2e$6$2e$0_react$40$19$2e$2$2e$1_$2f$node_modules$2f$zustand$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createStore"])(createState);
    const useBoundStore = (selector)=>useStore(api, selector);
    Object.assign(useBoundStore, api);
    return useBoundStore;
};
const create = (createState)=>createState ? createImpl(createState) : createImpl;
;
}),
"[project]/node_modules/.pnpm/@faker-js+faker@9.9.0/node_modules/@faker-js/faker/dist/chunk-KERBADJJ.js [app-client] (ecmascript) <export a as en>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "en",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$KERBADJJ$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["a"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$KERBADJJ$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@faker-js+faker@9.9.0/node_modules/@faker-js/faker/dist/chunk-KERBADJJ.js [app-client] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@faker-js+faker@9.9.0/node_modules/@faker-js/faker/dist/chunk-YQYVFZYE.js [app-client] (ecmascript) <export n as Faker>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Faker",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$YQYVFZYE$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["n"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$YQYVFZYE$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@faker-js+faker@9.9.0/node_modules/@faker-js/faker/dist/chunk-YQYVFZYE.js [app-client] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@faker-js+faker@9.9.0/node_modules/@faker-js/faker/dist/chunk-RHFAIXC4.js [app-client] (ecmascript) <export a as nb_NO>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "nb_NO",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["a"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@faker-js+faker@9.9.0/node_modules/@faker-js/faker/dist/chunk-RHFAIXC4.js [app-client] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@faker-js+faker@9.9.0/node_modules/@faker-js/faker/dist/chunk-ALYSO3IW.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "a",
    ()=>O,
    "b",
    ()=>Ba
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$KERBADJJ$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@faker-js+faker@9.9.0/node_modules/@faker-js/faker/dist/chunk-KERBADJJ.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$YQYVFZYE$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@faker-js+faker@9.9.0/node_modules/@faker-js/faker/dist/chunk-YQYVFZYE.js [app-client] (ecmascript)");
;
;
var i = [
    "Ltd",
    "Plc",
    "Venture"
];
var c = {
    legal_entity_type: i
}, n = c;
var u = [
    "com",
    "com.ng",
    "ng",
    "org.ng"
];
var B = {
    domain_suffix: u
}, r = B;
var t = [
    "Abala",
    "Abalakiri",
    "Bekirikiri",
    "Bela",
    "Belatiwa",
    "Bokodo",
    "Ibinta",
    "Ibiono Ewura",
    "Farin Yashe",
    "Fedare",
    "Fobir",
    "Fobro",
    "Gabgell",
    "Gamajigo",
    "Gana",
    "Gana Daji",
    "Gidan Hardo",
    "Abagbo",
    "Abalabi",
    "Abaranjeh",
    "Abatiwa",
    "Abegede",
    "Abekkun",
    "Abule Ijesha",
    "Abule-Nla",
    "Adata",
    "Addo",
    "Adekanbi",
    "Adeleye",
    "Ado",
    "Ado Odo",
    "Afami",
    "Afanji",
    "Afowo Doforo",
    "Afowowa",
    "Agada",
    "Agaja",
    "Agala",
    "Agani",
    "Aganni",
    "Agaw Awusa",
    "Agaw Shasha",
    "Agbaku",
    "Agbara",
    "Agbede",
    "Agbedi",
    "Agbejedo",
    "Agbele",
    "Agbelekale",
    "Agboju",
    "Agboku",
    "Agbon",
    "Agbonyedo",
    "Agbowa",
    "Agboyi",
    "Age Mowo",
    "Agege",
    "Agelete",
    "Agerige",
    "Agidi",
    "Agidingbi",
    "Ago Egun",
    "Ago Hausa",
    "Ago Sasa",
    "Agomu",
    "Agonrin",
    "Agonu",
    "Aguda",
    "Agun",
    "Agunfoye",
    "Agura",
    "Ahanfe",
    "Ahovo",
    "Ahun",
    "Aiyede",
    "Aiyeteju",
    "Aiyetoro",
    "Aiyetoto-Asogun",
    "Aja",
    "Ajagambari",
    "Ajara",
    "Ajara Agamaden",
    "Ajebandele",
    "Ajebaw",
    "Ajebo",
    "Ajegbenwa",
    "Ajegunle",
    "Ajelanwa",
    "Ajerogun",
    "Ajibade",
    "Ajibawo",
    "Ajibo",
    "Ajido",
    "Ajise",
    "Ajumo",
    "Akando",
    "Akangba",
    "Akarakumo",
    "Akawdo",
    "Akawkaw",
    "Akere",
    "Akessan",
    "Akete",
    "Akinbo",
    "Akinlade",
    "Akinogun",
    "Akinyele",
    "Akio",
    "Akobale",
    "Akodo",
    "Akoko",
    "Akore",
    "Akowonjo",
    "Alagba",
    "Alagbede",
    "Alagbon",
    "Alago",
    "Alagogo",
    "Alaguntan",
    "Alaiyabiagba",
    "Alapako",
    "Alaparu",
    "Alaparun",
    "Alapoti",
    "Alaru",
    "Alasia",
    "Ale",
    "Aliayabiagba",
    "Alimosho",
    "Alimoso",
    "Amuwo",
    "Anagoji",
    "Anagunji",
    "Angorin",
    "Animashawun",
    "Animshaun",
    "Apa",
    "Apamu",
    "Apapa",
    "Apapa Eleko",
    "Apese",
    "Appa",
    "Aqani",
    "Aradagun",
    "Arapagi Oloko",
    "Arapagi-Awlawkaw",
    "Arapagi-Ejetu",
    "Araromi",
    "Araromi Orita",
    "Araromi Tawpe",
    "Araromi Tope",
    "Arida",
    "Arigo",
    "Ashon",
    "Asipa",
    "Ason",
    "Asore",
    "Asunora",
    "Atan",
    "Atapa",
    "Awado",
    "Awaiye",
    "Awaye",
    "Awdan Ilaro",
    "Awdan Iyasi",
    "Awfin",
    "Awgawgawraw",
    "Awgawmbaw",
    "Awja-Ikoradu",
    "Awjaw",
    "Awoyaya",
    "Awreta",
    "Awteyi",
    "Awwaw",
    "Ayekoshe",
    "Ayinla",
    "Ayobo",
    "Babalawo",
    "Badagri",
    "Badagry",
    "Badawre",
    "Badore",
    "Baiyeku",
    "Balagbe",
    "Balogun",
    "Bamgbose",
    "Bamgboshe",
    "Bandu",
    "Banimgbe",
    "Banimgbo",
    "Bariga",
    "Baruwa",
    "Bassa",
    "Beshi",
    "Bodashe",
    "Bode Ase",
    "Bolorunpelu",
    "Cardoso",
    "Coker",
    "Coker Market",
    "Cokers Market",
    "Dankaka",
    "Doforo",
    "Dosa",
    "Dosemo",
    "Ebute Ikorodu",
    "Ebute Leki",
    "Ebute Lekki",
    "Ebute-Egga",
    "Ebute-Metta",
    "Efiran",
    "Egan",
    "Egba",
    "Egbe",
    "Eggan",
    "Egudu Bale",
    "Egun",
    "Eiyekose",
    "Ejigbo",
    "Ejinrin",
    "Ejirin",
    "Eko",
    "Ekoro",
    "Ekundayo",
    "Elachi",
    "Elemoki",
    "Eleputu",
    "Elere",
    "Elesin",
    "Eluju",
    "Emu",
    "Epe",
    "Epeh",
    "Era",
    "Ere",
    "Eregun",
    "Erekiti",
    "Erukan",
    "Eruku",
    "Erunkan",
    "Etegbin",
    "Euni",
    "Ewekora",
    "Ewekoro",
    "Ewu",
    "Ewu Ebi",
    "Falomo",
    "Fatade",
    "Fatedo",
    "Fonji",
    "Ganme",
    "Ganyingbo",
    "Gbagidan",
    "Gbaj",
    "Gbaji",
    "Gbanko",
    "Gberegbe",
    "Gberigbe",
    "Gbesse",
    "Gbeta",
    "Gbodo",
    "Gbogbo",
    "Gbogije",
    "Gbokuta",
    "George",
    "Ginti",
    "Hausa",
    "Henume",
    "Hundo",
    "Iba",
    "Ibadan",
    "Ibasa",
    "Ibasha",
    "Ibatefin",
    "Ibawe Kekere",
    "Ibawe Tukuru",
    "Ibbojo",
    "Ibefon",
    "Ibefum",
    "Ibefun",
    "Ibeju",
    "Ibereko",
    "Iberekodo",
    "Ibese",
    "Ibeshe",
    "Ibeshi",
    "Ibiku",
    "Ibode",
    "Ibogun Adina",
    "Ibogun Akiode",
    "Ibogun Sowunmi",
    "Iboju",
    "Ibon",
    "Ibopa",
    "Ida",
    "Idain Isaga",
    "Idain-Ishaga",
    "Idamo",
    "Idanfuru",
    "Idashaw",
    "Idaso",
    "Idata",
    "Iddo",
    "Ide",
    "Idele",
    "Ideno",
    "Idi Agbon Agana",
    "Idi Iroko",
    "Idi Ofe",
    "Idi Oro",
    "Idi-Off",
    "Idimarun",
    "Idimi",
    "Idimu",
    "Idiori",
    "Idiroko",
    "Idobarun",
    "Idoforo",
    "Idolanja",
    "Idole",
    "Idolehin",
    "Idolorisha",
    "Idolosa",
    "Idomu",
    "Idopetu",
    "Idosa",
    "Idosemo",
    "Idowu",
    "Ifako",
    "Igami",
    "Igando",
    "Igando Awlawja",
    "Iganmi",
    "Iganmu",
    "Iganmu Siding",
    "Igbalu",
    "Igbe",
    "Igbe Ewoliwo",
    "Igbede",
    "Igbegodo",
    "Igbekun",
    "Igbele",
    "Igbessa",
    "Igbin",
    "Igbin Oloya",
    "Igbo",
    "Igbo Ejo",
    "Igbo Fipe",
    "Igbobi",
    "Igbodu",
    "Igboefon",
    "Igbogbele",
    "Igbogila",
    "Igbogun",
    "Igbogun-Sowunmi",
    "Igboje",
    "Igbokushun",
    "Igbolobi",
    "Igbologun",
    "Igboloye",
    "Igbopa",
    "Igborosun",
    "Igbosa",
    "Igbosere",
    "Igboshere",
    "Igodonu",
    "Igoro",
    "Igu",
    "Igude",
    "Igunnu Akabo",
    "Ijagemo",
    "Ijaiye",
    "Ijako",
    "Ijako Orile",
    "Ijanikin",
    "Ijawmi",
    "Ijawmu",
    "Ijawtun",
    "Ijayie",
    "Ijede",
    "Ijegun",
    "Ijero",
    "Ijesa-Tedo",
    "Ijofin",
    "Ijomi",
    "Ijomu",
    "Ijora",
    "Ijora Village",
    "Ijotan",
    "Iju",
    "Iju Junction",
    "Iju Water Works",
    "Ikare",
    "Ikate",
    "Ikawga",
    "Ikawga-Zebe",
    "Ikawlaji",
    "Ikawta",
    "Ikeja",
    "Ikoga",
    "Ikoga Ile",
    "Ikogbo",
    "Ikolaja",
    "Ikorodu",
    "Ikosi",
    "Ikotan",
    "Ikotun",
    "Ikoyi",
    "Ikuata",
    "Ilade",
    "Ilado",
    "Ilado Ogunu",
    "Ilagbo",
    "Ilasa",
    "Ilashe",
    "Ilemere",
    "Ilepa",
    "Ileppaw",
    "Ilera",
    "Ilikiti",
    "Ilo",
    "Ilogbo",
    "Ilogbo Elegba",
    "Iloro",
    "Ilugboro",
    "Ilumawfin",
    "Ilumofin",
    "Imare",
    "Imawte",
    "Imeke",
    "Imeri",
    "Imeseju",
    "Imore",
    "Imoru",
    "Imota",
    "Inogbe",
    "Inupa",
    "Inupa Kekere",
    "Ipaja",
    "Ipakan",
    "Ipanmi",
    "Ipatira",
    "Ipeshu",
    "Ipesu",
    "Ipewu",
    "Ipokia",
    "Iponri",
    "Ipota",
    "Iragbo",
    "Iragon",
    "Iranla",
    "Irede",
    "Irewe",
    "Iru",
    "Isagatedo",
    "Isagbo",
    "Isagbo Ere",
    "Isagira",
    "Isaku",
    "Isalu",
    "Isashi",
    "Isasi",
    "Isawo",
    "Ise",
    "Iseku",
    "Isekun",
    "Iseri-Osun",
    "Ishaga",
    "Ishagbo",
    "Ishagira",
    "Ishasi",
    "Ishawo",
    "Isheri-Olofin",
    "Ishersi",
    "Ishola",
    "Isiu",
    "Isiwu",
    "Isola",
    "Isolo",
    "Isunba",
    "Ita Egbe",
    "Ita Onimosa",
    "Itagbo",
    "Itamaga",
    "Itawga",
    "Itawikin",
    "Itawmu",
    "Iteku",
    "Itele",
    "Itere",
    "Itire",
    "Itirin",
    "Ito Omu",
    "Itoga",
    "Itohun",
    "Itoikin",
    "Itokin",
    "Itomu",
    "Itori",
    "Iwaya",
    "Iwerekun",
    "Iworo",
    "Iwuku",
    "Iyafin",
    "Iyagbe",
    "Iyasi",
    "Iyesi",
    "Jaguna",
    "Janikin",
    "Jibowu",
    "Jinadu",
    "Kadara",
    "Kafara",
    "Kajola",
    "Kajola Iboro",
    "Kandoro",
    "Kese"
];
var m = [
    "{{location.city_name}}"
];
var l = [
    "#####",
    "####"
];
var I = [
    "FCT",
    "ABIA",
    "ADAMAWA",
    "Akwa Ibom",
    "Anambra",
    "Bauchi",
    "Bayelsa",
    "Benue",
    "Bornu",
    "Cross River",
    "Delta",
    "Ebonyi",
    "Edo",
    "Ekiti",
    "Enugu",
    "Gombe",
    "Imo",
    "Jigawa",
    "Kaduna",
    "Kano",
    "Katsina",
    "Kebbi",
    "Kogi",
    "Kwara",
    "Lagos",
    "Nasarawa",
    "Niger",
    "Ogun",
    "Ondo",
    "Osun",
    "Oyo",
    "Plateau",
    "Rivers",
    "Sokoto",
    "Taraba",
    "Yobe",
    "Zamfara"
];
var b = [
    "{{person.firstName}} {{location.street_suffix}}",
    "{{person.lastName}} {{location.street_suffix}}"
];
var G = {
    city_name: t,
    city_pattern: m,
    postcode: l,
    state: I,
    street_pattern: b
}, A = G;
var C = {
    title: "English (Nigeria)",
    code: "en_NG",
    country: "NG",
    language: "en",
    endonym: "English (Nigeria)",
    dir: "ltr",
    script: "Latn"
}, g = C;
var d = {
    generic: [
        "Abimbola",
        "Abisola",
        "Abisoye",
        "Adaugo",
        "Adeboye",
        "Adedayo",
        "Adegoke",
        "Akande",
        "Akanni",
        "Akunna",
        "Alade",
        "Aminat",
        "Aminu",
        "Augustina",
        "Ayebatari",
        "Ayinde",
        "Azubuike",
        "Banji",
        "Bankole",
        "Buchi",
        "Bukola",
        "Cherechi",
        "Chiamaka",
        "Chimamanda",
        "Chinedu",
        "Chinyere",
        "Chisom",
        "Chizoba",
        "Chukwu",
        "Damilare",
        "Damilola",
        "Danjuma",
        "Ebiere",
        "Ebiowei",
        "Efe",
        "Emeka",
        "Emmanuel",
        "Esse",
        "Fatima",
        "Funmilade",
        "Funmilayo",
        "Gbeminiyi",
        "Gbemisola",
        "Habiba",
        "Ifeanyichukwu",
        "Ifeoma",
        "Ifunanya",
        "Ikenna",
        "Ikhidie",
        "Ireti",
        "Isioma",
        "Jadesola",
        "Johnson",
        "Jolayemi",
        "Kayode",
        "Kemi",
        "Kubra",
        "Kubura",
        "Lola",
        "Lolade",
        "Makinwa",
        "Mohammed",
        "Musa",
        "Muyiwa",
        "Nnamdi",
        "Obioma",
        "Olaide",
        "Olufunmi",
        "Olumide",
        "Oluwunmi",
        "Omawunmi",
        "Omolara",
        "Onome",
        "Onoriode",
        "Rasheedah",
        "Remilekun",
        "Rotimi",
        "Sekinat",
        "Shade",
        "Shalewa",
        "Simisola",
        "Sname",
        "Sumayyah",
        "Tari",
        "Temitope",
        "Titi",
        "Titilayo",
        "Titilope",
        "Tobiloba",
        "Toke",
        "Toluwani",
        "Tomiloba",
        "Tope",
        "Uzodimma",
        "Wale",
        "Yakubu",
        "Yusuf",
        "Zainab"
    ],
    female: [
        "Adaugo",
        "Akunna",
        "Aminat",
        "Aminu",
        "Augustina",
        "Ayebatari",
        "Cherechi",
        "Chiamaka",
        "Chimamanda",
        "Chinyere",
        "Chizoba",
        "Ebiere",
        "Efe",
        "Fatima",
        "Ifeoma",
        "Ifunanya",
        "Isioma",
        "Jolayemi",
        "Lola",
        "Obioma",
        "Omawunmi",
        "Omolara",
        "Onome",
        "Rasheedah",
        "Sekinat",
        "Simisola",
        "Sumayyah",
        "Titi",
        "Titilayo",
        "Toluwani",
        "Zainab"
    ],
    male: [
        "Abimbola",
        "Abisola",
        "Abisoye",
        "Adeboye",
        "Adedayo",
        "Adegoke",
        "Akande",
        "Akanni",
        "Alade",
        "Ayinde",
        "Azubuike",
        "Banji",
        "Bankole",
        "Buchi",
        "Bukola",
        "Chinedu",
        "Chisom",
        "Chukwu",
        "Damilare",
        "Damilola",
        "Danjuma",
        "Ebiowei",
        "Emeka",
        "Emmanuel",
        "Esse",
        "Funmilade",
        "Funmilayo",
        "Gbeminiyi",
        "Gbemisola",
        "Habiba",
        "Ifeanyichukwu",
        "Ikenna",
        "Ikhidie",
        "Ireti",
        "Jadesola",
        "Johnson",
        "Kayode",
        "Kemi",
        "Kubra",
        "Kubura",
        "Lolade",
        "Makinwa",
        "Mohammed",
        "Musa",
        "Muyiwa",
        "Nnamdi",
        "Olaide",
        "Olufunmi",
        "Olumide",
        "Oluwunmi",
        "Onoriode",
        "Remilekun",
        "Rotimi",
        "Shade",
        "Shalewa",
        "Sname",
        "Tari",
        "Temitope",
        "Titilope",
        "Tobiloba",
        "Toke",
        "Tomiloba",
        "Tope",
        "Uzodimma",
        "Wale",
        "Yakubu",
        "Yusuf"
    ]
};
var s = {
    generic: [
        "Abiodun",
        "Abiola",
        "Abodunrin",
        "Abosede",
        "Adaobi",
        "Adebayo",
        "Adegboye",
        "Adegoke",
        "Ademayowa",
        "Ademola",
        "Adeniyan",
        "Adeoluwa",
        "Aderinsola",
        "Aderonke",
        "Adesina",
        "Adewale",
        "Adewunmi",
        "Adewura",
        "Adeyemo",
        "Afolabi",
        "Afunku",
        "Agboola",
        "Agnes",
        "Aigbiniode",
        "Ajakaiye",
        "Ajose-adeogun",
        "Akeem-omosanya",
        "Akerele",
        "Akintade",
        "Aligbe",
        "Amaechi",
        "Aminat",
        "Aremu",
        "Atanda",
        "Ayisat",
        "Ayobami",
        "Ayomide",
        "Babalola",
        "Babatunde",
        "Balogun",
        "Bamisebi",
        "Bello",
        "Busari",
        "Chibike",
        "Chibuike",
        "Chidinma",
        "Chidozie",
        "Christian",
        "Clare",
        "David",
        "Ebubechukwu",
        "Egbochukwu",
        "Ehigiator",
        "Ekwueme",
        "Elebiyo",
        "Elizabeth",
        "Emmanuel",
        "Esther",
        "Funmilayo",
        "Gbadamosi",
        "Gbogboade",
        "Grace",
        "Habeeb",
        "Hanifat",
        "Isaac",
        "Ismail",
        "Isokun",
        "Israel",
        "Iyalla",
        "Jamiu",
        "Jimoh",
        "Joshua",
        "Justina",
        "Katherine",
        "Kayode",
        "Kimberly",
        "Ladega",
        "Latifat",
        "Lawal",
        "Leonard",
        "Makuachukwu",
        "Maryam",
        "Maryjane",
        "Mayowa",
        "Miracle",
        "Mobolaji",
        "Mogbadunade",
        "Motalo",
        "Muinat",
        "Mukaram",
        "Mustapha",
        "Mutiat",
        "Ndukwu",
        "Ngozi",
        "Nojeem",
        "Nwachukwu",
        "Nwogu",
        "Nwuzor",
        "Obiageli",
        "Obianuju",
        "Odunayo",
        "Ogunbanwo",
        "Ogunwande",
        "Okonkwo",
        "Okunola",
        "Oladeji",
        "Oladimeji",
        "Olaoluwa",
        "Olasunkanmi",
        "Olasunkanmi-fasayo",
        "Olawale",
        "Olubukola",
        "Olubunmi",
        "Olufeyikemi",
        "Olumide",
        "Olutola",
        "Oluwakemi",
        "Oluwanisola",
        "Oluwaseun",
        "Oluwaseyi",
        "Oluwashina",
        "Oluwatosin",
        "Omobolaji",
        "Omobolanle",
        "Omolara",
        "Omowale",
        "Onohinosen",
        "Onose",
        "Onyinyechukwu",
        "Opeyemi",
        "Osuagwu",
        "Oyebola",
        "Oyelude",
        "Oyinkansola",
        "Peter",
        "Sabdat",
        "Saheed",
        "Salami",
        "Samuel",
        "Sanusi",
        "Sarah",
        "Segunmaru",
        "Sekinat",
        "Sulaimon",
        "Sylvester",
        "Taiwo",
        "Tamunoemi",
        "Tella",
        "Temitope",
        "Tolulope",
        "Uchechi",
        "Wasiu",
        "Wilcox",
        "Wuraola",
        "Yaqub",
        "Yussuf"
    ]
};
var k = {
    generic: [
        {
            value: "{{person.last_name.generic}}",
            weight: 95
        },
        {
            value: "{{person.last_name.generic}}-{{person.last_name.generic}}",
            weight: 5
        }
    ]
};
var w = [
    {
        value: "{{person.firstName}} {{person.lastName}}",
        weight: 1
    },
    {
        value: "{{person.lastName}} {{person.firstName}}",
        weight: 1
    }
];
var D = {
    first_name: d,
    last_name: s,
    last_name_pattern: k,
    name: w
}, p = D;
var f = [
    "0803 ### ####",
    "0703 ### ####",
    "234809 ### ####",
    "+234 802 ### ####",
    "0805### ####"
];
var y = [
    "+234803#######",
    "+234703#######",
    "+234809#######",
    "+234802#######",
    "+234805#######"
];
var h = [
    "0803 ### ####",
    "0703 ### ####",
    "0809 ### ####",
    "0802 ### ####",
    "0805 ### ####"
];
var T = {
    human: f,
    international: y,
    national: h
}, j = T;
var S = {
    format: j
}, E = S;
var x = {
    company: n,
    internet: r,
    location: A,
    metadata: g,
    person: p,
    phone_number: E
}, O = x;
var Ba = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$YQYVFZYE$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["n"]({
    locale: [
        O,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$KERBADJJ$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["a"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$YQYVFZYE$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["o"]
    ]
});
;
}),
"[project]/node_modules/.pnpm/@faker-js+faker@9.9.0/node_modules/@faker-js/faker/dist/chunk-ALYSO3IW.js [app-client] (ecmascript) <export a as en_NG>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "en_NG",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$ALYSO3IW$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["a"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$ALYSO3IW$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@faker-js+faker@9.9.0/node_modules/@faker-js/faker/dist/chunk-ALYSO3IW.js [app-client] (ecmascript)");
}),
"[project]/node_modules/.pnpm/lucide-react@0.510.0_react@19.2.1/node_modules/lucide-react/dist/esm/icons/ellipsis.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Ellipsis
]);
/**
 * @license lucide-react v0.510.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$510$2e$0_react$40$19$2e$2$2e$1$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.510.0_react@19.2.1/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "circle",
        {
            cx: "12",
            cy: "12",
            r: "1",
            key: "41hilf"
        }
    ],
    [
        "circle",
        {
            cx: "19",
            cy: "12",
            r: "1",
            key: "1wjl8i"
        }
    ],
    [
        "circle",
        {
            cx: "5",
            cy: "12",
            r: "1",
            key: "1pcz8c"
        }
    ]
];
const Ellipsis = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$510$2e$0_react$40$19$2e$2$2e$1$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("ellipsis", __iconNode);
;
 //# sourceMappingURL=ellipsis.js.map
}),
"[project]/node_modules/.pnpm/lucide-react@0.510.0_react@19.2.1/node_modules/lucide-react/dist/esm/icons/ellipsis.js [app-client] (ecmascript) <export default as MoreHorizontal>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MoreHorizontal",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$510$2e$0_react$40$19$2e$2$2e$1$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$ellipsis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$510$2e$0_react$40$19$2e$2$2e$1$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$ellipsis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.510.0_react@19.2.1/node_modules/lucide-react/dist/esm/icons/ellipsis.js [app-client] (ecmascript)");
}),
"[project]/node_modules/.pnpm/lucide-react@0.510.0_react@19.2.1/node_modules/lucide-react/dist/esm/icons/link.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Link
]);
/**
 * @license lucide-react v0.510.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$510$2e$0_react$40$19$2e$2$2e$1$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.510.0_react@19.2.1/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71",
            key: "1cjeqo"
        }
    ],
    [
        "path",
        {
            d: "M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71",
            key: "19qd67"
        }
    ]
];
const Link = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$510$2e$0_react$40$19$2e$2$2e$1$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("link", __iconNode);
;
 //# sourceMappingURL=link.js.map
}),
"[project]/node_modules/.pnpm/lucide-react@0.510.0_react@19.2.1/node_modules/lucide-react/dist/esm/icons/link.js [app-client] (ecmascript) <export default as LinkIcon>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LinkIcon",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$510$2e$0_react$40$19$2e$2$2e$1$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$510$2e$0_react$40$19$2e$2$2e$1$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.510.0_react@19.2.1/node_modules/lucide-react/dist/esm/icons/link.js [app-client] (ecmascript)");
}),
"[project]/node_modules/.pnpm/lucide-react@0.510.0_react@19.2.1/node_modules/lucide-react/dist/esm/icons/chevron-down.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>ChevronDown
]);
/**
 * @license lucide-react v0.510.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$510$2e$0_react$40$19$2e$2$2e$1$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.510.0_react@19.2.1/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "m6 9 6 6 6-6",
            key: "qrunsl"
        }
    ]
];
const ChevronDown = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$510$2e$0_react$40$19$2e$2$2e$1$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("chevron-down", __iconNode);
;
 //# sourceMappingURL=chevron-down.js.map
}),
"[project]/node_modules/.pnpm/lucide-react@0.510.0_react@19.2.1/node_modules/lucide-react/dist/esm/icons/chevron-down.js [app-client] (ecmascript) <export default as ChevronDownIcon>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ChevronDownIcon",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$510$2e$0_react$40$19$2e$2$2e$1$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$510$2e$0_react$40$19$2e$2$2e$1$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.510.0_react@19.2.1/node_modules/lucide-react/dist/esm/icons/chevron-down.js [app-client] (ecmascript)");
}),
"[project]/node_modules/.pnpm/classnames@2.5.1/node_modules/classnames/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/*!
	Copyright (c) 2018 Jed Watson.
	Licensed under the MIT License (MIT), see
	http://jedwatson.github.io/classnames
*/ /* global define */ (function() {
    'use strict';
    var hasOwn = {}.hasOwnProperty;
    function classNames() {
        var classes = '';
        for(var i = 0; i < arguments.length; i++){
            var arg = arguments[i];
            if (arg) {
                classes = appendClass(classes, parseValue(arg));
            }
        }
        return classes;
    }
    function parseValue(arg) {
        if (typeof arg === 'string' || typeof arg === 'number') {
            return arg;
        }
        if (typeof arg !== 'object') {
            return '';
        }
        if (Array.isArray(arg)) {
            return classNames.apply(null, arg);
        }
        if (arg.toString !== Object.prototype.toString && !arg.toString.toString().includes('[native code]')) {
            return arg.toString();
        }
        var classes = '';
        for(var key in arg){
            if (hasOwn.call(arg, key) && arg[key]) {
                classes = appendClass(classes, key);
            }
        }
        return classes;
    }
    function appendClass(value, newClass) {
        if (!newClass) {
            return value;
        }
        if (value) {
            return value + ' ' + newClass;
        }
        return value + newClass;
    }
    if (("TURBOPACK compile-time value", "object") !== 'undefined' && module.exports) {
        classNames.default = classNames;
        module.exports = classNames;
    } else if (typeof define === 'function' && typeof define.amd === 'object' && define.amd) {
        // register as 'classnames', consistent with npm package name
        ((r)=>r !== undefined && __turbopack_context__.v(r))(function() {
            return classNames;
        }());
    } else {
        window.classNames = classNames;
    }
})();
}),
"[project]/node_modules/.pnpm/react-dnd-html5-backend@16.0.1/node_modules/react-dnd-html5-backend/dist/utils/js_utils.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// cheap lodash replacements
__turbopack_context__.s([
    "memoize",
    ()=>memoize,
    "union",
    ()=>union,
    "without",
    ()=>without
]);
function memoize(fn) {
    let result = null;
    const memoized = ()=>{
        if (result == null) {
            result = fn();
        }
        return result;
    };
    return memoized;
}
function without(items, item) {
    return items.filter((i)=>i !== item);
}
function union(itemsA, itemsB) {
    const set = new Set();
    const insertItem = (item)=>set.add(item);
    itemsA.forEach(insertItem);
    itemsB.forEach(insertItem);
    const result = [];
    set.forEach((key)=>result.push(key));
    return result;
} //# sourceMappingURL=js_utils.js.map
}),
"[project]/node_modules/.pnpm/react-dnd-html5-backend@16.0.1/node_modules/react-dnd-html5-backend/dist/EnterLeaveCounter.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "EnterLeaveCounter",
    ()=>EnterLeaveCounter
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$utils$2f$js_utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd-html5-backend@16.0.1/node_modules/react-dnd-html5-backend/dist/utils/js_utils.js [app-client] (ecmascript)");
;
class EnterLeaveCounter {
    enter(enteringNode) {
        const previousLength = this.entered.length;
        const isNodeEntered = (node)=>this.isNodeInDocument(node) && (!node.contains || node.contains(enteringNode));
        this.entered = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$utils$2f$js_utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["union"])(this.entered.filter(isNodeEntered), [
            enteringNode
        ]);
        return previousLength === 0 && this.entered.length > 0;
    }
    leave(leavingNode) {
        const previousLength = this.entered.length;
        this.entered = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$utils$2f$js_utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["without"])(this.entered.filter(this.isNodeInDocument), leavingNode);
        return previousLength > 0 && this.entered.length === 0;
    }
    reset() {
        this.entered = [];
    }
    constructor(isNodeInDocument){
        this.entered = [];
        this.isNodeInDocument = isNodeInDocument;
    }
} //# sourceMappingURL=EnterLeaveCounter.js.map
}),
"[project]/node_modules/.pnpm/react-dnd-html5-backend@16.0.1/node_modules/react-dnd-html5-backend/dist/NativeDragSources/NativeDragSource.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "NativeDragSource",
    ()=>NativeDragSource
]);
class NativeDragSource {
    initializeExposedProperties() {
        Object.keys(this.config.exposeProperties).forEach((property)=>{
            Object.defineProperty(this.item, property, {
                configurable: true,
                enumerable: true,
                get () {
                    // eslint-disable-next-line no-console
                    console.warn(`Browser doesn't allow reading "${property}" until the drop event.`);
                    return null;
                }
            });
        });
    }
    loadDataTransfer(dataTransfer) {
        if (dataTransfer) {
            const newProperties = {};
            Object.keys(this.config.exposeProperties).forEach((property)=>{
                const propertyFn = this.config.exposeProperties[property];
                if (propertyFn != null) {
                    newProperties[property] = {
                        value: propertyFn(dataTransfer, this.config.matchesTypes),
                        configurable: true,
                        enumerable: true
                    };
                }
            });
            Object.defineProperties(this.item, newProperties);
        }
    }
    canDrag() {
        return true;
    }
    beginDrag() {
        return this.item;
    }
    isDragging(monitor, handle) {
        return handle === monitor.getSourceId();
    }
    endDrag() {
    // empty
    }
    constructor(config){
        this.config = config;
        this.item = {};
        this.initializeExposedProperties();
    }
} //# sourceMappingURL=NativeDragSource.js.map
}),
"[project]/node_modules/.pnpm/react-dnd-html5-backend@16.0.1/node_modules/react-dnd-html5-backend/dist/NativeTypes.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FILE",
    ()=>FILE,
    "HTML",
    ()=>HTML,
    "TEXT",
    ()=>TEXT,
    "URL",
    ()=>URL
]);
const FILE = '__NATIVE_FILE__';
const URL = '__NATIVE_URL__';
const TEXT = '__NATIVE_TEXT__';
const HTML = '__NATIVE_HTML__'; //# sourceMappingURL=NativeTypes.js.map
}),
"[project]/node_modules/.pnpm/react-dnd-html5-backend@16.0.1/node_modules/react-dnd-html5-backend/dist/NativeDragSources/getDataFromDataTransfer.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getDataFromDataTransfer",
    ()=>getDataFromDataTransfer
]);
function getDataFromDataTransfer(dataTransfer, typesToTry, defaultValue) {
    const result = typesToTry.reduce((resultSoFar, typeToTry)=>resultSoFar || dataTransfer.getData(typeToTry), '');
    return result != null ? result : defaultValue;
} //# sourceMappingURL=getDataFromDataTransfer.js.map
}),
"[project]/node_modules/.pnpm/react-dnd-html5-backend@16.0.1/node_modules/react-dnd-html5-backend/dist/NativeDragSources/nativeTypesConfig.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "nativeTypesConfig",
    ()=>nativeTypesConfig
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$NativeTypes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd-html5-backend@16.0.1/node_modules/react-dnd-html5-backend/dist/NativeTypes.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$NativeDragSources$2f$getDataFromDataTransfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd-html5-backend@16.0.1/node_modules/react-dnd-html5-backend/dist/NativeDragSources/getDataFromDataTransfer.js [app-client] (ecmascript)");
;
;
const nativeTypesConfig = {
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$NativeTypes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FILE"]]: {
        exposeProperties: {
            files: (dataTransfer)=>Array.prototype.slice.call(dataTransfer.files),
            items: (dataTransfer)=>dataTransfer.items,
            dataTransfer: (dataTransfer)=>dataTransfer
        },
        matchesTypes: [
            'Files'
        ]
    },
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$NativeTypes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HTML"]]: {
        exposeProperties: {
            html: (dataTransfer, matchesTypes)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$NativeDragSources$2f$getDataFromDataTransfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDataFromDataTransfer"])(dataTransfer, matchesTypes, ''),
            dataTransfer: (dataTransfer)=>dataTransfer
        },
        matchesTypes: [
            'Html',
            'text/html'
        ]
    },
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$NativeTypes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["URL"]]: {
        exposeProperties: {
            urls: (dataTransfer, matchesTypes)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$NativeDragSources$2f$getDataFromDataTransfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDataFromDataTransfer"])(dataTransfer, matchesTypes, '').split('\n'),
            dataTransfer: (dataTransfer)=>dataTransfer
        },
        matchesTypes: [
            'Url',
            'text/uri-list'
        ]
    },
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$NativeTypes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TEXT"]]: {
        exposeProperties: {
            text: (dataTransfer, matchesTypes)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$NativeDragSources$2f$getDataFromDataTransfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDataFromDataTransfer"])(dataTransfer, matchesTypes, ''),
            dataTransfer: (dataTransfer)=>dataTransfer
        },
        matchesTypes: [
            'Text',
            'text/plain'
        ]
    }
}; //# sourceMappingURL=nativeTypesConfig.js.map
}),
"[project]/node_modules/.pnpm/react-dnd-html5-backend@16.0.1/node_modules/react-dnd-html5-backend/dist/NativeDragSources/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createNativeDragSource",
    ()=>createNativeDragSource,
    "matchNativeItemType",
    ()=>matchNativeItemType
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$NativeDragSources$2f$NativeDragSource$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd-html5-backend@16.0.1/node_modules/react-dnd-html5-backend/dist/NativeDragSources/NativeDragSource.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$NativeDragSources$2f$nativeTypesConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd-html5-backend@16.0.1/node_modules/react-dnd-html5-backend/dist/NativeDragSources/nativeTypesConfig.js [app-client] (ecmascript)");
;
;
function createNativeDragSource(type, dataTransfer) {
    const config = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$NativeDragSources$2f$nativeTypesConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["nativeTypesConfig"][type];
    if (!config) {
        throw new Error(`native type ${type} has no configuration`);
    }
    const result = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$NativeDragSources$2f$NativeDragSource$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NativeDragSource"](config);
    result.loadDataTransfer(dataTransfer);
    return result;
}
function matchNativeItemType(dataTransfer) {
    if (!dataTransfer) {
        return null;
    }
    const dataTransferTypes = Array.prototype.slice.call(dataTransfer.types || []);
    return Object.keys(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$NativeDragSources$2f$nativeTypesConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["nativeTypesConfig"]).filter((nativeItemType)=>{
        const typeConfig = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$NativeDragSources$2f$nativeTypesConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["nativeTypesConfig"][nativeItemType];
        if (!(typeConfig === null || typeConfig === void 0 ? void 0 : typeConfig.matchesTypes)) {
            return false;
        }
        return typeConfig.matchesTypes.some((t)=>dataTransferTypes.indexOf(t) > -1);
    })[0] || null;
} //# sourceMappingURL=index.js.map
}),
"[project]/node_modules/.pnpm/react-dnd-html5-backend@16.0.1/node_modules/react-dnd-html5-backend/dist/BrowserDetector.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isFirefox",
    ()=>isFirefox,
    "isSafari",
    ()=>isSafari
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$utils$2f$js_utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd-html5-backend@16.0.1/node_modules/react-dnd-html5-backend/dist/utils/js_utils.js [app-client] (ecmascript)");
;
const isFirefox = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$utils$2f$js_utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memoize"])(()=>/firefox/i.test(navigator.userAgent));
const isSafari = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$utils$2f$js_utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memoize"])(()=>Boolean(window.safari)); //# sourceMappingURL=BrowserDetector.js.map
}),
"[project]/node_modules/.pnpm/react-dnd-html5-backend@16.0.1/node_modules/react-dnd-html5-backend/dist/MonotonicInterpolant.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MonotonicInterpolant",
    ()=>MonotonicInterpolant
]);
class MonotonicInterpolant {
    interpolate(x) {
        const { xs, ys, c1s, c2s, c3s } = this;
        // The rightmost point in the dataset should give an exact result
        let i = xs.length - 1;
        if (x === xs[i]) {
            return ys[i];
        }
        // Search for the interval x is in, returning the corresponding y if x is one of the original xs
        let low = 0;
        let high = c3s.length - 1;
        let mid;
        while(low <= high){
            mid = Math.floor(0.5 * (low + high));
            const xHere = xs[mid];
            if (xHere < x) {
                low = mid + 1;
            } else if (xHere > x) {
                high = mid - 1;
            } else {
                return ys[mid];
            }
        }
        i = Math.max(0, high);
        // Interpolate
        const diff = x - xs[i];
        const diffSq = diff * diff;
        return ys[i] + c1s[i] * diff + c2s[i] * diffSq + c3s[i] * diff * diffSq;
    }
    constructor(xs, ys){
        const { length } = xs;
        // Rearrange xs and ys so that xs is sorted
        const indexes = [];
        for(let i = 0; i < length; i++){
            indexes.push(i);
        }
        indexes.sort((a, b)=>xs[a] < xs[b] ? -1 : 1);
        // Get consecutive differences and slopes
        const dys = [];
        const dxs = [];
        const ms = [];
        let dx;
        let dy;
        for(let i1 = 0; i1 < length - 1; i1++){
            dx = xs[i1 + 1] - xs[i1];
            dy = ys[i1 + 1] - ys[i1];
            dxs.push(dx);
            dys.push(dy);
            ms.push(dy / dx);
        }
        // Get degree-1 coefficients
        const c1s = [
            ms[0]
        ];
        for(let i2 = 0; i2 < dxs.length - 1; i2++){
            const m2 = ms[i2];
            const mNext = ms[i2 + 1];
            if (m2 * mNext <= 0) {
                c1s.push(0);
            } else {
                dx = dxs[i2];
                const dxNext = dxs[i2 + 1];
                const common = dx + dxNext;
                c1s.push(3 * common / ((common + dxNext) / m2 + (common + dx) / mNext));
            }
        }
        c1s.push(ms[ms.length - 1]);
        // Get degree-2 and degree-3 coefficients
        const c2s = [];
        const c3s = [];
        let m;
        for(let i3 = 0; i3 < c1s.length - 1; i3++){
            m = ms[i3];
            const c1 = c1s[i3];
            const invDx = 1 / dxs[i3];
            const common = c1 + c1s[i3 + 1] - m - m;
            c2s.push((m - c1 - common) * invDx);
            c3s.push(common * invDx * invDx);
        }
        this.xs = xs;
        this.ys = ys;
        this.c1s = c1s;
        this.c2s = c2s;
        this.c3s = c3s;
    }
} //# sourceMappingURL=MonotonicInterpolant.js.map
}),
"[project]/node_modules/.pnpm/react-dnd-html5-backend@16.0.1/node_modules/react-dnd-html5-backend/dist/OffsetUtils.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getDragPreviewOffset",
    ()=>getDragPreviewOffset,
    "getEventClientOffset",
    ()=>getEventClientOffset,
    "getNodeClientOffset",
    ()=>getNodeClientOffset
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$BrowserDetector$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd-html5-backend@16.0.1/node_modules/react-dnd-html5-backend/dist/BrowserDetector.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$MonotonicInterpolant$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd-html5-backend@16.0.1/node_modules/react-dnd-html5-backend/dist/MonotonicInterpolant.js [app-client] (ecmascript)");
;
;
const ELEMENT_NODE = 1;
function getNodeClientOffset(node) {
    const el = node.nodeType === ELEMENT_NODE ? node : node.parentElement;
    if (!el) {
        return null;
    }
    const { top, left } = el.getBoundingClientRect();
    return {
        x: left,
        y: top
    };
}
function getEventClientOffset(e) {
    return {
        x: e.clientX,
        y: e.clientY
    };
}
function isImageNode(node) {
    var ref;
    return node.nodeName === 'IMG' && ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$BrowserDetector$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFirefox"])() || !((ref = document.documentElement) === null || ref === void 0 ? void 0 : ref.contains(node)));
}
function getDragPreviewSize(isImage, dragPreview, sourceWidth, sourceHeight) {
    let dragPreviewWidth = isImage ? dragPreview.width : sourceWidth;
    let dragPreviewHeight = isImage ? dragPreview.height : sourceHeight;
    // Work around @2x coordinate discrepancies in browsers
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$BrowserDetector$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSafari"])() && isImage) {
        dragPreviewHeight /= window.devicePixelRatio;
        dragPreviewWidth /= window.devicePixelRatio;
    }
    return {
        dragPreviewWidth,
        dragPreviewHeight
    };
}
function getDragPreviewOffset(sourceNode, dragPreview, clientOffset, anchorPoint, offsetPoint) {
    // The browsers will use the image intrinsic size under different conditions.
    // Firefox only cares if it's an image, but WebKit also wants it to be detached.
    const isImage = isImageNode(dragPreview);
    const dragPreviewNode = isImage ? sourceNode : dragPreview;
    const dragPreviewNodeOffsetFromClient = getNodeClientOffset(dragPreviewNode);
    const offsetFromDragPreview = {
        x: clientOffset.x - dragPreviewNodeOffsetFromClient.x,
        y: clientOffset.y - dragPreviewNodeOffsetFromClient.y
    };
    const { offsetWidth: sourceWidth, offsetHeight: sourceHeight } = sourceNode;
    const { anchorX, anchorY } = anchorPoint;
    const { dragPreviewWidth, dragPreviewHeight } = getDragPreviewSize(isImage, dragPreview, sourceWidth, sourceHeight);
    const calculateYOffset = ()=>{
        const interpolantY = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$MonotonicInterpolant$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MonotonicInterpolant"]([
            0,
            0.5,
            1
        ], [
            // Dock to the top
            offsetFromDragPreview.y,
            // Align at the center
            offsetFromDragPreview.y / sourceHeight * dragPreviewHeight,
            // Dock to the bottom
            offsetFromDragPreview.y + dragPreviewHeight - sourceHeight
        ]);
        let y = interpolantY.interpolate(anchorY);
        // Work around Safari 8 positioning bug
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$BrowserDetector$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSafari"])() && isImage) {
            // We'll have to wait for @3x to see if this is entirely correct
            y += (window.devicePixelRatio - 1) * dragPreviewHeight;
        }
        return y;
    };
    const calculateXOffset = ()=>{
        // Interpolate coordinates depending on anchor point
        // If you know a simpler way to do this, let me know
        const interpolantX = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$MonotonicInterpolant$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MonotonicInterpolant"]([
            0,
            0.5,
            1
        ], [
            // Dock to the left
            offsetFromDragPreview.x,
            // Align at the center
            offsetFromDragPreview.x / sourceWidth * dragPreviewWidth,
            // Dock to the right
            offsetFromDragPreview.x + dragPreviewWidth - sourceWidth
        ]);
        return interpolantX.interpolate(anchorX);
    };
    // Force offsets if specified in the options.
    const { offsetX, offsetY } = offsetPoint;
    const isManualOffsetX = offsetX === 0 || offsetX;
    const isManualOffsetY = offsetY === 0 || offsetY;
    return {
        x: isManualOffsetX ? offsetX : calculateXOffset(),
        y: isManualOffsetY ? offsetY : calculateYOffset()
    };
} //# sourceMappingURL=OffsetUtils.js.map
}),
"[project]/node_modules/.pnpm/react-dnd-html5-backend@16.0.1/node_modules/react-dnd-html5-backend/dist/OptionsReader.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "OptionsReader",
    ()=>OptionsReader
]);
class OptionsReader {
    get window() {
        if (this.globalContext) {
            return this.globalContext;
        } else if (typeof window !== 'undefined') {
            return window;
        }
        return undefined;
    }
    get document() {
        var ref;
        if ((ref = this.globalContext) === null || ref === void 0 ? void 0 : ref.document) {
            return this.globalContext.document;
        } else if (this.window) {
            return this.window.document;
        } else {
            return undefined;
        }
    }
    get rootElement() {
        var ref;
        return ((ref = this.optionsArgs) === null || ref === void 0 ? void 0 : ref.rootElement) || this.window;
    }
    constructor(globalContext, options){
        this.ownerDocument = null;
        this.globalContext = globalContext;
        this.optionsArgs = options;
    }
} //# sourceMappingURL=OptionsReader.js.map
}),
"[project]/node_modules/.pnpm/react-dnd-html5-backend@16.0.1/node_modules/react-dnd-html5-backend/dist/HTML5BackendImpl.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HTML5BackendImpl",
    ()=>HTML5BackendImpl
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$EnterLeaveCounter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd-html5-backend@16.0.1/node_modules/react-dnd-html5-backend/dist/EnterLeaveCounter.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$NativeDragSources$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd-html5-backend@16.0.1/node_modules/react-dnd-html5-backend/dist/NativeDragSources/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$NativeTypes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd-html5-backend@16.0.1/node_modules/react-dnd-html5-backend/dist/NativeTypes.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$OffsetUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd-html5-backend@16.0.1/node_modules/react-dnd-html5-backend/dist/OffsetUtils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$OptionsReader$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd-html5-backend@16.0.1/node_modules/react-dnd-html5-backend/dist/OptionsReader.js [app-client] (ecmascript)");
function _defineProperty(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _objectSpread(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === 'function') {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _defineProperty(target, key, source[key]);
        });
    }
    return target;
}
;
;
;
;
;
class HTML5BackendImpl {
    /**
	 * Generate profiling statistics for the HTML5Backend.
	 */ profile() {
        var ref, ref1;
        return {
            sourcePreviewNodes: this.sourcePreviewNodes.size,
            sourcePreviewNodeOptions: this.sourcePreviewNodeOptions.size,
            sourceNodeOptions: this.sourceNodeOptions.size,
            sourceNodes: this.sourceNodes.size,
            dragStartSourceIds: ((ref = this.dragStartSourceIds) === null || ref === void 0 ? void 0 : ref.length) || 0,
            dropTargetIds: this.dropTargetIds.length,
            dragEnterTargetIds: this.dragEnterTargetIds.length,
            dragOverTargetIds: ((ref1 = this.dragOverTargetIds) === null || ref1 === void 0 ? void 0 : ref1.length) || 0
        };
    }
    // public for test
    get window() {
        return this.options.window;
    }
    get document() {
        return this.options.document;
    }
    /**
	 * Get the root element to use for event subscriptions
	 */ get rootElement() {
        return this.options.rootElement;
    }
    setup() {
        const root = this.rootElement;
        if (root === undefined) {
            return;
        }
        if (root.__isReactDndBackendSetUp) {
            throw new Error('Cannot have two HTML5 backends at the same time.');
        }
        root.__isReactDndBackendSetUp = true;
        this.addEventListeners(root);
    }
    teardown() {
        const root = this.rootElement;
        if (root === undefined) {
            return;
        }
        root.__isReactDndBackendSetUp = false;
        this.removeEventListeners(this.rootElement);
        this.clearCurrentDragSourceNode();
        if (this.asyncEndDragFrameId) {
            var ref;
            (ref = this.window) === null || ref === void 0 ? void 0 : ref.cancelAnimationFrame(this.asyncEndDragFrameId);
        }
    }
    connectDragPreview(sourceId, node, options) {
        this.sourcePreviewNodeOptions.set(sourceId, options);
        this.sourcePreviewNodes.set(sourceId, node);
        return ()=>{
            this.sourcePreviewNodes.delete(sourceId);
            this.sourcePreviewNodeOptions.delete(sourceId);
        };
    }
    connectDragSource(sourceId, node, options) {
        this.sourceNodes.set(sourceId, node);
        this.sourceNodeOptions.set(sourceId, options);
        const handleDragStart = (e)=>this.handleDragStart(e, sourceId);
        const handleSelectStart = (e)=>this.handleSelectStart(e);
        node.setAttribute('draggable', 'true');
        node.addEventListener('dragstart', handleDragStart);
        node.addEventListener('selectstart', handleSelectStart);
        return ()=>{
            this.sourceNodes.delete(sourceId);
            this.sourceNodeOptions.delete(sourceId);
            node.removeEventListener('dragstart', handleDragStart);
            node.removeEventListener('selectstart', handleSelectStart);
            node.setAttribute('draggable', 'false');
        };
    }
    connectDropTarget(targetId, node) {
        const handleDragEnter = (e)=>this.handleDragEnter(e, targetId);
        const handleDragOver = (e)=>this.handleDragOver(e, targetId);
        const handleDrop = (e)=>this.handleDrop(e, targetId);
        node.addEventListener('dragenter', handleDragEnter);
        node.addEventListener('dragover', handleDragOver);
        node.addEventListener('drop', handleDrop);
        return ()=>{
            node.removeEventListener('dragenter', handleDragEnter);
            node.removeEventListener('dragover', handleDragOver);
            node.removeEventListener('drop', handleDrop);
        };
    }
    addEventListeners(target) {
        // SSR Fix (https://github.com/react-dnd/react-dnd/pull/813
        if (!target.addEventListener) {
            return;
        }
        target.addEventListener('dragstart', this.handleTopDragStart);
        target.addEventListener('dragstart', this.handleTopDragStartCapture, true);
        target.addEventListener('dragend', this.handleTopDragEndCapture, true);
        target.addEventListener('dragenter', this.handleTopDragEnter);
        target.addEventListener('dragenter', this.handleTopDragEnterCapture, true);
        target.addEventListener('dragleave', this.handleTopDragLeaveCapture, true);
        target.addEventListener('dragover', this.handleTopDragOver);
        target.addEventListener('dragover', this.handleTopDragOverCapture, true);
        target.addEventListener('drop', this.handleTopDrop);
        target.addEventListener('drop', this.handleTopDropCapture, true);
    }
    removeEventListeners(target) {
        // SSR Fix (https://github.com/react-dnd/react-dnd/pull/813
        if (!target.removeEventListener) {
            return;
        }
        target.removeEventListener('dragstart', this.handleTopDragStart);
        target.removeEventListener('dragstart', this.handleTopDragStartCapture, true);
        target.removeEventListener('dragend', this.handleTopDragEndCapture, true);
        target.removeEventListener('dragenter', this.handleTopDragEnter);
        target.removeEventListener('dragenter', this.handleTopDragEnterCapture, true);
        target.removeEventListener('dragleave', this.handleTopDragLeaveCapture, true);
        target.removeEventListener('dragover', this.handleTopDragOver);
        target.removeEventListener('dragover', this.handleTopDragOverCapture, true);
        target.removeEventListener('drop', this.handleTopDrop);
        target.removeEventListener('drop', this.handleTopDropCapture, true);
    }
    getCurrentSourceNodeOptions() {
        const sourceId = this.monitor.getSourceId();
        const sourceNodeOptions = this.sourceNodeOptions.get(sourceId);
        return _objectSpread({
            dropEffect: this.altKeyPressed ? 'copy' : 'move'
        }, sourceNodeOptions || {});
    }
    getCurrentDropEffect() {
        if (this.isDraggingNativeItem()) {
            // It makes more sense to default to 'copy' for native resources
            return 'copy';
        }
        return this.getCurrentSourceNodeOptions().dropEffect;
    }
    getCurrentSourcePreviewNodeOptions() {
        const sourceId = this.monitor.getSourceId();
        const sourcePreviewNodeOptions = this.sourcePreviewNodeOptions.get(sourceId);
        return _objectSpread({
            anchorX: 0.5,
            anchorY: 0.5,
            captureDraggingState: false
        }, sourcePreviewNodeOptions || {});
    }
    isDraggingNativeItem() {
        const itemType = this.monitor.getItemType();
        return Object.keys(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$NativeTypes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__).some((key)=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$NativeTypes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__[key] === itemType);
    }
    beginDragNativeItem(type, dataTransfer) {
        this.clearCurrentDragSourceNode();
        this.currentNativeSource = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$NativeDragSources$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createNativeDragSource"])(type, dataTransfer);
        this.currentNativeHandle = this.registry.addSource(type, this.currentNativeSource);
        this.actions.beginDrag([
            this.currentNativeHandle
        ]);
    }
    setCurrentDragSourceNode(node) {
        this.clearCurrentDragSourceNode();
        this.currentDragSourceNode = node;
        // A timeout of > 0 is necessary to resolve Firefox issue referenced
        // See:
        //   * https://github.com/react-dnd/react-dnd/pull/928
        //   * https://github.com/react-dnd/react-dnd/issues/869
        const MOUSE_MOVE_TIMEOUT = 1000;
        // Receiving a mouse event in the middle of a dragging operation
        // means it has ended and the drag source node disappeared from DOM,
        // so the browser didn't dispatch the dragend event.
        //
        // We need to wait before we start listening for mousemove events.
        // This is needed because the drag preview needs to be drawn or else it fires an 'mousemove' event
        // immediately in some browsers.
        //
        // See:
        //   * https://github.com/react-dnd/react-dnd/pull/928
        //   * https://github.com/react-dnd/react-dnd/issues/869
        //
        this.mouseMoveTimeoutTimer = setTimeout(()=>{
            var ref;
            return (ref = this.rootElement) === null || ref === void 0 ? void 0 : ref.addEventListener('mousemove', this.endDragIfSourceWasRemovedFromDOM, true);
        }, MOUSE_MOVE_TIMEOUT);
    }
    clearCurrentDragSourceNode() {
        if (this.currentDragSourceNode) {
            this.currentDragSourceNode = null;
            if (this.rootElement) {
                var ref;
                (ref = this.window) === null || ref === void 0 ? void 0 : ref.clearTimeout(this.mouseMoveTimeoutTimer || undefined);
                this.rootElement.removeEventListener('mousemove', this.endDragIfSourceWasRemovedFromDOM, true);
            }
            this.mouseMoveTimeoutTimer = null;
            return true;
        }
        return false;
    }
    handleDragStart(e, sourceId) {
        if (e.defaultPrevented) {
            return;
        }
        if (!this.dragStartSourceIds) {
            this.dragStartSourceIds = [];
        }
        this.dragStartSourceIds.unshift(sourceId);
    }
    handleDragEnter(_e, targetId) {
        this.dragEnterTargetIds.unshift(targetId);
    }
    handleDragOver(_e, targetId) {
        if (this.dragOverTargetIds === null) {
            this.dragOverTargetIds = [];
        }
        this.dragOverTargetIds.unshift(targetId);
    }
    handleDrop(_e, targetId) {
        this.dropTargetIds.unshift(targetId);
    }
    constructor(manager, globalContext, options){
        this.sourcePreviewNodes = new Map();
        this.sourcePreviewNodeOptions = new Map();
        this.sourceNodes = new Map();
        this.sourceNodeOptions = new Map();
        this.dragStartSourceIds = null;
        this.dropTargetIds = [];
        this.dragEnterTargetIds = [];
        this.currentNativeSource = null;
        this.currentNativeHandle = null;
        this.currentDragSourceNode = null;
        this.altKeyPressed = false;
        this.mouseMoveTimeoutTimer = null;
        this.asyncEndDragFrameId = null;
        this.dragOverTargetIds = null;
        this.lastClientOffset = null;
        this.hoverRafId = null;
        this.getSourceClientOffset = (sourceId)=>{
            const source = this.sourceNodes.get(sourceId);
            return source && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$OffsetUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNodeClientOffset"])(source) || null;
        };
        this.endDragNativeItem = ()=>{
            if (!this.isDraggingNativeItem()) {
                return;
            }
            this.actions.endDrag();
            if (this.currentNativeHandle) {
                this.registry.removeSource(this.currentNativeHandle);
            }
            this.currentNativeHandle = null;
            this.currentNativeSource = null;
        };
        this.isNodeInDocument = (node)=>{
            // Check the node either in the main document or in the current context
            return Boolean(node && this.document && this.document.body && this.document.body.contains(node));
        };
        this.endDragIfSourceWasRemovedFromDOM = ()=>{
            const node = this.currentDragSourceNode;
            if (node == null || this.isNodeInDocument(node)) {
                return;
            }
            if (this.clearCurrentDragSourceNode() && this.monitor.isDragging()) {
                this.actions.endDrag();
            }
            this.cancelHover();
        };
        this.scheduleHover = (dragOverTargetIds)=>{
            if (this.hoverRafId === null && typeof requestAnimationFrame !== 'undefined') {
                this.hoverRafId = requestAnimationFrame(()=>{
                    if (this.monitor.isDragging()) {
                        this.actions.hover(dragOverTargetIds || [], {
                            clientOffset: this.lastClientOffset
                        });
                    }
                    this.hoverRafId = null;
                });
            }
        };
        this.cancelHover = ()=>{
            if (this.hoverRafId !== null && typeof cancelAnimationFrame !== 'undefined') {
                cancelAnimationFrame(this.hoverRafId);
                this.hoverRafId = null;
            }
        };
        this.handleTopDragStartCapture = ()=>{
            this.clearCurrentDragSourceNode();
            this.dragStartSourceIds = [];
        };
        this.handleTopDragStart = (e)=>{
            if (e.defaultPrevented) {
                return;
            }
            const { dragStartSourceIds } = this;
            this.dragStartSourceIds = null;
            const clientOffset = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$OffsetUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getEventClientOffset"])(e);
            // Avoid crashing if we missed a drop event or our previous drag died
            if (this.monitor.isDragging()) {
                this.actions.endDrag();
                this.cancelHover();
            }
            // Don't publish the source just yet (see why below)
            this.actions.beginDrag(dragStartSourceIds || [], {
                publishSource: false,
                getSourceClientOffset: this.getSourceClientOffset,
                clientOffset
            });
            const { dataTransfer } = e;
            const nativeType = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$NativeDragSources$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["matchNativeItemType"])(dataTransfer);
            if (this.monitor.isDragging()) {
                if (dataTransfer && typeof dataTransfer.setDragImage === 'function') {
                    // Use custom drag image if user specifies it.
                    // If child drag source refuses drag but parent agrees,
                    // use parent's node as drag image. Neither works in IE though.
                    const sourceId = this.monitor.getSourceId();
                    const sourceNode = this.sourceNodes.get(sourceId);
                    const dragPreview = this.sourcePreviewNodes.get(sourceId) || sourceNode;
                    if (dragPreview) {
                        const { anchorX, anchorY, offsetX, offsetY } = this.getCurrentSourcePreviewNodeOptions();
                        const anchorPoint = {
                            anchorX,
                            anchorY
                        };
                        const offsetPoint = {
                            offsetX,
                            offsetY
                        };
                        const dragPreviewOffset = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$OffsetUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDragPreviewOffset"])(sourceNode, dragPreview, clientOffset, anchorPoint, offsetPoint);
                        dataTransfer.setDragImage(dragPreview, dragPreviewOffset.x, dragPreviewOffset.y);
                    }
                }
                try {
                    // Firefox won't drag without setting data
                    dataTransfer === null || dataTransfer === void 0 ? void 0 : dataTransfer.setData('application/json', {});
                } catch (err) {
                // IE doesn't support MIME types in setData
                }
                // Store drag source node so we can check whether
                // it is removed from DOM and trigger endDrag manually.
                this.setCurrentDragSourceNode(e.target);
                // Now we are ready to publish the drag source.. or are we not?
                const { captureDraggingState } = this.getCurrentSourcePreviewNodeOptions();
                if (!captureDraggingState) {
                    // Usually we want to publish it in the next tick so that browser
                    // is able to screenshot the current (not yet dragging) state.
                    //
                    // It also neatly avoids a situation where render() returns null
                    // in the same tick for the source element, and browser freaks out.
                    setTimeout(()=>this.actions.publishDragSource(), 0);
                } else {
                    // In some cases the user may want to override this behavior, e.g.
                    // to work around IE not supporting custom drag previews.
                    //
                    // When using a custom drag layer, the only way to prevent
                    // the default drag preview from drawing in IE is to screenshot
                    // the dragging state in which the node itself has zero opacity
                    // and height. In this case, though, returning null from render()
                    // will abruptly end the dragging, which is not obvious.
                    //
                    // This is the reason such behavior is strictly opt-in.
                    this.actions.publishDragSource();
                }
            } else if (nativeType) {
                // A native item (such as URL) dragged from inside the document
                this.beginDragNativeItem(nativeType);
            } else if (dataTransfer && !dataTransfer.types && (e.target && !e.target.hasAttribute || !e.target.hasAttribute('draggable'))) {
                // Looks like a Safari bug: dataTransfer.types is null, but there was no draggable.
                // Just let it drag. It's a native type (URL or text) and will be picked up in
                // dragenter handler.
                return;
            } else {
                // If by this time no drag source reacted, tell browser not to drag.
                e.preventDefault();
            }
        };
        this.handleTopDragEndCapture = ()=>{
            if (this.clearCurrentDragSourceNode() && this.monitor.isDragging()) {
                // Firefox can dispatch this event in an infinite loop
                // if dragend handler does something like showing an alert.
                // Only proceed if we have not handled it already.
                this.actions.endDrag();
            }
            this.cancelHover();
        };
        this.handleTopDragEnterCapture = (e)=>{
            this.dragEnterTargetIds = [];
            if (this.isDraggingNativeItem()) {
                var ref;
                (ref = this.currentNativeSource) === null || ref === void 0 ? void 0 : ref.loadDataTransfer(e.dataTransfer);
            }
            const isFirstEnter = this.enterLeaveCounter.enter(e.target);
            if (!isFirstEnter || this.monitor.isDragging()) {
                return;
            }
            const { dataTransfer } = e;
            const nativeType = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$NativeDragSources$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["matchNativeItemType"])(dataTransfer);
            if (nativeType) {
                // A native item (such as file or URL) dragged from outside the document
                this.beginDragNativeItem(nativeType, dataTransfer);
            }
        };
        this.handleTopDragEnter = (e)=>{
            const { dragEnterTargetIds } = this;
            this.dragEnterTargetIds = [];
            if (!this.monitor.isDragging()) {
                // This is probably a native item type we don't understand.
                return;
            }
            this.altKeyPressed = e.altKey;
            // If the target changes position as the result of `dragenter`, `dragover` might still
            // get dispatched despite target being no longer there. The easy solution is to check
            // whether there actually is a target before firing `hover`.
            if (dragEnterTargetIds.length > 0) {
                this.actions.hover(dragEnterTargetIds, {
                    clientOffset: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$OffsetUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getEventClientOffset"])(e)
                });
            }
            const canDrop = dragEnterTargetIds.some((targetId)=>this.monitor.canDropOnTarget(targetId));
            if (canDrop) {
                // IE requires this to fire dragover events
                e.preventDefault();
                if (e.dataTransfer) {
                    e.dataTransfer.dropEffect = this.getCurrentDropEffect();
                }
            }
        };
        this.handleTopDragOverCapture = (e)=>{
            this.dragOverTargetIds = [];
            if (this.isDraggingNativeItem()) {
                var ref;
                (ref = this.currentNativeSource) === null || ref === void 0 ? void 0 : ref.loadDataTransfer(e.dataTransfer);
            }
        };
        this.handleTopDragOver = (e)=>{
            const { dragOverTargetIds } = this;
            this.dragOverTargetIds = [];
            if (!this.monitor.isDragging()) {
                // This is probably a native item type we don't understand.
                // Prevent default "drop and blow away the whole document" action.
                e.preventDefault();
                if (e.dataTransfer) {
                    e.dataTransfer.dropEffect = 'none';
                }
                return;
            }
            this.altKeyPressed = e.altKey;
            this.lastClientOffset = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$OffsetUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getEventClientOffset"])(e);
            this.scheduleHover(dragOverTargetIds);
            const canDrop = (dragOverTargetIds || []).some((targetId)=>this.monitor.canDropOnTarget(targetId));
            if (canDrop) {
                // Show user-specified drop effect.
                e.preventDefault();
                if (e.dataTransfer) {
                    e.dataTransfer.dropEffect = this.getCurrentDropEffect();
                }
            } else if (this.isDraggingNativeItem()) {
                // Don't show a nice cursor but still prevent default
                // "drop and blow away the whole document" action.
                e.preventDefault();
            } else {
                e.preventDefault();
                if (e.dataTransfer) {
                    e.dataTransfer.dropEffect = 'none';
                }
            }
        };
        this.handleTopDragLeaveCapture = (e)=>{
            if (this.isDraggingNativeItem()) {
                e.preventDefault();
            }
            const isLastLeave = this.enterLeaveCounter.leave(e.target);
            if (!isLastLeave) {
                return;
            }
            if (this.isDraggingNativeItem()) {
                setTimeout(()=>this.endDragNativeItem(), 0);
            }
            this.cancelHover();
        };
        this.handleTopDropCapture = (e)=>{
            this.dropTargetIds = [];
            if (this.isDraggingNativeItem()) {
                var ref;
                e.preventDefault();
                (ref = this.currentNativeSource) === null || ref === void 0 ? void 0 : ref.loadDataTransfer(e.dataTransfer);
            } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$NativeDragSources$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["matchNativeItemType"])(e.dataTransfer)) {
                // Dragging some elements, like <a> and <img> may still behave like a native drag event,
                // even if the current drag event matches a user-defined type.
                // Stop the default behavior when we're not expecting a native item to be dropped.
                e.preventDefault();
            }
            this.enterLeaveCounter.reset();
        };
        this.handleTopDrop = (e)=>{
            const { dropTargetIds } = this;
            this.dropTargetIds = [];
            this.actions.hover(dropTargetIds, {
                clientOffset: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$OffsetUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getEventClientOffset"])(e)
            });
            this.actions.drop({
                dropEffect: this.getCurrentDropEffect()
            });
            if (this.isDraggingNativeItem()) {
                this.endDragNativeItem();
            } else if (this.monitor.isDragging()) {
                this.actions.endDrag();
            }
            this.cancelHover();
        };
        this.handleSelectStart = (e)=>{
            const target = e.target;
            // Only IE requires us to explicitly say
            // we want drag drop operation to start
            if (typeof target.dragDrop !== 'function') {
                return;
            }
            // Inputs and textareas should be selectable
            if (target.tagName === 'INPUT' || target.tagName === 'SELECT' || target.tagName === 'TEXTAREA' || target.isContentEditable) {
                return;
            }
            // For other targets, ask IE
            // to enable drag and drop
            e.preventDefault();
            target.dragDrop();
        };
        this.options = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$OptionsReader$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OptionsReader"](globalContext, options);
        this.actions = manager.getActions();
        this.monitor = manager.getMonitor();
        this.registry = manager.getRegistry();
        this.enterLeaveCounter = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$EnterLeaveCounter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EnterLeaveCounter"](this.isNodeInDocument);
    }
} //# sourceMappingURL=HTML5BackendImpl.js.map
}),
"[project]/node_modules/.pnpm/react-dnd-html5-backend@16.0.1/node_modules/react-dnd-html5-backend/dist/index.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HTML5Backend",
    ()=>HTML5Backend
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$HTML5BackendImpl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd-html5-backend@16.0.1/node_modules/react-dnd-html5-backend/dist/HTML5BackendImpl.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$NativeTypes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd-html5-backend@16.0.1/node_modules/react-dnd-html5-backend/dist/NativeTypes.js [app-client] (ecmascript)");
;
;
;
;
const HTML5Backend = function createBackend(manager, context, options) {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$HTML5BackendImpl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HTML5BackendImpl"](manager, context, options);
}; //# sourceMappingURL=index.js.map
}),
"[project]/node_modules/.pnpm/@react-dnd+invariant@4.0.2/node_modules/@react-dnd/invariant/dist/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Use invariant() to assert state which your program assumes to be true.
 *
 * Provide sprintf-style format (only %s is supported) and arguments
 * to provide information about what broke and what you were
 * expecting.
 *
 * The invariant message will be stripped in production, but the invariant
 * will remain to ensure logic does not differ in production.
 */ __turbopack_context__.s([
    "invariant",
    ()=>invariant
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
function invariant(condition, format, ...args) {
    if (isProduction()) //TURBOPACK unreachable
    ;
    if (!condition) {
        let error;
        if (format === undefined) {
            error = new Error('Minified exception occurred; use the non-minified dev environment ' + 'for the full error message and additional helpful warnings.');
        } else {
            let argIndex = 0;
            error = new Error(format.replace(/%s/g, function() {
                return args[argIndex++];
            }));
            error.name = 'Invariant Violation';
        }
        error.framesToPop = 1 // we don't care about invariant's own frame
        ;
        throw error;
    }
}
function isProduction() {
    return typeof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] !== 'undefined' && ("TURBOPACK compile-time value", "development") === 'production';
} //# sourceMappingURL=index.js.map
}),
"[project]/node_modules/.pnpm/react-dnd-touch-backend@16.0.1/node_modules/react-dnd-touch-backend/dist/interfaces.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ListenerType",
    ()=>ListenerType
]);
var ListenerType;
(function(ListenerType) {
    ListenerType["mouse"] = "mouse";
    ListenerType["touch"] = "touch";
    ListenerType["keyboard"] = "keyboard";
})(ListenerType || (ListenerType = {})); //# sourceMappingURL=interfaces.js.map
}),
"[project]/node_modules/.pnpm/react-dnd-touch-backend@16.0.1/node_modules/react-dnd-touch-backend/dist/OptionsReader.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "OptionsReader",
    ()=>OptionsReader
]);
class OptionsReader {
    get delay() {
        var _delay;
        return (_delay = this.args.delay) !== null && _delay !== void 0 ? _delay : 0;
    }
    get scrollAngleRanges() {
        return this.args.scrollAngleRanges;
    }
    get getDropTargetElementsAtPoint() {
        return this.args.getDropTargetElementsAtPoint;
    }
    get ignoreContextMenu() {
        var _ignoreContextMenu;
        return (_ignoreContextMenu = this.args.ignoreContextMenu) !== null && _ignoreContextMenu !== void 0 ? _ignoreContextMenu : false;
    }
    get enableHoverOutsideTarget() {
        var _enableHoverOutsideTarget;
        return (_enableHoverOutsideTarget = this.args.enableHoverOutsideTarget) !== null && _enableHoverOutsideTarget !== void 0 ? _enableHoverOutsideTarget : false;
    }
    get enableKeyboardEvents() {
        var _enableKeyboardEvents;
        return (_enableKeyboardEvents = this.args.enableKeyboardEvents) !== null && _enableKeyboardEvents !== void 0 ? _enableKeyboardEvents : false;
    }
    get enableMouseEvents() {
        var _enableMouseEvents;
        return (_enableMouseEvents = this.args.enableMouseEvents) !== null && _enableMouseEvents !== void 0 ? _enableMouseEvents : false;
    }
    get enableTouchEvents() {
        var _enableTouchEvents;
        return (_enableTouchEvents = this.args.enableTouchEvents) !== null && _enableTouchEvents !== void 0 ? _enableTouchEvents : true;
    }
    get touchSlop() {
        return this.args.touchSlop || 0;
    }
    get delayTouchStart() {
        var ref, ref1;
        var ref2, ref3;
        return (ref3 = (ref2 = (ref = this.args) === null || ref === void 0 ? void 0 : ref.delayTouchStart) !== null && ref2 !== void 0 ? ref2 : (ref1 = this.args) === null || ref1 === void 0 ? void 0 : ref1.delay) !== null && ref3 !== void 0 ? ref3 : 0;
    }
    get delayMouseStart() {
        var ref, ref4;
        var ref5, ref6;
        return (ref6 = (ref5 = (ref = this.args) === null || ref === void 0 ? void 0 : ref.delayMouseStart) !== null && ref5 !== void 0 ? ref5 : (ref4 = this.args) === null || ref4 === void 0 ? void 0 : ref4.delay) !== null && ref6 !== void 0 ? ref6 : 0;
    }
    get window() {
        if (this.context && this.context.window) {
            return this.context.window;
        } else if (typeof window !== 'undefined') {
            return window;
        }
        return undefined;
    }
    get document() {
        var ref;
        if ((ref = this.context) === null || ref === void 0 ? void 0 : ref.document) {
            return this.context.document;
        }
        if (this.window) {
            return this.window.document;
        }
        return undefined;
    }
    get rootElement() {
        var ref;
        return ((ref = this.args) === null || ref === void 0 ? void 0 : ref.rootElement) || this.document;
    }
    constructor(args, context){
        this.args = args;
        this.context = context;
    }
} //# sourceMappingURL=OptionsReader.js.map
}),
"[project]/node_modules/.pnpm/react-dnd-touch-backend@16.0.1/node_modules/react-dnd-touch-backend/dist/utils/math.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "distance",
    ()=>distance,
    "inAngleRanges",
    ()=>inAngleRanges
]);
function distance(x1, y1, x2, y2) {
    return Math.sqrt(Math.pow(Math.abs(x2 - x1), 2) + Math.pow(Math.abs(y2 - y1), 2));
}
function inAngleRanges(x1, y1, x2, y2, angleRanges) {
    if (!angleRanges) {
        return false;
    }
    const angle = Math.atan2(y2 - y1, x2 - x1) * 180 / Math.PI + 180;
    for(let i = 0; i < angleRanges.length; ++i){
        const ar = angleRanges[i];
        if (ar && (ar.start == null || angle >= ar.start) && (ar.end == null || angle <= ar.end)) {
            return true;
        }
    }
    return false;
} //# sourceMappingURL=math.js.map
}),
"[project]/node_modules/.pnpm/react-dnd-touch-backend@16.0.1/node_modules/react-dnd-touch-backend/dist/utils/predicates.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "eventShouldEndDrag",
    ()=>eventShouldEndDrag,
    "eventShouldStartDrag",
    ()=>eventShouldStartDrag,
    "isTouchEvent",
    ()=>isTouchEvent
]);
// Used for MouseEvent.buttons (note the s on the end).
const MouseButtons = {
    Left: 1,
    Right: 2,
    Center: 4
};
// Used for e.button (note the lack of an s on the end).
const MouseButton = {
    Left: 0,
    Center: 1,
    Right: 2
};
function eventShouldStartDrag(e) {
    // For touch events, button will be undefined. If e.button is defined,
    // then it should be MouseButton.Left.
    return e.button === undefined || e.button === MouseButton.Left;
}
function eventShouldEndDrag(e) {
    // Touch events will have buttons be undefined, while mouse events will have e.buttons's left button
    // bit field unset if the left mouse button has been released
    return e.buttons === undefined || (e.buttons & MouseButtons.Left) === 0;
}
function isTouchEvent(e) {
    return !!e.targetTouches;
} //# sourceMappingURL=predicates.js.map
}),
"[project]/node_modules/.pnpm/react-dnd-touch-backend@16.0.1/node_modules/react-dnd-touch-backend/dist/utils/offsets.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getEventClientOffset",
    ()=>getEventClientOffset,
    "getEventClientTouchOffset",
    ()=>getEventClientTouchOffset,
    "getNodeClientOffset",
    ()=>getNodeClientOffset
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$touch$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$touch$2d$backend$2f$dist$2f$utils$2f$predicates$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd-touch-backend@16.0.1/node_modules/react-dnd-touch-backend/dist/utils/predicates.js [app-client] (ecmascript)");
;
const ELEMENT_NODE = 1;
function getNodeClientOffset(node) {
    const el = node.nodeType === ELEMENT_NODE ? node : node.parentElement;
    if (!el) {
        return undefined;
    }
    const { top, left } = el.getBoundingClientRect();
    return {
        x: left,
        y: top
    };
}
function getEventClientTouchOffset(e, lastTargetTouchFallback) {
    if (e.targetTouches.length === 1) {
        return getEventClientOffset(e.targetTouches[0]);
    } else if (lastTargetTouchFallback && e.touches.length === 1) {
        if (e.touches[0].target === lastTargetTouchFallback.target) {
            return getEventClientOffset(e.touches[0]);
        }
    }
    return;
}
function getEventClientOffset(e, lastTargetTouchFallback) {
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$touch$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$touch$2d$backend$2f$dist$2f$utils$2f$predicates$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isTouchEvent"])(e)) {
        return getEventClientTouchOffset(e, lastTargetTouchFallback);
    } else {
        return {
            x: e.clientX,
            y: e.clientY
        };
    }
} //# sourceMappingURL=offsets.js.map
}),
"[project]/node_modules/.pnpm/react-dnd-touch-backend@16.0.1/node_modules/react-dnd-touch-backend/dist/utils/supportsPassive.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "supportsPassive",
    ()=>supportsPassive
]);
const supportsPassive = (()=>{
    // simular to jQuery's test
    let supported = false;
    try {
        addEventListener('test', ()=>{
        // do nothing
        }, Object.defineProperty({}, 'passive', {
            get () {
                supported = true;
                return true;
            }
        }));
    } catch (e) {
    // do nothing
    }
    return supported;
})(); //# sourceMappingURL=supportsPassive.js.map
}),
"[project]/node_modules/.pnpm/react-dnd-touch-backend@16.0.1/node_modules/react-dnd-touch-backend/dist/TouchBackendImpl.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TouchBackendImpl",
    ()=>TouchBackendImpl
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$4$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+invariant@4.0.2/node_modules/@react-dnd/invariant/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$touch$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$touch$2d$backend$2f$dist$2f$interfaces$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd-touch-backend@16.0.1/node_modules/react-dnd-touch-backend/dist/interfaces.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$touch$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$touch$2d$backend$2f$dist$2f$OptionsReader$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd-touch-backend@16.0.1/node_modules/react-dnd-touch-backend/dist/OptionsReader.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$touch$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$touch$2d$backend$2f$dist$2f$utils$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd-touch-backend@16.0.1/node_modules/react-dnd-touch-backend/dist/utils/math.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$touch$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$touch$2d$backend$2f$dist$2f$utils$2f$offsets$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd-touch-backend@16.0.1/node_modules/react-dnd-touch-backend/dist/utils/offsets.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$touch$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$touch$2d$backend$2f$dist$2f$utils$2f$predicates$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd-touch-backend@16.0.1/node_modules/react-dnd-touch-backend/dist/utils/predicates.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$touch$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$touch$2d$backend$2f$dist$2f$utils$2f$supportsPassive$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd-touch-backend@16.0.1/node_modules/react-dnd-touch-backend/dist/utils/supportsPassive.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
const eventNames = {
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$touch$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$touch$2d$backend$2f$dist$2f$interfaces$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ListenerType"].mouse]: {
        start: 'mousedown',
        move: 'mousemove',
        end: 'mouseup',
        contextmenu: 'contextmenu'
    },
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$touch$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$touch$2d$backend$2f$dist$2f$interfaces$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ListenerType"].touch]: {
        start: 'touchstart',
        move: 'touchmove',
        end: 'touchend'
    },
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$touch$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$touch$2d$backend$2f$dist$2f$interfaces$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ListenerType"].keyboard]: {
        keydown: 'keydown'
    }
};
class TouchBackendImpl {
    /**
	 * Generate profiling statistics for the HTML5Backend.
	 */ profile() {
        var ref;
        return {
            sourceNodes: this.sourceNodes.size,
            sourcePreviewNodes: this.sourcePreviewNodes.size,
            sourcePreviewNodeOptions: this.sourcePreviewNodeOptions.size,
            targetNodes: this.targetNodes.size,
            dragOverTargetIds: ((ref = this.dragOverTargetIds) === null || ref === void 0 ? void 0 : ref.length) || 0
        };
    }
    // public for test
    get document() {
        return this.options.document;
    }
    setup() {
        const root = this.options.rootElement;
        if (!root) {
            return;
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$4$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(!TouchBackendImpl.isSetUp, 'Cannot have two Touch backends at the same time.');
        TouchBackendImpl.isSetUp = true;
        this.addEventListener(root, 'start', this.getTopMoveStartHandler());
        this.addEventListener(root, 'start', this.handleTopMoveStartCapture, true);
        this.addEventListener(root, 'move', this.handleTopMove);
        this.addEventListener(root, 'move', this.handleTopMoveCapture, true);
        this.addEventListener(root, 'end', this.handleTopMoveEndCapture, true);
        if (this.options.enableMouseEvents && !this.options.ignoreContextMenu) {
            this.addEventListener(root, 'contextmenu', this.handleTopMoveEndCapture);
        }
        if (this.options.enableKeyboardEvents) {
            this.addEventListener(root, 'keydown', this.handleCancelOnEscape, true);
        }
    }
    teardown() {
        const root = this.options.rootElement;
        if (!root) {
            return;
        }
        TouchBackendImpl.isSetUp = false;
        this._mouseClientOffset = {};
        this.removeEventListener(root, 'start', this.handleTopMoveStartCapture, true);
        this.removeEventListener(root, 'start', this.handleTopMoveStart);
        this.removeEventListener(root, 'move', this.handleTopMoveCapture, true);
        this.removeEventListener(root, 'move', this.handleTopMove);
        this.removeEventListener(root, 'end', this.handleTopMoveEndCapture, true);
        if (this.options.enableMouseEvents && !this.options.ignoreContextMenu) {
            this.removeEventListener(root, 'contextmenu', this.handleTopMoveEndCapture);
        }
        if (this.options.enableKeyboardEvents) {
            this.removeEventListener(root, 'keydown', this.handleCancelOnEscape, true);
        }
        this.uninstallSourceNodeRemovalObserver();
    }
    addEventListener(subject, event, handler, capture = false) {
        const options = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$touch$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$touch$2d$backend$2f$dist$2f$utils$2f$supportsPassive$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supportsPassive"] ? {
            capture,
            passive: false
        } : capture;
        this.listenerTypes.forEach(function(listenerType) {
            const evt = eventNames[listenerType][event];
            if (evt) {
                subject.addEventListener(evt, handler, options);
            }
        });
    }
    removeEventListener(subject, event, handler, capture = false) {
        const options = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$touch$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$touch$2d$backend$2f$dist$2f$utils$2f$supportsPassive$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supportsPassive"] ? {
            capture,
            passive: false
        } : capture;
        this.listenerTypes.forEach(function(listenerType) {
            const evt = eventNames[listenerType][event];
            if (evt) {
                subject.removeEventListener(evt, handler, options);
            }
        });
    }
    connectDragSource(sourceId, node) {
        const handleMoveStart = this.handleMoveStart.bind(this, sourceId);
        this.sourceNodes.set(sourceId, node);
        this.addEventListener(node, 'start', handleMoveStart);
        return ()=>{
            this.sourceNodes.delete(sourceId);
            this.removeEventListener(node, 'start', handleMoveStart);
        };
    }
    connectDragPreview(sourceId, node, options) {
        this.sourcePreviewNodeOptions.set(sourceId, options);
        this.sourcePreviewNodes.set(sourceId, node);
        return ()=>{
            this.sourcePreviewNodes.delete(sourceId);
            this.sourcePreviewNodeOptions.delete(sourceId);
        };
    }
    connectDropTarget(targetId, node) {
        const root = this.options.rootElement;
        if (!this.document || !root) {
            return ()=>{
            /* noop */ };
        }
        const handleMove = (e)=>{
            if (!this.document || !root || !this.monitor.isDragging()) {
                return;
            }
            let coords;
            /**
			 * Grab the coordinates for the current mouse/touch position
			 */ switch(e.type){
                case eventNames.mouse.move:
                    coords = {
                        x: e.clientX,
                        y: e.clientY
                    };
                    break;
                case eventNames.touch.move:
                    var ref, ref1;
                    coords = {
                        x: ((ref = e.touches[0]) === null || ref === void 0 ? void 0 : ref.clientX) || 0,
                        y: ((ref1 = e.touches[0]) === null || ref1 === void 0 ? void 0 : ref1.clientY) || 0
                    };
                    break;
            }
            /**
			 * Use the coordinates to grab the element the drag ended on.
			 * If the element is the same as the target node (or any of it's children) then we have hit a drop target and can handle the move.
			 */ const droppedOn = coords != null ? this.document.elementFromPoint(coords.x, coords.y) : undefined;
            const childMatch = droppedOn && node.contains(droppedOn);
            if (droppedOn === node || childMatch) {
                return this.handleMove(e, targetId);
            }
        };
        /**
		 * Attaching the event listener to the body so that touchmove will work while dragging over multiple target elements.
		 */ this.addEventListener(this.document.body, 'move', handleMove);
        this.targetNodes.set(targetId, node);
        return ()=>{
            if (this.document) {
                this.targetNodes.delete(targetId);
                this.removeEventListener(this.document.body, 'move', handleMove);
            }
        };
    }
    getTopMoveStartHandler() {
        if (!this.options.delayTouchStart && !this.options.delayMouseStart) {
            return this.handleTopMoveStart;
        }
        return this.handleTopMoveStartDelay;
    }
    installSourceNodeRemovalObserver(node) {
        this.uninstallSourceNodeRemovalObserver();
        this.draggedSourceNode = node;
        this.draggedSourceNodeRemovalObserver = new MutationObserver(()=>{
            if (node && !node.parentElement) {
                this.resurrectSourceNode();
                this.uninstallSourceNodeRemovalObserver();
            }
        });
        if (!node || !node.parentElement) {
            return;
        }
        this.draggedSourceNodeRemovalObserver.observe(node.parentElement, {
            childList: true
        });
    }
    resurrectSourceNode() {
        if (this.document && this.draggedSourceNode) {
            this.draggedSourceNode.style.display = 'none';
            this.draggedSourceNode.removeAttribute('data-reactid');
            this.document.body.appendChild(this.draggedSourceNode);
        }
    }
    uninstallSourceNodeRemovalObserver() {
        if (this.draggedSourceNodeRemovalObserver) {
            this.draggedSourceNodeRemovalObserver.disconnect();
        }
        this.draggedSourceNodeRemovalObserver = undefined;
        this.draggedSourceNode = undefined;
    }
    constructor(manager, context, options){
        this.getSourceClientOffset = (sourceId)=>{
            const element = this.sourceNodes.get(sourceId);
            return element && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$touch$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$touch$2d$backend$2f$dist$2f$utils$2f$offsets$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNodeClientOffset"])(element);
        };
        this.handleTopMoveStartCapture = (e)=>{
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$touch$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$touch$2d$backend$2f$dist$2f$utils$2f$predicates$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["eventShouldStartDrag"])(e)) {
                return;
            }
            this.moveStartSourceIds = [];
        };
        this.handleMoveStart = (sourceId)=>{
            // Just because we received an event doesn't necessarily mean we need to collect drag sources.
            // We only collect start collecting drag sources on touch and left mouse events.
            if (Array.isArray(this.moveStartSourceIds)) {
                this.moveStartSourceIds.unshift(sourceId);
            }
        };
        this.handleTopMoveStart = (e)=>{
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$touch$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$touch$2d$backend$2f$dist$2f$utils$2f$predicates$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["eventShouldStartDrag"])(e)) {
                return;
            }
            // Don't prematurely preventDefault() here since it might:
            // 1. Mess up scrolling
            // 2. Mess up long tap (which brings up context menu)
            // 3. If there's an anchor link as a child, tap won't be triggered on link
            const clientOffset = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$touch$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$touch$2d$backend$2f$dist$2f$utils$2f$offsets$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getEventClientOffset"])(e);
            if (clientOffset) {
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$touch$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$touch$2d$backend$2f$dist$2f$utils$2f$predicates$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isTouchEvent"])(e)) {
                    this.lastTargetTouchFallback = e.targetTouches[0];
                }
                this._mouseClientOffset = clientOffset;
            }
            this.waitingForDelay = false;
        };
        this.handleTopMoveStartDelay = (e)=>{
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$touch$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$touch$2d$backend$2f$dist$2f$utils$2f$predicates$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["eventShouldStartDrag"])(e)) {
                return;
            }
            const delay = e.type === eventNames.touch.start ? this.options.delayTouchStart : this.options.delayMouseStart;
            this.timeout = setTimeout(this.handleTopMoveStart.bind(this, e), delay);
            this.waitingForDelay = true;
        };
        this.handleTopMoveCapture = ()=>{
            this.dragOverTargetIds = [];
        };
        this.handleMove = (_evt, targetId)=>{
            if (this.dragOverTargetIds) {
                this.dragOverTargetIds.unshift(targetId);
            }
        };
        this.handleTopMove = (e1)=>{
            if (this.timeout) {
                clearTimeout(this.timeout);
            }
            if (!this.document || this.waitingForDelay) {
                return;
            }
            const { moveStartSourceIds, dragOverTargetIds } = this;
            const enableHoverOutsideTarget = this.options.enableHoverOutsideTarget;
            const clientOffset = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$touch$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$touch$2d$backend$2f$dist$2f$utils$2f$offsets$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getEventClientOffset"])(e1, this.lastTargetTouchFallback);
            if (!clientOffset) {
                return;
            }
            // If the touch move started as a scroll, or is is between the scroll angles
            if (this._isScrolling || !this.monitor.isDragging() && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$touch$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$touch$2d$backend$2f$dist$2f$utils$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["inAngleRanges"])(this._mouseClientOffset.x || 0, this._mouseClientOffset.y || 0, clientOffset.x, clientOffset.y, this.options.scrollAngleRanges)) {
                this._isScrolling = true;
                return;
            }
            // If we're not dragging and we've moved a little, that counts as a drag start
            if (!this.monitor.isDragging() && // eslint-disable-next-line no-prototype-builtins
            this._mouseClientOffset.hasOwnProperty('x') && moveStartSourceIds && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$touch$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$touch$2d$backend$2f$dist$2f$utils$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["distance"])(this._mouseClientOffset.x || 0, this._mouseClientOffset.y || 0, clientOffset.x, clientOffset.y) > (this.options.touchSlop ? this.options.touchSlop : 0)) {
                this.moveStartSourceIds = undefined;
                this.actions.beginDrag(moveStartSourceIds, {
                    clientOffset: this._mouseClientOffset,
                    getSourceClientOffset: this.getSourceClientOffset,
                    publishSource: false
                });
            }
            if (!this.monitor.isDragging()) {
                return;
            }
            const sourceNode = this.sourceNodes.get(this.monitor.getSourceId());
            this.installSourceNodeRemovalObserver(sourceNode);
            this.actions.publishDragSource();
            if (e1.cancelable) e1.preventDefault();
            // Get the node elements of the hovered DropTargets
            const dragOverTargetNodes = (dragOverTargetIds || []).map((key)=>this.targetNodes.get(key)).filter((e)=>!!e);
            // Get the a ordered list of nodes that are touched by
            const elementsAtPoint = this.options.getDropTargetElementsAtPoint ? this.options.getDropTargetElementsAtPoint(clientOffset.x, clientOffset.y, dragOverTargetNodes) : this.document.elementsFromPoint(clientOffset.x, clientOffset.y);
            // Extend list with parents that are not receiving elementsFromPoint events (size 0 elements and svg groups)
            const elementsAtPointExtended = [];
            for(const nodeId in elementsAtPoint){
                // eslint-disable-next-line no-prototype-builtins
                if (!elementsAtPoint.hasOwnProperty(nodeId)) {
                    continue;
                }
                let currentNode = elementsAtPoint[nodeId];
                if (currentNode != null) {
                    elementsAtPointExtended.push(currentNode);
                }
                while(currentNode){
                    currentNode = currentNode.parentElement;
                    if (currentNode && elementsAtPointExtended.indexOf(currentNode) === -1) {
                        elementsAtPointExtended.push(currentNode);
                    }
                }
            }
            const orderedDragOverTargetIds = elementsAtPointExtended // Filter off nodes that arent a hovered DropTargets nodes
            .filter((node)=>dragOverTargetNodes.indexOf(node) > -1) // Map back the nodes elements to targetIds
            .map((node)=>this._getDropTargetId(node)) // Filter off possible null rows
            .filter((node)=>!!node).filter((id, index, ids)=>ids.indexOf(id) === index);
            // Invoke hover for drop targets when source node is still over and pointer is outside
            if (enableHoverOutsideTarget) {
                for(const targetId in this.targetNodes){
                    const targetNode = this.targetNodes.get(targetId);
                    if (sourceNode && targetNode && targetNode.contains(sourceNode) && orderedDragOverTargetIds.indexOf(targetId) === -1) {
                        orderedDragOverTargetIds.unshift(targetId);
                        break;
                    }
                }
            }
            // Reverse order because dnd-core reverse it before calling the DropTarget drop methods
            orderedDragOverTargetIds.reverse();
            this.actions.hover(orderedDragOverTargetIds, {
                clientOffset: clientOffset
            });
        };
        /**
	 *
	 * visible for testing
	 */ this._getDropTargetId = (node)=>{
            const keys = this.targetNodes.keys();
            let next = keys.next();
            while(next.done === false){
                const targetId = next.value;
                if (node === this.targetNodes.get(targetId)) {
                    return targetId;
                } else {
                    next = keys.next();
                }
            }
            return undefined;
        };
        this.handleTopMoveEndCapture = (e)=>{
            this._isScrolling = false;
            this.lastTargetTouchFallback = undefined;
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$touch$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$touch$2d$backend$2f$dist$2f$utils$2f$predicates$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["eventShouldEndDrag"])(e)) {
                return;
            }
            if (!this.monitor.isDragging() || this.monitor.didDrop()) {
                this.moveStartSourceIds = undefined;
                return;
            }
            if (e.cancelable) e.preventDefault();
            this._mouseClientOffset = {};
            this.uninstallSourceNodeRemovalObserver();
            this.actions.drop();
            this.actions.endDrag();
        };
        this.handleCancelOnEscape = (e)=>{
            if (e.key === 'Escape' && this.monitor.isDragging()) {
                this._mouseClientOffset = {};
                this.uninstallSourceNodeRemovalObserver();
                this.actions.endDrag();
            }
        };
        this.options = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$touch$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$touch$2d$backend$2f$dist$2f$OptionsReader$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OptionsReader"](options, context);
        this.actions = manager.getActions();
        this.monitor = manager.getMonitor();
        this.sourceNodes = new Map();
        this.sourcePreviewNodes = new Map();
        this.sourcePreviewNodeOptions = new Map();
        this.targetNodes = new Map();
        this.listenerTypes = [];
        this._mouseClientOffset = {};
        this._isScrolling = false;
        if (this.options.enableMouseEvents) {
            this.listenerTypes.push(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$touch$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$touch$2d$backend$2f$dist$2f$interfaces$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ListenerType"].mouse);
        }
        if (this.options.enableTouchEvents) {
            this.listenerTypes.push(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$touch$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$touch$2d$backend$2f$dist$2f$interfaces$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ListenerType"].touch);
        }
        if (this.options.enableKeyboardEvents) {
            this.listenerTypes.push(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$touch$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$touch$2d$backend$2f$dist$2f$interfaces$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ListenerType"].keyboard);
        }
    }
} //# sourceMappingURL=TouchBackendImpl.js.map
}),
"[project]/node_modules/.pnpm/react-dnd-touch-backend@16.0.1/node_modules/react-dnd-touch-backend/dist/index.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TouchBackend",
    ()=>TouchBackend
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$touch$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$touch$2d$backend$2f$dist$2f$TouchBackendImpl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd-touch-backend@16.0.1/node_modules/react-dnd-touch-backend/dist/TouchBackendImpl.js [app-client] (ecmascript)");
;
;
;
const TouchBackend = function createBackend(manager, context = {}, options = {}) {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$touch$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$touch$2d$backend$2f$dist$2f$TouchBackendImpl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TouchBackendImpl"](manager, context, options);
}; //# sourceMappingURL=index.js.map
}),
"[project]/node_modules/.pnpm/dnd-multi-backend@8.1.2_dnd-core@16.0.1/node_modules/dnd-multi-backend/dist/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HTML5DragTransition",
    ()=>O,
    "MouseTransition",
    ()=>C,
    "MultiBackend",
    ()=>S,
    "PointerTransition",
    ()=>U,
    "TouchTransition",
    ()=>L,
    "createTransition",
    ()=>y
]);
var E = (r)=>{
    throw TypeError(r);
};
var P = (r, n, e)=>n.has(r) || E("Cannot " + e);
var t = (r, n, e)=>(P(r, n, "read from private field"), e ? e.call(r) : n.get(r)), s = (r, n, e)=>n.has(r) ? E("Cannot add the same private member more than once") : n instanceof WeakSet ? n.add(r) : n.set(r, e), p = (r, n, e, i)=>(P(r, n, "write to private field"), i ? i.call(r, e) : n.set(r, e), e);
var h, B = class {
    constructor(){
        s(this, h);
        this.register = (n)=>{
            t(this, h).push(n);
        };
        this.unregister = (n)=>{
            for(; t(this, h).indexOf(n) !== -1;)t(this, h).splice(t(this, h).indexOf(n), 1);
        };
        this.backendChanged = (n)=>{
            for (let e of t(this, h))e.backendChanged(n);
        };
        p(this, h, []);
    }
};
h = new WeakMap;
var c, l, a, d, k, x, T, D, m, v, f, w = class w {
    constructor(n, e, i){
        s(this, c);
        s(this, l);
        s(this, a);
        s(this, d);
        s(this, k);
        s(this, x, (n, e, i)=>{
            if (!i.backend) throw new Error(`You must specify a 'backend' property in your Backend entry: ${JSON.stringify(i)}`);
            let u = i.backend(n, e, i.options), o = i.id, g = !i.id && u && u.constructor;
            if (g && (o = u.constructor.name), !o) throw new Error(`You must specify an 'id' property in your Backend entry: ${JSON.stringify(i)}
        see this guide: https://github.com/louisbrunner/dnd-multi-backend/tree/master/packages/react-dnd-multi-backend#migrating-from-5xx`);
            if (g && console.warn(`Deprecation notice: You are using a pipeline which doesn't include backends' 'id'.
        This might be unsupported in the future, please specify 'id' explicitely for every backend.`), t(this, a)[o]) throw new Error(`You must specify a unique 'id' property in your Backend entry:
        ${JSON.stringify(i)} (conflicts with: ${JSON.stringify(t(this, a)[o])})`);
            return {
                id: o,
                instance: u,
                preview: i.preview ?? !1,
                transition: i.transition,
                skipDispatchOnTransition: i.skipDispatchOnTransition ?? !1
            };
        });
        this.setup = ()=>{
            if (!(typeof window > "u")) {
                if (w.isSetUp) throw new Error("Cannot have two MultiBackends at the same time.");
                w.isSetUp = !0, t(this, T).call(this, window), t(this, a)[t(this, c)].instance.setup();
            }
        };
        this.teardown = ()=>{
            typeof window > "u" || (w.isSetUp = !1, t(this, D).call(this, window), t(this, a)[t(this, c)].instance.teardown());
        };
        this.connectDragSource = (n, e, i)=>t(this, f).call(this, "connectDragSource", n, e, i);
        this.connectDragPreview = (n, e, i)=>t(this, f).call(this, "connectDragPreview", n, e, i);
        this.connectDropTarget = (n, e, i)=>t(this, f).call(this, "connectDropTarget", n, e, i);
        this.profile = ()=>t(this, a)[t(this, c)].instance.profile();
        this.previewEnabled = ()=>t(this, a)[t(this, c)].preview;
        this.previewsList = ()=>t(this, l);
        this.backendsList = ()=>t(this, d);
        s(this, T, (n)=>{
            for (let e of t(this, d))e.transition && n.addEventListener(e.transition.event, t(this, m));
        });
        s(this, D, (n)=>{
            for (let e of t(this, d))e.transition && n.removeEventListener(e.transition.event, t(this, m));
        });
        s(this, m, (n)=>{
            let e = t(this, c);
            if (t(this, d).some((i)=>i.id !== t(this, c) && i.transition && i.transition.check(n) ? (p(this, c, i.id), !0) : !1), t(this, c) !== e) {
                t(this, a)[e].instance.teardown();
                for (let [g, b] of Object.entries(t(this, k)))b.unsubscribe(), b.unsubscribe = t(this, v).call(this, b.func, ...b.args);
                t(this, l).backendChanged(this);
                let i = t(this, a)[t(this, c)];
                if (i.instance.setup(), i.skipDispatchOnTransition) return;
                let u = n.constructor, o = new u(n.type, n);
                n.target?.dispatchEvent(o);
            }
        });
        s(this, v, (n, e, i, u)=>t(this, a)[t(this, c)].instance[n](e, i, u));
        s(this, f, (n, e, i, u)=>{
            let o = `${n}_${e}`, g = t(this, v).call(this, n, e, i, u);
            return t(this, k)[o] = {
                func: n,
                args: [
                    e,
                    i,
                    u
                ],
                unsubscribe: g
            }, ()=>{
                t(this, k)[o].unsubscribe(), delete t(this, k)[o];
            };
        });
        if (!i || !i.backends || i.backends.length < 1) throw new Error(`You must specify at least one Backend, if you are coming from 2.x.x (or don't understand this error)
        see this guide: https://github.com/louisbrunner/dnd-multi-backend/tree/master/packages/react-dnd-multi-backend#migrating-from-2xx`);
        p(this, l, new B), p(this, a, {}), p(this, d, []);
        for (let u of i.backends){
            let o = t(this, x).call(this, n, e, u);
            t(this, a)[o.id] = o, t(this, d).push(o);
        }
        p(this, c, t(this, d)[0].id), p(this, k, {});
    }
};
c = new WeakMap, l = new WeakMap, a = new WeakMap, d = new WeakMap, k = new WeakMap, x = new WeakMap, T = new WeakMap, D = new WeakMap, m = new WeakMap, v = new WeakMap, f = new WeakMap, w.isSetUp = !1;
var M = w;
var S = (r, n, e)=>new M(r, n, e);
var y = (r, n)=>({
        event: r,
        check: n
    });
var L = y("touchstart", (r)=>{
    let n = r;
    return n.touches !== null && n.touches !== void 0;
}), O = y("dragstart", (r)=>r.type.indexOf("drag") !== -1 || r.type.indexOf("drop") !== -1), C = y("mousedown", (r)=>r.type.indexOf("touch") === -1 && r.type.indexOf("mouse") !== -1), U = y("pointerdown", (r)=>r.pointerType === "mouse");
;
}),
"[project]/node_modules/.pnpm/rdndmb-html5-to-touch@8.1.2_dnd-core@16.0.1/node_modules/rdndmb-html5-to-touch/dist/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HTML5toTouch",
    ()=>c
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd-html5-backend@16.0.1/node_modules/react-dnd-html5-backend/dist/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$touch$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$touch$2d$backend$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd-touch-backend@16.0.1/node_modules/react-dnd-touch-backend/dist/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$multi$2d$backend$40$8$2e$1$2e$2_dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$multi$2d$backend$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-multi-backend@8.1.2_dnd-core@16.0.1/node_modules/dnd-multi-backend/dist/index.js [app-client] (ecmascript)");
;
;
;
var c = {
    backends: [
        {
            id: "html5",
            backend: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["HTML5Backend"],
            transition: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$multi$2d$backend$40$8$2e$1$2e$2_dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$multi$2d$backend$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PointerTransition"]
        },
        {
            id: "touch",
            backend: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$touch$2d$backend$40$16$2e$0$2e$1$2f$node_modules$2f$react$2d$dnd$2d$touch$2d$backend$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["TouchBackend"],
            options: {
                enableMouseEvents: !0
            },
            preview: !0,
            transition: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$multi$2d$backend$40$8$2e$1$2e$2_dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$multi$2d$backend$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TouchTransition"]
        }
    ]
};
;
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.6/node_modules/@babel/runtime/helpers/esm/typeof.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>_typeof
]);
function _typeof(o) {
    "@babel/helpers - typeof";
    return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
        return typeof o;
    } : function(o) {
        return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
    }, _typeof(o);
}
;
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.6/node_modules/@babel/runtime/helpers/esm/toPrimitive.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>toPrimitive
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$babel$2b$runtime$40$7$2e$28$2e$6$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$typeof$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@babel+runtime@7.28.6/node_modules/@babel/runtime/helpers/esm/typeof.js [app-client] (ecmascript)");
;
function toPrimitive(t, r) {
    if ("object" != (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$babel$2b$runtime$40$7$2e$28$2e$6$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$typeof$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(t) || !t) return t;
    var e = t[Symbol.toPrimitive];
    if (void 0 !== e) {
        var i = e.call(t, r || "default");
        if ("object" != (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$babel$2b$runtime$40$7$2e$28$2e$6$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$typeof$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(i)) return i;
        throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return ("string" === r ? String : Number)(t);
}
;
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.6/node_modules/@babel/runtime/helpers/esm/toPropertyKey.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>toPropertyKey
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$babel$2b$runtime$40$7$2e$28$2e$6$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$typeof$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@babel+runtime@7.28.6/node_modules/@babel/runtime/helpers/esm/typeof.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$babel$2b$runtime$40$7$2e$28$2e$6$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$toPrimitive$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@babel+runtime@7.28.6/node_modules/@babel/runtime/helpers/esm/toPrimitive.js [app-client] (ecmascript)");
;
;
function toPropertyKey(t) {
    var i = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$babel$2b$runtime$40$7$2e$28$2e$6$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$toPrimitive$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(t, "string");
    return "symbol" == (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$babel$2b$runtime$40$7$2e$28$2e$6$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$typeof$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(i) ? i : i + "";
}
;
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.6/node_modules/@babel/runtime/helpers/esm/defineProperty.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>_defineProperty
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$babel$2b$runtime$40$7$2e$28$2e$6$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$toPropertyKey$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@babel+runtime@7.28.6/node_modules/@babel/runtime/helpers/esm/toPropertyKey.js [app-client] (ecmascript)");
;
function _defineProperty(e, r, t) {
    return (r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$babel$2b$runtime$40$7$2e$28$2e$6$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$toPropertyKey$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(r)) in e ? Object.defineProperty(e, r, {
        value: t,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[r] = t, e;
}
;
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.6/node_modules/@babel/runtime/helpers/esm/objectSpread2.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>_objectSpread2
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$babel$2b$runtime$40$7$2e$28$2e$6$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$defineProperty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@babel+runtime@7.28.6/node_modules/@babel/runtime/helpers/esm/defineProperty.js [app-client] (ecmascript)");
;
function ownKeys(e, r) {
    var t = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        r && (o = o.filter(function(r) {
            return Object.getOwnPropertyDescriptor(e, r).enumerable;
        })), t.push.apply(t, o);
    }
    return t;
}
function _objectSpread2(e) {
    for(var r = 1; r < arguments.length; r++){
        var t = null != arguments[r] ? arguments[r] : {};
        r % 2 ? ownKeys(Object(t), !0).forEach(function(r) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$babel$2b$runtime$40$7$2e$28$2e$6$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$defineProperty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(e, r, t[r]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r) {
            Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
        });
    }
    return e;
}
;
}),
"[project]/node_modules/.pnpm/redux@4.2.1/node_modules/redux/es/redux.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__DO_NOT_USE__ActionTypes",
    ()=>ActionTypes,
    "applyMiddleware",
    ()=>applyMiddleware,
    "bindActionCreators",
    ()=>bindActionCreators,
    "combineReducers",
    ()=>combineReducers,
    "compose",
    ()=>compose,
    "createStore",
    ()=>createStore,
    "legacy_createStore",
    ()=>legacy_createStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$babel$2b$runtime$40$7$2e$28$2e$6$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$objectSpread2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@babel+runtime@7.28.6/node_modules/@babel/runtime/helpers/esm/objectSpread2.js [app-client] (ecmascript)");
;
/**
 * Adapted from React: https://github.com/facebook/react/blob/master/packages/shared/formatProdErrorMessage.js
 *
 * Do not require this module directly! Use normal throw error calls. These messages will be replaced with error codes
 * during build.
 * @param {number} code
 */ function formatProdErrorMessage(code) {
    return "Minified Redux error #" + code + "; visit https://redux.js.org/Errors?code=" + code + " for the full message or " + 'use the non-minified dev environment for full errors. ';
}
// Inlined version of the `symbol-observable` polyfill
var $$observable = function() {
    return typeof Symbol === 'function' && Symbol.observable || '@@observable';
}();
/**
 * These are private action types reserved by Redux.
 * For any unknown actions, you must return the current state.
 * If the current state is undefined, you must return the initial state.
 * Do not reference these action types directly in your code.
 */ var randomString = function randomString() {
    return Math.random().toString(36).substring(7).split('').join('.');
};
var ActionTypes = {
    INIT: "@@redux/INIT" + randomString(),
    REPLACE: "@@redux/REPLACE" + randomString(),
    PROBE_UNKNOWN_ACTION: function PROBE_UNKNOWN_ACTION() {
        return "@@redux/PROBE_UNKNOWN_ACTION" + randomString();
    }
};
/**
 * @param {any} obj The object to inspect.
 * @returns {boolean} True if the argument appears to be a plain object.
 */ function isPlainObject(obj) {
    if (typeof obj !== 'object' || obj === null) return false;
    var proto = obj;
    while(Object.getPrototypeOf(proto) !== null){
        proto = Object.getPrototypeOf(proto);
    }
    return Object.getPrototypeOf(obj) === proto;
}
// Inlined / shortened version of `kindOf` from https://github.com/jonschlinkert/kind-of
function miniKindOf(val) {
    if (val === void 0) return 'undefined';
    if (val === null) return 'null';
    var type = typeof val;
    switch(type){
        case 'boolean':
        case 'string':
        case 'number':
        case 'symbol':
        case 'function':
            {
                return type;
            }
    }
    if (Array.isArray(val)) return 'array';
    if (isDate(val)) return 'date';
    if (isError(val)) return 'error';
    var constructorName = ctorName(val);
    switch(constructorName){
        case 'Symbol':
        case 'Promise':
        case 'WeakMap':
        case 'WeakSet':
        case 'Map':
        case 'Set':
            return constructorName;
    } // other
    return type.slice(8, -1).toLowerCase().replace(/\s/g, '');
}
function ctorName(val) {
    return typeof val.constructor === 'function' ? val.constructor.name : null;
}
function isError(val) {
    return val instanceof Error || typeof val.message === 'string' && val.constructor && typeof val.constructor.stackTraceLimit === 'number';
}
function isDate(val) {
    if (val instanceof Date) return true;
    return typeof val.toDateString === 'function' && typeof val.getDate === 'function' && typeof val.setDate === 'function';
}
function kindOf(val) {
    var typeOfVal = typeof val;
    if ("TURBOPACK compile-time truthy", 1) {
        typeOfVal = miniKindOf(val);
    }
    return typeOfVal;
}
/**
 * @deprecated
 *
 * **We recommend using the `configureStore` method
 * of the `@reduxjs/toolkit` package**, which replaces `createStore`.
 *
 * Redux Toolkit is our recommended approach for writing Redux logic today,
 * including store setup, reducers, data fetching, and more.
 *
 * **For more details, please read this Redux docs page:**
 * **https://redux.js.org/introduction/why-rtk-is-redux-today**
 *
 * `configureStore` from Redux Toolkit is an improved version of `createStore` that
 * simplifies setup and helps avoid common bugs.
 *
 * You should not be using the `redux` core package by itself today, except for learning purposes.
 * The `createStore` method from the core `redux` package will not be removed, but we encourage
 * all users to migrate to using Redux Toolkit for all Redux code.
 *
 * If you want to use `createStore` without this visual deprecation warning, use
 * the `legacy_createStore` import instead:
 *
 * `import { legacy_createStore as createStore} from 'redux'`
 *
 */ function createStore(reducer, preloadedState, enhancer) {
    var _ref2;
    if (typeof preloadedState === 'function' && typeof enhancer === 'function' || typeof enhancer === 'function' && typeof arguments[3] === 'function') {
        throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : 'It looks like you are passing several store enhancers to ' + 'createStore(). This is not supported. Instead, compose them ' + 'together to a single function. See https://redux.js.org/tutorials/fundamentals/part-4-store#creating-a-store-with-enhancers for an example.');
    }
    if (typeof preloadedState === 'function' && typeof enhancer === 'undefined') {
        enhancer = preloadedState;
        preloadedState = undefined;
    }
    if (typeof enhancer !== 'undefined') {
        if (typeof enhancer !== 'function') {
            throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : "Expected the enhancer to be a function. Instead, received: '" + kindOf(enhancer) + "'");
        }
        return enhancer(createStore)(reducer, preloadedState);
    }
    if (typeof reducer !== 'function') {
        throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : "Expected the root reducer to be a function. Instead, received: '" + kindOf(reducer) + "'");
    }
    var currentReducer = reducer;
    var currentState = preloadedState;
    var currentListeners = [];
    var nextListeners = currentListeners;
    var isDispatching = false;
    /**
   * This makes a shallow copy of currentListeners so we can use
   * nextListeners as a temporary list while dispatching.
   *
   * This prevents any bugs around consumers calling
   * subscribe/unsubscribe in the middle of a dispatch.
   */ function ensureCanMutateNextListeners() {
        if (nextListeners === currentListeners) {
            nextListeners = currentListeners.slice();
        }
    }
    /**
   * Reads the state tree managed by the store.
   *
   * @returns {any} The current state tree of your application.
   */ function getState() {
        if (isDispatching) {
            throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : 'You may not call store.getState() while the reducer is executing. ' + 'The reducer has already received the state as an argument. ' + 'Pass it down from the top reducer instead of reading it from the store.');
        }
        return currentState;
    }
    /**
   * Adds a change listener. It will be called any time an action is dispatched,
   * and some part of the state tree may potentially have changed. You may then
   * call `getState()` to read the current state tree inside the callback.
   *
   * You may call `dispatch()` from a change listener, with the following
   * caveats:
   *
   * 1. The subscriptions are snapshotted just before every `dispatch()` call.
   * If you subscribe or unsubscribe while the listeners are being invoked, this
   * will not have any effect on the `dispatch()` that is currently in progress.
   * However, the next `dispatch()` call, whether nested or not, will use a more
   * recent snapshot of the subscription list.
   *
   * 2. The listener should not expect to see all state changes, as the state
   * might have been updated multiple times during a nested `dispatch()` before
   * the listener is called. It is, however, guaranteed that all subscribers
   * registered before the `dispatch()` started will be called with the latest
   * state by the time it exits.
   *
   * @param {Function} listener A callback to be invoked on every dispatch.
   * @returns {Function} A function to remove this change listener.
   */ function subscribe(listener) {
        if (typeof listener !== 'function') {
            throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : "Expected the listener to be a function. Instead, received: '" + kindOf(listener) + "'");
        }
        if (isDispatching) {
            throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : 'You may not call store.subscribe() while the reducer is executing. ' + 'If you would like to be notified after the store has been updated, subscribe from a ' + 'component and invoke store.getState() in the callback to access the latest state. ' + 'See https://redux.js.org/api/store#subscribelistener for more details.');
        }
        var isSubscribed = true;
        ensureCanMutateNextListeners();
        nextListeners.push(listener);
        return function unsubscribe() {
            if (!isSubscribed) {
                return;
            }
            if (isDispatching) {
                throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : 'You may not unsubscribe from a store listener while the reducer is executing. ' + 'See https://redux.js.org/api/store#subscribelistener for more details.');
            }
            isSubscribed = false;
            ensureCanMutateNextListeners();
            var index = nextListeners.indexOf(listener);
            nextListeners.splice(index, 1);
            currentListeners = null;
        };
    }
    /**
   * Dispatches an action. It is the only way to trigger a state change.
   *
   * The `reducer` function, used to create the store, will be called with the
   * current state tree and the given `action`. Its return value will
   * be considered the **next** state of the tree, and the change listeners
   * will be notified.
   *
   * The base implementation only supports plain object actions. If you want to
   * dispatch a Promise, an Observable, a thunk, or something else, you need to
   * wrap your store creating function into the corresponding middleware. For
   * example, see the documentation for the `redux-thunk` package. Even the
   * middleware will eventually dispatch plain object actions using this method.
   *
   * @param {Object} action A plain object representing “what changed”. It is
   * a good idea to keep actions serializable so you can record and replay user
   * sessions, or use the time travelling `redux-devtools`. An action must have
   * a `type` property which may not be `undefined`. It is a good idea to use
   * string constants for action types.
   *
   * @returns {Object} For convenience, the same action object you dispatched.
   *
   * Note that, if you use a custom middleware, it may wrap `dispatch()` to
   * return something else (for example, a Promise you can await).
   */ function dispatch(action) {
        if (!isPlainObject(action)) {
            throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : "Actions must be plain objects. Instead, the actual type was: '" + kindOf(action) + "'. You may need to add middleware to your store setup to handle dispatching other values, such as 'redux-thunk' to handle dispatching functions. See https://redux.js.org/tutorials/fundamentals/part-4-store#middleware and https://redux.js.org/tutorials/fundamentals/part-6-async-logic#using-the-redux-thunk-middleware for examples.");
        }
        if (typeof action.type === 'undefined') {
            throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : 'Actions may not have an undefined "type" property. You may have misspelled an action type string constant.');
        }
        if (isDispatching) {
            throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : 'Reducers may not dispatch actions.');
        }
        try {
            isDispatching = true;
            currentState = currentReducer(currentState, action);
        } finally{
            isDispatching = false;
        }
        var listeners = currentListeners = nextListeners;
        for(var i = 0; i < listeners.length; i++){
            var listener = listeners[i];
            listener();
        }
        return action;
    }
    /**
   * Replaces the reducer currently used by the store to calculate the state.
   *
   * You might need this if your app implements code splitting and you want to
   * load some of the reducers dynamically. You might also need this if you
   * implement a hot reloading mechanism for Redux.
   *
   * @param {Function} nextReducer The reducer for the store to use instead.
   * @returns {void}
   */ function replaceReducer(nextReducer) {
        if (typeof nextReducer !== 'function') {
            throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : "Expected the nextReducer to be a function. Instead, received: '" + kindOf(nextReducer));
        }
        currentReducer = nextReducer; // This action has a similiar effect to ActionTypes.INIT.
        // Any reducers that existed in both the new and old rootReducer
        // will receive the previous state. This effectively populates
        // the new state tree with any relevant data from the old one.
        dispatch({
            type: ActionTypes.REPLACE
        });
    }
    /**
   * Interoperability point for observable/reactive libraries.
   * @returns {observable} A minimal observable of state changes.
   * For more information, see the observable proposal:
   * https://github.com/tc39/proposal-observable
   */ function observable() {
        var _ref;
        var outerSubscribe = subscribe;
        return _ref = {
            /**
       * The minimal observable subscription method.
       * @param {Object} observer Any object that can be used as an observer.
       * The observer object should have a `next` method.
       * @returns {subscription} An object with an `unsubscribe` method that can
       * be used to unsubscribe the observable from the store, and prevent further
       * emission of values from the observable.
       */ subscribe: function subscribe(observer) {
                if (typeof observer !== 'object' || observer === null) {
                    throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : "Expected the observer to be an object. Instead, received: '" + kindOf(observer) + "'");
                }
                function observeState() {
                    if (observer.next) {
                        observer.next(getState());
                    }
                }
                observeState();
                var unsubscribe = outerSubscribe(observeState);
                return {
                    unsubscribe: unsubscribe
                };
            }
        }, _ref[$$observable] = function() {
            return this;
        }, _ref;
    } // When a store is created, an "INIT" action is dispatched so that every
    // reducer returns their initial state. This effectively populates
    // the initial state tree.
    dispatch({
        type: ActionTypes.INIT
    });
    return _ref2 = {
        dispatch: dispatch,
        subscribe: subscribe,
        getState: getState,
        replaceReducer: replaceReducer
    }, _ref2[$$observable] = observable, _ref2;
}
/**
 * Creates a Redux store that holds the state tree.
 *
 * **We recommend using `configureStore` from the
 * `@reduxjs/toolkit` package**, which replaces `createStore`:
 * **https://redux.js.org/introduction/why-rtk-is-redux-today**
 *
 * The only way to change the data in the store is to call `dispatch()` on it.
 *
 * There should only be a single store in your app. To specify how different
 * parts of the state tree respond to actions, you may combine several reducers
 * into a single reducer function by using `combineReducers`.
 *
 * @param {Function} reducer A function that returns the next state tree, given
 * the current state tree and the action to handle.
 *
 * @param {any} [preloadedState] The initial state. You may optionally specify it
 * to hydrate the state from the server in universal apps, or to restore a
 * previously serialized user session.
 * If you use `combineReducers` to produce the root reducer function, this must be
 * an object with the same shape as `combineReducers` keys.
 *
 * @param {Function} [enhancer] The store enhancer. You may optionally specify it
 * to enhance the store with third-party capabilities such as middleware,
 * time travel, persistence, etc. The only store enhancer that ships with Redux
 * is `applyMiddleware()`.
 *
 * @returns {Store} A Redux store that lets you read the state, dispatch actions
 * and subscribe to changes.
 */ var legacy_createStore = createStore;
/**
 * Prints a warning in the console if it exists.
 *
 * @param {String} message The warning message.
 * @returns {void}
 */ function warning(message) {
    /* eslint-disable no-console */ if (typeof console !== 'undefined' && typeof console.error === 'function') {
        console.error(message);
    }
    /* eslint-enable no-console */ try {
        // This error was thrown as a convenience so that if you enable
        // "break on all exceptions" in your console,
        // it would pause the execution at this line.
        throw new Error(message);
    } catch (e) {} // eslint-disable-line no-empty
}
function getUnexpectedStateShapeWarningMessage(inputState, reducers, action, unexpectedKeyCache) {
    var reducerKeys = Object.keys(reducers);
    var argumentName = action && action.type === ActionTypes.INIT ? 'preloadedState argument passed to createStore' : 'previous state received by the reducer';
    if (reducerKeys.length === 0) {
        return 'Store does not have a valid reducer. Make sure the argument passed ' + 'to combineReducers is an object whose values are reducers.';
    }
    if (!isPlainObject(inputState)) {
        return "The " + argumentName + " has unexpected type of \"" + kindOf(inputState) + "\". Expected argument to be an object with the following " + ("keys: \"" + reducerKeys.join('", "') + "\"");
    }
    var unexpectedKeys = Object.keys(inputState).filter(function(key) {
        return !reducers.hasOwnProperty(key) && !unexpectedKeyCache[key];
    });
    unexpectedKeys.forEach(function(key) {
        unexpectedKeyCache[key] = true;
    });
    if (action && action.type === ActionTypes.REPLACE) return;
    if (unexpectedKeys.length > 0) {
        return "Unexpected " + (unexpectedKeys.length > 1 ? 'keys' : 'key') + " " + ("\"" + unexpectedKeys.join('", "') + "\" found in " + argumentName + ". ") + "Expected to find one of the known reducer keys instead: " + ("\"" + reducerKeys.join('", "') + "\". Unexpected keys will be ignored.");
    }
}
function assertReducerShape(reducers) {
    Object.keys(reducers).forEach(function(key) {
        var reducer = reducers[key];
        var initialState = reducer(undefined, {
            type: ActionTypes.INIT
        });
        if (typeof initialState === 'undefined') {
            throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : "The slice reducer for key \"" + key + "\" returned undefined during initialization. " + "If the state passed to the reducer is undefined, you must " + "explicitly return the initial state. The initial state may " + "not be undefined. If you don't want to set a value for this reducer, " + "you can use null instead of undefined.");
        }
        if (typeof reducer(undefined, {
            type: ActionTypes.PROBE_UNKNOWN_ACTION()
        }) === 'undefined') {
            throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : "The slice reducer for key \"" + key + "\" returned undefined when probed with a random type. " + ("Don't try to handle '" + ActionTypes.INIT + "' or other actions in \"redux/*\" ") + "namespace. They are considered private. Instead, you must return the " + "current state for any unknown actions, unless it is undefined, " + "in which case you must return the initial state, regardless of the " + "action type. The initial state may not be undefined, but can be null.");
        }
    });
}
/**
 * Turns an object whose values are different reducer functions, into a single
 * reducer function. It will call every child reducer, and gather their results
 * into a single state object, whose keys correspond to the keys of the passed
 * reducer functions.
 *
 * @param {Object} reducers An object whose values correspond to different
 * reducer functions that need to be combined into one. One handy way to obtain
 * it is to use ES6 `import * as reducers` syntax. The reducers may never return
 * undefined for any action. Instead, they should return their initial state
 * if the state passed to them was undefined, and the current state for any
 * unrecognized action.
 *
 * @returns {Function} A reducer function that invokes every reducer inside the
 * passed object, and builds a state object with the same shape.
 */ function combineReducers(reducers) {
    var reducerKeys = Object.keys(reducers);
    var finalReducers = {};
    for(var i = 0; i < reducerKeys.length; i++){
        var key = reducerKeys[i];
        if ("TURBOPACK compile-time truthy", 1) {
            if (typeof reducers[key] === 'undefined') {
                warning("No reducer provided for key \"" + key + "\"");
            }
        }
        if (typeof reducers[key] === 'function') {
            finalReducers[key] = reducers[key];
        }
    }
    var finalReducerKeys = Object.keys(finalReducers); // This is used to make sure we don't warn about the same
    // keys multiple times.
    var unexpectedKeyCache;
    if (("TURBOPACK compile-time value", "development") !== 'production') {
        unexpectedKeyCache = {};
    }
    var shapeAssertionError;
    try {
        assertReducerShape(finalReducers);
    } catch (e) {
        shapeAssertionError = e;
    }
    return function combination(state, action) {
        if (state === void 0) {
            state = {};
        }
        if (shapeAssertionError) {
            throw shapeAssertionError;
        }
        if ("TURBOPACK compile-time truthy", 1) {
            var warningMessage = getUnexpectedStateShapeWarningMessage(state, finalReducers, action, unexpectedKeyCache);
            if (warningMessage) {
                warning(warningMessage);
            }
        }
        var hasChanged = false;
        var nextState = {};
        for(var _i = 0; _i < finalReducerKeys.length; _i++){
            var _key = finalReducerKeys[_i];
            var reducer = finalReducers[_key];
            var previousStateForKey = state[_key];
            var nextStateForKey = reducer(previousStateForKey, action);
            if (typeof nextStateForKey === 'undefined') {
                var actionType = action && action.type;
                throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : "When called with an action of type " + (actionType ? "\"" + String(actionType) + "\"" : '(unknown type)') + ", the slice reducer for key \"" + _key + "\" returned undefined. " + "To ignore an action, you must explicitly return the previous state. " + "If you want this reducer to hold no value, you can return null instead of undefined.");
            }
            nextState[_key] = nextStateForKey;
            hasChanged = hasChanged || nextStateForKey !== previousStateForKey;
        }
        hasChanged = hasChanged || finalReducerKeys.length !== Object.keys(state).length;
        return hasChanged ? nextState : state;
    };
}
function bindActionCreator(actionCreator, dispatch) {
    return function() {
        return dispatch(actionCreator.apply(this, arguments));
    };
}
/**
 * Turns an object whose values are action creators, into an object with the
 * same keys, but with every function wrapped into a `dispatch` call so they
 * may be invoked directly. This is just a convenience method, as you can call
 * `store.dispatch(MyActionCreators.doSomething())` yourself just fine.
 *
 * For convenience, you can also pass an action creator as the first argument,
 * and get a dispatch wrapped function in return.
 *
 * @param {Function|Object} actionCreators An object whose values are action
 * creator functions. One handy way to obtain it is to use ES6 `import * as`
 * syntax. You may also pass a single function.
 *
 * @param {Function} dispatch The `dispatch` function available on your Redux
 * store.
 *
 * @returns {Function|Object} The object mimicking the original object, but with
 * every action creator wrapped into the `dispatch` call. If you passed a
 * function as `actionCreators`, the return value will also be a single
 * function.
 */ function bindActionCreators(actionCreators, dispatch) {
    if (typeof actionCreators === 'function') {
        return bindActionCreator(actionCreators, dispatch);
    }
    if (typeof actionCreators !== 'object' || actionCreators === null) {
        throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : "bindActionCreators expected an object or a function, but instead received: '" + kindOf(actionCreators) + "'. " + "Did you write \"import ActionCreators from\" instead of \"import * as ActionCreators from\"?");
    }
    var boundActionCreators = {};
    for(var key in actionCreators){
        var actionCreator = actionCreators[key];
        if (typeof actionCreator === 'function') {
            boundActionCreators[key] = bindActionCreator(actionCreator, dispatch);
        }
    }
    return boundActionCreators;
}
/**
 * Composes single-argument functions from right to left. The rightmost
 * function can take multiple arguments as it provides the signature for
 * the resulting composite function.
 *
 * @param {...Function} funcs The functions to compose.
 * @returns {Function} A function obtained by composing the argument functions
 * from right to left. For example, compose(f, g, h) is identical to doing
 * (...args) => f(g(h(...args))).
 */ function compose() {
    for(var _len = arguments.length, funcs = new Array(_len), _key = 0; _key < _len; _key++){
        funcs[_key] = arguments[_key];
    }
    if (funcs.length === 0) {
        return function(arg) {
            return arg;
        };
    }
    if (funcs.length === 1) {
        return funcs[0];
    }
    return funcs.reduce(function(a, b) {
        return function() {
            return a(b.apply(void 0, arguments));
        };
    });
}
/**
 * Creates a store enhancer that applies middleware to the dispatch method
 * of the Redux store. This is handy for a variety of tasks, such as expressing
 * asynchronous actions in a concise manner, or logging every action payload.
 *
 * See `redux-thunk` package as an example of the Redux middleware.
 *
 * Because middleware is potentially asynchronous, this should be the first
 * store enhancer in the composition chain.
 *
 * Note that each middleware will be given the `dispatch` and `getState` functions
 * as named arguments.
 *
 * @param {...Function} middlewares The middleware chain to be applied.
 * @returns {Function} A store enhancer applying the middleware.
 */ function applyMiddleware() {
    for(var _len = arguments.length, middlewares = new Array(_len), _key = 0; _key < _len; _key++){
        middlewares[_key] = arguments[_key];
    }
    return function(createStore) {
        return function() {
            var store = createStore.apply(void 0, arguments);
            var _dispatch = function dispatch() {
                throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : 'Dispatching while constructing your middleware is not allowed. ' + 'Other middleware would not be applied to this dispatch.');
            };
            var middlewareAPI = {
                getState: store.getState,
                dispatch: function dispatch() {
                    return _dispatch.apply(void 0, arguments);
                }
            };
            var chain = middlewares.map(function(middleware) {
                return middleware(middlewareAPI);
            });
            _dispatch = compose.apply(void 0, chain)(store.dispatch);
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$babel$2b$runtime$40$7$2e$28$2e$6$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$objectSpread2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$babel$2b$runtime$40$7$2e$28$2e$6$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$objectSpread2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, store), {}, {
                dispatch: _dispatch
            });
        };
    };
}
;
}),
"[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/utils/js_utils.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// cheap lodash replacements
/**
 * drop-in replacement for _.get
 * @param obj
 * @param path
 * @param defaultValue
 */ __turbopack_context__.s([
    "get",
    ()=>get,
    "intersection",
    ()=>intersection,
    "isObject",
    ()=>isObject,
    "isString",
    ()=>isString,
    "without",
    ()=>without,
    "xor",
    ()=>xor
]);
function get(obj, path, defaultValue) {
    return path.split('.').reduce((a, c)=>a && a[c] ? a[c] : defaultValue || null, obj);
}
function without(items, item) {
    return items.filter((i)=>i !== item);
}
function isString(input) {
    return typeof input === 'string';
}
function isObject(input) {
    return typeof input === 'object';
}
function xor(itemsA, itemsB) {
    const map = new Map();
    const insertItem = (item)=>{
        map.set(item, map.has(item) ? map.get(item) + 1 : 1);
    };
    itemsA.forEach(insertItem);
    itemsB.forEach(insertItem);
    const result = [];
    map.forEach((count, key)=>{
        if (count === 1) {
            result.push(key);
        }
    });
    return result;
}
function intersection(itemsA, itemsB) {
    return itemsA.filter((t)=>itemsB.indexOf(t) > -1);
} //# sourceMappingURL=js_utils.js.map
}),
"[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/actions/dragDrop/types.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BEGIN_DRAG",
    ()=>BEGIN_DRAG,
    "DROP",
    ()=>DROP,
    "END_DRAG",
    ()=>END_DRAG,
    "HOVER",
    ()=>HOVER,
    "INIT_COORDS",
    ()=>INIT_COORDS,
    "PUBLISH_DRAG_SOURCE",
    ()=>PUBLISH_DRAG_SOURCE
]);
const INIT_COORDS = 'dnd-core/INIT_COORDS';
const BEGIN_DRAG = 'dnd-core/BEGIN_DRAG';
const PUBLISH_DRAG_SOURCE = 'dnd-core/PUBLISH_DRAG_SOURCE';
const HOVER = 'dnd-core/HOVER';
const DROP = 'dnd-core/DROP';
const END_DRAG = 'dnd-core/END_DRAG'; //# sourceMappingURL=types.js.map
}),
"[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/actions/dragDrop/local/setClientOffset.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "setClientOffset",
    ()=>setClientOffset
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/actions/dragDrop/types.js [app-client] (ecmascript)");
;
function setClientOffset(clientOffset, sourceClientOffset) {
    return {
        type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["INIT_COORDS"],
        payload: {
            sourceClientOffset: sourceClientOffset || null,
            clientOffset: clientOffset || null
        }
    };
} //# sourceMappingURL=setClientOffset.js.map
}),
"[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/actions/dragDrop/beginDrag.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createBeginDrag",
    ()=>createBeginDrag
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$4$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+invariant@4.0.2/node_modules/@react-dnd/invariant/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$utils$2f$js_utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/utils/js_utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$local$2f$setClientOffset$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/actions/dragDrop/local/setClientOffset.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/actions/dragDrop/types.js [app-client] (ecmascript)");
;
;
;
;
const ResetCoordinatesAction = {
    type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["INIT_COORDS"],
    payload: {
        clientOffset: null,
        sourceClientOffset: null
    }
};
function createBeginDrag(manager) {
    return function beginDrag(sourceIds = [], options = {
        publishSource: true
    }) {
        const { publishSource = true, clientOffset, getSourceClientOffset } = options;
        const monitor = manager.getMonitor();
        const registry = manager.getRegistry();
        // Initialize the coordinates using the client offset
        manager.dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$local$2f$setClientOffset$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setClientOffset"])(clientOffset));
        verifyInvariants(sourceIds, monitor, registry);
        // Get the draggable source
        const sourceId = getDraggableSource(sourceIds, monitor);
        if (sourceId == null) {
            manager.dispatch(ResetCoordinatesAction);
            return;
        }
        // Get the source client offset
        let sourceClientOffset = null;
        if (clientOffset) {
            if (!getSourceClientOffset) {
                throw new Error('getSourceClientOffset must be defined');
            }
            verifyGetSourceClientOffsetIsFunction(getSourceClientOffset);
            sourceClientOffset = getSourceClientOffset(sourceId);
        }
        // Initialize the full coordinates
        manager.dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$local$2f$setClientOffset$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setClientOffset"])(clientOffset, sourceClientOffset));
        const source = registry.getSource(sourceId);
        const item = source.beginDrag(monitor, sourceId);
        // If source.beginDrag returns null, this is an indicator to cancel the drag
        if (item == null) {
            return undefined;
        }
        verifyItemIsObject(item);
        registry.pinSource(sourceId);
        const itemType = registry.getSourceType(sourceId);
        return {
            type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BEGIN_DRAG"],
            payload: {
                itemType,
                item,
                sourceId,
                clientOffset: clientOffset || null,
                sourceClientOffset: sourceClientOffset || null,
                isSourcePublic: !!publishSource
            }
        };
    };
}
function verifyInvariants(sourceIds, monitor, registry) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$4$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(!monitor.isDragging(), 'Cannot call beginDrag while dragging.');
    sourceIds.forEach(function(sourceId) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$4$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(registry.getSource(sourceId), 'Expected sourceIds to be registered.');
    });
}
function verifyGetSourceClientOffsetIsFunction(getSourceClientOffset) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$4$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(typeof getSourceClientOffset === 'function', 'When clientOffset is provided, getSourceClientOffset must be a function.');
}
function verifyItemIsObject(item) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$4$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$utils$2f$js_utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isObject"])(item), 'Item must be an object.');
}
function getDraggableSource(sourceIds, monitor) {
    let sourceId = null;
    for(let i = sourceIds.length - 1; i >= 0; i--){
        if (monitor.canDragSource(sourceIds[i])) {
            sourceId = sourceIds[i];
            break;
        }
    }
    return sourceId;
} //# sourceMappingURL=beginDrag.js.map
}),
"[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/actions/dragDrop/drop.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createDrop",
    ()=>createDrop
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$4$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+invariant@4.0.2/node_modules/@react-dnd/invariant/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$utils$2f$js_utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/utils/js_utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/actions/dragDrop/types.js [app-client] (ecmascript)");
function _defineProperty(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _objectSpread(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === 'function') {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _defineProperty(target, key, source[key]);
        });
    }
    return target;
}
;
;
;
function createDrop(manager) {
    return function drop(options = {}) {
        const monitor = manager.getMonitor();
        const registry = manager.getRegistry();
        verifyInvariants(monitor);
        const targetIds = getDroppableTargets(monitor);
        // Multiple actions are dispatched here, which is why this doesn't return an action
        targetIds.forEach((targetId, index)=>{
            const dropResult = determineDropResult(targetId, index, registry, monitor);
            const action = {
                type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DROP"],
                payload: {
                    dropResult: _objectSpread({}, options, dropResult)
                }
            };
            manager.dispatch(action);
        });
    };
}
function verifyInvariants(monitor) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$4$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(monitor.isDragging(), 'Cannot call drop while not dragging.');
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$4$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(!monitor.didDrop(), 'Cannot call drop twice during one drag operation.');
}
function determineDropResult(targetId, index, registry, monitor) {
    const target = registry.getTarget(targetId);
    let dropResult = target ? target.drop(monitor, targetId) : undefined;
    verifyDropResultType(dropResult);
    if (typeof dropResult === 'undefined') {
        dropResult = index === 0 ? {} : monitor.getDropResult();
    }
    return dropResult;
}
function verifyDropResultType(dropResult) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$4$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(typeof dropResult === 'undefined' || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$utils$2f$js_utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isObject"])(dropResult), 'Drop result must either be an object or undefined.');
}
function getDroppableTargets(monitor) {
    const targetIds = monitor.getTargetIds().filter(monitor.canDropOnTarget, monitor);
    targetIds.reverse();
    return targetIds;
} //# sourceMappingURL=drop.js.map
}),
"[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/actions/dragDrop/endDrag.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createEndDrag",
    ()=>createEndDrag
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$4$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+invariant@4.0.2/node_modules/@react-dnd/invariant/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/actions/dragDrop/types.js [app-client] (ecmascript)");
;
;
function createEndDrag(manager) {
    return function endDrag() {
        const monitor = manager.getMonitor();
        const registry = manager.getRegistry();
        verifyIsDragging(monitor);
        const sourceId = monitor.getSourceId();
        if (sourceId != null) {
            const source = registry.getSource(sourceId, true);
            source.endDrag(monitor, sourceId);
            registry.unpinSource();
        }
        return {
            type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["END_DRAG"]
        };
    };
}
function verifyIsDragging(monitor) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$4$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(monitor.isDragging(), 'Cannot call endDrag while not dragging.');
} //# sourceMappingURL=endDrag.js.map
}),
"[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/utils/matchesType.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "matchesType",
    ()=>matchesType
]);
function matchesType(targetType, draggedItemType) {
    if (draggedItemType === null) {
        return targetType === null;
    }
    return Array.isArray(targetType) ? targetType.some((t)=>t === draggedItemType) : targetType === draggedItemType;
} //# sourceMappingURL=matchesType.js.map
}),
"[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/actions/dragDrop/hover.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createHover",
    ()=>createHover
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$4$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+invariant@4.0.2/node_modules/@react-dnd/invariant/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$utils$2f$matchesType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/utils/matchesType.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/actions/dragDrop/types.js [app-client] (ecmascript)");
;
;
;
function createHover(manager) {
    return function hover(targetIdsArg, { clientOffset } = {}) {
        verifyTargetIdsIsArray(targetIdsArg);
        const targetIds = targetIdsArg.slice(0);
        const monitor = manager.getMonitor();
        const registry = manager.getRegistry();
        const draggedItemType = monitor.getItemType();
        removeNonMatchingTargetIds(targetIds, registry, draggedItemType);
        checkInvariants(targetIds, monitor, registry);
        hoverAllTargets(targetIds, monitor, registry);
        return {
            type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HOVER"],
            payload: {
                targetIds,
                clientOffset: clientOffset || null
            }
        };
    };
}
function verifyTargetIdsIsArray(targetIdsArg) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$4$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(Array.isArray(targetIdsArg), 'Expected targetIds to be an array.');
}
function checkInvariants(targetIds, monitor, registry) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$4$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(monitor.isDragging(), 'Cannot call hover while not dragging.');
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$4$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(!monitor.didDrop(), 'Cannot call hover after drop.');
    for(let i = 0; i < targetIds.length; i++){
        const targetId = targetIds[i];
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$4$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(targetIds.lastIndexOf(targetId) === i, 'Expected targetIds to be unique in the passed array.');
        const target = registry.getTarget(targetId);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$4$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(target, 'Expected targetIds to be registered.');
    }
}
function removeNonMatchingTargetIds(targetIds, registry, draggedItemType) {
    // Remove those targetIds that don't match the targetType.  This
    // fixes shallow isOver which would only be non-shallow because of
    // non-matching targets.
    for(let i = targetIds.length - 1; i >= 0; i--){
        const targetId = targetIds[i];
        const targetType = registry.getTargetType(targetId);
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$utils$2f$matchesType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["matchesType"])(targetType, draggedItemType)) {
            targetIds.splice(i, 1);
        }
    }
}
function hoverAllTargets(targetIds, monitor, registry) {
    // Finally call hover on all matching targets.
    targetIds.forEach(function(targetId) {
        const target = registry.getTarget(targetId);
        target.hover(monitor, targetId);
    });
} //# sourceMappingURL=hover.js.map
}),
"[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/actions/dragDrop/publishDragSource.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createPublishDragSource",
    ()=>createPublishDragSource
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/actions/dragDrop/types.js [app-client] (ecmascript)");
;
function createPublishDragSource(manager) {
    return function publishDragSource() {
        const monitor = manager.getMonitor();
        if (monitor.isDragging()) {
            return {
                type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PUBLISH_DRAG_SOURCE"]
            };
        }
        return;
    };
} //# sourceMappingURL=publishDragSource.js.map
}),
"[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/actions/dragDrop/index.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createDragDropActions",
    ()=>createDragDropActions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$beginDrag$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/actions/dragDrop/beginDrag.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$drop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/actions/dragDrop/drop.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$endDrag$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/actions/dragDrop/endDrag.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$hover$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/actions/dragDrop/hover.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$publishDragSource$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/actions/dragDrop/publishDragSource.js [app-client] (ecmascript)");
;
;
;
;
;
;
function createDragDropActions(manager) {
    return {
        beginDrag: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$beginDrag$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createBeginDrag"])(manager),
        publishDragSource: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$publishDragSource$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPublishDragSource"])(manager),
        hover: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$hover$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createHover"])(manager),
        drop: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$drop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createDrop"])(manager),
        endDrag: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$endDrag$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createEndDrag"])(manager)
    };
} //# sourceMappingURL=index.js.map
}),
"[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/classes/DragDropManagerImpl.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DragDropManagerImpl",
    ()=>DragDropManagerImpl
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/actions/dragDrop/index.js [app-client] (ecmascript) <locals>");
;
class DragDropManagerImpl {
    receiveBackend(backend) {
        this.backend = backend;
    }
    getMonitor() {
        return this.monitor;
    }
    getBackend() {
        return this.backend;
    }
    getRegistry() {
        return this.monitor.registry;
    }
    getActions() {
        /* eslint-disable-next-line @typescript-eslint/no-this-alias */ const manager = this;
        const { dispatch } = this.store;
        function bindActionCreator(actionCreator) {
            return (...args)=>{
                const action = actionCreator.apply(manager, args);
                if (typeof action !== 'undefined') {
                    dispatch(action);
                }
            };
        }
        const actions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createDragDropActions"])(this);
        return Object.keys(actions).reduce((boundActions, key)=>{
            const action = actions[key];
            boundActions[key] = bindActionCreator(action);
            return boundActions;
        }, {});
    }
    dispatch(action) {
        this.store.dispatch(action);
    }
    constructor(store, monitor){
        this.isSetUp = false;
        this.handleRefCountChange = ()=>{
            const shouldSetUp = this.store.getState().refCount > 0;
            if (this.backend) {
                if (shouldSetUp && !this.isSetUp) {
                    this.backend.setup();
                    this.isSetUp = true;
                } else if (!shouldSetUp && this.isSetUp) {
                    this.backend.teardown();
                    this.isSetUp = false;
                }
            }
        };
        this.store = store;
        this.monitor = monitor;
        store.subscribe(this.handleRefCountChange);
    }
} //# sourceMappingURL=DragDropManagerImpl.js.map
}),
"[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/utils/coords.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Coordinate addition
 * @param a The first coordinate
 * @param b The second coordinate
 */ __turbopack_context__.s([
    "add",
    ()=>add,
    "getDifferenceFromInitialOffset",
    ()=>getDifferenceFromInitialOffset,
    "getSourceClientOffset",
    ()=>getSourceClientOffset,
    "subtract",
    ()=>subtract
]);
function add(a, b) {
    return {
        x: a.x + b.x,
        y: a.y + b.y
    };
}
function subtract(a, b) {
    return {
        x: a.x - b.x,
        y: a.y - b.y
    };
}
function getSourceClientOffset(state) {
    const { clientOffset, initialClientOffset, initialSourceClientOffset } = state;
    if (!clientOffset || !initialClientOffset || !initialSourceClientOffset) {
        return null;
    }
    return subtract(add(clientOffset, initialSourceClientOffset), initialClientOffset);
}
function getDifferenceFromInitialOffset(state) {
    const { clientOffset, initialClientOffset } = state;
    if (!clientOffset || !initialClientOffset) {
        return null;
    }
    return subtract(clientOffset, initialClientOffset);
} //# sourceMappingURL=coords.js.map
}),
"[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/utils/dirtiness.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ALL",
    ()=>ALL,
    "NONE",
    ()=>NONE,
    "areDirty",
    ()=>areDirty
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$utils$2f$js_utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/utils/js_utils.js [app-client] (ecmascript)");
;
const NONE = [];
const ALL = [];
NONE.__IS_NONE__ = true;
ALL.__IS_ALL__ = true;
function areDirty(dirtyIds, handlerIds) {
    if (dirtyIds === NONE) {
        return false;
    }
    if (dirtyIds === ALL || typeof handlerIds === 'undefined') {
        return true;
    }
    const commonIds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$utils$2f$js_utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["intersection"])(handlerIds, dirtyIds);
    return commonIds.length > 0;
} //# sourceMappingURL=dirtiness.js.map
}),
"[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/classes/DragDropMonitorImpl.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DragDropMonitorImpl",
    ()=>DragDropMonitorImpl
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$4$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+invariant@4.0.2/node_modules/@react-dnd/invariant/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$utils$2f$coords$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/utils/coords.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$utils$2f$dirtiness$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/utils/dirtiness.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$utils$2f$matchesType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/utils/matchesType.js [app-client] (ecmascript)");
;
;
;
;
class DragDropMonitorImpl {
    subscribeToStateChange(listener, options = {}) {
        const { handlerIds } = options;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$4$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(typeof listener === 'function', 'listener must be a function.');
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$4$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(typeof handlerIds === 'undefined' || Array.isArray(handlerIds), 'handlerIds, when specified, must be an array of strings.');
        let prevStateId = this.store.getState().stateId;
        const handleChange = ()=>{
            const state = this.store.getState();
            const currentStateId = state.stateId;
            try {
                const canSkipListener = currentStateId === prevStateId || currentStateId === prevStateId + 1 && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$utils$2f$dirtiness$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["areDirty"])(state.dirtyHandlerIds, handlerIds);
                if (!canSkipListener) {
                    listener();
                }
            } finally{
                prevStateId = currentStateId;
            }
        };
        return this.store.subscribe(handleChange);
    }
    subscribeToOffsetChange(listener) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$4$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(typeof listener === 'function', 'listener must be a function.');
        let previousState = this.store.getState().dragOffset;
        const handleChange = ()=>{
            const nextState = this.store.getState().dragOffset;
            if (nextState === previousState) {
                return;
            }
            previousState = nextState;
            listener();
        };
        return this.store.subscribe(handleChange);
    }
    canDragSource(sourceId) {
        if (!sourceId) {
            return false;
        }
        const source = this.registry.getSource(sourceId);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$4$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(source, `Expected to find a valid source. sourceId=${sourceId}`);
        if (this.isDragging()) {
            return false;
        }
        return source.canDrag(this, sourceId);
    }
    canDropOnTarget(targetId) {
        // undefined on initial render
        if (!targetId) {
            return false;
        }
        const target = this.registry.getTarget(targetId);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$4$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(target, `Expected to find a valid target. targetId=${targetId}`);
        if (!this.isDragging() || this.didDrop()) {
            return false;
        }
        const targetType = this.registry.getTargetType(targetId);
        const draggedItemType = this.getItemType();
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$utils$2f$matchesType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["matchesType"])(targetType, draggedItemType) && target.canDrop(this, targetId);
    }
    isDragging() {
        return Boolean(this.getItemType());
    }
    isDraggingSource(sourceId) {
        // undefined on initial render
        if (!sourceId) {
            return false;
        }
        const source = this.registry.getSource(sourceId, true);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$4$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(source, `Expected to find a valid source. sourceId=${sourceId}`);
        if (!this.isDragging() || !this.isSourcePublic()) {
            return false;
        }
        const sourceType = this.registry.getSourceType(sourceId);
        const draggedItemType = this.getItemType();
        if (sourceType !== draggedItemType) {
            return false;
        }
        return source.isDragging(this, sourceId);
    }
    isOverTarget(targetId, options = {
        shallow: false
    }) {
        // undefined on initial render
        if (!targetId) {
            return false;
        }
        const { shallow } = options;
        if (!this.isDragging()) {
            return false;
        }
        const targetType = this.registry.getTargetType(targetId);
        const draggedItemType = this.getItemType();
        if (draggedItemType && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$utils$2f$matchesType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["matchesType"])(targetType, draggedItemType)) {
            return false;
        }
        const targetIds = this.getTargetIds();
        if (!targetIds.length) {
            return false;
        }
        const index = targetIds.indexOf(targetId);
        if (shallow) {
            return index === targetIds.length - 1;
        } else {
            return index > -1;
        }
    }
    getItemType() {
        return this.store.getState().dragOperation.itemType;
    }
    getItem() {
        return this.store.getState().dragOperation.item;
    }
    getSourceId() {
        return this.store.getState().dragOperation.sourceId;
    }
    getTargetIds() {
        return this.store.getState().dragOperation.targetIds;
    }
    getDropResult() {
        return this.store.getState().dragOperation.dropResult;
    }
    didDrop() {
        return this.store.getState().dragOperation.didDrop;
    }
    isSourcePublic() {
        return Boolean(this.store.getState().dragOperation.isSourcePublic);
    }
    getInitialClientOffset() {
        return this.store.getState().dragOffset.initialClientOffset;
    }
    getInitialSourceClientOffset() {
        return this.store.getState().dragOffset.initialSourceClientOffset;
    }
    getClientOffset() {
        return this.store.getState().dragOffset.clientOffset;
    }
    getSourceClientOffset() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$utils$2f$coords$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSourceClientOffset"])(this.store.getState().dragOffset);
    }
    getDifferenceFromInitialOffset() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$utils$2f$coords$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDifferenceFromInitialOffset"])(this.store.getState().dragOffset);
    }
    constructor(store, registry){
        this.store = store;
        this.registry = registry;
    }
} //# sourceMappingURL=DragDropMonitorImpl.js.map
}),
"[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/actions/registry.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ADD_SOURCE",
    ()=>ADD_SOURCE,
    "ADD_TARGET",
    ()=>ADD_TARGET,
    "REMOVE_SOURCE",
    ()=>REMOVE_SOURCE,
    "REMOVE_TARGET",
    ()=>REMOVE_TARGET,
    "addSource",
    ()=>addSource,
    "addTarget",
    ()=>addTarget,
    "removeSource",
    ()=>removeSource,
    "removeTarget",
    ()=>removeTarget
]);
const ADD_SOURCE = 'dnd-core/ADD_SOURCE';
const ADD_TARGET = 'dnd-core/ADD_TARGET';
const REMOVE_SOURCE = 'dnd-core/REMOVE_SOURCE';
const REMOVE_TARGET = 'dnd-core/REMOVE_TARGET';
function addSource(sourceId) {
    return {
        type: ADD_SOURCE,
        payload: {
            sourceId
        }
    };
}
function addTarget(targetId) {
    return {
        type: ADD_TARGET,
        payload: {
            targetId
        }
    };
}
function removeSource(sourceId) {
    return {
        type: REMOVE_SOURCE,
        payload: {
            sourceId
        }
    };
}
function removeTarget(targetId) {
    return {
        type: REMOVE_TARGET,
        payload: {
            targetId
        }
    };
} //# sourceMappingURL=registry.js.map
}),
"[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/contracts.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "validateSourceContract",
    ()=>validateSourceContract,
    "validateTargetContract",
    ()=>validateTargetContract,
    "validateType",
    ()=>validateType
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$4$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+invariant@4.0.2/node_modules/@react-dnd/invariant/dist/index.js [app-client] (ecmascript)");
;
function validateSourceContract(source) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$4$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(typeof source.canDrag === 'function', 'Expected canDrag to be a function.');
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$4$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(typeof source.beginDrag === 'function', 'Expected beginDrag to be a function.');
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$4$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(typeof source.endDrag === 'function', 'Expected endDrag to be a function.');
}
function validateTargetContract(target) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$4$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(typeof target.canDrop === 'function', 'Expected canDrop to be a function.');
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$4$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(typeof target.hover === 'function', 'Expected hover to be a function.');
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$4$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(typeof target.drop === 'function', 'Expected beginDrag to be a function.');
}
function validateType(type, allowArray) {
    if (allowArray && Array.isArray(type)) {
        type.forEach((t)=>validateType(t, false));
        return;
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$4$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(typeof type === 'string' || typeof type === 'symbol', allowArray ? 'Type can only be a string, a symbol, or an array of either.' : 'Type can only be a string or a symbol.');
} //# sourceMappingURL=contracts.js.map
}),
"[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/interfaces.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HandlerRole",
    ()=>HandlerRole
]);
var HandlerRole;
(function(HandlerRole) {
    HandlerRole["SOURCE"] = "SOURCE";
    HandlerRole["TARGET"] = "TARGET";
})(HandlerRole || (HandlerRole = {})); //# sourceMappingURL=interfaces.js.map
}),
"[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/utils/getNextUniqueId.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getNextUniqueId",
    ()=>getNextUniqueId
]);
let nextUniqueId = 0;
function getNextUniqueId() {
    return nextUniqueId++;
} //# sourceMappingURL=getNextUniqueId.js.map
}),
"[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/classes/HandlerRegistryImpl.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HandlerRegistryImpl",
    ()=>HandlerRegistryImpl
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$asap$40$5$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$asap$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+asap@5.0.2/node_modules/@react-dnd/asap/dist/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$asap$40$5$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$asap$2f$dist$2f$asap$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+asap@5.0.2/node_modules/@react-dnd/asap/dist/asap.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$4$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+invariant@4.0.2/node_modules/@react-dnd/invariant/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/actions/registry.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$contracts$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/contracts.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$interfaces$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/interfaces.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$utils$2f$getNextUniqueId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/utils/getNextUniqueId.js [app-client] (ecmascript)");
;
;
;
;
;
;
function getNextHandlerId(role) {
    const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$utils$2f$getNextUniqueId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNextUniqueId"])().toString();
    switch(role){
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$interfaces$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HandlerRole"].SOURCE:
            return `S${id}`;
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$interfaces$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HandlerRole"].TARGET:
            return `T${id}`;
        default:
            throw new Error(`Unknown Handler Role: ${role}`);
    }
}
function parseRoleFromHandlerId(handlerId) {
    switch(handlerId[0]){
        case 'S':
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$interfaces$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HandlerRole"].SOURCE;
        case 'T':
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$interfaces$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HandlerRole"].TARGET;
        default:
            throw new Error(`Cannot parse handler ID: ${handlerId}`);
    }
}
function mapContainsValue(map, searchValue) {
    const entries = map.entries();
    let isDone = false;
    do {
        const { done, value: [, value] } = entries.next();
        if (value === searchValue) {
            return true;
        }
        isDone = !!done;
    }while (!isDone)
    return false;
}
class HandlerRegistryImpl {
    addSource(type, source) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$contracts$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateType"])(type);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$contracts$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateSourceContract"])(source);
        const sourceId = this.addHandler(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$interfaces$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HandlerRole"].SOURCE, type, source);
        this.store.dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addSource"])(sourceId));
        return sourceId;
    }
    addTarget(type, target) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$contracts$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateType"])(type, true);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$contracts$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateTargetContract"])(target);
        const targetId = this.addHandler(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$interfaces$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HandlerRole"].TARGET, type, target);
        this.store.dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addTarget"])(targetId));
        return targetId;
    }
    containsHandler(handler) {
        return mapContainsValue(this.dragSources, handler) || mapContainsValue(this.dropTargets, handler);
    }
    getSource(sourceId, includePinned = false) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$4$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(this.isSourceId(sourceId), 'Expected a valid source ID.');
        const isPinned = includePinned && sourceId === this.pinnedSourceId;
        const source = isPinned ? this.pinnedSource : this.dragSources.get(sourceId);
        return source;
    }
    getTarget(targetId) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$4$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(this.isTargetId(targetId), 'Expected a valid target ID.');
        return this.dropTargets.get(targetId);
    }
    getSourceType(sourceId) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$4$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(this.isSourceId(sourceId), 'Expected a valid source ID.');
        return this.types.get(sourceId);
    }
    getTargetType(targetId) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$4$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(this.isTargetId(targetId), 'Expected a valid target ID.');
        return this.types.get(targetId);
    }
    isSourceId(handlerId) {
        const role = parseRoleFromHandlerId(handlerId);
        return role === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$interfaces$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HandlerRole"].SOURCE;
    }
    isTargetId(handlerId) {
        const role = parseRoleFromHandlerId(handlerId);
        return role === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$interfaces$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HandlerRole"].TARGET;
    }
    removeSource(sourceId) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$4$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(this.getSource(sourceId), 'Expected an existing source.');
        this.store.dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["removeSource"])(sourceId));
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$asap$40$5$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$asap$2f$dist$2f$asap$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["asap"])(()=>{
            this.dragSources.delete(sourceId);
            this.types.delete(sourceId);
        });
    }
    removeTarget(targetId) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$4$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(this.getTarget(targetId), 'Expected an existing target.');
        this.store.dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["removeTarget"])(targetId));
        this.dropTargets.delete(targetId);
        this.types.delete(targetId);
    }
    pinSource(sourceId) {
        const source = this.getSource(sourceId);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$4$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(source, 'Expected an existing source.');
        this.pinnedSourceId = sourceId;
        this.pinnedSource = source;
    }
    unpinSource() {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$4$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(this.pinnedSource, 'No source is pinned at the time.');
        this.pinnedSourceId = null;
        this.pinnedSource = null;
    }
    addHandler(role, type, handler) {
        const id = getNextHandlerId(role);
        this.types.set(id, type);
        if (role === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$interfaces$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HandlerRole"].SOURCE) {
            this.dragSources.set(id, handler);
        } else if (role === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$interfaces$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HandlerRole"].TARGET) {
            this.dropTargets.set(id, handler);
        }
        return id;
    }
    constructor(store){
        this.types = new Map();
        this.dragSources = new Map();
        this.dropTargets = new Map();
        this.pinnedSourceId = null;
        this.pinnedSource = null;
        this.store = store;
    }
} //# sourceMappingURL=HandlerRegistryImpl.js.map
}),
"[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/utils/equality.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "areArraysEqual",
    ()=>areArraysEqual,
    "areCoordsEqual",
    ()=>areCoordsEqual,
    "strictEquality",
    ()=>strictEquality
]);
const strictEquality = (a, b)=>a === b;
function areCoordsEqual(offsetA, offsetB) {
    if (!offsetA && !offsetB) {
        return true;
    } else if (!offsetA || !offsetB) {
        return false;
    } else {
        return offsetA.x === offsetB.x && offsetA.y === offsetB.y;
    }
}
function areArraysEqual(a, b, isEqual = strictEquality) {
    if (a.length !== b.length) {
        return false;
    }
    for(let i = 0; i < a.length; ++i){
        if (!isEqual(a[i], b[i])) {
            return false;
        }
    }
    return true;
} //# sourceMappingURL=equality.js.map
}),
"[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/reducers/dirtyHandlerIds.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "reduce",
    ()=>reduce
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/actions/dragDrop/types.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/actions/registry.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$utils$2f$dirtiness$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/utils/dirtiness.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$utils$2f$equality$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/utils/equality.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$utils$2f$js_utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/utils/js_utils.js [app-client] (ecmascript)");
;
;
;
;
;
function reduce(_state = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$utils$2f$dirtiness$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NONE"], action) {
    switch(action.type){
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HOVER"]:
            break;
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ADD_SOURCE"]:
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ADD_TARGET"]:
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["REMOVE_TARGET"]:
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["REMOVE_SOURCE"]:
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$utils$2f$dirtiness$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NONE"];
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BEGIN_DRAG"]:
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PUBLISH_DRAG_SOURCE"]:
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["END_DRAG"]:
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DROP"]:
        default:
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$utils$2f$dirtiness$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ALL"];
    }
    const { targetIds = [], prevTargetIds = [] } = action.payload;
    const result = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$utils$2f$js_utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["xor"])(targetIds, prevTargetIds);
    const didChange = result.length > 0 || !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$utils$2f$equality$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["areArraysEqual"])(targetIds, prevTargetIds);
    if (!didChange) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$utils$2f$dirtiness$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NONE"];
    }
    // Check the target ids at the innermost position. If they are valid, add them
    // to the result
    const prevInnermostTargetId = prevTargetIds[prevTargetIds.length - 1];
    const innermostTargetId = targetIds[targetIds.length - 1];
    if (prevInnermostTargetId !== innermostTargetId) {
        if (prevInnermostTargetId) {
            result.push(prevInnermostTargetId);
        }
        if (innermostTargetId) {
            result.push(innermostTargetId);
        }
    }
    return result;
} //# sourceMappingURL=dirtyHandlerIds.js.map
}),
"[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/reducers/dragOffset.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "reduce",
    ()=>reduce
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/actions/dragDrop/types.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$utils$2f$equality$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/utils/equality.js [app-client] (ecmascript)");
function _defineProperty(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _objectSpread(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === 'function') {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _defineProperty(target, key, source[key]);
        });
    }
    return target;
}
;
;
const initialState = {
    initialSourceClientOffset: null,
    initialClientOffset: null,
    clientOffset: null
};
function reduce(state = initialState, action) {
    const { payload } = action;
    switch(action.type){
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["INIT_COORDS"]:
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BEGIN_DRAG"]:
            return {
                initialSourceClientOffset: payload.sourceClientOffset,
                initialClientOffset: payload.clientOffset,
                clientOffset: payload.clientOffset
            };
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HOVER"]:
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$utils$2f$equality$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["areCoordsEqual"])(state.clientOffset, payload.clientOffset)) {
                return state;
            }
            return _objectSpread({}, state, {
                clientOffset: payload.clientOffset
            });
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["END_DRAG"]:
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DROP"]:
            return initialState;
        default:
            return state;
    }
} //# sourceMappingURL=dragOffset.js.map
}),
"[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/reducers/dragOperation.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "reduce",
    ()=>reduce
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/actions/dragDrop/types.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/actions/registry.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$utils$2f$js_utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/utils/js_utils.js [app-client] (ecmascript)");
function _defineProperty(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _objectSpread(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === 'function') {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _defineProperty(target, key, source[key]);
        });
    }
    return target;
}
;
;
;
const initialState = {
    itemType: null,
    item: null,
    sourceId: null,
    targetIds: [],
    dropResult: null,
    didDrop: false,
    isSourcePublic: null
};
function reduce(state = initialState, action) {
    const { payload } = action;
    switch(action.type){
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BEGIN_DRAG"]:
            return _objectSpread({}, state, {
                itemType: payload.itemType,
                item: payload.item,
                sourceId: payload.sourceId,
                isSourcePublic: payload.isSourcePublic,
                dropResult: null,
                didDrop: false
            });
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PUBLISH_DRAG_SOURCE"]:
            return _objectSpread({}, state, {
                isSourcePublic: true
            });
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HOVER"]:
            return _objectSpread({}, state, {
                targetIds: payload.targetIds
            });
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["REMOVE_TARGET"]:
            if (state.targetIds.indexOf(payload.targetId) === -1) {
                return state;
            }
            return _objectSpread({}, state, {
                targetIds: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$utils$2f$js_utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["without"])(state.targetIds, payload.targetId)
            });
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DROP"]:
            return _objectSpread({}, state, {
                dropResult: payload.dropResult,
                didDrop: true,
                targetIds: []
            });
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["END_DRAG"]:
            return _objectSpread({}, state, {
                itemType: null,
                item: null,
                sourceId: null,
                dropResult: null,
                didDrop: false,
                isSourcePublic: null,
                targetIds: []
            });
        default:
            return state;
    }
} //# sourceMappingURL=dragOperation.js.map
}),
"[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/reducers/refCount.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "reduce",
    ()=>reduce
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/actions/registry.js [app-client] (ecmascript)");
;
function reduce(state = 0, action) {
    switch(action.type){
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ADD_SOURCE"]:
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ADD_TARGET"]:
            return state + 1;
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["REMOVE_SOURCE"]:
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$actions$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["REMOVE_TARGET"]:
            return state - 1;
        default:
            return state;
    }
} //# sourceMappingURL=refCount.js.map
}),
"[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/reducers/stateId.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "reduce",
    ()=>reduce
]);
function reduce(state = 0) {
    return state + 1;
} //# sourceMappingURL=stateId.js.map
}),
"[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/reducers/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "reduce",
    ()=>reduce
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$utils$2f$js_utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/utils/js_utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$reducers$2f$dirtyHandlerIds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/reducers/dirtyHandlerIds.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$reducers$2f$dragOffset$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/reducers/dragOffset.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$reducers$2f$dragOperation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/reducers/dragOperation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$reducers$2f$refCount$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/reducers/refCount.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$reducers$2f$stateId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/reducers/stateId.js [app-client] (ecmascript)");
function _defineProperty(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _objectSpread(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === 'function') {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _defineProperty(target, key, source[key]);
        });
    }
    return target;
}
;
;
;
;
;
;
function reduce(state = {}, action) {
    return {
        dirtyHandlerIds: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$reducers$2f$dirtyHandlerIds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reduce"])(state.dirtyHandlerIds, {
            type: action.type,
            payload: _objectSpread({}, action.payload, {
                prevTargetIds: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$utils$2f$js_utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["get"])(state, 'dragOperation.targetIds', [])
            })
        }),
        dragOffset: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$reducers$2f$dragOffset$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reduce"])(state.dragOffset, action),
        refCount: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$reducers$2f$refCount$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reduce"])(state.refCount, action),
        dragOperation: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$reducers$2f$dragOperation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reduce"])(state.dragOperation, action),
        stateId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$reducers$2f$stateId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reduce"])(state.stateId)
    };
} //# sourceMappingURL=index.js.map
}),
"[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/createDragDropManager.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createDragDropManager",
    ()=>createDragDropManager
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$redux$40$4$2e$2$2e$1$2f$node_modules$2f$redux$2f$es$2f$redux$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/redux@4.2.1/node_modules/redux/es/redux.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$classes$2f$DragDropManagerImpl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/classes/DragDropManagerImpl.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$classes$2f$DragDropMonitorImpl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/classes/DragDropMonitorImpl.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$classes$2f$HandlerRegistryImpl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/classes/HandlerRegistryImpl.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$reducers$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@16.0.1/node_modules/dnd-core/dist/reducers/index.js [app-client] (ecmascript)");
;
;
;
;
;
function createDragDropManager(backendFactory, globalContext = undefined, backendOptions = {}, debugMode = false) {
    const store = makeStoreInstance(debugMode);
    const monitor = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$classes$2f$DragDropMonitorImpl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DragDropMonitorImpl"](store, new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$classes$2f$HandlerRegistryImpl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HandlerRegistryImpl"](store));
    const manager = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$classes$2f$DragDropManagerImpl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DragDropManagerImpl"](store, monitor);
    const backend = backendFactory(manager, globalContext, backendOptions);
    manager.receiveBackend(backend);
    return manager;
}
function makeStoreInstance(debugMode) {
    // TODO: if we ever make a react-native version of this,
    // we'll need to consider how to pull off dev-tooling
    const reduxDevTools = typeof window !== 'undefined' && window.__REDUX_DEVTOOLS_EXTENSION__;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$redux$40$4$2e$2$2e$1$2f$node_modules$2f$redux$2f$es$2f$redux$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createStore"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$reducers$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reduce"], debugMode && reduxDevTools && reduxDevTools({
        name: 'dnd-core',
        instanceId: 'dnd-core'
    }));
} //# sourceMappingURL=createDragDropManager.js.map
}),
"[project]/node_modules/.pnpm/@react-dnd+asap@5.0.2/node_modules/@react-dnd/asap/dist/makeRequestCall.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "makeRequestCall",
    ()=>makeRequestCall,
    "makeRequestCallFromMutationObserver",
    ()=>makeRequestCallFromMutationObserver,
    "makeRequestCallFromTimer",
    ()=>makeRequestCallFromTimer
]);
// Safari 6 and 6.1 for desktop, iPad, and iPhone are the only browsers that
// have WebKitMutationObserver but not un-prefixed MutationObserver.
// Must use `global` or `self` instead of `window` to work in both frames and web
// workers. `global` is a provision of Browserify, Mr, Mrs, or Mop.
/* globals self */ const scope = ("TURBOPACK compile-time truthy", 1) ? /*TURBOPACK member replacement*/ __turbopack_context__.g : "TURBOPACK unreachable";
const BrowserMutationObserver = scope.MutationObserver || scope.WebKitMutationObserver;
function makeRequestCallFromTimer(callback) {
    return function requestCall() {
        // We dispatch a timeout with a specified delay of 0 for engines that
        // can reliably accommodate that request. This will usually be snapped
        // to a 4 milisecond delay, but once we're flushing, there's no delay
        // between events.
        const timeoutHandle = setTimeout(handleTimer, 0);
        // However, since this timer gets frequently dropped in Firefox
        // workers, we enlist an interval handle that will try to fire
        // an event 20 times per second until it succeeds.
        const intervalHandle = setInterval(handleTimer, 50);
        function handleTimer() {
            // Whichever timer succeeds will cancel both timers and
            // execute the callback.
            clearTimeout(timeoutHandle);
            clearInterval(intervalHandle);
            callback();
        }
    };
}
function makeRequestCallFromMutationObserver(callback) {
    let toggle = 1;
    const observer = new BrowserMutationObserver(callback);
    const node = document.createTextNode('');
    observer.observe(node, {
        characterData: true
    });
    return function requestCall() {
        toggle = -toggle;
        node.data = toggle;
    };
}
const makeRequestCall = typeof BrowserMutationObserver === 'function' ? // They are implemented in all modern browsers.
//
// - Android 4-4.3
// - Chrome 26-34
// - Firefox 14-29
// - Internet Explorer 11
// - iPad Safari 6-7.1
// - iPhone Safari 7-7.1
// - Safari 6-7
makeRequestCallFromMutationObserver : // 11-12, and in web workers in many engines.
// Although message channels yield to any queued rendering and IO tasks, they
// would be better than imposing the 4ms delay of timers.
// However, they do not work reliably in Internet Explorer or Safari.
// Internet Explorer 10 is the only browser that has setImmediate but does
// not have MutationObservers.
// Although setImmediate yields to the browser's renderer, it would be
// preferrable to falling back to setTimeout since it does not have
// the minimum 4ms penalty.
// Unfortunately there appears to be a bug in Internet Explorer 10 Mobile (and
// Desktop to a lesser extent) that renders both setImmediate and
// MessageChannel useless for the purposes of ASAP.
// https://github.com/kriskowal/q/issues/396
// Timers are implemented universally.
// We fall back to timers in workers in most engines, and in foreground
// contexts in the following browsers.
// However, note that even this simple case requires nuances to operate in a
// broad spectrum of browsers.
//
// - Firefox 3-13
// - Internet Explorer 6-9
// - iPad Safari 4.3
// - Lynx 2.8.7
makeRequestCallFromTimer; //# sourceMappingURL=makeRequestCall.js.map
}),
"[project]/node_modules/.pnpm/@react-dnd+asap@5.0.2/node_modules/@react-dnd/asap/dist/AsapQueue.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AsapQueue",
    ()=>AsapQueue
]);
/* eslint-disable no-restricted-globals, @typescript-eslint/ban-ts-comment, @typescript-eslint/no-unused-vars, @typescript-eslint/no-non-null-assertion */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$asap$40$5$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$asap$2f$dist$2f$makeRequestCall$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+asap@5.0.2/node_modules/@react-dnd/asap/dist/makeRequestCall.js [app-client] (ecmascript)");
;
class AsapQueue {
    // Use the fastest means possible to execute a task in its own turn, with
    // priority over other events including IO, animation, reflow, and redraw
    // events in browsers.
    //
    // An exception thrown by a task will permanently interrupt the processing of
    // subsequent tasks. The higher level `asap` function ensures that if an
    // exception is thrown by a task, that the task queue will continue flushing as
    // soon as possible, but if you use `rawAsap` directly, you are responsible to
    // either ensure that no exceptions are thrown from your task, or to manually
    // call `rawAsap.requestFlush` if an exception is thrown.
    enqueueTask(task) {
        const { queue: q, requestFlush } = this;
        if (!q.length) {
            requestFlush();
            this.flushing = true;
        }
        // Equivalent to push, but avoids a function call.
        q[q.length] = task;
    }
    constructor(){
        this.queue = [];
        // We queue errors to ensure they are thrown in right order (FIFO).
        // Array-as-queue is good enough here, since we are just dealing with exceptions.
        this.pendingErrors = [];
        // Once a flush has been requested, no further calls to `requestFlush` are
        // necessary until the next `flush` completes.
        // @ts-ignore
        this.flushing = false;
        // The position of the next task to execute in the task queue. This is
        // preserved between calls to `flush` so that it can be resumed if
        // a task throws an exception.
        this.index = 0;
        // If a task schedules additional tasks recursively, the task queue can grow
        // unbounded. To prevent memory exhaustion, the task queue will periodically
        // truncate already-completed tasks.
        this.capacity = 1024;
        // The flush function processes all tasks that have been scheduled with
        // `rawAsap` unless and until one of those tasks throws an exception.
        // If a task throws an exception, `flush` ensures that its state will remain
        // consistent and will resume where it left off when called again.
        // However, `flush` does not make any arrangements to be called again if an
        // exception is thrown.
        this.flush = ()=>{
            const { queue: q } = this;
            while(this.index < q.length){
                const currentIndex = this.index;
                // Advance the index before calling the task. This ensures that we will
                // begin flushing on the next task the task throws an error.
                this.index++;
                q[currentIndex].call();
                // Prevent leaking memory for long chains of recursive calls to `asap`.
                // If we call `asap` within tasks scheduled by `asap`, the queue will
                // grow, but to avoid an O(n) walk for every task we execute, we don't
                // shift tasks off the queue after they have been executed.
                // Instead, we periodically shift 1024 tasks off the queue.
                if (this.index > this.capacity) {
                    // Manually shift all values starting at the index back to the
                    // beginning of the queue.
                    for(let scan = 0, newLength = q.length - this.index; scan < newLength; scan++){
                        q[scan] = q[scan + this.index];
                    }
                    q.length -= this.index;
                    this.index = 0;
                }
            }
            q.length = 0;
            this.index = 0;
            this.flushing = false;
        };
        // In a web browser, exceptions are not fatal. However, to avoid
        // slowing down the queue of pending tasks, we rethrow the error in a
        // lower priority turn.
        this.registerPendingError = (err)=>{
            this.pendingErrors.push(err);
            this.requestErrorThrow();
        };
        // `requestFlush` requests that the high priority event queue be flushed as
        // soon as possible.
        // This is useful to prevent an error thrown in a task from stalling the event
        // queue if the exception handled by Node.js’s
        // `process.on("uncaughtException")` or by a domain.
        // `requestFlush` is implemented using a strategy based on data collected from
        // every available SauceLabs Selenium web driver worker at time of writing.
        // https://docs.google.com/spreadsheets/d/1mG-5UYGup5qxGdEMWkhP6BWCz053NUb2E1QoUTU16uA/edit#gid=783724593
        this.requestFlush = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$asap$40$5$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$asap$2f$dist$2f$makeRequestCall$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["makeRequestCall"])(this.flush);
        this.requestErrorThrow = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$asap$40$5$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$asap$2f$dist$2f$makeRequestCall$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["makeRequestCallFromTimer"])(()=>{
            // Throw first error
            if (this.pendingErrors.length) {
                throw this.pendingErrors.shift();
            }
        });
    }
} // The message channel technique was discovered by Malte Ubl and was the
 // original foundation for this library.
 // http://www.nonblocking.io/2011/06/windownexttick.html
 // Safari 6.0.5 (at least) intermittently fails to create message ports on a
 // page's first load. Thankfully, this version of Safari supports
 // MutationObservers, so we don't need to fall back in that case.
 // function makeRequestCallFromMessageChannel(callback) {
 //     var channel = new MessageChannel();
 //     channel.port1.onmessage = callback;
 //     return function requestCall() {
 //         channel.port2.postMessage(0);
 //     };
 // }
 // For reasons explained above, we are also unable to use `setImmediate`
 // under any circumstances.
 // Even if we were, there is another bug in Internet Explorer 10.
 // It is not sufficient to assign `setImmediate` to `requestFlush` because
 // `setImmediate` must be called *by name* and therefore must be wrapped in a
 // closure.
 // Never forget.
 // function makeRequestCallFromSetImmediate(callback) {
 //     return function requestCall() {
 //         setImmediate(callback);
 //     };
 // }
 // Safari 6.0 has a problem where timers will get lost while the user is
 // scrolling. This problem does not impact ASAP because Safari 6.0 supports
 // mutation observers, so that implementation is used instead.
 // However, if we ever elect to use timers in Safari, the prevalent work-around
 // is to add a scroll event listener that calls for a flush.
 // `setTimeout` does not call the passed callback if the delay is less than
 // approximately 7 in web workers in Firefox 8 through 18, and sometimes not
 // even then.
 // This is for `asap.js` only.
 // Its name will be periodically randomized to break any code that depends on
 // // its existence.
 // rawAsap.makeRequestCallFromTimer = makeRequestCallFromTimer
 // ASAP was originally a nextTick shim included in Q. This was factored out
 // into this ASAP package. It was later adapted to RSVP which made further
 // amendments. These decisions, particularly to marginalize MessageChannel and
 // to capture the MutationObserver implementation in a closure, were integrated
 // back into ASAP proper.
 // https://github.com/tildeio/rsvp.js/blob/cddf7232546a9cf858524b75cde6f9edf72620a7/lib/rsvp/asap.js
 //# sourceMappingURL=AsapQueue.js.map
}),
"[project]/node_modules/.pnpm/@react-dnd+asap@5.0.2/node_modules/@react-dnd/asap/dist/RawTask.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// `call`, just like a function.
__turbopack_context__.s([
    "RawTask",
    ()=>RawTask
]);
class RawTask {
    call() {
        try {
            this.task && this.task();
        } catch (error) {
            this.onError(error);
        } finally{
            this.task = null;
            this.release(this);
        }
    }
    constructor(onError, release){
        this.onError = onError;
        this.release = release;
        this.task = null;
    }
} //# sourceMappingURL=RawTask.js.map
}),
"[project]/node_modules/.pnpm/@react-dnd+asap@5.0.2/node_modules/@react-dnd/asap/dist/TaskFactory.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TaskFactory",
    ()=>TaskFactory
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$asap$40$5$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$asap$2f$dist$2f$RawTask$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+asap@5.0.2/node_modules/@react-dnd/asap/dist/RawTask.js [app-client] (ecmascript)");
;
class TaskFactory {
    create(task) {
        const tasks = this.freeTasks;
        const t1 = tasks.length ? tasks.pop() : new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$asap$40$5$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$asap$2f$dist$2f$RawTask$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RawTask"](this.onError, (t)=>tasks[tasks.length] = t);
        t1.task = task;
        return t1;
    }
    constructor(onError){
        this.onError = onError;
        this.freeTasks = [];
    }
} //# sourceMappingURL=TaskFactory.js.map
}),
"[project]/node_modules/.pnpm/@react-dnd+asap@5.0.2/node_modules/@react-dnd/asap/dist/asap.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "asap",
    ()=>asap
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$asap$40$5$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$asap$2f$dist$2f$AsapQueue$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+asap@5.0.2/node_modules/@react-dnd/asap/dist/AsapQueue.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$asap$40$5$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$asap$2f$dist$2f$TaskFactory$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+asap@5.0.2/node_modules/@react-dnd/asap/dist/TaskFactory.js [app-client] (ecmascript)");
;
;
const asapQueue = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$asap$40$5$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$asap$2f$dist$2f$AsapQueue$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AsapQueue"]();
const taskFactory = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$asap$40$5$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$asap$2f$dist$2f$TaskFactory$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TaskFactory"](asapQueue.registerPendingError);
function asap(task) {
    asapQueue.enqueueTask(taskFactory.create(task));
} //# sourceMappingURL=asap.js.map
}),
"[project]/node_modules/.pnpm/@react-dnd+asap@5.0.2/node_modules/@react-dnd/asap/dist/types.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
 //# sourceMappingURL=types.js.map
}),
"[project]/node_modules/.pnpm/@react-dnd+asap@5.0.2/node_modules/@react-dnd/asap/dist/index.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$asap$40$5$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$asap$2f$dist$2f$asap$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+asap@5.0.2/node_modules/@react-dnd/asap/dist/asap.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$asap$40$5$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$asap$2f$dist$2f$AsapQueue$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+asap@5.0.2/node_modules/@react-dnd/asap/dist/AsapQueue.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$asap$40$5$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$asap$2f$dist$2f$TaskFactory$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+asap@5.0.2/node_modules/@react-dnd/asap/dist/TaskFactory.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$asap$40$5$2e$0$2e$2$2f$node_modules$2f40$react$2d$dnd$2f$asap$2f$dist$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+asap@5.0.2/node_modules/@react-dnd/asap/dist/types.js [app-client] (ecmascript)"); //# sourceMappingURL=index.js.map
;
;
;
;
}),
"[project]/node_modules/.pnpm/fast-deep-equal@3.1.3/node_modules/fast-deep-equal/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// do not edit .js files directly - edit src/index.jst
module.exports = function equal(a, b) {
    if (a === b) return true;
    if (a && b && typeof a == 'object' && typeof b == 'object') {
        if (a.constructor !== b.constructor) return false;
        var length, i, keys;
        if (Array.isArray(a)) {
            length = a.length;
            if (length != b.length) return false;
            for(i = length; i-- !== 0;)if (!equal(a[i], b[i])) return false;
            return true;
        }
        if (a.constructor === RegExp) return a.source === b.source && a.flags === b.flags;
        if (a.valueOf !== Object.prototype.valueOf) return a.valueOf() === b.valueOf();
        if (a.toString !== Object.prototype.toString) return a.toString() === b.toString();
        keys = Object.keys(a);
        length = keys.length;
        if (length !== Object.keys(b).length) return false;
        for(i = length; i-- !== 0;)if (!Object.prototype.hasOwnProperty.call(b, keys[i])) return false;
        for(i = length; i-- !== 0;){
            var key = keys[i];
            if (!equal(a[key], b[key])) return false;
        }
        return true;
    }
    // true if both NaN, false otherwise
    return a !== a && b !== b;
};
}),
"[project]/node_modules/.pnpm/@react-dnd+shallowequal@4.0.2/node_modules/@react-dnd/shallowequal/dist/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "shallowEqual",
    ()=>shallowEqual
]);
function shallowEqual(objA, objB, compare, compareContext) {
    let compareResult = compare ? compare.call(compareContext, objA, objB) : void 0;
    if (compareResult !== void 0) {
        return !!compareResult;
    }
    if (objA === objB) {
        return true;
    }
    if (typeof objA !== 'object' || !objA || typeof objB !== 'object' || !objB) {
        return false;
    }
    const keysA = Object.keys(objA);
    const keysB = Object.keys(objB);
    if (keysA.length !== keysB.length) {
        return false;
    }
    const bHasOwnProperty = Object.prototype.hasOwnProperty.bind(objB);
    // Test for A's keys different from B.
    for(let idx = 0; idx < keysA.length; idx++){
        const key = keysA[idx];
        if (!bHasOwnProperty(key)) {
            return false;
        }
        const valueA = objA[key];
        const valueB = objB[key];
        compareResult = compare ? compare.call(compareContext, valueA, valueB, key) : void 0;
        if (compareResult === false || compareResult === void 0 && valueA !== valueB) {
            return false;
        }
    }
    return true;
} //# sourceMappingURL=index.js.map
}),
"[project]/node_modules/.pnpm/react-dnd-preview@8.1.2_react-dnd@16.0.1_@types+node@24.10.9_@types+react@19.2.9_react@19.2.1__react@19.2.1/node_modules/react-dnd-preview/dist/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Context",
    ()=>i,
    "Preview",
    ()=>v,
    "usePreview",
    ()=>a
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$16$2e$0$2e$1_$40$types$2b$node$40$24$2e$10$2e$9_$40$types$2b$react$40$19$2e$2$2e$9_react$40$19$2e$2$2e$1$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$hooks$2f$useDragLayer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@16.0.1_@types+node@24.10.9_@types+react@19.2.9_react@19.2.1/node_modules/react-dnd/dist/hooks/useDragLayer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
;
var i = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(void 0);
;
;
var l = (e, t)=>({
        x: e.x - t.x,
        y: e.y - t.y
    }), m = (e, t)=>({
        x: e.x + t.x,
        y: e.y + t.y
    }), P = (e)=>{
    let t = e.getInitialClientOffset(), n = e.getInitialSourceClientOffset();
    return t === null || n === null ? {
        x: 0,
        y: 0
    } : l(t, n);
}, f = (e, t)=>{
    switch(e){
        case "left":
        case "top-start":
        case "bottom-start":
            return 0;
        case "right":
        case "top-end":
        case "bottom-end":
            return t.width;
        default:
            return t.width / 2;
    }
}, d = (e, t)=>{
    switch(e){
        case "top":
        case "top-start":
        case "top-end":
            return 0;
        case "bottom":
        case "bottom-start":
        case "bottom-end":
            return t.height;
        default:
            return t.height / 2;
    }
}, c = (e, t, n = "center", r = {
    x: 0,
    y: 0
})=>{
    let o = e.getClientOffset();
    if (o === null) return null;
    if (!t.current || !t.current.getBoundingClientRect) return l(o, P(e));
    let s = t.current.getBoundingClientRect(), p = {
        x: f(n, s),
        y: d(n, s)
    };
    return m(l(o, p), r);
};
var x = (e)=>{
    let t = `translate(${e.x.toFixed(1)}px, ${e.y.toFixed(1)}px)`;
    return {
        pointerEvents: "none",
        position: "fixed",
        top: 0,
        left: 0,
        transform: t,
        WebkitTransform: t
    };
}, a = (e)=>{
    let t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$16$2e$0$2e$1_$40$types$2b$node$40$24$2e$10$2e$9_$40$types$2b$react$40$19$2e$2$2e$9_react$40$19$2e$2$2e$1$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$hooks$2f$useDragLayer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDragLayer"])((r)=>({
            currentOffset: c(r, t, e?.placement, e?.padding),
            isDragging: r.isDragging(),
            itemType: r.getItemType(),
            item: r.getItem(),
            monitor: r
        }));
    return !n.isDragging || n.currentOffset === null ? {
        display: !1
    } : {
        display: !0,
        itemType: n.itemType,
        item: n.item,
        style: x(n.currentOffset),
        monitor: n.monitor,
        ref: t
    };
};
;
var v = (e)=>{
    let t = a({
        placement: e.placement,
        padding: e.padding
    });
    if (!t.display) return null;
    let { display: n, ...r } = t, o;
    return "children" in e ? typeof e.children == "function" ? o = e.children(r) : o = e.children : o = e.generator(r), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(i.Provider, {
        value: r,
        children: o
    });
};
;
}),
"[project]/node_modules/.pnpm/react-dnd-multi-backend@8.1.2_dnd-core@16.0.1_react-dnd@16.0.1_@types+node@24.10.9_@types+rea_pdtzydzhwhxaghcnub657f7in4/node_modules/react-dnd-multi-backend/dist/index.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DndProvider",
    ()=>g,
    "Preview",
    ()=>b,
    "useMultiDrag",
    ()=>ee,
    "useMultiDrop",
    ()=>ne,
    "usePreview",
    ()=>ie
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$multi$2d$backend$40$8$2e$1$2e$2_dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$multi$2d$backend$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-multi-backend@8.1.2_dnd-core@16.0.1/node_modules/dnd-multi-backend/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$16$2e$0$2e$1_$40$types$2b$node$40$24$2e$10$2e$9_$40$types$2b$react$40$19$2e$2$2e$9_react$40$19$2e$2$2e$1$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$core$2f$DndProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@16.0.1_@types+node@24.10.9_@types+react@19.2.9_react@19.2.1/node_modules/react-dnd/dist/core/DndProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$preview$40$8$2e$1$2e$2_react$2d$dnd$40$16$2e$0$2e$1_$40$types$2b$node$40$24$2e$10$2e$9_$40$types$2b$react$40$19$2e$2$2e$9_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f$react$2d$dnd$2d$preview$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd-preview@8.1.2_react-dnd@16.0.1_@types+node@24.10.9_@types+react@19.2.9_react@19.2.1__react@19.2.1/node_modules/react-dnd-preview/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react-dom/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$16$2e$0$2e$1_$40$types$2b$node$40$24$2e$10$2e$9_$40$types$2b$react$40$19$2e$2$2e$9_react$40$19$2e$2$2e$1$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$core$2f$DndContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@16.0.1_@types+node@24.10.9_@types+react@19.2.9_react@19.2.1/node_modules/react-dnd/dist/core/DndContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$16$2e$0$2e$1_$40$types$2b$node$40$24$2e$10$2e$9_$40$types$2b$react$40$19$2e$2$2e$9_react$40$19$2e$2$2e$1$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$hooks$2f$useDrag$2f$useDrag$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@16.0.1_@types+node@24.10.9_@types+react@19.2.9_react@19.2.1/node_modules/react-dnd/dist/hooks/useDrag/useDrag.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$16$2e$0$2e$1_$40$types$2b$node$40$24$2e$10$2e$9_$40$types$2b$react$40$19$2e$2$2e$9_react$40$19$2e$2$2e$1$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$hooks$2f$useDrop$2f$useDrop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@16.0.1_@types+node@24.10.9_@types+react@19.2.9_react@19.2.1/node_modules/react-dnd/dist/hooks/useDrop/useDrop.js [app-client] (ecmascript)");
;
;
;
;
;
var i = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(null), g = ({ portal: e, ...t })=>{
    let [r, o] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(i.Provider, {
        value: e ?? r,
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$16$2e$0$2e$1_$40$types$2b$node$40$24$2e$10$2e$9_$40$types$2b$react$40$19$2e$2$2e$9_react$40$19$2e$2$2e$1$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$core$2f$DndProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DndProvider"], {
                backend: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$multi$2d$backend$40$8$2e$1$2e$2_dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$multi$2d$backend$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MultiBackend"],
                ...t
            }),
            e ? null : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
                ref: o
            })
        ]
    });
};
;
;
;
;
;
var s = ()=>{
    let [e, t] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(!1), r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$16$2e$0$2e$1_$40$types$2b$node$40$24$2e$10$2e$9_$40$types$2b$react$40$19$2e$2$2e$9_react$40$19$2e$2$2e$1$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$core$2f$DndContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DndContext"]);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        let o = r?.dragDropManager?.getBackend(), n = {
            backendChanged: (p)=>{
                t(p.previewEnabled());
            }
        };
        return t(o.previewEnabled()), o.previewsList().register(n), ()=>{
            o.previewsList().unregister(n);
        };
    }, [
        r,
        r.dragDropManager
    ]), e;
};
;
var b = (e)=>{
    let t = s(), r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(i);
    if (!t) return null;
    let o = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$preview$40$8$2e$1$2e$2_react$2d$dnd$40$16$2e$0$2e$1_$40$types$2b$node$40$24$2e$10$2e$9_$40$types$2b$react$40$19$2e$2$2e$9_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f$react$2d$dnd$2d$preview$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Preview"], {
        ...e
    });
    return r !== null ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPortal"])(o, r) : o;
};
b.Context = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$preview$40$8$2e$1$2e$2_react$2d$dnd$40$16$2e$0$2e$1_$40$types$2b$node$40$24$2e$10$2e$9_$40$types$2b$react$40$19$2e$2$2e$9_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f$react$2d$dnd$2d$preview$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Context"];
;
;
;
var O = (e, t, r, o)=>{
    let n = r.getBackend();
    r.receiveBackend(o);
    let p = t(e);
    return r.receiveBackend(n), p;
}, a = (e, t)=>{
    let r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$16$2e$0$2e$1_$40$types$2b$node$40$24$2e$10$2e$9_$40$types$2b$react$40$19$2e$2$2e$9_react$40$19$2e$2$2e$1$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$core$2f$DndContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DndContext"]), o = r?.dragDropManager?.getBackend();
    if (o === void 0) throw new Error("could not find backend, make sure you are using a <DndProvider />");
    let n = t(e), p = {}, d = o.backendsList();
    for (let u of d)p[u.id] = O(e, t, r.dragDropManager, u.instance);
    return [
        n,
        p
    ];
};
var ee = (e)=>a(e, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$16$2e$0$2e$1_$40$types$2b$node$40$24$2e$10$2e$9_$40$types$2b$react$40$19$2e$2$2e$9_react$40$19$2e$2$2e$1$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$hooks$2f$useDrag$2f$useDrag$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDrag"]);
;
var ne = (e)=>a(e, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$16$2e$0$2e$1_$40$types$2b$node$40$24$2e$10$2e$9_$40$types$2b$react$40$19$2e$2$2e$9_react$40$19$2e$2$2e$1$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$hooks$2f$useDrop$2f$useDrop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDrop"]);
;
var ie = (e)=>{
    let t = s(), r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$preview$40$8$2e$1$2e$2_react$2d$dnd$40$16$2e$0$2e$1_$40$types$2b$node$40$24$2e$10$2e$9_$40$types$2b$react$40$19$2e$2$2e$9_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f$react$2d$dnd$2d$preview$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePreview"])(e);
    return t ? r : {
        display: !1
    };
};
;
}),
"[project]/node_modules/.pnpm/react-dnd-multi-backend@8.1.2_dnd-core@16.0.1_react-dnd@16.0.1_@types+node@24.10.9_@types+rea_pdtzydzhwhxaghcnub657f7in4/node_modules/react-dnd-multi-backend/dist/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DndProvider",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$multi$2d$backend$40$8$2e$1$2e$2_dnd$2d$core$40$16$2e$0$2e$1_react$2d$dnd$40$16$2e$0$2e$1_$40$types$2b$node$40$24$2e$10$2e$9_$40$types$2b$rea_pdtzydzhwhxaghcnub657f7in4$2f$node_modules$2f$react$2d$dnd$2d$multi$2d$backend$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["DndProvider"],
    "HTML5DragTransition",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$multi$2d$backend$40$8$2e$1$2e$2_dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$multi$2d$backend$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HTML5DragTransition"],
    "MouseTransition",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$multi$2d$backend$40$8$2e$1$2e$2_dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$multi$2d$backend$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MouseTransition"],
    "MultiBackend",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$multi$2d$backend$40$8$2e$1$2e$2_dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$multi$2d$backend$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MultiBackend"],
    "PointerTransition",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$multi$2d$backend$40$8$2e$1$2e$2_dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$multi$2d$backend$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PointerTransition"],
    "Preview",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$multi$2d$backend$40$8$2e$1$2e$2_dnd$2d$core$40$16$2e$0$2e$1_react$2d$dnd$40$16$2e$0$2e$1_$40$types$2b$node$40$24$2e$10$2e$9_$40$types$2b$rea_pdtzydzhwhxaghcnub657f7in4$2f$node_modules$2f$react$2d$dnd$2d$multi$2d$backend$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Preview"],
    "PreviewContext",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$preview$40$8$2e$1$2e$2_react$2d$dnd$40$16$2e$0$2e$1_$40$types$2b$node$40$24$2e$10$2e$9_$40$types$2b$react$40$19$2e$2$2e$9_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f$react$2d$dnd$2d$preview$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Context"],
    "TouchTransition",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$multi$2d$backend$40$8$2e$1$2e$2_dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$multi$2d$backend$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TouchTransition"],
    "createTransition",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$multi$2d$backend$40$8$2e$1$2e$2_dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$multi$2d$backend$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createTransition"],
    "useMultiDrag",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$multi$2d$backend$40$8$2e$1$2e$2_dnd$2d$core$40$16$2e$0$2e$1_react$2d$dnd$40$16$2e$0$2e$1_$40$types$2b$node$40$24$2e$10$2e$9_$40$types$2b$rea_pdtzydzhwhxaghcnub657f7in4$2f$node_modules$2f$react$2d$dnd$2d$multi$2d$backend$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useMultiDrag"],
    "useMultiDrop",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$multi$2d$backend$40$8$2e$1$2e$2_dnd$2d$core$40$16$2e$0$2e$1_react$2d$dnd$40$16$2e$0$2e$1_$40$types$2b$node$40$24$2e$10$2e$9_$40$types$2b$rea_pdtzydzhwhxaghcnub657f7in4$2f$node_modules$2f$react$2d$dnd$2d$multi$2d$backend$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useMultiDrop"],
    "usePreview",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$multi$2d$backend$40$8$2e$1$2e$2_dnd$2d$core$40$16$2e$0$2e$1_react$2d$dnd$40$16$2e$0$2e$1_$40$types$2b$node$40$24$2e$10$2e$9_$40$types$2b$rea_pdtzydzhwhxaghcnub657f7in4$2f$node_modules$2f$react$2d$dnd$2d$multi$2d$backend$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["usePreview"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$multi$2d$backend$40$8$2e$1$2e$2_dnd$2d$core$40$16$2e$0$2e$1_react$2d$dnd$40$16$2e$0$2e$1_$40$types$2b$node$40$24$2e$10$2e$9_$40$types$2b$rea_pdtzydzhwhxaghcnub657f7in4$2f$node_modules$2f$react$2d$dnd$2d$multi$2d$backend$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd-multi-backend@8.1.2_dnd-core@16.0.1_react-dnd@16.0.1_@types+node@24.10.9_@types+rea_pdtzydzhwhxaghcnub657f7in4/node_modules/react-dnd-multi-backend/dist/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$multi$2d$backend$40$8$2e$1$2e$2_dnd$2d$core$40$16$2e$0$2e$1$2f$node_modules$2f$dnd$2d$multi$2d$backend$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-multi-backend@8.1.2_dnd-core@16.0.1/node_modules/dnd-multi-backend/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$preview$40$8$2e$1$2e$2_react$2d$dnd$40$16$2e$0$2e$1_$40$types$2b$node$40$24$2e$10$2e$9_$40$types$2b$react$40$19$2e$2$2e$9_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f$react$2d$dnd$2d$preview$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd-preview@8.1.2_react-dnd@16.0.1_@types+node@24.10.9_@types+react@19.2.9_react@19.2.1__react@19.2.1/node_modules/react-dnd-preview/dist/index.js [app-client] (ecmascript)");
}),
"[project]/node_modules/.pnpm/uuid@9.0.1/node_modules/uuid/dist/commonjs-browser/rng.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = rng;
// Unique ID creation requires a high quality random # generator. In the browser we therefore
// require the crypto API and do not support built-in fallback to lower quality random number
// generators (like Math.random()).
let getRandomValues;
const rnds8 = new Uint8Array(16);
function rng() {
    // lazy load so that environments that need to polyfill have a chance to do so
    if (!getRandomValues) {
        // getRandomValues needs to be invoked in a context where "this" is a Crypto implementation.
        getRandomValues = typeof crypto !== 'undefined' && crypto.getRandomValues && crypto.getRandomValues.bind(crypto);
        if (!getRandomValues) {
            throw new Error('crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported');
        }
    }
    return getRandomValues(rnds8);
}
}),
"[project]/node_modules/.pnpm/uuid@9.0.1/node_modules/uuid/dist/commonjs-browser/regex.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = void 0;
var _default = /^(?:[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000)$/i;
exports.default = _default;
}),
"[project]/node_modules/.pnpm/uuid@9.0.1/node_modules/uuid/dist/commonjs-browser/validate.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = void 0;
var _regex = _interopRequireDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/uuid@9.0.1/node_modules/uuid/dist/commonjs-browser/regex.js [app-client] (ecmascript)"));
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
function validate(uuid) {
    return typeof uuid === 'string' && _regex.default.test(uuid);
}
var _default = validate;
exports.default = _default;
}),
"[project]/node_modules/.pnpm/uuid@9.0.1/node_modules/uuid/dist/commonjs-browser/stringify.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = void 0;
exports.unsafeStringify = unsafeStringify;
var _validate = _interopRequireDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/uuid@9.0.1/node_modules/uuid/dist/commonjs-browser/validate.js [app-client] (ecmascript)"));
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
/**
 * Convert array of 16 byte values to UUID string format of the form:
 * XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX
 */ const byteToHex = [];
for(let i = 0; i < 256; ++i){
    byteToHex.push((i + 0x100).toString(16).slice(1));
}
function unsafeStringify(arr, offset = 0) {
    // Note: Be careful editing this code!  It's been tuned for performance
    // and works in ways you may not expect. See https://github.com/uuidjs/uuid/pull/434
    return byteToHex[arr[offset + 0]] + byteToHex[arr[offset + 1]] + byteToHex[arr[offset + 2]] + byteToHex[arr[offset + 3]] + '-' + byteToHex[arr[offset + 4]] + byteToHex[arr[offset + 5]] + '-' + byteToHex[arr[offset + 6]] + byteToHex[arr[offset + 7]] + '-' + byteToHex[arr[offset + 8]] + byteToHex[arr[offset + 9]] + '-' + byteToHex[arr[offset + 10]] + byteToHex[arr[offset + 11]] + byteToHex[arr[offset + 12]] + byteToHex[arr[offset + 13]] + byteToHex[arr[offset + 14]] + byteToHex[arr[offset + 15]];
}
function stringify(arr, offset = 0) {
    const uuid = unsafeStringify(arr, offset); // Consistency check for valid UUID.  If this throws, it's likely due to one
    // of the following:
    // - One or more input array values don't map to a hex octet (leading to
    // "undefined" in the uuid)
    // - Invalid input values for the RFC `version` or `variant` fields
    if (!(0, _validate.default)(uuid)) {
        throw TypeError('Stringified UUID is invalid');
    }
    return uuid;
}
var _default = stringify;
exports.default = _default;
}),
"[project]/node_modules/.pnpm/uuid@9.0.1/node_modules/uuid/dist/commonjs-browser/v1.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = void 0;
var _rng = _interopRequireDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/uuid@9.0.1/node_modules/uuid/dist/commonjs-browser/rng.js [app-client] (ecmascript)"));
var _stringify = __turbopack_context__.r("[project]/node_modules/.pnpm/uuid@9.0.1/node_modules/uuid/dist/commonjs-browser/stringify.js [app-client] (ecmascript)");
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
// **`v1()` - Generate time-based UUID**
//
// Inspired by https://github.com/LiosK/UUID.js
// and http://docs.python.org/library/uuid.html
let _nodeId;
let _clockseq; // Previous uuid creation time
let _lastMSecs = 0;
let _lastNSecs = 0; // See https://github.com/uuidjs/uuid for API details
function v1(options, buf, offset) {
    let i = buf && offset || 0;
    const b = buf || new Array(16);
    options = options || {};
    let node = options.node || _nodeId;
    let clockseq = options.clockseq !== undefined ? options.clockseq : _clockseq; // node and clockseq need to be initialized to random values if they're not
    // specified.  We do this lazily to minimize issues related to insufficient
    // system entropy.  See #189
    if (node == null || clockseq == null) {
        const seedBytes = options.random || (options.rng || _rng.default)();
        if (node == null) {
            // Per 4.5, create and 48-bit node id, (47 random bits + multicast bit = 1)
            node = _nodeId = [
                seedBytes[0] | 0x01,
                seedBytes[1],
                seedBytes[2],
                seedBytes[3],
                seedBytes[4],
                seedBytes[5]
            ];
        }
        if (clockseq == null) {
            // Per 4.2.2, randomize (14 bit) clockseq
            clockseq = _clockseq = (seedBytes[6] << 8 | seedBytes[7]) & 0x3fff;
        }
    } // UUID timestamps are 100 nano-second units since the Gregorian epoch,
    // (1582-10-15 00:00).  JSNumbers aren't precise enough for this, so
    // time is handled internally as 'msecs' (integer milliseconds) and 'nsecs'
    // (100-nanoseconds offset from msecs) since unix epoch, 1970-01-01 00:00.
    let msecs = options.msecs !== undefined ? options.msecs : Date.now(); // Per 4.2.1.2, use count of uuid's generated during the current clock
    // cycle to simulate higher resolution clock
    let nsecs = options.nsecs !== undefined ? options.nsecs : _lastNSecs + 1; // Time since last uuid creation (in msecs)
    const dt = msecs - _lastMSecs + (nsecs - _lastNSecs) / 10000; // Per 4.2.1.2, Bump clockseq on clock regression
    if (dt < 0 && options.clockseq === undefined) {
        clockseq = clockseq + 1 & 0x3fff;
    } // Reset nsecs if clock regresses (new clockseq) or we've moved onto a new
    // time interval
    if ((dt < 0 || msecs > _lastMSecs) && options.nsecs === undefined) {
        nsecs = 0;
    } // Per 4.2.1.2 Throw error if too many uuids are requested
    if (nsecs >= 10000) {
        throw new Error("uuid.v1(): Can't create more than 10M uuids/sec");
    }
    _lastMSecs = msecs;
    _lastNSecs = nsecs;
    _clockseq = clockseq; // Per 4.1.4 - Convert from unix epoch to Gregorian epoch
    msecs += 12219292800000; // `time_low`
    const tl = ((msecs & 0xfffffff) * 10000 + nsecs) % 0x100000000;
    b[i++] = tl >>> 24 & 0xff;
    b[i++] = tl >>> 16 & 0xff;
    b[i++] = tl >>> 8 & 0xff;
    b[i++] = tl & 0xff; // `time_mid`
    const tmh = msecs / 0x100000000 * 10000 & 0xfffffff;
    b[i++] = tmh >>> 8 & 0xff;
    b[i++] = tmh & 0xff; // `time_high_and_version`
    b[i++] = tmh >>> 24 & 0xf | 0x10; // include version
    b[i++] = tmh >>> 16 & 0xff; // `clock_seq_hi_and_reserved` (Per 4.2.2 - include variant)
    b[i++] = clockseq >>> 8 | 0x80; // `clock_seq_low`
    b[i++] = clockseq & 0xff; // `node`
    for(let n = 0; n < 6; ++n){
        b[i + n] = node[n];
    }
    return buf || (0, _stringify.unsafeStringify)(b);
}
var _default = v1;
exports.default = _default;
}),
"[project]/node_modules/.pnpm/uuid@9.0.1/node_modules/uuid/dist/commonjs-browser/parse.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = void 0;
var _validate = _interopRequireDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/uuid@9.0.1/node_modules/uuid/dist/commonjs-browser/validate.js [app-client] (ecmascript)"));
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
function parse(uuid) {
    if (!(0, _validate.default)(uuid)) {
        throw TypeError('Invalid UUID');
    }
    let v;
    const arr = new Uint8Array(16); // Parse ########-....-....-....-............
    arr[0] = (v = parseInt(uuid.slice(0, 8), 16)) >>> 24;
    arr[1] = v >>> 16 & 0xff;
    arr[2] = v >>> 8 & 0xff;
    arr[3] = v & 0xff; // Parse ........-####-....-....-............
    arr[4] = (v = parseInt(uuid.slice(9, 13), 16)) >>> 8;
    arr[5] = v & 0xff; // Parse ........-....-####-....-............
    arr[6] = (v = parseInt(uuid.slice(14, 18), 16)) >>> 8;
    arr[7] = v & 0xff; // Parse ........-....-....-####-............
    arr[8] = (v = parseInt(uuid.slice(19, 23), 16)) >>> 8;
    arr[9] = v & 0xff; // Parse ........-....-....-....-############
    // (Use "/" to avoid 32-bit truncation when bit-shifting high-order bytes)
    arr[10] = (v = parseInt(uuid.slice(24, 36), 16)) / 0x10000000000 & 0xff;
    arr[11] = v / 0x100000000 & 0xff;
    arr[12] = v >>> 24 & 0xff;
    arr[13] = v >>> 16 & 0xff;
    arr[14] = v >>> 8 & 0xff;
    arr[15] = v & 0xff;
    return arr;
}
var _default = parse;
exports.default = _default;
}),
"[project]/node_modules/.pnpm/uuid@9.0.1/node_modules/uuid/dist/commonjs-browser/v35.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.URL = exports.DNS = void 0;
exports.default = v35;
var _stringify = __turbopack_context__.r("[project]/node_modules/.pnpm/uuid@9.0.1/node_modules/uuid/dist/commonjs-browser/stringify.js [app-client] (ecmascript)");
var _parse = _interopRequireDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/uuid@9.0.1/node_modules/uuid/dist/commonjs-browser/parse.js [app-client] (ecmascript)"));
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
function stringToBytes(str) {
    str = unescape(encodeURIComponent(str)); // UTF8 escape
    const bytes = [];
    for(let i = 0; i < str.length; ++i){
        bytes.push(str.charCodeAt(i));
    }
    return bytes;
}
const DNS = '6ba7b810-9dad-11d1-80b4-00c04fd430c8';
exports.DNS = DNS;
const URL = '6ba7b811-9dad-11d1-80b4-00c04fd430c8';
exports.URL = URL;
function v35(name, version, hashfunc) {
    function generateUUID(value, namespace, buf, offset) {
        var _namespace;
        if (typeof value === 'string') {
            value = stringToBytes(value);
        }
        if (typeof namespace === 'string') {
            namespace = (0, _parse.default)(namespace);
        }
        if (((_namespace = namespace) === null || _namespace === void 0 ? void 0 : _namespace.length) !== 16) {
            throw TypeError('Namespace must be array-like (16 iterable integer values, 0-255)');
        } // Compute hash of namespace and value, Per 4.3
        // Future: Use spread syntax when supported on all platforms, e.g. `bytes =
        // hashfunc([...namespace, ... value])`
        let bytes = new Uint8Array(16 + value.length);
        bytes.set(namespace);
        bytes.set(value, namespace.length);
        bytes = hashfunc(bytes);
        bytes[6] = bytes[6] & 0x0f | version;
        bytes[8] = bytes[8] & 0x3f | 0x80;
        if (buf) {
            offset = offset || 0;
            for(let i = 0; i < 16; ++i){
                buf[offset + i] = bytes[i];
            }
            return buf;
        }
        return (0, _stringify.unsafeStringify)(bytes);
    } // Function#name is not settable on some platforms (#270)
    try {
        generateUUID.name = name; // eslint-disable-next-line no-empty
    } catch (err) {} // For CommonJS default export support
    generateUUID.DNS = DNS;
    generateUUID.URL = URL;
    return generateUUID;
}
}),
"[project]/node_modules/.pnpm/uuid@9.0.1/node_modules/uuid/dist/commonjs-browser/md5.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = void 0;
/*
 * Browser-compatible JavaScript MD5
 *
 * Modification of JavaScript MD5
 * https://github.com/blueimp/JavaScript-MD5
 *
 * Copyright 2011, Sebastian Tschan
 * https://blueimp.net
 *
 * Licensed under the MIT license:
 * https://opensource.org/licenses/MIT
 *
 * Based on
 * A JavaScript implementation of the RSA Data Security, Inc. MD5 Message
 * Digest Algorithm, as defined in RFC 1321.
 * Version 2.2 Copyright (C) Paul Johnston 1999 - 2009
 * Other contributors: Greg Holt, Andrew Kepert, Ydnar, Lostinet
 * Distributed under the BSD License
 * See http://pajhome.org.uk/crypt/md5 for more info.
 */ function md5(bytes) {
    if (typeof bytes === 'string') {
        const msg = unescape(encodeURIComponent(bytes)); // UTF8 escape
        bytes = new Uint8Array(msg.length);
        for(let i = 0; i < msg.length; ++i){
            bytes[i] = msg.charCodeAt(i);
        }
    }
    return md5ToHexEncodedArray(wordsToMd5(bytesToWords(bytes), bytes.length * 8));
}
/*
 * Convert an array of little-endian words to an array of bytes
 */ function md5ToHexEncodedArray(input) {
    const output = [];
    const length32 = input.length * 32;
    const hexTab = '0123456789abcdef';
    for(let i = 0; i < length32; i += 8){
        const x = input[i >> 5] >>> i % 32 & 0xff;
        const hex = parseInt(hexTab.charAt(x >>> 4 & 0x0f) + hexTab.charAt(x & 0x0f), 16);
        output.push(hex);
    }
    return output;
}
/**
 * Calculate output length with padding and bit length
 */ function getOutputLength(inputLength8) {
    return (inputLength8 + 64 >>> 9 << 4) + 14 + 1;
}
/*
 * Calculate the MD5 of an array of little-endian words, and a bit length.
 */ function wordsToMd5(x, len) {
    /* append padding */ x[len >> 5] |= 0x80 << len % 32;
    x[getOutputLength(len) - 1] = len;
    let a = 1732584193;
    let b = -271733879;
    let c = -1732584194;
    let d = 271733878;
    for(let i = 0; i < x.length; i += 16){
        const olda = a;
        const oldb = b;
        const oldc = c;
        const oldd = d;
        a = md5ff(a, b, c, d, x[i], 7, -680876936);
        d = md5ff(d, a, b, c, x[i + 1], 12, -389564586);
        c = md5ff(c, d, a, b, x[i + 2], 17, 606105819);
        b = md5ff(b, c, d, a, x[i + 3], 22, -1044525330);
        a = md5ff(a, b, c, d, x[i + 4], 7, -176418897);
        d = md5ff(d, a, b, c, x[i + 5], 12, 1200080426);
        c = md5ff(c, d, a, b, x[i + 6], 17, -1473231341);
        b = md5ff(b, c, d, a, x[i + 7], 22, -45705983);
        a = md5ff(a, b, c, d, x[i + 8], 7, 1770035416);
        d = md5ff(d, a, b, c, x[i + 9], 12, -1958414417);
        c = md5ff(c, d, a, b, x[i + 10], 17, -42063);
        b = md5ff(b, c, d, a, x[i + 11], 22, -1990404162);
        a = md5ff(a, b, c, d, x[i + 12], 7, 1804603682);
        d = md5ff(d, a, b, c, x[i + 13], 12, -40341101);
        c = md5ff(c, d, a, b, x[i + 14], 17, -1502002290);
        b = md5ff(b, c, d, a, x[i + 15], 22, 1236535329);
        a = md5gg(a, b, c, d, x[i + 1], 5, -165796510);
        d = md5gg(d, a, b, c, x[i + 6], 9, -1069501632);
        c = md5gg(c, d, a, b, x[i + 11], 14, 643717713);
        b = md5gg(b, c, d, a, x[i], 20, -373897302);
        a = md5gg(a, b, c, d, x[i + 5], 5, -701558691);
        d = md5gg(d, a, b, c, x[i + 10], 9, 38016083);
        c = md5gg(c, d, a, b, x[i + 15], 14, -660478335);
        b = md5gg(b, c, d, a, x[i + 4], 20, -405537848);
        a = md5gg(a, b, c, d, x[i + 9], 5, 568446438);
        d = md5gg(d, a, b, c, x[i + 14], 9, -1019803690);
        c = md5gg(c, d, a, b, x[i + 3], 14, -187363961);
        b = md5gg(b, c, d, a, x[i + 8], 20, 1163531501);
        a = md5gg(a, b, c, d, x[i + 13], 5, -1444681467);
        d = md5gg(d, a, b, c, x[i + 2], 9, -51403784);
        c = md5gg(c, d, a, b, x[i + 7], 14, 1735328473);
        b = md5gg(b, c, d, a, x[i + 12], 20, -1926607734);
        a = md5hh(a, b, c, d, x[i + 5], 4, -378558);
        d = md5hh(d, a, b, c, x[i + 8], 11, -2022574463);
        c = md5hh(c, d, a, b, x[i + 11], 16, 1839030562);
        b = md5hh(b, c, d, a, x[i + 14], 23, -35309556);
        a = md5hh(a, b, c, d, x[i + 1], 4, -1530992060);
        d = md5hh(d, a, b, c, x[i + 4], 11, 1272893353);
        c = md5hh(c, d, a, b, x[i + 7], 16, -155497632);
        b = md5hh(b, c, d, a, x[i + 10], 23, -1094730640);
        a = md5hh(a, b, c, d, x[i + 13], 4, 681279174);
        d = md5hh(d, a, b, c, x[i], 11, -358537222);
        c = md5hh(c, d, a, b, x[i + 3], 16, -722521979);
        b = md5hh(b, c, d, a, x[i + 6], 23, 76029189);
        a = md5hh(a, b, c, d, x[i + 9], 4, -640364487);
        d = md5hh(d, a, b, c, x[i + 12], 11, -421815835);
        c = md5hh(c, d, a, b, x[i + 15], 16, 530742520);
        b = md5hh(b, c, d, a, x[i + 2], 23, -995338651);
        a = md5ii(a, b, c, d, x[i], 6, -198630844);
        d = md5ii(d, a, b, c, x[i + 7], 10, 1126891415);
        c = md5ii(c, d, a, b, x[i + 14], 15, -1416354905);
        b = md5ii(b, c, d, a, x[i + 5], 21, -57434055);
        a = md5ii(a, b, c, d, x[i + 12], 6, 1700485571);
        d = md5ii(d, a, b, c, x[i + 3], 10, -1894986606);
        c = md5ii(c, d, a, b, x[i + 10], 15, -1051523);
        b = md5ii(b, c, d, a, x[i + 1], 21, -2054922799);
        a = md5ii(a, b, c, d, x[i + 8], 6, 1873313359);
        d = md5ii(d, a, b, c, x[i + 15], 10, -30611744);
        c = md5ii(c, d, a, b, x[i + 6], 15, -1560198380);
        b = md5ii(b, c, d, a, x[i + 13], 21, 1309151649);
        a = md5ii(a, b, c, d, x[i + 4], 6, -145523070);
        d = md5ii(d, a, b, c, x[i + 11], 10, -1120210379);
        c = md5ii(c, d, a, b, x[i + 2], 15, 718787259);
        b = md5ii(b, c, d, a, x[i + 9], 21, -343485551);
        a = safeAdd(a, olda);
        b = safeAdd(b, oldb);
        c = safeAdd(c, oldc);
        d = safeAdd(d, oldd);
    }
    return [
        a,
        b,
        c,
        d
    ];
}
/*
 * Convert an array bytes to an array of little-endian words
 * Characters >255 have their high-byte silently ignored.
 */ function bytesToWords(input) {
    if (input.length === 0) {
        return [];
    }
    const length8 = input.length * 8;
    const output = new Uint32Array(getOutputLength(length8));
    for(let i = 0; i < length8; i += 8){
        output[i >> 5] |= (input[i / 8] & 0xff) << i % 32;
    }
    return output;
}
/*
 * Add integers, wrapping at 2^32. This uses 16-bit operations internally
 * to work around bugs in some JS interpreters.
 */ function safeAdd(x, y) {
    const lsw = (x & 0xffff) + (y & 0xffff);
    const msw = (x >> 16) + (y >> 16) + (lsw >> 16);
    return msw << 16 | lsw & 0xffff;
}
/*
 * Bitwise rotate a 32-bit number to the left.
 */ function bitRotateLeft(num, cnt) {
    return num << cnt | num >>> 32 - cnt;
}
/*
 * These functions implement the four basic operations the algorithm uses.
 */ function md5cmn(q, a, b, x, s, t) {
    return safeAdd(bitRotateLeft(safeAdd(safeAdd(a, q), safeAdd(x, t)), s), b);
}
function md5ff(a, b, c, d, x, s, t) {
    return md5cmn(b & c | ~b & d, a, b, x, s, t);
}
function md5gg(a, b, c, d, x, s, t) {
    return md5cmn(b & d | c & ~d, a, b, x, s, t);
}
function md5hh(a, b, c, d, x, s, t) {
    return md5cmn(b ^ c ^ d, a, b, x, s, t);
}
function md5ii(a, b, c, d, x, s, t) {
    return md5cmn(c ^ (b | ~d), a, b, x, s, t);
}
var _default = md5;
exports.default = _default;
}),
"[project]/node_modules/.pnpm/uuid@9.0.1/node_modules/uuid/dist/commonjs-browser/v3.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = void 0;
var _v = _interopRequireDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/uuid@9.0.1/node_modules/uuid/dist/commonjs-browser/v35.js [app-client] (ecmascript)"));
var _md = _interopRequireDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/uuid@9.0.1/node_modules/uuid/dist/commonjs-browser/md5.js [app-client] (ecmascript)"));
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
const v3 = (0, _v.default)('v3', 0x30, _md.default);
var _default = v3;
exports.default = _default;
}),
"[project]/node_modules/.pnpm/uuid@9.0.1/node_modules/uuid/dist/commonjs-browser/native.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = void 0;
const randomUUID = typeof crypto !== 'undefined' && crypto.randomUUID && crypto.randomUUID.bind(crypto);
var _default = {
    randomUUID
};
exports.default = _default;
}),
"[project]/node_modules/.pnpm/uuid@9.0.1/node_modules/uuid/dist/commonjs-browser/v4.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = void 0;
var _native = _interopRequireDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/uuid@9.0.1/node_modules/uuid/dist/commonjs-browser/native.js [app-client] (ecmascript)"));
var _rng = _interopRequireDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/uuid@9.0.1/node_modules/uuid/dist/commonjs-browser/rng.js [app-client] (ecmascript)"));
var _stringify = __turbopack_context__.r("[project]/node_modules/.pnpm/uuid@9.0.1/node_modules/uuid/dist/commonjs-browser/stringify.js [app-client] (ecmascript)");
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
function v4(options, buf, offset) {
    if (_native.default.randomUUID && !buf && !options) {
        return _native.default.randomUUID();
    }
    options = options || {};
    const rnds = options.random || (options.rng || _rng.default)(); // Per 4.4, set bits for version and `clock_seq_hi_and_reserved`
    rnds[6] = rnds[6] & 0x0f | 0x40;
    rnds[8] = rnds[8] & 0x3f | 0x80; // Copy bytes to buffer, if provided
    if (buf) {
        offset = offset || 0;
        for(let i = 0; i < 16; ++i){
            buf[offset + i] = rnds[i];
        }
        return buf;
    }
    return (0, _stringify.unsafeStringify)(rnds);
}
var _default = v4;
exports.default = _default;
}),
"[project]/node_modules/.pnpm/uuid@9.0.1/node_modules/uuid/dist/commonjs-browser/sha1.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = void 0;
// Adapted from Chris Veness' SHA1 code at
// http://www.movable-type.co.uk/scripts/sha1.html
function f(s, x, y, z) {
    switch(s){
        case 0:
            return x & y ^ ~x & z;
        case 1:
            return x ^ y ^ z;
        case 2:
            return x & y ^ x & z ^ y & z;
        case 3:
            return x ^ y ^ z;
    }
}
function ROTL(x, n) {
    return x << n | x >>> 32 - n;
}
function sha1(bytes) {
    const K = [
        0x5a827999,
        0x6ed9eba1,
        0x8f1bbcdc,
        0xca62c1d6
    ];
    const H = [
        0x67452301,
        0xefcdab89,
        0x98badcfe,
        0x10325476,
        0xc3d2e1f0
    ];
    if (typeof bytes === 'string') {
        const msg = unescape(encodeURIComponent(bytes)); // UTF8 escape
        bytes = [];
        for(let i = 0; i < msg.length; ++i){
            bytes.push(msg.charCodeAt(i));
        }
    } else if (!Array.isArray(bytes)) {
        // Convert Array-like to Array
        bytes = Array.prototype.slice.call(bytes);
    }
    bytes.push(0x80);
    const l = bytes.length / 4 + 2;
    const N = Math.ceil(l / 16);
    const M = new Array(N);
    for(let i = 0; i < N; ++i){
        const arr = new Uint32Array(16);
        for(let j = 0; j < 16; ++j){
            arr[j] = bytes[i * 64 + j * 4] << 24 | bytes[i * 64 + j * 4 + 1] << 16 | bytes[i * 64 + j * 4 + 2] << 8 | bytes[i * 64 + j * 4 + 3];
        }
        M[i] = arr;
    }
    M[N - 1][14] = (bytes.length - 1) * 8 / Math.pow(2, 32);
    M[N - 1][14] = Math.floor(M[N - 1][14]);
    M[N - 1][15] = (bytes.length - 1) * 8 & 0xffffffff;
    for(let i = 0; i < N; ++i){
        const W = new Uint32Array(80);
        for(let t = 0; t < 16; ++t){
            W[t] = M[i][t];
        }
        for(let t = 16; t < 80; ++t){
            W[t] = ROTL(W[t - 3] ^ W[t - 8] ^ W[t - 14] ^ W[t - 16], 1);
        }
        let a = H[0];
        let b = H[1];
        let c = H[2];
        let d = H[3];
        let e = H[4];
        for(let t = 0; t < 80; ++t){
            const s = Math.floor(t / 20);
            const T = ROTL(a, 5) + f(s, b, c, d) + e + K[s] + W[t] >>> 0;
            e = d;
            d = c;
            c = ROTL(b, 30) >>> 0;
            b = a;
            a = T;
        }
        H[0] = H[0] + a >>> 0;
        H[1] = H[1] + b >>> 0;
        H[2] = H[2] + c >>> 0;
        H[3] = H[3] + d >>> 0;
        H[4] = H[4] + e >>> 0;
    }
    return [
        H[0] >> 24 & 0xff,
        H[0] >> 16 & 0xff,
        H[0] >> 8 & 0xff,
        H[0] & 0xff,
        H[1] >> 24 & 0xff,
        H[1] >> 16 & 0xff,
        H[1] >> 8 & 0xff,
        H[1] & 0xff,
        H[2] >> 24 & 0xff,
        H[2] >> 16 & 0xff,
        H[2] >> 8 & 0xff,
        H[2] & 0xff,
        H[3] >> 24 & 0xff,
        H[3] >> 16 & 0xff,
        H[3] >> 8 & 0xff,
        H[3] & 0xff,
        H[4] >> 24 & 0xff,
        H[4] >> 16 & 0xff,
        H[4] >> 8 & 0xff,
        H[4] & 0xff
    ];
}
var _default = sha1;
exports.default = _default;
}),
"[project]/node_modules/.pnpm/uuid@9.0.1/node_modules/uuid/dist/commonjs-browser/v5.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = void 0;
var _v = _interopRequireDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/uuid@9.0.1/node_modules/uuid/dist/commonjs-browser/v35.js [app-client] (ecmascript)"));
var _sha = _interopRequireDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/uuid@9.0.1/node_modules/uuid/dist/commonjs-browser/sha1.js [app-client] (ecmascript)"));
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
const v5 = (0, _v.default)('v5', 0x50, _sha.default);
var _default = v5;
exports.default = _default;
}),
"[project]/node_modules/.pnpm/uuid@9.0.1/node_modules/uuid/dist/commonjs-browser/nil.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = void 0;
var _default = '00000000-0000-0000-0000-000000000000';
exports.default = _default;
}),
"[project]/node_modules/.pnpm/uuid@9.0.1/node_modules/uuid/dist/commonjs-browser/version.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = void 0;
var _validate = _interopRequireDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/uuid@9.0.1/node_modules/uuid/dist/commonjs-browser/validate.js [app-client] (ecmascript)"));
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
function version(uuid) {
    if (!(0, _validate.default)(uuid)) {
        throw TypeError('Invalid UUID');
    }
    return parseInt(uuid.slice(14, 15), 16);
}
var _default = version;
exports.default = _default;
}),
"[project]/node_modules/.pnpm/uuid@9.0.1/node_modules/uuid/dist/commonjs-browser/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "NIL", {
    enumerable: true,
    get: function get() {
        return _nil.default;
    }
});
Object.defineProperty(exports, "parse", {
    enumerable: true,
    get: function get() {
        return _parse.default;
    }
});
Object.defineProperty(exports, "stringify", {
    enumerable: true,
    get: function get() {
        return _stringify.default;
    }
});
Object.defineProperty(exports, "v1", {
    enumerable: true,
    get: function get() {
        return _v.default;
    }
});
Object.defineProperty(exports, "v3", {
    enumerable: true,
    get: function get() {
        return _v2.default;
    }
});
Object.defineProperty(exports, "v4", {
    enumerable: true,
    get: function get() {
        return _v3.default;
    }
});
Object.defineProperty(exports, "v5", {
    enumerable: true,
    get: function get() {
        return _v4.default;
    }
});
Object.defineProperty(exports, "validate", {
    enumerable: true,
    get: function get() {
        return _validate.default;
    }
});
Object.defineProperty(exports, "version", {
    enumerable: true,
    get: function get() {
        return _version.default;
    }
});
var _v = _interopRequireDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/uuid@9.0.1/node_modules/uuid/dist/commonjs-browser/v1.js [app-client] (ecmascript)"));
var _v2 = _interopRequireDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/uuid@9.0.1/node_modules/uuid/dist/commonjs-browser/v3.js [app-client] (ecmascript)"));
var _v3 = _interopRequireDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/uuid@9.0.1/node_modules/uuid/dist/commonjs-browser/v4.js [app-client] (ecmascript)"));
var _v4 = _interopRequireDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/uuid@9.0.1/node_modules/uuid/dist/commonjs-browser/v5.js [app-client] (ecmascript)"));
var _nil = _interopRequireDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/uuid@9.0.1/node_modules/uuid/dist/commonjs-browser/nil.js [app-client] (ecmascript)"));
var _version = _interopRequireDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/uuid@9.0.1/node_modules/uuid/dist/commonjs-browser/version.js [app-client] (ecmascript)"));
var _validate = _interopRequireDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/uuid@9.0.1/node_modules/uuid/dist/commonjs-browser/validate.js [app-client] (ecmascript)"));
var _stringify = _interopRequireDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/uuid@9.0.1/node_modules/uuid/dist/commonjs-browser/stringify.js [app-client] (ecmascript)"));
var _parse = _interopRequireDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/uuid@9.0.1/node_modules/uuid/dist/commonjs-browser/parse.js [app-client] (ecmascript)"));
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
}),
"[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/contextTypes.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __importDefault = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.MosaicWindowContext = exports.MosaicContext = void 0;
var react_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
exports.MosaicContext = react_1.default.createContext(undefined);
exports.MosaicWindowContext = react_1.default.createContext(undefined); //# sourceMappingURL=contextTypes.js.map
}),
"[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/util/assertNever.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.assertNever = void 0;
function assertNever(shouldBeNever) {
    throw new Error('Unhandled case: ' + JSON.stringify(shouldBeNever));
}
exports.assertNever = assertNever; //# sourceMappingURL=assertNever.js.map
}),
"[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/util/BoundingBox.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __assign = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__assign || function() {
    __assign = Object.assign || function(t) {
        for(var s, i = 1, n = arguments.length; i < n; i++){
            s = arguments[i];
            for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.BoundingBox = void 0;
var assertNever_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/util/assertNever.js [app-client] (ecmascript)");
var BoundingBox;
(function(BoundingBox) {
    function empty() {
        return {
            top: 0,
            right: 0,
            bottom: 0,
            left: 0
        };
    }
    BoundingBox.empty = empty;
    function split(boundingBox, relativeSplitPercentage, direction) {
        var absolutePercentage = getAbsoluteSplitPercentage(boundingBox, relativeSplitPercentage, direction);
        if (direction === 'column') {
            return {
                first: __assign(__assign({}, boundingBox), {
                    bottom: 100 - absolutePercentage
                }),
                second: __assign(__assign({}, boundingBox), {
                    top: absolutePercentage
                })
            };
        } else if (direction === 'row') {
            return {
                first: __assign(__assign({}, boundingBox), {
                    right: 100 - absolutePercentage
                }),
                second: __assign(__assign({}, boundingBox), {
                    left: absolutePercentage
                })
            };
        } else {
            return (0, assertNever_1.assertNever)(direction);
        }
    }
    BoundingBox.split = split;
    function getAbsoluteSplitPercentage(boundingBox, relativeSplitPercentage, direction) {
        var top = boundingBox.top, right = boundingBox.right, bottom = boundingBox.bottom, left = boundingBox.left;
        if (direction === 'column') {
            var height = 100 - top - bottom;
            return height * relativeSplitPercentage / 100 + top;
        } else if (direction === 'row') {
            var width = 100 - right - left;
            return width * relativeSplitPercentage / 100 + left;
        } else {
            return (0, assertNever_1.assertNever)(direction);
        }
    }
    BoundingBox.getAbsoluteSplitPercentage = getAbsoluteSplitPercentage;
    function getRelativeSplitPercentage(boundingBox, absoluteSplitPercentage, direction) {
        var top = boundingBox.top, right = boundingBox.right, bottom = boundingBox.bottom, left = boundingBox.left;
        if (direction === 'column') {
            var height = 100 - top - bottom;
            return (absoluteSplitPercentage - top) / height * 100;
        } else if (direction === 'row') {
            var width = 100 - right - left;
            return (absoluteSplitPercentage - left) / width * 100;
        } else {
            return (0, assertNever_1.assertNever)(direction);
        }
    }
    BoundingBox.getRelativeSplitPercentage = getRelativeSplitPercentage;
    function asStyles(_a) {
        var top = _a.top, right = _a.right, bottom = _a.bottom, left = _a.left;
        return {
            top: "".concat(top, "%"),
            right: "".concat(right, "%"),
            bottom: "".concat(bottom, "%"),
            left: "".concat(left, "%")
        };
    }
    BoundingBox.asStyles = asStyles;
})(BoundingBox = exports.BoundingBox || (exports.BoundingBox = {})); //# sourceMappingURL=BoundingBox.js.map
}),
"[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/Split.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __extends = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__extends || function() {
    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || ({
            __proto__: []
        }) instanceof Array && function(d, b) {
            d.__proto__ = b;
        } || function(d, b) {
            for(var p in b)if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
        };
        return extendStatics(d, b);
    };
    return function(d, b) {
        if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() {
            this.constructor = d;
        }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
}();
var __assign = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__assign || function() {
    __assign = Object.assign || function(t) {
        for(var s, i = 1, n = arguments.length; i < n; i++){
            s = arguments[i];
            for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __importDefault = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Split = void 0;
var classnames_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/classnames@2.5.1/node_modules/classnames/index.js [app-client] (ecmascript)"));
var clamp_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/lodash@4.17.23/node_modules/lodash/clamp.js [app-client] (ecmascript)"));
var throttle_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/lodash@4.17.23/node_modules/lodash/throttle.js [app-client] (ecmascript)"));
var react_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
var BoundingBox_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/util/BoundingBox.js [app-client] (ecmascript)");
var RESIZE_THROTTLE_MS = 1000 / 30; // 30 fps
var TOUCH_EVENT_OPTIONS = {
    capture: true,
    passive: false
};
var Split = function(_super) {
    __extends(Split, _super);
    function Split() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.rootElement = react_1.default.createRef();
        _this.listenersBound = false;
        _this.onMouseDown = function(event) {
            if (!isTouchEvent(event)) {
                if (event.button !== 0) {
                    return;
                }
            }
            event.preventDefault();
            _this.bindListeners();
        };
        _this.onMouseUp = function(event) {
            _this.unbindListeners();
            var percentage = _this.calculateRelativePercentage(event);
            _this.props.onRelease(percentage);
        };
        _this.onMouseMove = function(event) {
            event.preventDefault();
            _this.throttledUpdatePercentage(event);
        };
        _this.throttledUpdatePercentage = (0, throttle_1.default)(function(event) {
            var percentage = _this.calculateRelativePercentage(event);
            if (percentage !== _this.props.splitPercentage) {
                _this.props.onChange(percentage);
            }
        }, RESIZE_THROTTLE_MS);
        return _this;
    }
    Split.prototype.render = function() {
        var direction = this.props.direction;
        return react_1.default.createElement("div", {
            className: (0, classnames_1.default)('mosaic-split', {
                '-row': direction === 'row',
                '-column': direction === 'column'
            }),
            ref: this.rootElement,
            onMouseDown: this.onMouseDown,
            style: this.computeStyle()
        }, react_1.default.createElement("div", {
            className: "mosaic-split-line"
        }));
    };
    Split.prototype.componentDidMount = function() {
        this.rootElement.current.addEventListener('touchstart', this.onMouseDown, TOUCH_EVENT_OPTIONS);
    };
    Split.prototype.componentWillUnmount = function() {
        this.unbindListeners();
        if (this.rootElement.current) {
            this.rootElement.current.ownerDocument.removeEventListener('touchstart', this.onMouseDown, TOUCH_EVENT_OPTIONS);
        }
    };
    Split.prototype.bindListeners = function() {
        if (!this.listenersBound) {
            this.rootElement.current.ownerDocument.addEventListener('mousemove', this.onMouseMove, true);
            this.rootElement.current.ownerDocument.addEventListener('touchmove', this.onMouseMove, TOUCH_EVENT_OPTIONS);
            this.rootElement.current.ownerDocument.addEventListener('mouseup', this.onMouseUp, true);
            this.rootElement.current.ownerDocument.addEventListener('touchend', this.onMouseUp, true);
            this.listenersBound = true;
        }
    };
    Split.prototype.unbindListeners = function() {
        if (this.rootElement.current) {
            this.rootElement.current.ownerDocument.removeEventListener('mousemove', this.onMouseMove, true);
            this.rootElement.current.ownerDocument.removeEventListener('touchmove', this.onMouseMove, TOUCH_EVENT_OPTIONS);
            this.rootElement.current.ownerDocument.removeEventListener('mouseup', this.onMouseUp, true);
            this.rootElement.current.ownerDocument.removeEventListener('touchend', this.onMouseUp, true);
            this.listenersBound = false;
        }
    };
    Split.prototype.computeStyle = function() {
        var _a;
        var _b = this.props, boundingBox = _b.boundingBox, direction = _b.direction, splitPercentage = _b.splitPercentage;
        var positionStyle = direction === 'column' ? 'top' : 'left';
        var absolutePercentage = BoundingBox_1.BoundingBox.getAbsoluteSplitPercentage(boundingBox, splitPercentage, direction);
        return __assign(__assign({}, BoundingBox_1.BoundingBox.asStyles(boundingBox)), (_a = {}, _a[positionStyle] = "".concat(absolutePercentage, "%"), _a));
    };
    Split.prototype.calculateRelativePercentage = function(event) {
        var _a = this.props, minimumPaneSizePercentage = _a.minimumPaneSizePercentage, direction = _a.direction, boundingBox = _a.boundingBox;
        var parentBBox = this.rootElement.current.parentElement.getBoundingClientRect();
        var location = isTouchEvent(event) ? event.changedTouches[0] : event;
        var absolutePercentage;
        if (direction === 'column') {
            absolutePercentage = (location.clientY - parentBBox.top) / parentBBox.height * 100.0;
        } else {
            absolutePercentage = (location.clientX - parentBBox.left) / parentBBox.width * 100.0;
        }
        var relativePercentage = BoundingBox_1.BoundingBox.getRelativeSplitPercentage(boundingBox, absolutePercentage, direction);
        return (0, clamp_1.default)(relativePercentage, minimumPaneSizePercentage, 100 - minimumPaneSizePercentage);
    };
    Split.defaultProps = {
        onChange: function() {
            return void 0;
        },
        onRelease: function() {
            return void 0;
        },
        minimumPaneSizePercentage: 20
    };
    return Split;
}(react_1.default.PureComponent);
exports.Split = Split;
function isTouchEvent(event) {
    return event.changedTouches != null;
} //# sourceMappingURL=Split.js.map
}),
"[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/util/mosaicUtilities.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __importDefault = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getAndAssertNodeAtPathExists = exports.getNodeAtPath = exports.getLeaves = exports.getPathToCorner = exports.getOtherDirection = exports.getOtherBranch = exports.createBalancedTreeFromLeaves = exports.isParent = exports.Corner = void 0;
var clone_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/lodash@4.17.23/node_modules/lodash/clone.js [app-client] (ecmascript)"));
var get_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/lodash@4.17.23/node_modules/lodash/get.js [app-client] (ecmascript)"));
function alternateDirection(node, direction) {
    if (direction === void 0) {
        direction = 'row';
    }
    if (isParent(node)) {
        var nextDirection = getOtherDirection(direction);
        return {
            direction: direction,
            first: alternateDirection(node.first, nextDirection),
            second: alternateDirection(node.second, nextDirection)
        };
    } else {
        return node;
    }
}
var Corner;
(function(Corner) {
    Corner[Corner["TOP_LEFT"] = 1] = "TOP_LEFT";
    Corner[Corner["TOP_RIGHT"] = 2] = "TOP_RIGHT";
    Corner[Corner["BOTTOM_LEFT"] = 3] = "BOTTOM_LEFT";
    Corner[Corner["BOTTOM_RIGHT"] = 4] = "BOTTOM_RIGHT";
})(Corner = exports.Corner || (exports.Corner = {}));
/**
 * Returns `true` if `node` is a MosaicParent
 * @param node
 * @returns {boolean}
 */ function isParent(node) {
    return node.direction != null;
}
exports.isParent = isParent;
/**
 * Creates a balanced binary tree from `leaves` with the goal of making them as equal area as possible
 * @param leaves
 * @param startDirection
 * @returns {MosaicNode<T>}
 */ function createBalancedTreeFromLeaves(leaves, startDirection) {
    if (startDirection === void 0) {
        startDirection = 'row';
    }
    if (leaves.length === 0) {
        return null;
    }
    var current = (0, clone_1.default)(leaves);
    var next = [];
    while(current.length > 1){
        while(current.length > 0){
            if (current.length > 1) {
                next.push({
                    direction: 'row',
                    first: current.shift(),
                    second: current.shift()
                });
            } else {
                next.unshift(current.shift());
            }
        }
        current = next;
        next = [];
    }
    return alternateDirection(current[0], startDirection);
}
exports.createBalancedTreeFromLeaves = createBalancedTreeFromLeaves;
/**
 * Gets the sibling of `branch`
 * @param branch
 * @returns {any}
 */ function getOtherBranch(branch) {
    if (branch === 'first') {
        return 'second';
    } else if (branch === 'second') {
        return 'first';
    } else {
        throw new Error("Branch '".concat(branch, "' not a valid branch"));
    }
}
exports.getOtherBranch = getOtherBranch;
/**
 * Gets the opposite of `direction`
 * @param direction
 * @returns {any}
 */ function getOtherDirection(direction) {
    if (direction === 'row') {
        return 'column';
    } else {
        return 'row';
    }
}
exports.getOtherDirection = getOtherDirection;
/**
 * Traverses `tree` to find the path to the specified `corner`
 * @param tree
 * @param corner
 * @returns {MosaicPath}
 */ function getPathToCorner(tree, corner) {
    var currentNode = tree;
    var currentPath = [];
    while(isParent(currentNode)){
        if (currentNode.direction === 'row' && (corner === Corner.TOP_LEFT || corner === Corner.BOTTOM_LEFT)) {
            currentPath.push('first');
            currentNode = currentNode.first;
        } else if (currentNode.direction === 'column' && (corner === Corner.TOP_LEFT || corner === Corner.TOP_RIGHT)) {
            currentPath.push('first');
            currentNode = currentNode.first;
        } else {
            currentPath.push('second');
            currentNode = currentNode.second;
        }
    }
    return currentPath;
}
exports.getPathToCorner = getPathToCorner;
/**
 * Gets all leaves of `tree`
 * @param tree
 * @returns {T[]}
 */ function getLeaves(tree) {
    if (tree == null) {
        return [];
    } else if (isParent(tree)) {
        return getLeaves(tree.first).concat(getLeaves(tree.second));
    } else {
        return [
            tree
        ];
    }
}
exports.getLeaves = getLeaves;
/**
 * Gets node at `path` from `tree`
 * @param tree
 * @param path
 * @returns {MosaicNode<T>|null}
 */ function getNodeAtPath(tree, path) {
    if (path.length > 0) {
        return (0, get_1.default)(tree, path, null);
    } else {
        return tree;
    }
}
exports.getNodeAtPath = getNodeAtPath;
/**
 * Gets node at `path` from `tree` and verifies that neither `tree` nor the result are null
 * @param tree
 * @param path
 * @returns {MosaicNode<T>}
 */ function getAndAssertNodeAtPathExists(tree, path) {
    if (tree == null) {
        throw new Error('Root is empty, cannot fetch path');
    }
    var node = getNodeAtPath(tree, path);
    if (node == null) {
        throw new Error("Path [".concat(path.join(', '), "] did not resolve to a node"));
    }
    return node;
}
exports.getAndAssertNodeAtPathExists = getAndAssertNodeAtPathExists; //# sourceMappingURL=mosaicUtilities.js.map
}),
"[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/MosaicRoot.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __extends = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__extends || function() {
    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || ({
            __proto__: []
        }) instanceof Array && function(d, b) {
            d.__proto__ = b;
        } || function(d, b) {
            for(var p in b)if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
        };
        return extendStatics(d, b);
    };
    return function(d, b) {
        if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() {
            this.constructor = d;
        }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
}();
var __assign = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__assign || function() {
    __assign = Object.assign || function(t) {
        for(var s, i = 1, n = arguments.length; i < n; i++){
            s = arguments[i];
            for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __importDefault = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.MosaicRoot = void 0;
var flatten_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/lodash@4.17.23/node_modules/lodash/flatten.js [app-client] (ecmascript)"));
var react_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
var contextTypes_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/contextTypes.js [app-client] (ecmascript)");
var Split_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/Split.js [app-client] (ecmascript)");
var BoundingBox_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/util/BoundingBox.js [app-client] (ecmascript)");
var mosaicUtilities_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/util/mosaicUtilities.js [app-client] (ecmascript)");
var MosaicRoot = function(_super) {
    __extends(MosaicRoot, _super);
    function MosaicRoot() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.onResize = function(percentage, path, suppressOnRelease) {
            _this.context.mosaicActions.updateTree([
                {
                    path: path,
                    spec: {
                        splitPercentage: {
                            $set: percentage
                        }
                    }
                }
            ], suppressOnRelease);
        };
        return _this;
    }
    MosaicRoot.prototype.render = function() {
        var root = this.props.root;
        return react_1.default.createElement("div", {
            className: "mosaic-root"
        }, this.renderRecursively(root, BoundingBox_1.BoundingBox.empty(), []));
    };
    MosaicRoot.prototype.renderRecursively = function(node, boundingBox, path) {
        if ((0, mosaicUtilities_1.isParent)(node)) {
            var splitPercentage = node.splitPercentage == null ? 50 : node.splitPercentage;
            var _a = BoundingBox_1.BoundingBox.split(boundingBox, splitPercentage, node.direction), first = _a.first, second = _a.second;
            return (0, flatten_1.default)([
                this.renderRecursively(node.first, first, path.concat('first')),
                this.renderSplit(node.direction, boundingBox, splitPercentage, path),
                this.renderRecursively(node.second, second, path.concat('second'))
            ].filter(nonNullElement));
        } else {
            return react_1.default.createElement("div", {
                key: node,
                className: "mosaic-tile",
                style: __assign({}, BoundingBox_1.BoundingBox.asStyles(boundingBox))
            }, this.props.renderTile(node, path));
        }
    };
    MosaicRoot.prototype.renderSplit = function(direction, boundingBox, splitPercentage, path) {
        var _this = this;
        var resize = this.props.resize;
        if (resize !== 'DISABLED') {
            return react_1.default.createElement(Split_1.Split, __assign({
                key: path.join(',') + 'splitter'
            }, resize, {
                boundingBox: boundingBox,
                splitPercentage: splitPercentage,
                direction: direction,
                onChange: function(percentage) {
                    return _this.onResize(percentage, path, true);
                },
                onRelease: function(percentage) {
                    return _this.onResize(percentage, path, false);
                }
            }));
        } else {
            return null;
        }
    };
    MosaicRoot.contextType = contextTypes_1.MosaicContext;
    return MosaicRoot;
}(react_1.default.PureComponent);
exports.MosaicRoot = MosaicRoot;
function nonNullElement(x) {
    return x !== null;
} //# sourceMappingURL=MosaicRoot.js.map
}),
"[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/util/OptionalBlueprint.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __createBinding = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __setModuleDefault = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
});
var __importStar = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__importStar || function(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) {
        for(var k in mod)if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    }
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.OptionalBlueprint = void 0;
var classnames_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/classnames@2.5.1/node_modules/classnames/index.js [app-client] (ecmascript)"));
var kebabCase_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/lodash@4.17.23/node_modules/lodash/kebabCase.js [app-client] (ecmascript)"));
var React = __importStar(__turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
var contextTypes_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/contextTypes.js [app-client] (ecmascript)");
var OptionalBlueprint;
(function(OptionalBlueprint) {
    OptionalBlueprint.Icon = function(_a) {
        var icon = _a.icon, className = _a.className, _b = _a.size, size = _b === void 0 ? 'standard' : _b;
        var blueprintNamespace = React.useContext(contextTypes_1.MosaicContext).blueprintNamespace;
        return React.createElement("span", {
            className: (0, classnames_1.default)(className, getIconClass(blueprintNamespace, icon), "".concat(blueprintNamespace, "-icon-").concat(size))
        });
    };
    function getClasses(blueprintNamespace) {
        var names = [];
        for(var _i = 1; _i < arguments.length; _i++){
            names[_i - 1] = arguments[_i];
        }
        return names.map(function(name) {
            return "".concat(blueprintNamespace, "-").concat((0, kebabCase_1.default)(name));
        }).join(' ');
    }
    OptionalBlueprint.getClasses = getClasses;
    function getIconClass(blueprintNamespace, iconName) {
        return "".concat(blueprintNamespace, "-icon-").concat((0, kebabCase_1.default)(iconName));
    }
    OptionalBlueprint.getIconClass = getIconClass;
})(OptionalBlueprint = exports.OptionalBlueprint || (exports.OptionalBlueprint = {})); //# sourceMappingURL=OptionalBlueprint.js.map
}),
"[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/MosaicZeroState.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __extends = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__extends || function() {
    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || ({
            __proto__: []
        }) instanceof Array && function(d, b) {
            d.__proto__ = b;
        } || function(d, b) {
            for(var p in b)if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
        };
        return extendStatics(d, b);
    };
    return function(d, b) {
        if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() {
            this.constructor = d;
        }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
}();
var __importDefault = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.MosaicZeroState = void 0;
var classnames_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/classnames@2.5.1/node_modules/classnames/index.js [app-client] (ecmascript)"));
var noop_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/lodash@4.17.23/node_modules/lodash/noop.js [app-client] (ecmascript)"));
var react_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
var contextTypes_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/contextTypes.js [app-client] (ecmascript)");
var OptionalBlueprint_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/util/OptionalBlueprint.js [app-client] (ecmascript)");
var MosaicZeroState = function(_super) {
    __extends(MosaicZeroState, _super);
    function MosaicZeroState() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.replace = function() {
            return Promise.resolve(_this.props.createNode()).then(function(node) {
                return _this.context.mosaicActions.replaceWith([], node);
            }).catch(noop_1.default);
        }; // Swallow rejections (i.e. on user cancel)
        return _this;
    }
    MosaicZeroState.prototype.render = function() {
        return react_1.default.createElement("div", {
            className: (0, classnames_1.default)('mosaic-zero-state', OptionalBlueprint_1.OptionalBlueprint.getClasses(this.context.blueprintNamespace, 'NON_IDEAL_STATE'))
        }, react_1.default.createElement("div", {
            className: OptionalBlueprint_1.OptionalBlueprint.getClasses(this.context.blueprintNamespace, 'NON_IDEAL_STATE_VISUAL')
        }, react_1.default.createElement(OptionalBlueprint_1.OptionalBlueprint.Icon, {
            className: "default-zero-state-icon",
            size: "large",
            icon: "APPLICATIONS"
        })), react_1.default.createElement("h4", {
            className: OptionalBlueprint_1.OptionalBlueprint.getClasses(this.context.blueprintNamespace, 'HEADING')
        }, "No Windows Present"), react_1.default.createElement("div", null, this.props.createNode && react_1.default.createElement("button", {
            className: (0, classnames_1.default)(OptionalBlueprint_1.OptionalBlueprint.getClasses(this.context.blueprintNamespace, 'BUTTON'), OptionalBlueprint_1.OptionalBlueprint.getIconClass(this.context.blueprintNamespace, 'ADD')),
            onClick: this.replace
        }, "Add New Window")));
    };
    MosaicZeroState.contextType = contextTypes_1.MosaicContext;
    return MosaicZeroState;
}(react_1.default.PureComponent);
exports.MosaicZeroState = MosaicZeroState; //# sourceMappingURL=MosaicZeroState.js.map
}),
"[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/internalTypes.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.MosaicDropTargetPosition = void 0;
exports.MosaicDropTargetPosition = {
    TOP: 'top',
    BOTTOM: 'bottom',
    LEFT: 'left',
    RIGHT: 'right'
}; //# sourceMappingURL=internalTypes.js.map
}),
"[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/types.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.MosaicDragType = void 0;
/**
 * Used by `react-dnd`
 * @type {{WINDOW: string}}
 */ exports.MosaicDragType = {
    WINDOW: 'MosaicWindow'
}; //# sourceMappingURL=types.js.map
}),
"[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/MosaicDropTarget.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __createBinding = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __setModuleDefault = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
});
var __importStar = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__importStar || function(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) {
        for(var k in mod)if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    }
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.MosaicDropTarget = void 0;
var classnames_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/classnames@2.5.1/node_modules/classnames/index.js [app-client] (ecmascript)"));
var react_1 = __importStar(__turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
var react_dnd_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-dnd@16.0.1_@types+node@24.10.9_@types+react@19.2.9_react@19.2.1/node_modules/react-dnd/dist/index.js [app-client] (ecmascript)");
var contextTypes_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/contextTypes.js [app-client] (ecmascript)");
var types_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/types.js [app-client] (ecmascript)");
function MosaicDropTarget(_a) {
    var path = _a.path, position = _a.position;
    var mosaicId = (0, react_1.useContext)(contextTypes_1.MosaicContext).mosaicId;
    var _b = (0, react_dnd_1.useDrop)({
        accept: types_1.MosaicDragType.WINDOW,
        drop: function(item, _monitor) {
            if (mosaicId === (item === null || item === void 0 ? void 0 : item.mosaicId)) {
                return {
                    path: path,
                    position: position
                };
            } else {
                return {};
            }
        },
        collect: function(monitor) {
            return {
                isOver: monitor.isOver(),
                draggedMosaicId: (monitor.getItem() || {}).mosaicId
            };
        }
    }), _c = _b[0], isOver = _c.isOver, draggedMosaicId = _c.draggedMosaicId, connectDropTarget = _b[1];
    return react_1.default.createElement("div", {
        ref: connectDropTarget,
        className: (0, classnames_1.default)('drop-target', position, {
            'drop-target-hover': isOver && draggedMosaicId === mosaicId
        })
    });
}
exports.MosaicDropTarget = MosaicDropTarget; //# sourceMappingURL=MosaicDropTarget.js.map
}),
"[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/RootDropTargets.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __importDefault = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.RootDropTargets = void 0;
var classnames_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/classnames@2.5.1/node_modules/classnames/index.js [app-client] (ecmascript)"));
var values_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/lodash@4.17.23/node_modules/lodash/values.js [app-client] (ecmascript)"));
var react_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
var react_dnd_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-dnd@16.0.1_@types+node@24.10.9_@types+react@19.2.9_react@19.2.1/node_modules/react-dnd/dist/index.js [app-client] (ecmascript)");
var internalTypes_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/internalTypes.js [app-client] (ecmascript)");
var MosaicDropTarget_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/MosaicDropTarget.js [app-client] (ecmascript)");
var types_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/types.js [app-client] (ecmascript)");
exports.RootDropTargets = react_1.default.memo(function() {
    var isDragging = (0, react_dnd_1.useDrop)({
        accept: types_1.MosaicDragType.WINDOW,
        collect: function(monitor) {
            return {
                isDragging: monitor.getItem() !== null && monitor.getItemType() === types_1.MosaicDragType.WINDOW
            };
        }
    })[0].isDragging;
    var delayedIsDragging = useDelayedTrue(isDragging, 0);
    return react_1.default.createElement("div", {
        className: (0, classnames_1.default)('drop-target-container', {
            '-dragging': delayedIsDragging
        })
    }, (0, values_1.default)(internalTypes_1.MosaicDropTargetPosition).map(function(position) {
        return react_1.default.createElement(MosaicDropTarget_1.MosaicDropTarget, {
            position: position,
            path: [],
            key: position
        });
    }));
});
exports.RootDropTargets.displayName = 'RootDropTargets';
function useDelayedTrue(currentValue, delay) {
    var delayedRef = react_1.default.useRef(currentValue);
    var _a = react_1.default.useState(0), setCounter = _a[1];
    var setAndRender = function(newValue) {
        delayedRef.current = newValue;
        setCounter(function(count) {
            return count + 1;
        });
    };
    if (!currentValue) {
        delayedRef.current = false;
    }
    react_1.default.useEffect({
        "useDelayedTrue.useEffect": function() {
            if (delayedRef.current === currentValue || !currentValue) {
                return;
            }
            var timer = window.setTimeout({
                "useDelayedTrue.useEffect.timer": function() {
                    return setAndRender(true);
                }
            }["useDelayedTrue.useEffect.timer"], delay);
            return ({
                "useDelayedTrue.useEffect": function() {
                    window.clearTimeout(timer);
                }
            })["useDelayedTrue.useEffect"];
        }
    }["useDelayedTrue.useEffect"], [
        currentValue
    ]);
    return delayedRef.current;
} //# sourceMappingURL=RootDropTargets.js.map
}),
"[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/util/mosaicUpdates.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __importDefault = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.createExpandUpdate = exports.createHideUpdate = exports.createDragToUpdates = exports.createRemoveUpdate = exports.updateTree = exports.buildSpecFromUpdate = void 0;
var immutability_helper_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/immutability-helper@3.1.1/node_modules/immutability-helper/index.js [app-client] (ecmascript)"));
var drop_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/lodash@4.17.23/node_modules/lodash/drop.js [app-client] (ecmascript)"));
var dropRight_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/lodash@4.17.23/node_modules/lodash/dropRight.js [app-client] (ecmascript)"));
var isEqual_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/lodash@4.17.23/node_modules/lodash/isEqual.js [app-client] (ecmascript)"));
var last_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/lodash@4.17.23/node_modules/lodash/last.js [app-client] (ecmascript)"));
var set_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/lodash@4.17.23/node_modules/lodash/set.js [app-client] (ecmascript)"));
var take_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/lodash@4.17.23/node_modules/lodash/take.js [app-client] (ecmascript)"));
var internalTypes_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/internalTypes.js [app-client] (ecmascript)");
var mosaicUtilities_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/util/mosaicUtilities.js [app-client] (ecmascript)");
/**
 * Used to prepare `update` for `immutability-helper`
 * @param mosaicUpdate
 * @returns {any}
 */ function buildSpecFromUpdate(mosaicUpdate) {
    if (mosaicUpdate.path.length > 0) {
        return (0, set_1.default)({}, mosaicUpdate.path, mosaicUpdate.spec);
    } else {
        return mosaicUpdate.spec;
    }
}
exports.buildSpecFromUpdate = buildSpecFromUpdate;
/**
 * Applies `updates` to `root`
 * @param root
 * @param updates
 * @returns {MosaicNode<T>}
 */ function updateTree(root, updates) {
    var currentNode = root;
    updates.forEach(function(mUpdate) {
        currentNode = (0, immutability_helper_1.default)(currentNode, buildSpecFromUpdate(mUpdate));
    });
    return currentNode;
}
exports.updateTree = updateTree;
/**
 * Creates a `MosaicUpdate<T>` to remove the node at `path` from `root`
 * @param root
 * @param path
 * @returns {{path: T[], spec: {$set: MosaicNode<T>}}}
 */ function createRemoveUpdate(root, path) {
    var parentPath = (0, dropRight_1.default)(path);
    var nodeToRemove = (0, last_1.default)(path);
    var siblingPath = parentPath.concat((0, mosaicUtilities_1.getOtherBranch)(nodeToRemove));
    var sibling = (0, mosaicUtilities_1.getAndAssertNodeAtPathExists)(root, siblingPath);
    return {
        path: parentPath,
        spec: {
            $set: sibling
        }
    };
}
exports.createRemoveUpdate = createRemoveUpdate;
function isPathPrefixEqual(a, b, length) {
    return (0, isEqual_1.default)((0, take_1.default)(a, length), (0, take_1.default)(b, length));
}
/**
 * Creates a `MosaicUpdate<T>` to split the _leaf_ at `destinationPath` into a node of it and the node from `sourcePath`
 * placing the node from `sourcePath` in `position`.
 * @param root
 * @param sourcePath
 * @param destinationPath
 * @param position
 * @returns {(MosaicUpdate<T>|{path: MosaicPath, spec: {$set: {first: MosaicNode<T>, second: MosaicNode<T>, direction: MosaicDirection}}})[]}
 */ function createDragToUpdates(root, sourcePath, destinationPath, position) {
    var destinationNode = (0, mosaicUtilities_1.getAndAssertNodeAtPathExists)(root, destinationPath);
    var updates = [];
    var destinationIsParentOfSource = isPathPrefixEqual(sourcePath, destinationPath, destinationPath.length);
    if (destinationIsParentOfSource) {
        // Must explicitly remove source from the destination node
        destinationNode = updateTree(destinationNode, [
            createRemoveUpdate(destinationNode, (0, drop_1.default)(sourcePath, destinationPath.length))
        ]);
    } else {
        // Can remove source normally
        updates.push(createRemoveUpdate(root, sourcePath));
        // Have to drop in the correct destination after the source has been removed
        var removedNodeParentIsInPath = isPathPrefixEqual(sourcePath, destinationPath, sourcePath.length - 1);
        if (removedNodeParentIsInPath) {
            destinationPath.splice(sourcePath.length - 1, 1);
        }
    }
    var sourceNode = (0, mosaicUtilities_1.getAndAssertNodeAtPathExists)(root, sourcePath);
    var first;
    var second;
    if (position === internalTypes_1.MosaicDropTargetPosition.LEFT || position === internalTypes_1.MosaicDropTargetPosition.TOP) {
        first = sourceNode;
        second = destinationNode;
    } else {
        first = destinationNode;
        second = sourceNode;
    }
    var direction = 'column';
    if (position === internalTypes_1.MosaicDropTargetPosition.LEFT || position === internalTypes_1.MosaicDropTargetPosition.RIGHT) {
        direction = 'row';
    }
    updates.push({
        path: destinationPath,
        spec: {
            $set: {
                first: first,
                second: second,
                direction: direction
            }
        }
    });
    return updates;
}
exports.createDragToUpdates = createDragToUpdates;
/**
 * Sets the splitPercentage to hide the node at `path`
 * @param path
 * @returns {{path: T[], spec: {splitPercentage: {$set: number}}}}
 */ function createHideUpdate(path) {
    var targetPath = (0, dropRight_1.default)(path);
    var thisBranch = (0, last_1.default)(path);
    var splitPercentage;
    if (thisBranch === 'first') {
        splitPercentage = 0;
    } else {
        splitPercentage = 100;
    }
    return {
        path: targetPath,
        spec: {
            splitPercentage: {
                $set: splitPercentage
            }
        }
    };
}
exports.createHideUpdate = createHideUpdate;
/**
 * Sets the splitPercentage of node at `path` and all of its parents to `percentage` in order to expand it
 * @param path
 * @param percentage
 * @returns {{spec: MosaicUpdateSpec<T>, path: Array}}
 */ function createExpandUpdate(path, percentage) {
    var _a;
    var spec = {};
    for(var i = path.length - 1; i >= 0; i--){
        var branch = path[i];
        var splitPercentage = branch === 'first' ? percentage : 100 - percentage;
        spec = (_a = {
            splitPercentage: {
                $set: splitPercentage
            }
        }, _a[branch] = spec, _a);
    }
    return {
        spec: spec,
        path: []
    };
}
exports.createExpandUpdate = createExpandUpdate; //# sourceMappingURL=mosaicUpdates.js.map
}),
"[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/Mosaic.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
var __extends = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__extends || function() {
    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || ({
            __proto__: []
        }) instanceof Array && function(d, b) {
            d.__proto__ = b;
        } || function(d, b) {
            for(var p in b)if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
        };
        return extendStatics(d, b);
    };
    return function(d, b) {
        if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() {
            this.constructor = d;
        }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
}();
var __assign = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__assign || function() {
    __assign = Object.assign || function(t) {
        for(var s, i = 1, n = arguments.length; i < n; i++){
            s = arguments[i];
            for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __importDefault = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Mosaic = exports.MosaicWithoutDragDropContext = void 0;
var classnames_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/classnames@2.5.1/node_modules/classnames/index.js [app-client] (ecmascript)"));
var countBy_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/lodash@4.17.23/node_modules/lodash/countBy.js [app-client] (ecmascript)"));
var keys_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/lodash@4.17.23/node_modules/lodash/keys.js [app-client] (ecmascript)"));
var pickBy_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/lodash@4.17.23/node_modules/lodash/pickBy.js [app-client] (ecmascript)"));
var rdndmb_html5_to_touch_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/rdndmb-html5-to-touch@8.1.2_dnd-core@16.0.1/node_modules/rdndmb-html5-to-touch/dist/index.js [app-client] (ecmascript)");
var react_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
var react_dnd_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-dnd@16.0.1_@types+node@24.10.9_@types+react@19.2.9_react@19.2.1/node_modules/react-dnd/dist/index.js [app-client] (ecmascript)");
var react_dnd_multi_backend_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-dnd-multi-backend@8.1.2_dnd-core@16.0.1_react-dnd@16.0.1_@types+node@24.10.9_@types+rea_pdtzydzhwhxaghcnub657f7in4/node_modules/react-dnd-multi-backend/dist/index.js [app-client] (ecmascript)");
var uuid_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/uuid@9.0.1/node_modules/uuid/dist/commonjs-browser/index.js [app-client] (ecmascript)");
var contextTypes_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/contextTypes.js [app-client] (ecmascript)");
var MosaicRoot_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/MosaicRoot.js [app-client] (ecmascript)");
var MosaicZeroState_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/MosaicZeroState.js [app-client] (ecmascript)");
var RootDropTargets_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/RootDropTargets.js [app-client] (ecmascript)");
var mosaicUpdates_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/util/mosaicUpdates.js [app-client] (ecmascript)");
var mosaicUtilities_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/util/mosaicUtilities.js [app-client] (ecmascript)");
var DEFAULT_EXPAND_PERCENTAGE = 70;
function isUncontrolled(props) {
    return props.initialValue != null;
}
var MosaicWithoutDragDropContext = function(_super) {
    __extends(MosaicWithoutDragDropContext, _super);
    function MosaicWithoutDragDropContext() {
        var _this = this;
        var _a;
        _this = _super.apply(this, arguments) || this;
        _this.state = {
            currentNode: null,
            lastInitialValue: null,
            mosaicId: (_a = _this.props.mosaicId) !== null && _a !== void 0 ? _a : (0, uuid_1.v4)()
        };
        _this.updateRoot = function(updates, suppressOnRelease) {
            if (suppressOnRelease === void 0) {
                suppressOnRelease = false;
            }
            var currentNode = _this.getRoot() || {};
            _this.replaceRoot((0, mosaicUpdates_1.updateTree)(currentNode, updates), suppressOnRelease);
        };
        _this.replaceRoot = function(currentNode, suppressOnRelease) {
            if (suppressOnRelease === void 0) {
                suppressOnRelease = false;
            }
            _this.props.onChange(currentNode);
            if (!suppressOnRelease && _this.props.onRelease) {
                _this.props.onRelease(currentNode);
            }
            if (isUncontrolled(_this.props)) {
                _this.setState({
                    currentNode: currentNode
                });
            }
        };
        _this.actions = {
            updateTree: _this.updateRoot,
            remove: function(path) {
                if (path.length === 0) {
                    _this.replaceRoot(null);
                } else {
                    _this.updateRoot([
                        (0, mosaicUpdates_1.createRemoveUpdate)(_this.getRoot(), path)
                    ]);
                }
            },
            expand: function(path, percentage) {
                if (percentage === void 0) {
                    percentage = DEFAULT_EXPAND_PERCENTAGE;
                }
                return _this.updateRoot([
                    (0, mosaicUpdates_1.createExpandUpdate)(path, percentage)
                ]);
            },
            getRoot: function() {
                return _this.getRoot();
            },
            hide: function(path) {
                return _this.updateRoot([
                    (0, mosaicUpdates_1.createHideUpdate)(path)
                ]);
            },
            replaceWith: function(path, newNode) {
                return _this.updateRoot([
                    {
                        path: path,
                        spec: {
                            $set: newNode
                        }
                    }
                ]);
            }
        };
        _this.childContext = {
            mosaicActions: _this.actions,
            mosaicId: _this.state.mosaicId,
            blueprintNamespace: _this.props.blueprintNamespace
        };
        return _this;
    }
    MosaicWithoutDragDropContext.getDerivedStateFromProps = function(nextProps, prevState) {
        if (nextProps.mosaicId && prevState.mosaicId !== nextProps.mosaicId && ("TURBOPACK compile-time value", "development") !== 'production') {
            throw new Error('Mosaic does not support updating the mosaicId after instantiation');
        }
        if (isUncontrolled(nextProps) && nextProps.initialValue !== prevState.lastInitialValue) {
            return {
                lastInitialValue: nextProps.initialValue,
                currentNode: nextProps.initialValue
            };
        }
        return null;
    };
    MosaicWithoutDragDropContext.prototype.render = function() {
        var className = this.props.className;
        return react_1.default.createElement(contextTypes_1.MosaicContext.Provider, {
            value: this.childContext
        }, react_1.default.createElement("div", {
            className: (0, classnames_1.default)(className, 'mosaic mosaic-drop-target')
        }, this.renderTree(), react_1.default.createElement(RootDropTargets_1.RootDropTargets, null)));
    };
    MosaicWithoutDragDropContext.prototype.getRoot = function() {
        if (isUncontrolled(this.props)) {
            return this.state.currentNode;
        } else {
            return this.props.value;
        }
    };
    MosaicWithoutDragDropContext.prototype.renderTree = function() {
        var root = this.getRoot();
        this.validateTree(root);
        if (root === null || root === undefined) {
            return this.props.zeroStateView;
        } else {
            var _a = this.props, renderTile = _a.renderTile, resize = _a.resize;
            return react_1.default.createElement(MosaicRoot_1.MosaicRoot, {
                root: root,
                renderTile: renderTile,
                resize: resize
            });
        }
    };
    MosaicWithoutDragDropContext.prototype.validateTree = function(node) {
        if ("TURBOPACK compile-time truthy", 1) {
            var duplicates = (0, keys_1.default)((0, pickBy_1.default)((0, countBy_1.default)((0, mosaicUtilities_1.getLeaves)(node)), function(n) {
                return n > 1;
            }));
            if (duplicates.length > 0) {
                throw new Error("Duplicate IDs [".concat(duplicates.join(', '), "] detected. Mosaic does not support leaves with the same ID"));
            }
        }
    };
    MosaicWithoutDragDropContext.defaultProps = {
        onChange: function() {
            return void 0;
        },
        zeroStateView: react_1.default.createElement(MosaicZeroState_1.MosaicZeroState, null),
        className: 'mosaic-blueprint-theme',
        blueprintNamespace: 'bp3'
    };
    return MosaicWithoutDragDropContext;
}(react_1.default.PureComponent);
exports.MosaicWithoutDragDropContext = MosaicWithoutDragDropContext;
var Mosaic = function(_super) {
    __extends(Mosaic, _super);
    function Mosaic() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Mosaic.prototype.render = function() {
        return react_1.default.createElement(react_dnd_1.DndProvider, __assign({
            backend: react_dnd_multi_backend_1.MultiBackend,
            options: rdndmb_html5_to_touch_1.HTML5toTouch
        }, this.props.dragAndDropManager && {
            manager: this.props.dragAndDropManager
        }), react_1.default.createElement(MosaicWithoutDragDropContext, __assign({}, this.props)));
    };
    return Mosaic;
}(react_1.default.PureComponent);
exports.Mosaic = Mosaic; //# sourceMappingURL=Mosaic.js.map
}),
"[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/buttons/MosaicButton.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __importDefault = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.createDefaultToolbarButton = exports.DefaultToolbarButton = void 0;
var classnames_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/classnames@2.5.1/node_modules/classnames/index.js [app-client] (ecmascript)"));
var react_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
var contextTypes_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/contextTypes.js [app-client] (ecmascript)");
var OptionalBlueprint_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/util/OptionalBlueprint.js [app-client] (ecmascript)");
var DefaultToolbarButton = function(_a) {
    var title = _a.title, className = _a.className, onClick = _a.onClick, text = _a.text;
    var blueprintNamespace = react_1.default.useContext(contextTypes_1.MosaicContext).blueprintNamespace;
    return react_1.default.createElement("button", {
        title: title,
        onClick: onClick,
        className: (0, classnames_1.default)('mosaic-default-control', OptionalBlueprint_1.OptionalBlueprint.getClasses(blueprintNamespace, 'BUTTON', 'MINIMAL'), className)
    }, text && react_1.default.createElement("span", {
        className: "control-text"
    }, text));
};
exports.DefaultToolbarButton = DefaultToolbarButton;
/**
 * @deprecated: see @DefaultToolbarButton
 */ var createDefaultToolbarButton = function(title, className, onClick, text) {
    return react_1.default.createElement(exports.DefaultToolbarButton, {
        title: title,
        className: className,
        onClick: onClick,
        text: text
    });
};
exports.createDefaultToolbarButton = createDefaultToolbarButton; //# sourceMappingURL=MosaicButton.js.map
}),
"[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/buttons/ExpandButton.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __extends = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__extends || function() {
    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || ({
            __proto__: []
        }) instanceof Array && function(d, b) {
            d.__proto__ = b;
        } || function(d, b) {
            for(var p in b)if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
        };
        return extendStatics(d, b);
    };
    return function(d, b) {
        if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() {
            this.constructor = d;
        }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
}();
var __importDefault = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.ExpandButton = void 0;
var classnames_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/classnames@2.5.1/node_modules/classnames/index.js [app-client] (ecmascript)"));
var react_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
var contextTypes_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/contextTypes.js [app-client] (ecmascript)");
var OptionalBlueprint_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/util/OptionalBlueprint.js [app-client] (ecmascript)");
var MosaicButton_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/buttons/MosaicButton.js [app-client] (ecmascript)");
var ExpandButton = function(_super) {
    __extends(ExpandButton, _super);
    function ExpandButton() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    ExpandButton.prototype.render = function() {
        var _this = this;
        return react_1.default.createElement(contextTypes_1.MosaicContext.Consumer, null, function(_a) {
            var mosaicActions = _a.mosaicActions;
            return react_1.default.createElement(MosaicButton_1.DefaultToolbarButton, {
                title: "Expand",
                className: (0, classnames_1.default)('expand-button', OptionalBlueprint_1.OptionalBlueprint.getIconClass(_this.context.blueprintNamespace, 'MAXIMIZE')),
                onClick: _this.createExpand(mosaicActions)
            });
        });
    };
    ExpandButton.prototype.createExpand = function(mosaicActions) {
        var _this = this;
        return function() {
            mosaicActions.expand(_this.context.mosaicWindowActions.getPath());
            if (_this.props.onClick) {
                _this.props.onClick();
            }
        };
    };
    ExpandButton.contextType = contextTypes_1.MosaicWindowContext;
    return ExpandButton;
}(react_1.default.PureComponent);
exports.ExpandButton = ExpandButton; //# sourceMappingURL=ExpandButton.js.map
}),
"[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/buttons/RemoveButton.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __extends = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__extends || function() {
    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || ({
            __proto__: []
        }) instanceof Array && function(d, b) {
            d.__proto__ = b;
        } || function(d, b) {
            for(var p in b)if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
        };
        return extendStatics(d, b);
    };
    return function(d, b) {
        if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() {
            this.constructor = d;
        }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
}();
var __importDefault = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.RemoveButton = void 0;
var classnames_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/classnames@2.5.1/node_modules/classnames/index.js [app-client] (ecmascript)"));
var react_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
var contextTypes_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/contextTypes.js [app-client] (ecmascript)");
var OptionalBlueprint_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/util/OptionalBlueprint.js [app-client] (ecmascript)");
var MosaicButton_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/buttons/MosaicButton.js [app-client] (ecmascript)");
var RemoveButton = function(_super) {
    __extends(RemoveButton, _super);
    function RemoveButton() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    RemoveButton.prototype.render = function() {
        var _this = this;
        return react_1.default.createElement(contextTypes_1.MosaicContext.Consumer, null, function(_a) {
            var mosaicActions = _a.mosaicActions, blueprintNamespace = _a.blueprintNamespace;
            return react_1.default.createElement(MosaicButton_1.DefaultToolbarButton, {
                title: "Close Window",
                className: (0, classnames_1.default)('close-button', OptionalBlueprint_1.OptionalBlueprint.getIconClass(blueprintNamespace, 'CROSS')),
                onClick: _this.createRemove(mosaicActions)
            });
        });
    };
    RemoveButton.prototype.createRemove = function(mosaicActions) {
        var _this = this;
        return function() {
            mosaicActions.remove(_this.context.mosaicWindowActions.getPath());
            if (_this.props.onClick) {
                _this.props.onClick();
            }
        };
    };
    RemoveButton.contextType = contextTypes_1.MosaicWindowContext;
    return RemoveButton;
}(react_1.default.PureComponent);
exports.RemoveButton = RemoveButton; //# sourceMappingURL=RemoveButton.js.map
}),
"[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/buttons/ReplaceButton.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __extends = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__extends || function() {
    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || ({
            __proto__: []
        }) instanceof Array && function(d, b) {
            d.__proto__ = b;
        } || function(d, b) {
            for(var p in b)if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
        };
        return extendStatics(d, b);
    };
    return function(d, b) {
        if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() {
            this.constructor = d;
        }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
}();
var __importDefault = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.ReplaceButton = void 0;
var classnames_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/classnames@2.5.1/node_modules/classnames/index.js [app-client] (ecmascript)"));
var noop_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/lodash@4.17.23/node_modules/lodash/noop.js [app-client] (ecmascript)"));
var react_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
var contextTypes_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/contextTypes.js [app-client] (ecmascript)");
var OptionalBlueprint_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/util/OptionalBlueprint.js [app-client] (ecmascript)");
var MosaicButton_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/buttons/MosaicButton.js [app-client] (ecmascript)");
var ReplaceButton = function(_super) {
    __extends(ReplaceButton, _super);
    function ReplaceButton() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.replace = function() {
            _this.context.mosaicWindowActions.replaceWithNew().then(function() {
                if (_this.props.onClick) {
                    _this.props.onClick();
                }
            }).catch(noop_1.default); // Swallow rejections (i.e. on user cancel)
        };
        return _this;
    }
    ReplaceButton.prototype.render = function() {
        return react_1.default.createElement(MosaicButton_1.DefaultToolbarButton, {
            title: "Replace Window",
            className: (0, classnames_1.default)('replace-button', OptionalBlueprint_1.OptionalBlueprint.getIconClass(this.context.blueprintNamespace, 'EXCHANGE')),
            onClick: this.replace
        });
    };
    ReplaceButton.contextType = contextTypes_1.MosaicWindowContext;
    return ReplaceButton;
}(react_1.default.PureComponent);
exports.ReplaceButton = ReplaceButton; //# sourceMappingURL=ReplaceButton.js.map
}),
"[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/buttons/SplitButton.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __extends = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__extends || function() {
    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || ({
            __proto__: []
        }) instanceof Array && function(d, b) {
            d.__proto__ = b;
        } || function(d, b) {
            for(var p in b)if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
        };
        return extendStatics(d, b);
    };
    return function(d, b) {
        if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() {
            this.constructor = d;
        }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
}();
var __importDefault = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SplitButton = void 0;
var classnames_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/classnames@2.5.1/node_modules/classnames/index.js [app-client] (ecmascript)"));
var noop_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/lodash@4.17.23/node_modules/lodash/noop.js [app-client] (ecmascript)"));
var react_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
var contextTypes_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/contextTypes.js [app-client] (ecmascript)");
var OptionalBlueprint_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/util/OptionalBlueprint.js [app-client] (ecmascript)");
var MosaicButton_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/buttons/MosaicButton.js [app-client] (ecmascript)");
var SplitButton = function(_super) {
    __extends(SplitButton, _super);
    function SplitButton() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.split = function() {
            _this.context.mosaicWindowActions.split().then(function() {
                if (_this.props.onClick) {
                    _this.props.onClick();
                }
            }).catch(noop_1.default); // Swallow rejections (i.e. on user cancel)
        };
        return _this;
    }
    SplitButton.prototype.render = function() {
        return react_1.default.createElement(MosaicButton_1.DefaultToolbarButton, {
            title: "Split Window",
            className: (0, classnames_1.default)('split-button', OptionalBlueprint_1.OptionalBlueprint.getIconClass(this.context.blueprintNamespace, 'ADD_COLUMN_RIGHT')),
            onClick: this.split
        });
    };
    SplitButton.contextType = contextTypes_1.MosaicWindowContext;
    return SplitButton;
}(react_1.default.PureComponent);
exports.SplitButton = SplitButton; //# sourceMappingURL=SplitButton.js.map
}),
"[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/buttons/defaultToolbarControls.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __importDefault = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.DEFAULT_CONTROLS_WITHOUT_CREATION = exports.DEFAULT_CONTROLS_WITH_CREATION = void 0;
var react_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
var ExpandButton_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/buttons/ExpandButton.js [app-client] (ecmascript)");
var RemoveButton_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/buttons/RemoveButton.js [app-client] (ecmascript)");
var ReplaceButton_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/buttons/ReplaceButton.js [app-client] (ecmascript)");
var SplitButton_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/buttons/SplitButton.js [app-client] (ecmascript)");
exports.DEFAULT_CONTROLS_WITH_CREATION = react_1.default.Children.toArray([
    react_1.default.createElement(ReplaceButton_1.ReplaceButton, null),
    react_1.default.createElement(SplitButton_1.SplitButton, null),
    react_1.default.createElement(ExpandButton_1.ExpandButton, null),
    react_1.default.createElement(RemoveButton_1.RemoveButton, null)
]);
exports.DEFAULT_CONTROLS_WITHOUT_CREATION = react_1.default.Children.toArray([
    react_1.default.createElement(ExpandButton_1.ExpandButton, null),
    react_1.default.createElement(RemoveButton_1.RemoveButton, null)
]); //# sourceMappingURL=defaultToolbarControls.js.map
}),
"[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/buttons/Separator.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __extends = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__extends || function() {
    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || ({
            __proto__: []
        }) instanceof Array && function(d, b) {
            d.__proto__ = b;
        } || function(d, b) {
            for(var p in b)if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
        };
        return extendStatics(d, b);
    };
    return function(d, b) {
        if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() {
            this.constructor = d;
        }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
}();
var __importDefault = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Separator = void 0;
var react_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
var Separator = function(_super) {
    __extends(Separator, _super);
    function Separator() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Separator.prototype.render = function() {
        return react_1.default.createElement("div", {
            className: "separator"
        });
    };
    return Separator;
}(react_1.default.PureComponent);
exports.Separator = Separator; //# sourceMappingURL=Separator.js.map
}),
"[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/MosaicWindow.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __extends = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__extends || function() {
    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || ({
            __proto__: []
        }) instanceof Array && function(d, b) {
            d.__proto__ = b;
        } || function(d, b) {
            for(var p in b)if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
        };
        return extendStatics(d, b);
    };
    return function(d, b) {
        if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() {
            this.constructor = d;
        }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
}();
var __assign = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__assign || function() {
    __assign = Object.assign || function(t) {
        for(var s, i = 1, n = arguments.length; i < n; i++){
            s = arguments[i];
            for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __createBinding = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __setModuleDefault = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
});
var __importStar = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__importStar || function(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) {
        for(var k in mod)if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    }
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.MosaicWindow = exports.InternalMosaicWindow = void 0;
var classnames_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/classnames@2.5.1/node_modules/classnames/index.js [app-client] (ecmascript)"));
var defer_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/lodash@4.17.23/node_modules/lodash/defer.js [app-client] (ecmascript)"));
var dropRight_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/lodash@4.17.23/node_modules/lodash/dropRight.js [app-client] (ecmascript)"));
var isEmpty_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/lodash@4.17.23/node_modules/lodash/isEmpty.js [app-client] (ecmascript)"));
var isEqual_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/lodash@4.17.23/node_modules/lodash/isEqual.js [app-client] (ecmascript)"));
var values_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/lodash@4.17.23/node_modules/lodash/values.js [app-client] (ecmascript)"));
var react_1 = __importStar(__turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
var react_dnd_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-dnd@16.0.1_@types+node@24.10.9_@types+react@19.2.9_react@19.2.1/node_modules/react-dnd/dist/index.js [app-client] (ecmascript)");
var defaultToolbarControls_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/buttons/defaultToolbarControls.js [app-client] (ecmascript)");
var Separator_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/buttons/Separator.js [app-client] (ecmascript)");
var contextTypes_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/contextTypes.js [app-client] (ecmascript)");
var internalTypes_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/internalTypes.js [app-client] (ecmascript)");
var MosaicDropTarget_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/MosaicDropTarget.js [app-client] (ecmascript)");
var types_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/types.js [app-client] (ecmascript)");
var mosaicUpdates_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/util/mosaicUpdates.js [app-client] (ecmascript)");
var mosaicUtilities_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/util/mosaicUtilities.js [app-client] (ecmascript)");
var OptionalBlueprint_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/util/OptionalBlueprint.js [app-client] (ecmascript)");
var InternalMosaicWindow = function(_super) {
    __extends(InternalMosaicWindow, _super);
    function InternalMosaicWindow() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.state = {
            additionalControlsOpen: false
        };
        _this.rootElement = null;
        _this.renderDropTarget = function(position) {
            var path = _this.props.path;
            return react_1.default.createElement(MosaicDropTarget_1.MosaicDropTarget, {
                position: position,
                path: path,
                key: position
            });
        };
        _this.split = function() {
            var args = [];
            for(var _i = 0; _i < arguments.length; _i++){
                args[_i] = arguments[_i];
            }
            _this.checkCreateNode();
            var _a = _this.props, createNode = _a.createNode, path = _a.path;
            var mosaicActions = _this.context.mosaicActions;
            var root = mosaicActions.getRoot();
            var direction = _this.rootElement.offsetWidth > _this.rootElement.offsetHeight ? 'row' : 'column';
            return Promise.resolve(createNode.apply(void 0, args)).then(function(second) {
                return mosaicActions.replaceWith(path, {
                    direction: direction,
                    second: second,
                    first: (0, mosaicUtilities_1.getAndAssertNodeAtPathExists)(root, path)
                });
            });
        };
        _this.swap = function() {
            var args = [];
            for(var _i = 0; _i < arguments.length; _i++){
                args[_i] = arguments[_i];
            }
            _this.checkCreateNode();
            var mosaicActions = _this.context.mosaicActions;
            var _a = _this.props, createNode = _a.createNode, path = _a.path;
            return Promise.resolve(createNode.apply(void 0, args)).then(function(node) {
                return mosaicActions.replaceWith(path, node);
            });
        };
        _this.setAdditionalControlsOpen = function(additionalControlsOpenOption) {
            var _a, _b;
            var additionalControlsOpen = additionalControlsOpenOption === 'toggle' ? !_this.state.additionalControlsOpen : additionalControlsOpenOption;
            _this.setState({
                additionalControlsOpen: additionalControlsOpen
            });
            (_b = (_a = _this.props).onAdditionalControlsToggle) === null || _b === void 0 ? void 0 : _b.call(_a, additionalControlsOpen);
        };
        _this.getPath = function() {
            return _this.props.path;
        };
        _this.connectDragSource = function(connectedElements) {
            var connectDragSource = _this.props.connectDragSource;
            return connectDragSource(connectedElements);
        };
        _this.childContext = {
            blueprintNamespace: _this.context.blueprintNamespace,
            mosaicWindowActions: {
                split: _this.split,
                replaceWithNew: _this.swap,
                setAdditionalControlsOpen: _this.setAdditionalControlsOpen,
                getPath: _this.getPath,
                connectDragSource: _this.connectDragSource
            }
        };
        return _this;
    }
    InternalMosaicWindow.prototype.render = function() {
        var _this = this;
        var _a = this.props, className = _a.className, isOver = _a.isOver, renderPreview = _a.renderPreview, additionalControls = _a.additionalControls, connectDropTarget = _a.connectDropTarget, connectDragPreview = _a.connectDragPreview, draggedMosaicId = _a.draggedMosaicId, disableAdditionalControlsOverlay = _a.disableAdditionalControlsOverlay;
        return react_1.default.createElement(contextTypes_1.MosaicWindowContext.Provider, {
            value: this.childContext
        }, connectDropTarget(react_1.default.createElement("div", {
            className: (0, classnames_1.default)('mosaic-window mosaic-drop-target', className, {
                'drop-target-hover': isOver && draggedMosaicId === this.context.mosaicId,
                'additional-controls-open': this.state.additionalControlsOpen
            }),
            ref: function(element) {
                return _this.rootElement = element;
            }
        }, this.renderToolbar(), react_1.default.createElement("div", {
            className: "mosaic-window-body"
        }, this.props.children), !disableAdditionalControlsOverlay && react_1.default.createElement("div", {
            className: "mosaic-window-body-overlay",
            onClick: function() {
                _this.setAdditionalControlsOpen(false);
            }
        }), react_1.default.createElement("div", {
            className: "mosaic-window-additional-actions-bar"
        }, additionalControls), connectDragPreview(renderPreview(this.props)), react_1.default.createElement("div", {
            className: "drop-target-container"
        }, (0, values_1.default)(internalTypes_1.MosaicDropTargetPosition).map(this.renderDropTarget)))));
    };
    InternalMosaicWindow.prototype.getToolbarControls = function() {
        var _a = this.props, toolbarControls = _a.toolbarControls, createNode = _a.createNode;
        if (toolbarControls) {
            return toolbarControls;
        } else if (createNode) {
            return defaultToolbarControls_1.DEFAULT_CONTROLS_WITH_CREATION;
        } else {
            return defaultToolbarControls_1.DEFAULT_CONTROLS_WITHOUT_CREATION;
        }
    };
    InternalMosaicWindow.prototype.renderToolbar = function() {
        var _a;
        var _this = this;
        var _b = this.props, title = _b.title, draggable = _b.draggable, additionalControls = _b.additionalControls, additionalControlButtonText = _b.additionalControlButtonText, path = _b.path, renderToolbar = _b.renderToolbar;
        var additionalControlsOpen = this.state.additionalControlsOpen;
        var toolbarControls = this.getToolbarControls();
        var draggableAndNotRoot = draggable && path.length > 0;
        var connectIfDraggable = draggableAndNotRoot ? this.props.connectDragSource : function(el) {
            return el;
        };
        if (renderToolbar) {
            var connectedToolbar = connectIfDraggable(renderToolbar(this.props, draggable));
            return react_1.default.createElement("div", {
                className: (0, classnames_1.default)('mosaic-window-toolbar', {
                    draggable: draggableAndNotRoot
                })
            }, connectedToolbar);
        }
        var titleDiv = connectIfDraggable(react_1.default.createElement("div", {
            title: title,
            className: "mosaic-window-title"
        }, title));
        var hasAdditionalControls = !(0, isEmpty_1.default)(additionalControls);
        return react_1.default.createElement("div", {
            className: (0, classnames_1.default)('mosaic-window-toolbar', {
                draggable: draggableAndNotRoot
            })
        }, titleDiv, react_1.default.createElement("div", {
            className: (0, classnames_1.default)('mosaic-window-controls', OptionalBlueprint_1.OptionalBlueprint.getClasses('BUTTON_GROUP'))
        }, hasAdditionalControls && react_1.default.createElement("button", {
            onClick: function() {
                return _this.setAdditionalControlsOpen(!additionalControlsOpen);
            },
            className: (0, classnames_1.default)(OptionalBlueprint_1.OptionalBlueprint.getClasses(this.context.blueprintNamespace, 'BUTTON', 'MINIMAL'), OptionalBlueprint_1.OptionalBlueprint.getIconClass(this.context.blueprintNamespace, 'MORE'), (_a = {}, _a[OptionalBlueprint_1.OptionalBlueprint.getClasses(this.context.blueprintNamespace, 'ACTIVE')] = additionalControlsOpen, _a))
        }, react_1.default.createElement("span", {
            className: "control-text"
        }, additionalControlButtonText)), hasAdditionalControls && react_1.default.createElement(Separator_1.Separator, null), toolbarControls));
    };
    InternalMosaicWindow.prototype.checkCreateNode = function() {
        if (this.props.createNode == null) {
            throw new Error('Operation invalid unless `createNode` is defined');
        }
    };
    InternalMosaicWindow.defaultProps = {
        additionalControlButtonText: 'More',
        draggable: true,
        renderPreview: function(_a) {
            var title = _a.title;
            return react_1.default.createElement("div", {
                className: "mosaic-preview"
            }, react_1.default.createElement("div", {
                className: "mosaic-window-toolbar"
            }, react_1.default.createElement("div", {
                className: "mosaic-window-title"
            }, title)), react_1.default.createElement("div", {
                className: "mosaic-window-body"
            }, react_1.default.createElement("h4", null, title), react_1.default.createElement(OptionalBlueprint_1.OptionalBlueprint.Icon, {
                className: "default-preview-icon",
                size: "large",
                icon: "APPLICATION"
            })));
        },
        renderToolbar: null
    };
    InternalMosaicWindow.contextType = contextTypes_1.MosaicContext;
    return InternalMosaicWindow;
}(react_1.default.Component);
exports.InternalMosaicWindow = InternalMosaicWindow;
function ConnectedInternalMosaicWindow(props) {
    var _a = (0, react_1.useContext)(contextTypes_1.MosaicContext), mosaicActions = _a.mosaicActions, mosaicId = _a.mosaicId;
    var _b = (0, react_dnd_1.useDrag)({
        type: types_1.MosaicDragType.WINDOW,
        item: function(_monitor) {
            if (props.onDragStart) {
                props.onDragStart();
            }
            // TODO: Actually just delete instead of hiding
            // The defer is necessary as the element must be present on start for HTML DnD to not cry
            var hideTimer = (0, defer_1.default)(function() {
                return mosaicActions.hide(props.path);
            });
            return {
                mosaicId: mosaicId,
                hideTimer: hideTimer
            };
        },
        end: function(item, monitor) {
            var hideTimer = item.hideTimer;
            // If the hide call hasn't happened yet, cancel it
            window.clearTimeout(hideTimer);
            var ownPath = props.path;
            var dropResult = monitor.getDropResult() || {};
            var position = dropResult.position, destinationPath = dropResult.path;
            if (position != null && destinationPath != null && !(0, isEqual_1.default)(destinationPath, ownPath)) {
                mosaicActions.updateTree((0, mosaicUpdates_1.createDragToUpdates)(mosaicActions.getRoot(), ownPath, destinationPath, position));
                if (props.onDragEnd) {
                    props.onDragEnd('drop');
                }
            } else {
                // TODO: restore node from captured state
                mosaicActions.updateTree([
                    {
                        path: (0, dropRight_1.default)(ownPath),
                        spec: {
                            splitPercentage: {
                                $set: undefined
                            }
                        }
                    }
                ]);
                if (props.onDragEnd) {
                    props.onDragEnd('reset');
                }
            }
        }
    }), connectDragSource = _b[1], connectDragPreview = _b[2];
    var _c = (0, react_dnd_1.useDrop)({
        accept: types_1.MosaicDragType.WINDOW,
        collect: function(monitor) {
            var _a;
            return {
                isOver: monitor.isOver(),
                draggedMosaicId: (_a = monitor.getItem()) === null || _a === void 0 ? void 0 : _a.mosaicId
            };
        }
    }), _d = _c[0], isOver = _d.isOver, draggedMosaicId = _d.draggedMosaicId, connectDropTarget = _c[1];
    return react_1.default.createElement(InternalMosaicWindow, __assign({}, props, {
        connectDragPreview: connectDragPreview,
        connectDragSource: connectDragSource,
        connectDropTarget: connectDropTarget,
        isOver: isOver,
        draggedMosaicId: draggedMosaicId
    }));
}
var MosaicWindow = function(_super) {
    __extends(MosaicWindow, _super);
    function MosaicWindow() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    MosaicWindow.prototype.render = function() {
        return react_1.default.createElement(ConnectedInternalMosaicWindow, __assign({}, this.props));
    };
    return MosaicWindow;
}(react_1.default.PureComponent);
exports.MosaicWindow = MosaicWindow; //# sourceMappingURL=MosaicWindow.js.map
}),
"[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.DEFAULT_CONTROLS_WITHOUT_CREATION = exports.DEFAULT_CONTROLS_WITH_CREATION = exports.RemoveButton = exports.SplitButton = exports.ReplaceButton = exports.ExpandButton = exports.Separator = exports.MosaicZeroState = exports.DefaultToolbarButton = exports.createDefaultToolbarButton = exports.MosaicWindow = exports.isParent = exports.getPathToCorner = exports.getOtherDirection = exports.getOtherBranch = exports.getNodeAtPath = exports.getLeaves = exports.getAndAssertNodeAtPathExists = exports.Corner = exports.createBalancedTreeFromLeaves = exports.updateTree = exports.createRemoveUpdate = exports.createHideUpdate = exports.createExpandUpdate = exports.createDragToUpdates = exports.buildSpecFromUpdate = exports.MosaicWindowContext = exports.MosaicContext = exports.MosaicDragType = exports.MosaicWithoutDragDropContext = exports.Mosaic = void 0;
/**
 * @license
 * Copyright 2019 Kevin Verdieck, originally developed at Palantir Technologies, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ var Mosaic_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/Mosaic.js [app-client] (ecmascript)");
Object.defineProperty(exports, "Mosaic", {
    enumerable: true,
    get: function() {
        return Mosaic_1.Mosaic;
    }
});
Object.defineProperty(exports, "MosaicWithoutDragDropContext", {
    enumerable: true,
    get: function() {
        return Mosaic_1.MosaicWithoutDragDropContext;
    }
});
var types_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/types.js [app-client] (ecmascript)");
Object.defineProperty(exports, "MosaicDragType", {
    enumerable: true,
    get: function() {
        return types_1.MosaicDragType;
    }
});
var contextTypes_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/contextTypes.js [app-client] (ecmascript)");
Object.defineProperty(exports, "MosaicContext", {
    enumerable: true,
    get: function() {
        return contextTypes_1.MosaicContext;
    }
});
Object.defineProperty(exports, "MosaicWindowContext", {
    enumerable: true,
    get: function() {
        return contextTypes_1.MosaicWindowContext;
    }
});
var mosaicUpdates_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/util/mosaicUpdates.js [app-client] (ecmascript)");
Object.defineProperty(exports, "buildSpecFromUpdate", {
    enumerable: true,
    get: function() {
        return mosaicUpdates_1.buildSpecFromUpdate;
    }
});
Object.defineProperty(exports, "createDragToUpdates", {
    enumerable: true,
    get: function() {
        return mosaicUpdates_1.createDragToUpdates;
    }
});
Object.defineProperty(exports, "createExpandUpdate", {
    enumerable: true,
    get: function() {
        return mosaicUpdates_1.createExpandUpdate;
    }
});
Object.defineProperty(exports, "createHideUpdate", {
    enumerable: true,
    get: function() {
        return mosaicUpdates_1.createHideUpdate;
    }
});
Object.defineProperty(exports, "createRemoveUpdate", {
    enumerable: true,
    get: function() {
        return mosaicUpdates_1.createRemoveUpdate;
    }
});
Object.defineProperty(exports, "updateTree", {
    enumerable: true,
    get: function() {
        return mosaicUpdates_1.updateTree;
    }
});
var mosaicUtilities_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/util/mosaicUtilities.js [app-client] (ecmascript)");
Object.defineProperty(exports, "createBalancedTreeFromLeaves", {
    enumerable: true,
    get: function() {
        return mosaicUtilities_1.createBalancedTreeFromLeaves;
    }
});
Object.defineProperty(exports, "Corner", {
    enumerable: true,
    get: function() {
        return mosaicUtilities_1.Corner;
    }
});
Object.defineProperty(exports, "getAndAssertNodeAtPathExists", {
    enumerable: true,
    get: function() {
        return mosaicUtilities_1.getAndAssertNodeAtPathExists;
    }
});
Object.defineProperty(exports, "getLeaves", {
    enumerable: true,
    get: function() {
        return mosaicUtilities_1.getLeaves;
    }
});
Object.defineProperty(exports, "getNodeAtPath", {
    enumerable: true,
    get: function() {
        return mosaicUtilities_1.getNodeAtPath;
    }
});
Object.defineProperty(exports, "getOtherBranch", {
    enumerable: true,
    get: function() {
        return mosaicUtilities_1.getOtherBranch;
    }
});
Object.defineProperty(exports, "getOtherDirection", {
    enumerable: true,
    get: function() {
        return mosaicUtilities_1.getOtherDirection;
    }
});
Object.defineProperty(exports, "getPathToCorner", {
    enumerable: true,
    get: function() {
        return mosaicUtilities_1.getPathToCorner;
    }
});
Object.defineProperty(exports, "isParent", {
    enumerable: true,
    get: function() {
        return mosaicUtilities_1.isParent;
    }
});
var MosaicWindow_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/MosaicWindow.js [app-client] (ecmascript)");
Object.defineProperty(exports, "MosaicWindow", {
    enumerable: true,
    get: function() {
        return MosaicWindow_1.MosaicWindow;
    }
});
var MosaicButton_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/buttons/MosaicButton.js [app-client] (ecmascript)");
Object.defineProperty(exports, "createDefaultToolbarButton", {
    enumerable: true,
    get: function() {
        return MosaicButton_1.createDefaultToolbarButton;
    }
});
Object.defineProperty(exports, "DefaultToolbarButton", {
    enumerable: true,
    get: function() {
        return MosaicButton_1.DefaultToolbarButton;
    }
});
var MosaicZeroState_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/MosaicZeroState.js [app-client] (ecmascript)");
Object.defineProperty(exports, "MosaicZeroState", {
    enumerable: true,
    get: function() {
        return MosaicZeroState_1.MosaicZeroState;
    }
});
var Separator_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/buttons/Separator.js [app-client] (ecmascript)");
Object.defineProperty(exports, "Separator", {
    enumerable: true,
    get: function() {
        return Separator_1.Separator;
    }
});
var ExpandButton_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/buttons/ExpandButton.js [app-client] (ecmascript)");
Object.defineProperty(exports, "ExpandButton", {
    enumerable: true,
    get: function() {
        return ExpandButton_1.ExpandButton;
    }
});
var ReplaceButton_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/buttons/ReplaceButton.js [app-client] (ecmascript)");
Object.defineProperty(exports, "ReplaceButton", {
    enumerable: true,
    get: function() {
        return ReplaceButton_1.ReplaceButton;
    }
});
var SplitButton_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/buttons/SplitButton.js [app-client] (ecmascript)");
Object.defineProperty(exports, "SplitButton", {
    enumerable: true,
    get: function() {
        return SplitButton_1.SplitButton;
    }
});
var RemoveButton_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/buttons/RemoveButton.js [app-client] (ecmascript)");
Object.defineProperty(exports, "RemoveButton", {
    enumerable: true,
    get: function() {
        return RemoveButton_1.RemoveButton;
    }
});
var defaultToolbarControls_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-mosaic-component@6.1.1_@types+node@24.10.9_@types+react@19.2.9_dnd-core@16.0.1_react-do_dfi42gppx5ojolgy6lmikm47zy/node_modules/react-mosaic-component/lib/buttons/defaultToolbarControls.js [app-client] (ecmascript)");
Object.defineProperty(exports, "DEFAULT_CONTROLS_WITH_CREATION", {
    enumerable: true,
    get: function() {
        return defaultToolbarControls_1.DEFAULT_CONTROLS_WITH_CREATION;
    }
});
Object.defineProperty(exports, "DEFAULT_CONTROLS_WITHOUT_CREATION", {
    enumerable: true,
    get: function() {
        return defaultToolbarControls_1.DEFAULT_CONTROLS_WITHOUT_CREATION;
    }
}); //# sourceMappingURL=index.js.map
}),
"[project]/node_modules/.pnpm/immutability-helper@3.1.1/node_modules/immutability-helper/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function stringifiable(obj) {
    // Safely stringify Object.create(null)
    /* istanbul ignore next */ return typeof obj === 'object' && !('toString' in obj) ? Object.prototype.toString.call(obj).slice(8, -1) : obj;
}
var isProduction = typeof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] === 'object' && ("TURBOPACK compile-time value", "development") === 'production';
function invariant(condition, message) {
    if (!condition) {
        /* istanbul ignore next */ if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
        throw new Error(message());
    }
}
exports.invariant = invariant;
var hasOwnProperty = Object.prototype.hasOwnProperty;
var splice = Array.prototype.splice;
var toString = Object.prototype.toString;
function type(obj) {
    return toString.call(obj).slice(8, -1);
}
var assign = Object.assign || function(target, source) {
    getAllKeys(source).forEach(function(key) {
        if (hasOwnProperty.call(source, key)) {
            target[key] = source[key];
        }
    });
    return target;
};
var getAllKeys = typeof Object.getOwnPropertySymbols === 'function' ? function(obj) {
    return Object.keys(obj).concat(Object.getOwnPropertySymbols(obj));
} : function(obj) {
    return Object.keys(obj);
};
function copy(object) {
    return Array.isArray(object) ? assign(object.constructor(object.length), object) : type(object) === 'Map' ? new Map(object) : type(object) === 'Set' ? new Set(object) : object && typeof object === 'object' ? assign(Object.create(Object.getPrototypeOf(object)), object) : object;
}
var Context = function() {
    function Context() {
        this.commands = assign({}, defaultCommands);
        this.update = this.update.bind(this);
        // Deprecated: update.extend, update.isEquals and update.newContext
        this.update.extend = this.extend = this.extend.bind(this);
        this.update.isEquals = function(x, y) {
            return x === y;
        };
        this.update.newContext = function() {
            return new Context().update;
        };
    }
    Object.defineProperty(Context.prototype, "isEquals", {
        get: function() {
            return this.update.isEquals;
        },
        set: function(value) {
            this.update.isEquals = value;
        },
        enumerable: true,
        configurable: true
    });
    Context.prototype.extend = function(directive, fn) {
        this.commands[directive] = fn;
    };
    Context.prototype.update = function(object, $spec) {
        var _this = this;
        var spec = typeof $spec === 'function' ? {
            $apply: $spec
        } : $spec;
        if (!(Array.isArray(object) && Array.isArray(spec))) {
            invariant(!Array.isArray(spec), function() {
                return "update(): You provided an invalid spec to update(). The spec may " + "not contain an array except as the value of $set, $push, $unshift, " + "$splice or any custom command allowing an array value.";
            });
        }
        invariant(typeof spec === 'object' && spec !== null, function() {
            return "update(): You provided an invalid spec to update(). The spec and " + "every included key path must be plain objects containing one of the " + ("following commands: " + Object.keys(_this.commands).join(', ') + ".");
        });
        var nextObject = object;
        getAllKeys(spec).forEach(function(key) {
            if (hasOwnProperty.call(_this.commands, key)) {
                var objectWasNextObject = object === nextObject;
                nextObject = _this.commands[key](spec[key], nextObject, spec, object);
                if (objectWasNextObject && _this.isEquals(nextObject, object)) {
                    nextObject = object;
                }
            } else {
                var nextValueForKey = type(object) === 'Map' ? _this.update(object.get(key), spec[key]) : _this.update(object[key], spec[key]);
                var nextObjectValue = type(nextObject) === 'Map' ? nextObject.get(key) : nextObject[key];
                if (!_this.isEquals(nextValueForKey, nextObjectValue) || typeof nextValueForKey === 'undefined' && !hasOwnProperty.call(object, key)) {
                    if (nextObject === object) {
                        nextObject = copy(object);
                    }
                    if (type(nextObject) === 'Map') {
                        nextObject.set(key, nextValueForKey);
                    } else {
                        nextObject[key] = nextValueForKey;
                    }
                }
            }
        });
        return nextObject;
    };
    return Context;
}();
exports.Context = Context;
var defaultCommands = {
    $push: function(value, nextObject, spec) {
        invariantPushAndUnshift(nextObject, spec, '$push');
        return value.length ? nextObject.concat(value) : nextObject;
    },
    $unshift: function(value, nextObject, spec) {
        invariantPushAndUnshift(nextObject, spec, '$unshift');
        return value.length ? value.concat(nextObject) : nextObject;
    },
    $splice: function(value, nextObject, spec, originalObject) {
        invariantSplices(nextObject, spec);
        value.forEach(function(args) {
            invariantSplice(args);
            if (nextObject === originalObject && args.length) {
                nextObject = copy(originalObject);
            }
            splice.apply(nextObject, args);
        });
        return nextObject;
    },
    $set: function(value, _nextObject, spec) {
        invariantSet(spec);
        return value;
    },
    $toggle: function(targets, nextObject) {
        invariantSpecArray(targets, '$toggle');
        var nextObjectCopy = targets.length ? copy(nextObject) : nextObject;
        targets.forEach(function(target) {
            nextObjectCopy[target] = !nextObject[target];
        });
        return nextObjectCopy;
    },
    $unset: function(value, nextObject, _spec, originalObject) {
        invariantSpecArray(value, '$unset');
        value.forEach(function(key) {
            if (Object.hasOwnProperty.call(nextObject, key)) {
                if (nextObject === originalObject) {
                    nextObject = copy(originalObject);
                }
                delete nextObject[key];
            }
        });
        return nextObject;
    },
    $add: function(values, nextObject, _spec, originalObject) {
        invariantMapOrSet(nextObject, '$add');
        invariantSpecArray(values, '$add');
        if (type(nextObject) === 'Map') {
            values.forEach(function(_a) {
                var key = _a[0], value = _a[1];
                if (nextObject === originalObject && nextObject.get(key) !== value) {
                    nextObject = copy(originalObject);
                }
                nextObject.set(key, value);
            });
        } else {
            values.forEach(function(value) {
                if (nextObject === originalObject && !nextObject.has(value)) {
                    nextObject = copy(originalObject);
                }
                nextObject.add(value);
            });
        }
        return nextObject;
    },
    $remove: function(value, nextObject, _spec, originalObject) {
        invariantMapOrSet(nextObject, '$remove');
        invariantSpecArray(value, '$remove');
        value.forEach(function(key) {
            if (nextObject === originalObject && nextObject.has(key)) {
                nextObject = copy(originalObject);
            }
            nextObject.delete(key);
        });
        return nextObject;
    },
    $merge: function(value, nextObject, _spec, originalObject) {
        invariantMerge(nextObject, value);
        getAllKeys(value).forEach(function(key) {
            if (value[key] !== nextObject[key]) {
                if (nextObject === originalObject) {
                    nextObject = copy(originalObject);
                }
                nextObject[key] = value[key];
            }
        });
        return nextObject;
    },
    $apply: function(value, original) {
        invariantApply(value);
        return value(original);
    }
};
var defaultContext = new Context();
exports.isEquals = defaultContext.update.isEquals;
exports.extend = defaultContext.extend;
exports.default = defaultContext.update;
// @ts-ignore
exports.default.default = module.exports = assign(exports.default, exports);
// invariants
function invariantPushAndUnshift(value, spec, command) {
    invariant(Array.isArray(value), function() {
        return "update(): expected target of " + stringifiable(command) + " to be an array; got " + stringifiable(value) + ".";
    });
    invariantSpecArray(spec[command], command);
}
function invariantSpecArray(spec, command) {
    invariant(Array.isArray(spec), function() {
        return "update(): expected spec of " + stringifiable(command) + " to be an array; got " + stringifiable(spec) + ". " + "Did you forget to wrap your parameter in an array?";
    });
}
function invariantSplices(value, spec) {
    invariant(Array.isArray(value), function() {
        return "Expected $splice target to be an array; got " + stringifiable(value);
    });
    invariantSplice(spec.$splice);
}
function invariantSplice(value) {
    invariant(Array.isArray(value), function() {
        return "update(): expected spec of $splice to be an array of arrays; got " + stringifiable(value) + ". " + "Did you forget to wrap your parameters in an array?";
    });
}
function invariantApply(fn) {
    invariant(typeof fn === 'function', function() {
        return "update(): expected spec of $apply to be a function; got " + stringifiable(fn) + ".";
    });
}
function invariantSet(spec) {
    invariant(Object.keys(spec).length === 1, function() {
        return "Cannot have more than one key in an object with $set";
    });
}
function invariantMerge(target, specValue) {
    invariant(specValue && typeof specValue === 'object', function() {
        return "update(): $merge expects a spec of type 'object'; got " + stringifiable(specValue);
    });
    invariant(target && typeof target === 'object', function() {
        return "update(): $merge expects a target of type 'object'; got " + stringifiable(target);
    });
}
function invariantMapOrSet(target, command) {
    var typeOfTarget = type(target);
    invariant(typeOfTarget === 'Map' || typeOfTarget === 'Set', function() {
        return "update(): " + stringifiable(command) + " expects a target of type Set or Map; got " + stringifiable(typeOfTarget);
    });
}
}),
"[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/isSameDay.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "isSameDay",
    ()=>isSameDay
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$_lib$2f$normalizeDates$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/_lib/normalizeDates.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$startOfDay$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/startOfDay.js [app-client] (ecmascript)");
;
;
function isSameDay(laterDate, earlierDate, options) {
    const [dateLeft_, dateRight_] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$_lib$2f$normalizeDates$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeDates"])(options?.in, laterDate, earlierDate);
    return +(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$startOfDay$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["startOfDay"])(dateLeft_) === +(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$startOfDay$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["startOfDay"])(dateRight_);
}
const __TURBOPACK__default__export__ = isSameDay;
}),
"[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/locale/en-GB/_lib/formatLong.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "formatLong",
    ()=>formatLong
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$_lib$2f$buildFormatLongFn$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/locale/_lib/buildFormatLongFn.js [app-client] (ecmascript)");
;
const dateFormats = {
    full: "EEEE, d MMMM yyyy",
    long: "d MMMM yyyy",
    medium: "d MMM yyyy",
    short: "dd/MM/yyyy"
};
const timeFormats = {
    full: "HH:mm:ss zzzz",
    long: "HH:mm:ss z",
    medium: "HH:mm:ss",
    short: "HH:mm"
};
const dateTimeFormats = {
    full: "{{date}} 'at' {{time}}",
    long: "{{date}} 'at' {{time}}",
    medium: "{{date}}, {{time}}",
    short: "{{date}}, {{time}}"
};
const formatLong = {
    date: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$_lib$2f$buildFormatLongFn$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildFormatLongFn"])({
        formats: dateFormats,
        defaultWidth: "full"
    }),
    time: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$_lib$2f$buildFormatLongFn$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildFormatLongFn"])({
        formats: timeFormats,
        defaultWidth: "full"
    }),
    dateTime: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$_lib$2f$buildFormatLongFn$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildFormatLongFn"])({
        formats: dateTimeFormats,
        defaultWidth: "full"
    })
};
}),
"[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/locale/en-GB.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "enGB",
    ()=>enGB
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$en$2d$US$2f$_lib$2f$formatDistance$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/locale/en-US/_lib/formatDistance.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$en$2d$US$2f$_lib$2f$formatRelative$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/locale/en-US/_lib/formatRelative.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$en$2d$US$2f$_lib$2f$localize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/locale/en-US/_lib/localize.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$en$2d$US$2f$_lib$2f$match$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/locale/en-US/_lib/match.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$en$2d$GB$2f$_lib$2f$formatLong$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/locale/en-GB/_lib/formatLong.js [app-client] (ecmascript)");
;
;
;
;
;
const enGB = {
    code: "en-GB",
    formatDistance: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$en$2d$US$2f$_lib$2f$formatDistance$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatDistance"],
    formatLong: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$en$2d$GB$2f$_lib$2f$formatLong$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatLong"],
    formatRelative: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$en$2d$US$2f$_lib$2f$formatRelative$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatRelative"],
    localize: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$en$2d$US$2f$_lib$2f$localize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["localize"],
    match: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$en$2d$US$2f$_lib$2f$match$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["match"],
    options: {
        weekStartsOn: 1 /* Monday */ ,
        firstWeekContainsDate: 4
    }
};
const __TURBOPACK__default__export__ = enGB;
}),
"[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/locale/nn/_lib/formatDistance.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "formatDistance",
    ()=>formatDistance
]);
const formatDistanceLocale = {
    lessThanXSeconds: {
        one: "mindre enn eitt sekund",
        other: "mindre enn {{count}} sekund"
    },
    xSeconds: {
        one: "eitt sekund",
        other: "{{count}} sekund"
    },
    halfAMinute: "eit halvt minutt",
    lessThanXMinutes: {
        one: "mindre enn eitt minutt",
        other: "mindre enn {{count}} minutt"
    },
    xMinutes: {
        one: "eitt minutt",
        other: "{{count}} minutt"
    },
    aboutXHours: {
        one: "omtrent ein time",
        other: "omtrent {{count}} timar"
    },
    xHours: {
        one: "ein time",
        other: "{{count}} timar"
    },
    xDays: {
        one: "ein dag",
        other: "{{count}} dagar"
    },
    aboutXWeeks: {
        one: "omtrent ei veke",
        other: "omtrent {{count}} veker"
    },
    xWeeks: {
        one: "ei veke",
        other: "{{count}} veker"
    },
    aboutXMonths: {
        one: "omtrent ein månad",
        other: "omtrent {{count}} månader"
    },
    xMonths: {
        one: "ein månad",
        other: "{{count}} månader"
    },
    aboutXYears: {
        one: "omtrent eitt år",
        other: "omtrent {{count}} år"
    },
    xYears: {
        one: "eitt år",
        other: "{{count}} år"
    },
    overXYears: {
        one: "over eitt år",
        other: "over {{count}} år"
    },
    almostXYears: {
        one: "nesten eitt år",
        other: "nesten {{count}} år"
    }
};
const wordMapping = [
    "null",
    "ein",
    "to",
    "tre",
    "fire",
    "fem",
    "seks",
    "sju",
    "åtte",
    "ni",
    "ti",
    "elleve",
    "tolv"
];
const formatDistance = (token, count, options)=>{
    let result;
    const tokenValue = formatDistanceLocale[token];
    if (typeof tokenValue === "string") {
        result = tokenValue;
    } else if (count === 1) {
        result = tokenValue.one;
    } else {
        result = tokenValue.other.replace("{{count}}", count < 13 ? wordMapping[count] : String(count));
    }
    if (options?.addSuffix) {
        if (options.comparison && options.comparison > 0) {
            return "om " + result;
        } else {
            return result + " sidan";
        }
    }
    return result;
};
}),
"[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/locale/nn/_lib/formatLong.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "formatLong",
    ()=>formatLong
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$_lib$2f$buildFormatLongFn$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/locale/_lib/buildFormatLongFn.js [app-client] (ecmascript)");
;
const dateFormats = {
    full: "EEEE d. MMMM y",
    long: "d. MMMM y",
    medium: "d. MMM y",
    short: "dd.MM.y"
};
const timeFormats = {
    full: "'kl'. HH:mm:ss zzzz",
    long: "HH:mm:ss z",
    medium: "HH:mm:ss",
    short: "HH:mm"
};
const dateTimeFormats = {
    full: "{{date}} 'kl.' {{time}}",
    long: "{{date}} 'kl.' {{time}}",
    medium: "{{date}} {{time}}",
    short: "{{date}} {{time}}"
};
const formatLong = {
    date: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$_lib$2f$buildFormatLongFn$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildFormatLongFn"])({
        formats: dateFormats,
        defaultWidth: "full"
    }),
    time: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$_lib$2f$buildFormatLongFn$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildFormatLongFn"])({
        formats: timeFormats,
        defaultWidth: "full"
    }),
    dateTime: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$_lib$2f$buildFormatLongFn$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildFormatLongFn"])({
        formats: dateTimeFormats,
        defaultWidth: "full"
    })
};
}),
"[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/locale/nn/_lib/formatRelative.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "formatRelative",
    ()=>formatRelative
]);
const formatRelativeLocale = {
    lastWeek: "'førre' eeee 'kl.' p",
    yesterday: "'i går kl.' p",
    today: "'i dag kl.' p",
    tomorrow: "'i morgon kl.' p",
    nextWeek: "EEEE 'kl.' p",
    other: "P"
};
const formatRelative = (token, _date, _baseDate, _options)=>formatRelativeLocale[token];
}),
"[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/locale/nn/_lib/localize.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "localize",
    ()=>localize
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$_lib$2f$buildLocalizeFn$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/locale/_lib/buildLocalizeFn.js [app-client] (ecmascript)");
;
const eraValues = {
    narrow: [
        "f.Kr.",
        "e.Kr."
    ],
    abbreviated: [
        "f.Kr.",
        "e.Kr."
    ],
    wide: [
        "før Kristus",
        "etter Kristus"
    ]
};
const quarterValues = {
    narrow: [
        "1",
        "2",
        "3",
        "4"
    ],
    abbreviated: [
        "Q1",
        "Q2",
        "Q3",
        "Q4"
    ],
    wide: [
        "1. kvartal",
        "2. kvartal",
        "3. kvartal",
        "4. kvartal"
    ]
};
const monthValues = {
    narrow: [
        "J",
        "F",
        "M",
        "A",
        "M",
        "J",
        "J",
        "A",
        "S",
        "O",
        "N",
        "D"
    ],
    abbreviated: [
        "jan.",
        "feb.",
        "mars",
        "apr.",
        "mai",
        "juni",
        "juli",
        "aug.",
        "sep.",
        "okt.",
        "nov.",
        "des."
    ],
    wide: [
        "januar",
        "februar",
        "mars",
        "april",
        "mai",
        "juni",
        "juli",
        "august",
        "september",
        "oktober",
        "november",
        "desember"
    ]
};
const dayValues = {
    narrow: [
        "S",
        "M",
        "T",
        "O",
        "T",
        "F",
        "L"
    ],
    short: [
        "su",
        "må",
        "ty",
        "on",
        "to",
        "fr",
        "lau"
    ],
    abbreviated: [
        "sun",
        "mån",
        "tys",
        "ons",
        "tor",
        "fre",
        "laur"
    ],
    wide: [
        "sundag",
        "måndag",
        "tysdag",
        "onsdag",
        "torsdag",
        "fredag",
        "laurdag"
    ]
};
const dayPeriodValues = {
    narrow: {
        am: "a",
        pm: "p",
        midnight: "midnatt",
        noon: "middag",
        morning: "på morg.",
        afternoon: "på etterm.",
        evening: "på kvelden",
        night: "på natta"
    },
    abbreviated: {
        am: "a.m.",
        pm: "p.m.",
        midnight: "midnatt",
        noon: "middag",
        morning: "på morg.",
        afternoon: "på etterm.",
        evening: "på kvelden",
        night: "på natta"
    },
    wide: {
        am: "a.m.",
        pm: "p.m.",
        midnight: "midnatt",
        noon: "middag",
        morning: "på morgonen",
        afternoon: "på ettermiddagen",
        evening: "på kvelden",
        night: "på natta"
    }
};
const ordinalNumber = (dirtyNumber, _options)=>{
    const number = Number(dirtyNumber);
    return number + ".";
};
const localize = {
    ordinalNumber,
    era: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$_lib$2f$buildLocalizeFn$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildLocalizeFn"])({
        values: eraValues,
        defaultWidth: "wide"
    }),
    quarter: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$_lib$2f$buildLocalizeFn$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildLocalizeFn"])({
        values: quarterValues,
        defaultWidth: "wide",
        argumentCallback: (quarter)=>quarter - 1
    }),
    month: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$_lib$2f$buildLocalizeFn$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildLocalizeFn"])({
        values: monthValues,
        defaultWidth: "wide"
    }),
    day: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$_lib$2f$buildLocalizeFn$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildLocalizeFn"])({
        values: dayValues,
        defaultWidth: "wide"
    }),
    dayPeriod: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$_lib$2f$buildLocalizeFn$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildLocalizeFn"])({
        values: dayPeriodValues,
        defaultWidth: "wide"
    })
};
}),
"[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/locale/nn/_lib/match.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "match",
    ()=>match
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$_lib$2f$buildMatchFn$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/locale/_lib/buildMatchFn.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$_lib$2f$buildMatchPatternFn$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/locale/_lib/buildMatchPatternFn.js [app-client] (ecmascript)");
;
;
const matchOrdinalNumberPattern = /^(\d+)\.?/i;
const parseOrdinalNumberPattern = /\d+/i;
const matchEraPatterns = {
    narrow: /^(f\.? ?Kr\.?|fvt\.?|e\.? ?Kr\.?|evt\.?)/i,
    abbreviated: /^(f\.? ?Kr\.?|fvt\.?|e\.? ?Kr\.?|evt\.?)/i,
    wide: /^(før Kristus|før vår tid|etter Kristus|vår tid)/i
};
const parseEraPatterns = {
    any: [
        /^f/i,
        /^e/i
    ]
};
const matchQuarterPatterns = {
    narrow: /^[1234]/i,
    abbreviated: /^q[1234]/i,
    wide: /^[1234](\.)? kvartal/i
};
const parseQuarterPatterns = {
    any: [
        /1/i,
        /2/i,
        /3/i,
        /4/i
    ]
};
const matchMonthPatterns = {
    narrow: /^[jfmasond]/i,
    abbreviated: /^(jan|feb|mars?|apr|mai|juni?|juli?|aug|sep|okt|nov|des)\.?/i,
    wide: /^(januar|februar|mars|april|mai|juni|juli|august|september|oktober|november|desember)/i
};
const parseMonthPatterns = {
    narrow: [
        /^j/i,
        /^f/i,
        /^m/i,
        /^a/i,
        /^m/i,
        /^j/i,
        /^j/i,
        /^a/i,
        /^s/i,
        /^o/i,
        /^n/i,
        /^d/i
    ],
    any: [
        /^ja/i,
        /^f/i,
        /^mar/i,
        /^ap/i,
        /^mai/i,
        /^jun/i,
        /^jul/i,
        /^aug/i,
        /^s/i,
        /^o/i,
        /^n/i,
        /^d/i
    ]
};
const matchDayPatterns = {
    narrow: /^[smtofl]/i,
    short: /^(su|må|ty|on|to|fr|la)/i,
    abbreviated: /^(sun|mån|tys|ons|tor|fre|laur)/i,
    wide: /^(sundag|måndag|tysdag|onsdag|torsdag|fredag|laurdag)/i
};
const parseDayPatterns = {
    any: [
        /^s/i,
        /^m/i,
        /^ty/i,
        /^o/i,
        /^to/i,
        /^f/i,
        /^l/i
    ]
};
const matchDayPeriodPatterns = {
    narrow: /^(midnatt|middag|(på) (morgonen|ettermiddagen|kvelden|natta)|[ap])/i,
    any: /^([ap]\.?\s?m\.?|midnatt|middag|(på) (morgonen|ettermiddagen|kvelden|natta))/i
};
const parseDayPeriodPatterns = {
    any: {
        am: /^a(\.?\s?m\.?)?$/i,
        pm: /^p(\.?\s?m\.?)?$/i,
        midnight: /^midn/i,
        noon: /^midd/i,
        morning: /morgon/i,
        afternoon: /ettermiddag/i,
        evening: /kveld/i,
        night: /natt/i
    }
};
const match = {
    ordinalNumber: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$_lib$2f$buildMatchPatternFn$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildMatchPatternFn"])({
        matchPattern: matchOrdinalNumberPattern,
        parsePattern: parseOrdinalNumberPattern,
        valueCallback: (value)=>parseInt(value, 10)
    }),
    era: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$_lib$2f$buildMatchFn$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildMatchFn"])({
        matchPatterns: matchEraPatterns,
        defaultMatchWidth: "wide",
        parsePatterns: parseEraPatterns,
        defaultParseWidth: "any"
    }),
    quarter: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$_lib$2f$buildMatchFn$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildMatchFn"])({
        matchPatterns: matchQuarterPatterns,
        defaultMatchWidth: "wide",
        parsePatterns: parseQuarterPatterns,
        defaultParseWidth: "any",
        valueCallback: (index)=>index + 1
    }),
    month: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$_lib$2f$buildMatchFn$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildMatchFn"])({
        matchPatterns: matchMonthPatterns,
        defaultMatchWidth: "wide",
        parsePatterns: parseMonthPatterns,
        defaultParseWidth: "any"
    }),
    day: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$_lib$2f$buildMatchFn$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildMatchFn"])({
        matchPatterns: matchDayPatterns,
        defaultMatchWidth: "wide",
        parsePatterns: parseDayPatterns,
        defaultParseWidth: "any"
    }),
    dayPeriod: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$_lib$2f$buildMatchFn$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildMatchFn"])({
        matchPatterns: matchDayPeriodPatterns,
        defaultMatchWidth: "any",
        parsePatterns: parseDayPeriodPatterns,
        defaultParseWidth: "any"
    })
};
}),
"[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/locale/nn.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "nn",
    ()=>nn
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$nn$2f$_lib$2f$formatDistance$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/locale/nn/_lib/formatDistance.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$nn$2f$_lib$2f$formatLong$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/locale/nn/_lib/formatLong.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$nn$2f$_lib$2f$formatRelative$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/locale/nn/_lib/formatRelative.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$nn$2f$_lib$2f$localize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/locale/nn/_lib/localize.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$nn$2f$_lib$2f$match$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/locale/nn/_lib/match.js [app-client] (ecmascript)");
;
;
;
;
;
const nn = {
    code: "nn",
    formatDistance: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$nn$2f$_lib$2f$formatDistance$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatDistance"],
    formatLong: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$nn$2f$_lib$2f$formatLong$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatLong"],
    formatRelative: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$nn$2f$_lib$2f$formatRelative$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatRelative"],
    localize: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$nn$2f$_lib$2f$localize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["localize"],
    match: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$nn$2f$_lib$2f$match$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["match"],
    options: {
        weekStartsOn: 1 /* Monday */ ,
        firstWeekContainsDate: 4
    }
};
const __TURBOPACK__default__export__ = nn;
}),
"[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/isWeekend.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "isWeekend",
    ()=>isWeekend
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$toDate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/toDate.js [app-client] (ecmascript)");
;
function isWeekend(date, options) {
    const day = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$toDate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDate"])(date, options?.in).getDay();
    return day === 0 || day === 6;
}
const __TURBOPACK__default__export__ = isWeekend;
}),
"[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/addMonths.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "addMonths",
    ()=>addMonths,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$constructFrom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/constructFrom.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$toDate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/toDate.js [app-client] (ecmascript)");
;
;
function addMonths(date, amount, options) {
    const _date = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$toDate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDate"])(date, options?.in);
    if (isNaN(amount)) return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$constructFrom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["constructFrom"])(options?.in || date, NaN);
    if (!amount) {
        // If 0 months, no-op to avoid changing times in the hour before end of DST
        return _date;
    }
    const dayOfMonth = _date.getDate();
    // The JS Date object supports date math by accepting out-of-bounds values for
    // month, day, etc. For example, new Date(2020, 0, 0) returns 31 Dec 2019 and
    // new Date(2020, 13, 1) returns 1 Feb 2021.  This is *almost* the behavior we
    // want except that dates will wrap around the end of a month, meaning that
    // new Date(2020, 13, 31) will return 3 Mar 2021 not 28 Feb 2021 as desired. So
    // we'll default to the end of the desired month by adding 1 to the desired
    // month and using a date of 0 to back up one day to the end of the desired
    // month.
    const endOfDesiredMonth = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$constructFrom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["constructFrom"])(options?.in || date, _date.getTime());
    endOfDesiredMonth.setMonth(_date.getMonth() + amount + 1, 0);
    const daysInMonth = endOfDesiredMonth.getDate();
    if (dayOfMonth >= daysInMonth) {
        // If we're already at the end of the month, then this is the correct date
        // and we're done.
        return endOfDesiredMonth;
    } else {
        // Otherwise, we now know that setting the original day-of-month value won't
        // cause an overflow, so set the desired day-of-month. Note that we can't
        // just set the date of `endOfDesiredMonth` because that object may have had
        // its time changed in the unusual case where where a DST transition was on
        // the last day of the month and its local time was in the hour skipped or
        // repeated next to a DST transition.  So we use `date` instead which is
        // guaranteed to still have the original time.
        _date.setFullYear(endOfDesiredMonth.getFullYear(), endOfDesiredMonth.getMonth(), dayOfMonth);
        return _date;
    }
}
const __TURBOPACK__default__export__ = addMonths;
}),
"[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/addWeeks.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "addWeeks",
    ()=>addWeeks,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$addDays$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/addDays.js [app-client] (ecmascript)");
;
function addWeeks(date, amount, options) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$addDays$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addDays"])(date, amount * 7, options);
}
const __TURBOPACK__default__export__ = addWeeks;
}),
"[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/addYears.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "addYears",
    ()=>addYears,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$addMonths$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/addMonths.js [app-client] (ecmascript)");
;
function addYears(date, amount, options) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$addMonths$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addMonths"])(date, amount * 12, options);
}
const __TURBOPACK__default__export__ = addYears;
}),
"[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/differenceInCalendarMonths.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "differenceInCalendarMonths",
    ()=>differenceInCalendarMonths
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$_lib$2f$normalizeDates$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/_lib/normalizeDates.js [app-client] (ecmascript)");
;
function differenceInCalendarMonths(laterDate, earlierDate, options) {
    const [laterDate_, earlierDate_] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$_lib$2f$normalizeDates$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeDates"])(options?.in, laterDate, earlierDate);
    const yearsDiff = laterDate_.getFullYear() - earlierDate_.getFullYear();
    const monthsDiff = laterDate_.getMonth() - earlierDate_.getMonth();
    return yearsDiff * 12 + monthsDiff;
}
const __TURBOPACK__default__export__ = differenceInCalendarMonths;
}),
"[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/_lib/normalizeInterval.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "normalizeInterval",
    ()=>normalizeInterval
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$_lib$2f$normalizeDates$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/_lib/normalizeDates.js [app-client] (ecmascript)");
;
function normalizeInterval(context, interval) {
    const [start, end] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$_lib$2f$normalizeDates$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeDates"])(context, interval.start, interval.end);
    return {
        start,
        end
    };
}
}),
"[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/eachMonthOfInterval.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "eachMonthOfInterval",
    ()=>eachMonthOfInterval
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$_lib$2f$normalizeInterval$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/_lib/normalizeInterval.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$constructFrom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/constructFrom.js [app-client] (ecmascript)");
;
;
function eachMonthOfInterval(interval, options) {
    const { start, end } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$_lib$2f$normalizeInterval$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeInterval"])(options?.in, interval);
    let reversed = +start > +end;
    const endTime = reversed ? +start : +end;
    const date = reversed ? end : start;
    date.setHours(0, 0, 0, 0);
    date.setDate(1);
    let step = options?.step ?? 1;
    if (!step) return [];
    if (step < 0) {
        step = -step;
        reversed = !reversed;
    }
    const dates = [];
    while(+date <= endTime){
        dates.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$constructFrom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["constructFrom"])(start, date));
        date.setMonth(date.getMonth() + step);
    }
    return reversed ? dates.reverse() : dates;
}
const __TURBOPACK__default__export__ = eachMonthOfInterval;
}),
"[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/endOfWeek.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "endOfWeek",
    ()=>endOfWeek
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$_lib$2f$defaultOptions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/_lib/defaultOptions.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$toDate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/toDate.js [app-client] (ecmascript)");
;
;
function endOfWeek(date, options) {
    const defaultOptions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$_lib$2f$defaultOptions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDefaultOptions"])();
    const weekStartsOn = options?.weekStartsOn ?? options?.locale?.options?.weekStartsOn ?? defaultOptions.weekStartsOn ?? defaultOptions.locale?.options?.weekStartsOn ?? 0;
    const _date = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$toDate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDate"])(date, options?.in);
    const day = _date.getDay();
    const diff = (day < weekStartsOn ? -7 : 0) + 6 - (day - weekStartsOn);
    _date.setDate(_date.getDate() + diff);
    _date.setHours(23, 59, 59, 999);
    return _date;
}
const __TURBOPACK__default__export__ = endOfWeek;
}),
"[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/endOfISOWeek.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "endOfISOWeek",
    ()=>endOfISOWeek
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$endOfWeek$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/endOfWeek.js [app-client] (ecmascript)");
;
function endOfISOWeek(date, options) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$endOfWeek$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["endOfWeek"])(date, {
        ...options,
        weekStartsOn: 1
    });
}
const __TURBOPACK__default__export__ = endOfISOWeek;
}),
"[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/endOfMonth.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "endOfMonth",
    ()=>endOfMonth
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$toDate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/toDate.js [app-client] (ecmascript)");
;
function endOfMonth(date, options) {
    const _date = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$toDate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDate"])(date, options?.in);
    const month = _date.getMonth();
    _date.setFullYear(_date.getFullYear(), month + 1, 0);
    _date.setHours(23, 59, 59, 999);
    return _date;
}
const __TURBOPACK__default__export__ = endOfMonth;
}),
"[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/endOfYear.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "endOfYear",
    ()=>endOfYear
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$toDate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/toDate.js [app-client] (ecmascript)");
;
function endOfYear(date, options) {
    const _date = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$toDate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDate"])(date, options?.in);
    const year = _date.getFullYear();
    _date.setFullYear(year + 1, 0, 0);
    _date.setHours(23, 59, 59, 999);
    return _date;
}
const __TURBOPACK__default__export__ = endOfYear;
}),
"[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/getMonth.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "getMonth",
    ()=>getMonth
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$toDate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/toDate.js [app-client] (ecmascript)");
;
function getMonth(date, options) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$toDate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDate"])(date, options?.in).getMonth();
}
const __TURBOPACK__default__export__ = getMonth;
}),
"[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/getYear.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "getYear",
    ()=>getYear
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$toDate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/toDate.js [app-client] (ecmascript)");
;
function getYear(date, options) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$toDate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDate"])(date, options?.in).getFullYear();
}
const __TURBOPACK__default__export__ = getYear;
}),
"[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/isAfter.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "isAfter",
    ()=>isAfter
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$toDate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/toDate.js [app-client] (ecmascript)");
;
function isAfter(date, dateToCompare) {
    return +(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$toDate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDate"])(date) > +(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$toDate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDate"])(dateToCompare);
}
const __TURBOPACK__default__export__ = isAfter;
}),
"[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/isSameMonth.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "isSameMonth",
    ()=>isSameMonth
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$_lib$2f$normalizeDates$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/_lib/normalizeDates.js [app-client] (ecmascript)");
;
function isSameMonth(laterDate, earlierDate, options) {
    const [laterDate_, earlierDate_] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$_lib$2f$normalizeDates$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeDates"])(options?.in, laterDate, earlierDate);
    return laterDate_.getFullYear() === earlierDate_.getFullYear() && laterDate_.getMonth() === earlierDate_.getMonth();
}
const __TURBOPACK__default__export__ = isSameMonth;
}),
"[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/isSameYear.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "isSameYear",
    ()=>isSameYear
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$_lib$2f$normalizeDates$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/_lib/normalizeDates.js [app-client] (ecmascript)");
;
function isSameYear(laterDate, earlierDate, options) {
    const [laterDate_, earlierDate_] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$_lib$2f$normalizeDates$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeDates"])(options?.in, laterDate, earlierDate);
    return laterDate_.getFullYear() === earlierDate_.getFullYear();
}
const __TURBOPACK__default__export__ = isSameYear;
}),
"[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/max.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "max",
    ()=>max
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$constructFrom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/constructFrom.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$toDate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/toDate.js [app-client] (ecmascript)");
;
;
function max(dates, options) {
    let result;
    let context = options?.in;
    dates.forEach((date)=>{
        // Use the first date object as the context function
        if (!context && typeof date === "object") context = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$constructFrom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["constructFrom"].bind(null, date);
        const date_ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$toDate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDate"])(date, context);
        if (!result || result < date_ || isNaN(+date_)) result = date_;
    });
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$constructFrom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["constructFrom"])(context, result || NaN);
}
const __TURBOPACK__default__export__ = max;
}),
"[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/min.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "min",
    ()=>min
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$constructFrom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/constructFrom.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$toDate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/toDate.js [app-client] (ecmascript)");
;
;
function min(dates, options) {
    let result;
    let context = options?.in;
    dates.forEach((date)=>{
        // Use the first date object as the context function
        if (!context && typeof date === "object") context = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$constructFrom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["constructFrom"].bind(null, date);
        const date_ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$toDate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDate"])(date, context);
        if (!result || result > date_ || isNaN(+date_)) result = date_;
    });
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$constructFrom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["constructFrom"])(context, result || NaN);
}
const __TURBOPACK__default__export__ = min;
}),
"[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/getDaysInMonth.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "getDaysInMonth",
    ()=>getDaysInMonth
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$constructFrom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/constructFrom.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$toDate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/toDate.js [app-client] (ecmascript)");
;
;
function getDaysInMonth(date, options) {
    const _date = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$toDate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDate"])(date, options?.in);
    const year = _date.getFullYear();
    const monthIndex = _date.getMonth();
    const lastDayOfMonth = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$constructFrom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["constructFrom"])(_date, 0);
    lastDayOfMonth.setFullYear(year, monthIndex + 1, 0);
    lastDayOfMonth.setHours(0, 0, 0, 0);
    return lastDayOfMonth.getDate();
}
const __TURBOPACK__default__export__ = getDaysInMonth;
}),
"[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/setMonth.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "setMonth",
    ()=>setMonth
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$constructFrom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/constructFrom.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$getDaysInMonth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/getDaysInMonth.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$toDate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/toDate.js [app-client] (ecmascript)");
;
;
;
function setMonth(date, month, options) {
    const _date = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$toDate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDate"])(date, options?.in);
    const year = _date.getFullYear();
    const day = _date.getDate();
    const midMonth = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$constructFrom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["constructFrom"])(options?.in || date, 0);
    midMonth.setFullYear(year, month, 15);
    midMonth.setHours(0, 0, 0, 0);
    const daysInMonth = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$getDaysInMonth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDaysInMonth"])(midMonth);
    // Set the earlier date, allows to wrap Jan 31 to Feb 28
    _date.setMonth(month, Math.min(day, daysInMonth));
    return _date;
}
const __TURBOPACK__default__export__ = setMonth;
}),
"[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/setYear.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "setYear",
    ()=>setYear
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$constructFrom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/constructFrom.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$toDate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/toDate.js [app-client] (ecmascript)");
;
;
function setYear(date, year, options) {
    const date_ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$toDate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDate"])(date, options?.in);
    // Check if date is Invalid Date because Date.prototype.setFullYear ignores the value of Invalid Date
    if (isNaN(+date_)) return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$constructFrom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["constructFrom"])(options?.in || date, NaN);
    date_.setFullYear(year);
    return date_;
}
const __TURBOPACK__default__export__ = setYear;
}),
"[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/startOfMonth.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "startOfMonth",
    ()=>startOfMonth
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$toDate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/toDate.js [app-client] (ecmascript)");
;
function startOfMonth(date, options) {
    const _date = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$toDate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDate"])(date, options?.in);
    _date.setDate(1);
    _date.setHours(0, 0, 0, 0);
    return _date;
}
const __TURBOPACK__default__export__ = startOfMonth;
}),
"[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/constructNow.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "constructNow",
    ()=>constructNow,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$constructFrom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/constructFrom.js [app-client] (ecmascript)");
;
function constructNow(date) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$constructFrom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["constructFrom"])(date, Date.now());
}
const __TURBOPACK__default__export__ = constructNow;
}),
"[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/isThisMonth.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "isThisMonth",
    ()=>isThisMonth
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$constructFrom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/constructFrom.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$constructNow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/constructNow.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$isSameMonth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/isSameMonth.js [app-client] (ecmascript)");
;
;
;
function isThisMonth(date, options) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$isSameMonth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSameMonth"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$constructFrom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["constructFrom"])(options?.in || date, date), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$constructNow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["constructNow"])(options?.in || date));
}
const __TURBOPACK__default__export__ = isThisMonth;
}),
"[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/subDays.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "subDays",
    ()=>subDays
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$addDays$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/addDays.js [app-client] (ecmascript)");
;
function subDays(date, amount, options) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$addDays$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addDays"])(date, -amount, options);
}
const __TURBOPACK__default__export__ = subDays;
}),
"[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/subMonths.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "subMonths",
    ()=>subMonths
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$addMonths$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/addMonths.js [app-client] (ecmascript)");
;
function subMonths(date, amount, options) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$addMonths$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addMonths"])(date, -amount, options);
}
const __TURBOPACK__default__export__ = subMonths;
}),
"[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/sub.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "sub",
    ()=>sub
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$constructFrom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/constructFrom.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$subDays$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/subDays.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$subMonths$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/subMonths.js [app-client] (ecmascript)");
;
;
;
function sub(date, duration, options) {
    const { years = 0, months = 0, weeks = 0, days = 0, hours = 0, minutes = 0, seconds = 0 } = duration;
    const withoutMonths = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$subMonths$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["subMonths"])(date, months + years * 12, options);
    const withoutDays = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$subDays$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["subDays"])(withoutMonths, days + weeks * 7, options);
    const minutesToSub = minutes + hours * 60;
    const secondsToSub = seconds + minutesToSub * 60;
    const msToSub = secondsToSub * 1000;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$constructFrom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["constructFrom"])(options?.in || date, +withoutDays - msToSub);
}
const __TURBOPACK__default__export__ = sub;
}),
"[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/differenceInDays.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "differenceInDays",
    ()=>differenceInDays
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$_lib$2f$normalizeDates$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/_lib/normalizeDates.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$differenceInCalendarDays$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/differenceInCalendarDays.js [app-client] (ecmascript)");
;
;
function differenceInDays(laterDate, earlierDate, options) {
    const [laterDate_, earlierDate_] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$_lib$2f$normalizeDates$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeDates"])(options?.in, laterDate, earlierDate);
    const sign = compareLocalAsc(laterDate_, earlierDate_);
    const difference = Math.abs((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$differenceInCalendarDays$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["differenceInCalendarDays"])(laterDate_, earlierDate_));
    laterDate_.setDate(laterDate_.getDate() - sign * difference);
    // Math.abs(diff in full days - diff in calendar days) === 1 if last calendar day is not full
    // If so, result must be decreased by 1 in absolute value
    const isLastDayNotFull = Number(compareLocalAsc(laterDate_, earlierDate_) === -sign);
    const result = sign * (difference - isLastDayNotFull);
    // Prevent negative zero
    return result === 0 ? 0 : result;
}
// Like `compareAsc` but uses local time not UTC, which is needed
// for accurate equality comparisons of UTC timestamps that end up
// having the same representation in local time, e.g. one hour before
// DST ends vs. the instant that DST ends.
function compareLocalAsc(laterDate, earlierDate) {
    const diff = laterDate.getFullYear() - earlierDate.getFullYear() || laterDate.getMonth() - earlierDate.getMonth() || laterDate.getDate() - earlierDate.getDate() || laterDate.getHours() - earlierDate.getHours() || laterDate.getMinutes() - earlierDate.getMinutes() || laterDate.getSeconds() - earlierDate.getSeconds() || laterDate.getMilliseconds() - earlierDate.getMilliseconds();
    if (diff < 0) return -1;
    if (diff > 0) return 1;
    // Return 0 if diff is 0; return NaN if diff is NaN
    return diff;
}
const __TURBOPACK__default__export__ = differenceInDays;
}),
"[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/endOfDay.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "endOfDay",
    ()=>endOfDay
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$toDate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/toDate.js [app-client] (ecmascript)");
;
function endOfDay(date, options) {
    const _date = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$toDate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDate"])(date, options?.in);
    _date.setHours(23, 59, 59, 999);
    return _date;
}
const __TURBOPACK__default__export__ = endOfDay;
}),
"[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/compareAsc.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "compareAsc",
    ()=>compareAsc,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$toDate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/toDate.js [app-client] (ecmascript)");
;
function compareAsc(dateLeft, dateRight) {
    const diff = +(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$toDate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDate"])(dateLeft) - +(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$toDate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDate"])(dateRight);
    if (diff < 0) return -1;
    else if (diff > 0) return 1;
    // Return 0 if diff is 0; return NaN if diff is NaN
    return diff;
}
const __TURBOPACK__default__export__ = compareAsc;
}),
"[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/isLastDayOfMonth.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "isLastDayOfMonth",
    ()=>isLastDayOfMonth
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$endOfDay$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/endOfDay.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$endOfMonth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/endOfMonth.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$toDate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/toDate.js [app-client] (ecmascript)");
;
;
;
function isLastDayOfMonth(date, options) {
    const _date = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$toDate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDate"])(date, options?.in);
    return +(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$endOfDay$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["endOfDay"])(_date, options) === +(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$endOfMonth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["endOfMonth"])(_date, options);
}
const __TURBOPACK__default__export__ = isLastDayOfMonth;
}),
"[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/differenceInMonths.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "differenceInMonths",
    ()=>differenceInMonths
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$_lib$2f$normalizeDates$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/_lib/normalizeDates.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$compareAsc$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/compareAsc.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$differenceInCalendarMonths$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/differenceInCalendarMonths.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$isLastDayOfMonth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/isLastDayOfMonth.js [app-client] (ecmascript)");
;
;
;
;
function differenceInMonths(laterDate, earlierDate, options) {
    const [laterDate_, workingLaterDate, earlierDate_] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$_lib$2f$normalizeDates$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeDates"])(options?.in, laterDate, laterDate, earlierDate);
    const sign = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$compareAsc$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compareAsc"])(workingLaterDate, earlierDate_);
    const difference = Math.abs((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$differenceInCalendarMonths$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["differenceInCalendarMonths"])(workingLaterDate, earlierDate_));
    if (difference < 1) return 0;
    if (workingLaterDate.getMonth() === 1 && workingLaterDate.getDate() > 27) workingLaterDate.setDate(30);
    workingLaterDate.setMonth(workingLaterDate.getMonth() - sign * difference);
    let isLastMonthNotFull = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$compareAsc$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compareAsc"])(workingLaterDate, earlierDate_) === -sign;
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$isLastDayOfMonth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isLastDayOfMonth"])(laterDate_) && difference === 1 && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$compareAsc$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compareAsc"])(laterDate_, earlierDate_) === 1) {
        isLastMonthNotFull = false;
    }
    const result = sign * (difference - +isLastMonthNotFull);
    return result === 0 ? 0 : result;
}
const __TURBOPACK__default__export__ = differenceInMonths;
}),
"[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/differenceInCalendarYears.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "differenceInCalendarYears",
    ()=>differenceInCalendarYears
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$_lib$2f$normalizeDates$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/_lib/normalizeDates.js [app-client] (ecmascript)");
;
function differenceInCalendarYears(laterDate, earlierDate, options) {
    const [laterDate_, earlierDate_] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$_lib$2f$normalizeDates$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeDates"])(options?.in, laterDate, earlierDate);
    return laterDate_.getFullYear() - earlierDate_.getFullYear();
}
const __TURBOPACK__default__export__ = differenceInCalendarYears;
}),
"[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/differenceInYears.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "differenceInYears",
    ()=>differenceInYears
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$_lib$2f$normalizeDates$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/_lib/normalizeDates.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$compareAsc$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/compareAsc.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$differenceInCalendarYears$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/differenceInCalendarYears.js [app-client] (ecmascript)");
;
;
;
function differenceInYears(laterDate, earlierDate, options) {
    const [laterDate_, earlierDate_] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$_lib$2f$normalizeDates$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeDates"])(options?.in, laterDate, earlierDate);
    // -1 if the left date is earlier than the right date
    // 2023-12-31 - 2024-01-01 = -1
    const sign = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$compareAsc$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compareAsc"])(laterDate_, earlierDate_);
    // First calculate the difference in calendar years
    // 2024-01-01 - 2023-12-31 = 1 year
    const diff = Math.abs((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$differenceInCalendarYears$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["differenceInCalendarYears"])(laterDate_, earlierDate_));
    // Now we need to calculate if the difference is full. To do that we set
    // both dates to the same year and check if the both date's month and day
    // form a full year.
    laterDate_.setFullYear(1584);
    earlierDate_.setFullYear(1584);
    // For it to be true, when the later date is indeed later than the earlier date
    // (2026-02-01 - 2023-12-10 = 3 years), the difference is full if
    // the normalized later date is also later than the normalized earlier date.
    // In our example, 1584-02-01 is earlier than 1584-12-10, so the difference
    // is partial, hence we need to subtract 1 from the difference 3 - 1 = 2.
    const partial = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$compareAsc$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compareAsc"])(laterDate_, earlierDate_) === -sign;
    const result = sign * (diff - +partial);
    // Prevent negative zero
    return result === 0 ? 0 : result;
}
const __TURBOPACK__default__export__ = differenceInYears;
}),
"[project]/node_modules/.pnpm/@date-fns+tz@1.2.0/node_modules/@date-fns/tz/constants/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * The symbol to access the `TZDate`'s function to construct a new instance from
 * the provided value. It helps date-fns to inherit the time zone.
 */ __turbopack_context__.s([
    "constructFromSymbol",
    ()=>constructFromSymbol
]);
const constructFromSymbol = Symbol.for("constructDateFrom");
}),
"[project]/node_modules/.pnpm/@date-fns+tz@1.2.0/node_modules/@date-fns/tz/tzOffset/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "tzOffset",
    ()=>tzOffset
]);
const offsetFormatCache = {};
const offsetCache = {};
function tzOffset(timeZone, date) {
    try {
        const format = offsetFormatCache[timeZone] ||= new Intl.DateTimeFormat("en-GB", {
            timeZone,
            hour: "numeric",
            timeZoneName: "longOffset"
        }).format;
        const offsetStr = format(date).split('GMT')[1] || '';
        if (offsetStr in offsetCache) return offsetCache[offsetStr];
        return calcOffset(offsetStr, offsetStr.split(":"));
    } catch  {
        // Fallback to manual parsing if the runtime doesn't support ±HH:MM/±HHMM/±HH
        // See: https://github.com/nodejs/node/issues/53419
        if (timeZone in offsetCache) return offsetCache[timeZone];
        const captures = timeZone?.match(offsetRe);
        if (captures) return calcOffset(timeZone, captures.slice(1));
        return NaN;
    }
}
const offsetRe = /([+-]\d\d):?(\d\d)?/;
function calcOffset(cacheStr, values) {
    const hours = +values[0];
    const minutes = +(values[1] || 0);
    return offsetCache[cacheStr] = hours > 0 ? hours * 60 + minutes : hours * 60 - minutes;
}
}),
"[project]/node_modules/.pnpm/@date-fns+tz@1.2.0/node_modules/@date-fns/tz/date/mini.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TZDateMini",
    ()=>TZDateMini
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$date$2d$fns$2b$tz$40$1$2e$2$2e$0$2f$node_modules$2f40$date$2d$fns$2f$tz$2f$tzOffset$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@date-fns+tz@1.2.0/node_modules/@date-fns/tz/tzOffset/index.js [app-client] (ecmascript)");
;
class TZDateMini extends Date {
    //#region static
    constructor(...args){
        super();
        if (args.length > 1 && typeof args[args.length - 1] === "string") {
            this.timeZone = args.pop();
        }
        this.internal = new Date();
        if (isNaN((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$date$2d$fns$2b$tz$40$1$2e$2$2e$0$2f$node_modules$2f40$date$2d$fns$2f$tz$2f$tzOffset$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tzOffset"])(this.timeZone, this))) {
            this.setTime(NaN);
        } else {
            if (!args.length) {
                this.setTime(Date.now());
            } else if (typeof args[0] === "number" && (args.length === 1 || args.length === 2 && typeof args[1] !== "number")) {
                this.setTime(args[0]);
            } else if (typeof args[0] === "string") {
                this.setTime(+new Date(args[0]));
            } else if (args[0] instanceof Date) {
                this.setTime(+args[0]);
            } else {
                this.setTime(+new Date(...args));
                adjustToSystemTZ(this, NaN);
                syncToInternal(this);
            }
        }
    }
    static tz(tz, ...args) {
        return args.length ? new TZDateMini(...args, tz) : new TZDateMini(Date.now(), tz);
    }
    //#endregion
    //#region time zone
    withTimeZone(timeZone) {
        return new TZDateMini(+this, timeZone);
    }
    getTimezoneOffset() {
        return -(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$date$2d$fns$2b$tz$40$1$2e$2$2e$0$2f$node_modules$2f40$date$2d$fns$2f$tz$2f$tzOffset$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tzOffset"])(this.timeZone, this);
    }
    //#endregion
    //#region time
    setTime(time) {
        Date.prototype.setTime.apply(this, arguments);
        syncToInternal(this);
        return +this;
    }
    //#endregion
    //#region date-fns integration
    [Symbol.for("constructDateFrom")](date) {
        return new TZDateMini(+new Date(date), this.timeZone);
    }
}
// Assign getters and setters
const re = /^(get|set)(?!UTC)/;
Object.getOwnPropertyNames(Date.prototype).forEach((method)=>{
    if (!re.test(method)) return;
    const utcMethod = method.replace(re, "$1UTC");
    // Filter out methods without UTC counterparts
    if (!TZDateMini.prototype[utcMethod]) return;
    if (method.startsWith("get")) {
        // Delegate to internal date's UTC method
        TZDateMini.prototype[method] = function() {
            return this.internal[utcMethod]();
        };
    } else {
        // Assign regular setter
        TZDateMini.prototype[method] = function() {
            Date.prototype[utcMethod].apply(this.internal, arguments);
            syncFromInternal(this);
            return +this;
        };
        // Assign UTC setter
        TZDateMini.prototype[utcMethod] = function() {
            Date.prototype[utcMethod].apply(this, arguments);
            syncToInternal(this);
            return +this;
        };
    }
});
/**
 * Function syncs time to internal date, applying the time zone offset.
 *
 * @param {Date} date - Date to sync
 */ function syncToInternal(date) {
    date.internal.setTime(+date);
    date.internal.setUTCMinutes(date.internal.getUTCMinutes() - date.getTimezoneOffset());
}
/**
 * Function syncs the internal date UTC values to the date. It allows to get
 * accurate timestamp value.
 *
 * @param {Date} date - The date to sync
 */ function syncFromInternal(date) {
    // First we transpose the internal values
    Date.prototype.setFullYear.call(date, date.internal.getUTCFullYear(), date.internal.getUTCMonth(), date.internal.getUTCDate());
    Date.prototype.setHours.call(date, date.internal.getUTCHours(), date.internal.getUTCMinutes(), date.internal.getUTCSeconds(), date.internal.getUTCMilliseconds());
    // Now we have to adjust the date to the system time zone
    adjustToSystemTZ(date);
}
/**
 * Function adjusts the date to the system time zone. It uses the time zone
 * differences to calculate the offset and adjust the date.
 *
 * @param {Date} date - Date to adjust
 */ function adjustToSystemTZ(date) {
    // Save the time zone offset before all the adjustments
    const offset = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$date$2d$fns$2b$tz$40$1$2e$2$2e$0$2f$node_modules$2f40$date$2d$fns$2f$tz$2f$tzOffset$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tzOffset"])(date.timeZone, date);
    //#region System DST adjustment
    // The biggest problem with using the system time zone is that when we create
    // a date from internal values stored in UTC, the system time zone might end
    // up on the DST hour:
    //
    //   $ TZ=America/New_York node
    //   > new Date(2020, 2, 8, 1).toString()
    //   'Sun Mar 08 2020 01:00:00 GMT-0500 (Eastern Standard Time)'
    //   > new Date(2020, 2, 8, 2).toString()
    //   'Sun Mar 08 2020 03:00:00 GMT-0400 (Eastern Daylight Time)'
    //   > new Date(2020, 2, 8, 3).toString()
    //   'Sun Mar 08 2020 03:00:00 GMT-0400 (Eastern Daylight Time)'
    //   > new Date(2020, 2, 8, 4).toString()
    //   'Sun Mar 08 2020 04:00:00 GMT-0400 (Eastern Daylight Time)'
    //
    // Here we get the same hour for both 2 and 3, because the system time zone
    // has DST beginning at 8 March 2020, 2 a.m. and jumps to 3 a.m. So we have
    // to adjust the internal date to reflect that.
    //
    // However we want to adjust only if that's the DST hour the change happenes,
    // not the hour where DST moves to.
    // We calculate the previous hour to see if the time zone offset has changed
    // and we have landed on the DST hour.
    const prevHour = new Date(+date);
    // We use UTC methods here as we don't want to land on the same hour again
    // in case of DST.
    prevHour.setUTCHours(prevHour.getUTCHours() - 1);
    // Calculate if we are on the system DST hour.
    const systemOffset = -new Date(+date).getTimezoneOffset();
    const prevHourSystemOffset = -new Date(+prevHour).getTimezoneOffset();
    const systemDSTChange = systemOffset - prevHourSystemOffset;
    // Detect the DST shift. System DST change will occur both on
    const dstShift = Date.prototype.getHours.apply(date) !== date.internal.getUTCHours();
    // Move the internal date when we are on the system DST hour.
    if (systemDSTChange && dstShift) date.internal.setUTCMinutes(date.internal.getUTCMinutes() + systemDSTChange);
    //#endregion
    //#region System diff adjustment
    // Now we need to adjust the date, since we just applied internal values.
    // We need to calculate the difference between the system and date time zones
    // and apply it to the date.
    const offsetDiff = systemOffset - offset;
    if (offsetDiff) Date.prototype.setUTCMinutes.call(date, Date.prototype.getUTCMinutes.call(date) + offsetDiff);
    //#endregion
    //#region Post-adjustment DST fix
    const postOffset = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$date$2d$fns$2b$tz$40$1$2e$2$2e$0$2f$node_modules$2f40$date$2d$fns$2f$tz$2f$tzOffset$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tzOffset"])(date.timeZone, date);
    const postSystemOffset = -new Date(+date).getTimezoneOffset();
    const postOffsetDiff = postSystemOffset - postOffset;
    const offsetChanged = postOffset !== offset;
    const postDiff = postOffsetDiff - offsetDiff;
    if (offsetChanged && postDiff) {
        Date.prototype.setUTCMinutes.call(date, Date.prototype.getUTCMinutes.call(date) + postDiff);
        // Now we need to check if got offset change during the post-adjustment.
        // If so, we also need both dates to reflect that.
        const newOffset = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$date$2d$fns$2b$tz$40$1$2e$2$2e$0$2f$node_modules$2f40$date$2d$fns$2f$tz$2f$tzOffset$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tzOffset"])(date.timeZone, date);
        const offsetChange = postOffset - newOffset;
        if (offsetChange) {
            date.internal.setUTCMinutes(date.internal.getUTCMinutes() + offsetChange);
            Date.prototype.setUTCMinutes.call(date, Date.prototype.getUTCMinutes.call(date) + offsetChange);
        }
    }
//#endregion
}
}),
"[project]/node_modules/.pnpm/@date-fns+tz@1.2.0/node_modules/@date-fns/tz/date/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TZDate",
    ()=>TZDate
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$date$2d$fns$2b$tz$40$1$2e$2$2e$0$2f$node_modules$2f40$date$2d$fns$2f$tz$2f$date$2f$mini$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@date-fns+tz@1.2.0/node_modules/@date-fns/tz/date/mini.js [app-client] (ecmascript)");
;
class TZDate extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$date$2d$fns$2b$tz$40$1$2e$2$2e$0$2f$node_modules$2f40$date$2d$fns$2f$tz$2f$date$2f$mini$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TZDateMini"] {
    //#region static
    static tz(tz, ...args) {
        return args.length ? new TZDate(...args, tz) : new TZDate(Date.now(), tz);
    }
    //#endregion
    //#region representation
    toISOString() {
        const [sign, hours, minutes] = this.tzComponents();
        const tz = `${sign}${hours}:${minutes}`;
        return this.internal.toISOString().slice(0, -1) + tz;
    }
    toString() {
        // "Tue Aug 13 2024 07:50:19 GMT+0800 (Singapore Standard Time)";
        return `${this.toDateString()} ${this.toTimeString()}`;
    }
    toDateString() {
        // toUTCString returns RFC 7231 ("Mon, 12 Aug 2024 23:36:08 GMT")
        const [day, date, month, year] = this.internal.toUTCString().split(" ");
        // "Tue Aug 13 2024"
        return `${day?.slice(0, -1)} ${month} ${date} ${year}`;
    }
    toTimeString() {
        // toUTCString returns RFC 7231 ("Mon, 12 Aug 2024 23:36:08 GMT")
        const time = this.internal.toUTCString().split(" ")[4];
        const [sign, hours, minutes] = this.tzComponents();
        // "07:42:23 GMT+0800 (Singapore Standard Time)"
        return `${time} GMT${sign}${hours}${minutes} (${tzName(this.timeZone, this)})`;
    }
    toLocaleString(locales, options) {
        return Date.prototype.toLocaleString.call(this, locales, {
            ...options,
            timeZone: options?.timeZone || this.timeZone
        });
    }
    toLocaleDateString(locales, options) {
        return Date.prototype.toLocaleDateString.call(this, locales, {
            ...options,
            timeZone: options?.timeZone || this.timeZone
        });
    }
    toLocaleTimeString(locales, options) {
        return Date.prototype.toLocaleTimeString.call(this, locales, {
            ...options,
            timeZone: options?.timeZone || this.timeZone
        });
    }
    //#endregion
    //#region private
    tzComponents() {
        const offset = this.getTimezoneOffset();
        const sign = offset > 0 ? "-" : "+";
        const hours = String(Math.floor(Math.abs(offset) / 60)).padStart(2, "0");
        const minutes = String(Math.abs(offset) % 60).padStart(2, "0");
        return [
            sign,
            hours,
            minutes
        ];
    }
    //#endregion
    withTimeZone(timeZone) {
        return new TZDate(+this, timeZone);
    }
    //#region date-fns integration
    [Symbol.for("constructDateFrom")](date) {
        return new TZDate(+new Date(date), this.timeZone);
    }
}
function tzName(tz, date) {
    return new Intl.DateTimeFormat("en-GB", {
        timeZone: tz,
        timeZoneName: "long"
    }).format(date).slice(12);
}
}),
"[project]/node_modules/.pnpm/@date-fns+tz@1.2.0/node_modules/@date-fns/tz/tz/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "tz",
    ()=>tz
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$date$2d$fns$2b$tz$40$1$2e$2$2e$0$2f$node_modules$2f40$date$2d$fns$2f$tz$2f$date$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@date-fns+tz@1.2.0/node_modules/@date-fns/tz/date/index.js [app-client] (ecmascript)");
;
const tz = (timeZone)=>(value)=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$date$2d$fns$2b$tz$40$1$2e$2$2e$0$2f$node_modules$2f40$date$2d$fns$2f$tz$2f$date$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TZDate"].tz(timeZone, +new Date(value));
}),
"[project]/node_modules/.pnpm/@date-fns+tz@1.2.0/node_modules/@date-fns/tz/tzScan/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "tzScan",
    ()=>tzScan
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$date$2d$fns$2b$tz$40$1$2e$2$2e$0$2f$node_modules$2f40$date$2d$fns$2f$tz$2f$tzOffset$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@date-fns+tz@1.2.0/node_modules/@date-fns/tz/tzOffset/index.js [app-client] (ecmascript)");
;
function tzScan(timeZone, interval) {
    const changes = [];
    const monthDate = new Date(interval.start);
    monthDate.setUTCSeconds(0, 0);
    const endDate = new Date(interval.end);
    endDate.setUTCSeconds(0, 0);
    const endMonthTime = +endDate;
    let lastOffset = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$date$2d$fns$2b$tz$40$1$2e$2$2e$0$2f$node_modules$2f40$date$2d$fns$2f$tz$2f$tzOffset$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tzOffset"])(timeZone, monthDate);
    while(+monthDate < endMonthTime){
        // Month forward
        monthDate.setUTCMonth(monthDate.getUTCMonth() + 1);
        // Find the month where the offset changes
        const offset = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$date$2d$fns$2b$tz$40$1$2e$2$2e$0$2f$node_modules$2f40$date$2d$fns$2f$tz$2f$tzOffset$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tzOffset"])(timeZone, monthDate);
        if (offset != lastOffset) {
            // Rewind a month back to find the day where the offset changes
            const dayDate = new Date(monthDate);
            dayDate.setUTCMonth(dayDate.getUTCMonth() - 1);
            const endDayTime = +monthDate;
            lastOffset = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$date$2d$fns$2b$tz$40$1$2e$2$2e$0$2f$node_modules$2f40$date$2d$fns$2f$tz$2f$tzOffset$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tzOffset"])(timeZone, dayDate);
            while(+dayDate < endDayTime){
                // Day forward
                dayDate.setUTCDate(dayDate.getUTCDate() + 1);
                // Find the day where the offset changes
                const offset = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$date$2d$fns$2b$tz$40$1$2e$2$2e$0$2f$node_modules$2f40$date$2d$fns$2f$tz$2f$tzOffset$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tzOffset"])(timeZone, dayDate);
                if (offset != lastOffset) {
                    // Rewind a day back to find the time where the offset changes
                    const hourDate = new Date(dayDate);
                    hourDate.setUTCDate(hourDate.getUTCDate() - 1);
                    const endHourTime = +dayDate;
                    lastOffset = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$date$2d$fns$2b$tz$40$1$2e$2$2e$0$2f$node_modules$2f40$date$2d$fns$2f$tz$2f$tzOffset$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tzOffset"])(timeZone, hourDate);
                    while(+hourDate < endHourTime){
                        // Hour forward
                        hourDate.setUTCHours(hourDate.getUTCHours() + 1);
                        // Find the hour where the offset changes
                        const hourOffset = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$date$2d$fns$2b$tz$40$1$2e$2$2e$0$2f$node_modules$2f40$date$2d$fns$2f$tz$2f$tzOffset$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tzOffset"])(timeZone, hourDate);
                        if (hourOffset !== lastOffset) {
                            changes.push({
                                date: new Date(hourDate),
                                change: hourOffset - lastOffset,
                                offset: hourOffset
                            });
                        }
                        lastOffset = hourOffset;
                    }
                }
                lastOffset = offset;
            }
        }
        lastOffset = offset;
    }
    return changes;
}
}),
"[project]/node_modules/.pnpm/@date-fns+tz@1.2.0/node_modules/@date-fns/tz/index.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$date$2d$fns$2b$tz$40$1$2e$2$2e$0$2f$node_modules$2f40$date$2d$fns$2f$tz$2f$constants$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@date-fns+tz@1.2.0/node_modules/@date-fns/tz/constants/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$date$2d$fns$2b$tz$40$1$2e$2$2e$0$2f$node_modules$2f40$date$2d$fns$2f$tz$2f$date$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@date-fns+tz@1.2.0/node_modules/@date-fns/tz/date/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$date$2d$fns$2b$tz$40$1$2e$2$2e$0$2f$node_modules$2f40$date$2d$fns$2f$tz$2f$date$2f$mini$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@date-fns+tz@1.2.0/node_modules/@date-fns/tz/date/mini.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$date$2d$fns$2b$tz$40$1$2e$2$2e$0$2f$node_modules$2f40$date$2d$fns$2f$tz$2f$tz$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@date-fns+tz@1.2.0/node_modules/@date-fns/tz/tz/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$date$2d$fns$2b$tz$40$1$2e$2$2e$0$2f$node_modules$2f40$date$2d$fns$2f$tz$2f$tzOffset$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@date-fns+tz@1.2.0/node_modules/@date-fns/tz/tzOffset/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$date$2d$fns$2b$tz$40$1$2e$2$2e$0$2f$node_modules$2f40$date$2d$fns$2f$tz$2f$tzScan$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@date-fns+tz@1.2.0/node_modules/@date-fns/tz/tzScan/index.js [app-client] (ecmascript)");
;
;
;
;
;
;
}),
"[project]/node_modules/.pnpm/@navikt+fnrvalidator@2.2.1/node_modules/@navikt/fnrvalidator/dist/validator.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.idnr = exports.getType = exports.dnrAndTnr = exports.dnrAndHnr = exports.tnr = exports.hnr = exports.dnr = exports.fnr = void 0;
const elevenDigits = new RegExp('^\\d{11}$');
const fnr = (digits)=>{
    return (0, exports.idnr)(digits);
};
exports.fnr = fnr;
const dnr = (digits)=>{
    return (0, exports.idnr)(digits);
};
exports.dnr = dnr;
const hnr = (digits)=>{
    return (0, exports.idnr)(digits);
};
exports.hnr = hnr;
const tnr = (digits)=>{
    return (0, exports.idnr)(digits);
};
exports.tnr = tnr;
const dnrAndHnr = (digits)=>{
    return (0, exports.idnr)(digits);
};
exports.dnrAndHnr = dnrAndHnr;
const dnrAndTnr = (digits)=>{
    return (0, exports.idnr)(digits);
};
exports.dnrAndTnr = dnrAndTnr;
const getType = (digits)=>{
    let nrs = digits.split("").map(Number);
    if (nrs[0] >= 4 && nrs[2] >= 8) {
        return 'dnr-and-tnr';
    }
    if (nrs[0] >= 4 && nrs[2] >= 4) {
        return 'dnr-and-hnr';
    }
    if (nrs[0] >= 4) {
        return 'dnr';
    }
    if (nrs[2] >= 8) {
        return "tnr";
    }
    if (nrs[2] >= 4) {
        return 'hnr';
    }
    return 'fnr';
};
exports.getType = getType;
const idnr = (digits)=>{
    const type = (0, exports.getType)(digits);
    return validate(digits, type);
};
exports.idnr = idnr;
const validate = (digits, type)=>{
    if (!elevenDigits.test(digits)) {
        return {
            status: "invalid",
            reasons: [
                "fnr, dnr or hnr must consist of 11 digits"
            ]
        };
    }
    const errMsgs = [
        ...checksums(digits),
        ...birthdate(digits, type)
    ];
    return errMsgs.length == 0 ? {
        status: "valid",
        type
    } : {
        status: "invalid",
        reasons: errMsgs
    };
};
const checksums = (digits)=>{
    let nrs = digits.split("").map(Number);
    // Calculate the weighted sum for k1
    const k1Sum = 3 * nrs[0] + 7 * nrs[1] + 6 * nrs[2] + 1 * nrs[3] + 8 * nrs[4] + 9 * nrs[5] + 4 * nrs[6] + 5 * nrs[7] + 2 * nrs[8];
    // https://skatteetaten.github.io/folkeregisteret-api-dokumentasjon/nytt-fodselsnummer-fra-2032/
    // New standard (2032): k1 can be calculated with rest values 0, 1, 2, or 3
    // This allows for 4 possible valid values for k1
    const validK1Values = [];
    for(let rest = 0; rest <= 3; rest++){
        let k1 = 11 + rest - k1Sum % 11;
        // If k1 > 10, subtract 11
        if (k1 > 10) {
            k1 = k1 - 11;
        }
        // Discard if k1 = 10
        if (k1 !== 10) {
            validK1Values.push(k1);
        }
    }
    const k1Actual = nrs[9];
    // Check if the actual k1 is one of the valid values
    if (!validK1Values.includes(k1Actual)) {
        return [
            "checksums don't match"
        ];
    }
    // Calculate k2 using the actual k1 value (same as before, only one valid value)
    let k2 = 11 - (5 * nrs[0] + 4 * nrs[1] + 3 * nrs[2] + 2 * nrs[3] + 7 * nrs[4] + 6 * nrs[5] + 5 * nrs[6] + 4 * nrs[7] + 3 * nrs[8] + 2 * k1Actual) % 11;
    if (k2 === 11) k2 = 0;
    // k2 must be less than 10 and match the actual value
    return k2 < 10 && k2 === nrs[10] ? [] : [
        "checksums don't match"
    ];
};
// copied from https://stackoverflow.com/questions/5812220/how-to-validate-a-date
const birthdate = (digits, type)=>{
    if (type === 'dnr') {
        digits = Number(digits.substring(0, 1)) - 4 + digits.substring(1);
    } else if (type === 'hnr') {
        digits = digits.substring(0, 2) + (Number(digits.substring(2, 3)) - 4) + digits.substring(3);
    } else if (type === 'tnr') {
        digits = digits.substring(0, 2) + (Number(digits.substring(2, 3)) - 8) + digits.substring(3);
    } else if (type === 'dnr-and-hnr') {
        digits = Number(digits.substring(0, 1)) - 4 + digits.substring(1, 2) + (Number(digits.substring(2, 3)) - 4) + digits.substring(3);
    } else if (type === 'dnr-and-tnr') {
        digits = Number(digits.substring(0, 1)) - 4 + digits.substring(1, 2) + (Number(digits.substring(2, 3)) - 8) + digits.substring(3);
    }
    const day = Number(digits.substring(0, 2));
    const month = Number(digits.substring(2, 4));
    const yearString = digits.substring(4, 6);
    const year = yearString == '00' ? 2000 : Number(yearString);
    // set year 00 default to 2000 instead of 1900
    const date = new Date(Date.UTC(year, month - 1, day));
    return date && date.getUTCMonth() + 1 == month && date.getUTCDate() == day ? [] : [
        "invalid date"
    ];
};
}),
"[project]/node_modules/.pnpm/domelementtype@2.3.0/node_modules/domelementtype/lib/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Doctype = exports.CDATA = exports.Tag = exports.Style = exports.Script = exports.Comment = exports.Directive = exports.Text = exports.Root = exports.isTag = exports.ElementType = void 0;
/** Types of elements found in htmlparser2's DOM */ var ElementType;
(function(ElementType) {
    /** Type for the root element of a document */ ElementType["Root"] = "root";
    /** Type for Text */ ElementType["Text"] = "text";
    /** Type for <? ... ?> */ ElementType["Directive"] = "directive";
    /** Type for <!-- ... --> */ ElementType["Comment"] = "comment";
    /** Type for <script> tags */ ElementType["Script"] = "script";
    /** Type for <style> tags */ ElementType["Style"] = "style";
    /** Type for Any tag */ ElementType["Tag"] = "tag";
    /** Type for <![CDATA[ ... ]]> */ ElementType["CDATA"] = "cdata";
    /** Type for <!doctype ...> */ ElementType["Doctype"] = "doctype";
})(ElementType = exports.ElementType || (exports.ElementType = {}));
/**
 * Tests whether an element is a tag or not.
 *
 * @param elem Element to test
 */ function isTag(elem) {
    return elem.type === ElementType.Tag || elem.type === ElementType.Script || elem.type === ElementType.Style;
}
exports.isTag = isTag;
// Exports for backwards compatibility
/** Type for the root element of a document */ exports.Root = ElementType.Root;
/** Type for Text */ exports.Text = ElementType.Text;
/** Type for <? ... ?> */ exports.Directive = ElementType.Directive;
/** Type for <!-- ... --> */ exports.Comment = ElementType.Comment;
/** Type for <script> tags */ exports.Script = ElementType.Script;
/** Type for <style> tags */ exports.Style = ElementType.Style;
/** Type for Any tag */ exports.Tag = ElementType.Tag;
/** Type for <![CDATA[ ... ]]> */ exports.CDATA = ElementType.CDATA;
/** Type for <!doctype ...> */ exports.Doctype = ElementType.Doctype;
}),
"[project]/node_modules/.pnpm/domhandler@5.0.3/node_modules/domhandler/lib/node.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __extends = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__extends || function() {
    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || ({
            __proto__: []
        }) instanceof Array && function(d, b) {
            d.__proto__ = b;
        } || function(d, b) {
            for(var p in b)if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
        };
        return extendStatics(d, b);
    };
    return function(d, b) {
        if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() {
            this.constructor = d;
        }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
}();
var __assign = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__assign || function() {
    __assign = Object.assign || function(t) {
        for(var s, i = 1, n = arguments.length; i < n; i++){
            s = arguments[i];
            for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.cloneNode = exports.hasChildren = exports.isDocument = exports.isDirective = exports.isComment = exports.isText = exports.isCDATA = exports.isTag = exports.Element = exports.Document = exports.CDATA = exports.NodeWithChildren = exports.ProcessingInstruction = exports.Comment = exports.Text = exports.DataNode = exports.Node = void 0;
var domelementtype_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/domelementtype@2.3.0/node_modules/domelementtype/lib/index.js [app-client] (ecmascript)");
/**
 * This object will be used as the prototype for Nodes when creating a
 * DOM-Level-1-compliant structure.
 */ var Node = function() {
    function Node() {
        /** Parent of the node */ this.parent = null;
        /** Previous sibling */ this.prev = null;
        /** Next sibling */ this.next = null;
        /** The start index of the node. Requires `withStartIndices` on the handler to be `true. */ this.startIndex = null;
        /** The end index of the node. Requires `withEndIndices` on the handler to be `true. */ this.endIndex = null;
    }
    Object.defineProperty(Node.prototype, "parentNode", {
        // Read-write aliases for properties
        /**
         * Same as {@link parent}.
         * [DOM spec](https://dom.spec.whatwg.org)-compatible alias.
         */ get: function() {
            return this.parent;
        },
        set: function(parent) {
            this.parent = parent;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Node.prototype, "previousSibling", {
        /**
         * Same as {@link prev}.
         * [DOM spec](https://dom.spec.whatwg.org)-compatible alias.
         */ get: function() {
            return this.prev;
        },
        set: function(prev) {
            this.prev = prev;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Node.prototype, "nextSibling", {
        /**
         * Same as {@link next}.
         * [DOM spec](https://dom.spec.whatwg.org)-compatible alias.
         */ get: function() {
            return this.next;
        },
        set: function(next) {
            this.next = next;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * Clone this node, and optionally its children.
     *
     * @param recursive Clone child nodes as well.
     * @returns A clone of the node.
     */ Node.prototype.cloneNode = function(recursive) {
        if (recursive === void 0) {
            recursive = false;
        }
        return cloneNode(this, recursive);
    };
    return Node;
}();
exports.Node = Node;
/**
 * A node that contains some data.
 */ var DataNode = function(_super) {
    __extends(DataNode, _super);
    /**
     * @param data The content of the data node
     */ function DataNode(data) {
        var _this = _super.call(this) || this;
        _this.data = data;
        return _this;
    }
    Object.defineProperty(DataNode.prototype, "nodeValue", {
        /**
         * Same as {@link data}.
         * [DOM spec](https://dom.spec.whatwg.org)-compatible alias.
         */ get: function() {
            return this.data;
        },
        set: function(data) {
            this.data = data;
        },
        enumerable: false,
        configurable: true
    });
    return DataNode;
}(Node);
exports.DataNode = DataNode;
/**
 * Text within the document.
 */ var Text = function(_super) {
    __extends(Text, _super);
    function Text() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.type = domelementtype_1.ElementType.Text;
        return _this;
    }
    Object.defineProperty(Text.prototype, "nodeType", {
        get: function() {
            return 3;
        },
        enumerable: false,
        configurable: true
    });
    return Text;
}(DataNode);
exports.Text = Text;
/**
 * Comments within the document.
 */ var Comment = function(_super) {
    __extends(Comment, _super);
    function Comment() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.type = domelementtype_1.ElementType.Comment;
        return _this;
    }
    Object.defineProperty(Comment.prototype, "nodeType", {
        get: function() {
            return 8;
        },
        enumerable: false,
        configurable: true
    });
    return Comment;
}(DataNode);
exports.Comment = Comment;
/**
 * Processing instructions, including doc types.
 */ var ProcessingInstruction = function(_super) {
    __extends(ProcessingInstruction, _super);
    function ProcessingInstruction(name, data) {
        var _this = _super.call(this, data) || this;
        _this.name = name;
        _this.type = domelementtype_1.ElementType.Directive;
        return _this;
    }
    Object.defineProperty(ProcessingInstruction.prototype, "nodeType", {
        get: function() {
            return 1;
        },
        enumerable: false,
        configurable: true
    });
    return ProcessingInstruction;
}(DataNode);
exports.ProcessingInstruction = ProcessingInstruction;
/**
 * A `Node` that can have children.
 */ var NodeWithChildren = function(_super) {
    __extends(NodeWithChildren, _super);
    /**
     * @param children Children of the node. Only certain node types can have children.
     */ function NodeWithChildren(children) {
        var _this = _super.call(this) || this;
        _this.children = children;
        return _this;
    }
    Object.defineProperty(NodeWithChildren.prototype, "firstChild", {
        // Aliases
        /** First child of the node. */ get: function() {
            var _a;
            return (_a = this.children[0]) !== null && _a !== void 0 ? _a : null;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(NodeWithChildren.prototype, "lastChild", {
        /** Last child of the node. */ get: function() {
            return this.children.length > 0 ? this.children[this.children.length - 1] : null;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(NodeWithChildren.prototype, "childNodes", {
        /**
         * Same as {@link children}.
         * [DOM spec](https://dom.spec.whatwg.org)-compatible alias.
         */ get: function() {
            return this.children;
        },
        set: function(children) {
            this.children = children;
        },
        enumerable: false,
        configurable: true
    });
    return NodeWithChildren;
}(Node);
exports.NodeWithChildren = NodeWithChildren;
var CDATA = function(_super) {
    __extends(CDATA, _super);
    function CDATA() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.type = domelementtype_1.ElementType.CDATA;
        return _this;
    }
    Object.defineProperty(CDATA.prototype, "nodeType", {
        get: function() {
            return 4;
        },
        enumerable: false,
        configurable: true
    });
    return CDATA;
}(NodeWithChildren);
exports.CDATA = CDATA;
/**
 * The root node of the document.
 */ var Document = function(_super) {
    __extends(Document, _super);
    function Document() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.type = domelementtype_1.ElementType.Root;
        return _this;
    }
    Object.defineProperty(Document.prototype, "nodeType", {
        get: function() {
            return 9;
        },
        enumerable: false,
        configurable: true
    });
    return Document;
}(NodeWithChildren);
exports.Document = Document;
/**
 * An element within the DOM.
 */ var Element = function(_super) {
    __extends(Element, _super);
    /**
     * @param name Name of the tag, eg. `div`, `span`.
     * @param attribs Object mapping attribute names to attribute values.
     * @param children Children of the node.
     */ function Element(name, attribs, children, type) {
        if (children === void 0) {
            children = [];
        }
        if (type === void 0) {
            type = name === "script" ? domelementtype_1.ElementType.Script : name === "style" ? domelementtype_1.ElementType.Style : domelementtype_1.ElementType.Tag;
        }
        var _this = _super.call(this, children) || this;
        _this.name = name;
        _this.attribs = attribs;
        _this.type = type;
        return _this;
    }
    Object.defineProperty(Element.prototype, "nodeType", {
        get: function() {
            return 1;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Element.prototype, "tagName", {
        // DOM Level 1 aliases
        /**
         * Same as {@link name}.
         * [DOM spec](https://dom.spec.whatwg.org)-compatible alias.
         */ get: function() {
            return this.name;
        },
        set: function(name) {
            this.name = name;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Element.prototype, "attributes", {
        get: function() {
            var _this = this;
            return Object.keys(this.attribs).map(function(name) {
                var _a, _b;
                return {
                    name: name,
                    value: _this.attribs[name],
                    namespace: (_a = _this["x-attribsNamespace"]) === null || _a === void 0 ? void 0 : _a[name],
                    prefix: (_b = _this["x-attribsPrefix"]) === null || _b === void 0 ? void 0 : _b[name]
                };
            });
        },
        enumerable: false,
        configurable: true
    });
    return Element;
}(NodeWithChildren);
exports.Element = Element;
/**
 * @param node Node to check.
 * @returns `true` if the node is a `Element`, `false` otherwise.
 */ function isTag(node) {
    return (0, domelementtype_1.isTag)(node);
}
exports.isTag = isTag;
/**
 * @param node Node to check.
 * @returns `true` if the node has the type `CDATA`, `false` otherwise.
 */ function isCDATA(node) {
    return node.type === domelementtype_1.ElementType.CDATA;
}
exports.isCDATA = isCDATA;
/**
 * @param node Node to check.
 * @returns `true` if the node has the type `Text`, `false` otherwise.
 */ function isText(node) {
    return node.type === domelementtype_1.ElementType.Text;
}
exports.isText = isText;
/**
 * @param node Node to check.
 * @returns `true` if the node has the type `Comment`, `false` otherwise.
 */ function isComment(node) {
    return node.type === domelementtype_1.ElementType.Comment;
}
exports.isComment = isComment;
/**
 * @param node Node to check.
 * @returns `true` if the node has the type `ProcessingInstruction`, `false` otherwise.
 */ function isDirective(node) {
    return node.type === domelementtype_1.ElementType.Directive;
}
exports.isDirective = isDirective;
/**
 * @param node Node to check.
 * @returns `true` if the node has the type `ProcessingInstruction`, `false` otherwise.
 */ function isDocument(node) {
    return node.type === domelementtype_1.ElementType.Root;
}
exports.isDocument = isDocument;
/**
 * @param node Node to check.
 * @returns `true` if the node has children, `false` otherwise.
 */ function hasChildren(node) {
    return Object.prototype.hasOwnProperty.call(node, "children");
}
exports.hasChildren = hasChildren;
/**
 * Clone a node, and optionally its children.
 *
 * @param recursive Clone child nodes as well.
 * @returns A clone of the node.
 */ function cloneNode(node, recursive) {
    if (recursive === void 0) {
        recursive = false;
    }
    var result;
    if (isText(node)) {
        result = new Text(node.data);
    } else if (isComment(node)) {
        result = new Comment(node.data);
    } else if (isTag(node)) {
        var children = recursive ? cloneChildren(node.children) : [];
        var clone_1 = new Element(node.name, __assign({}, node.attribs), children);
        children.forEach(function(child) {
            return child.parent = clone_1;
        });
        if (node.namespace != null) {
            clone_1.namespace = node.namespace;
        }
        if (node["x-attribsNamespace"]) {
            clone_1["x-attribsNamespace"] = __assign({}, node["x-attribsNamespace"]);
        }
        if (node["x-attribsPrefix"]) {
            clone_1["x-attribsPrefix"] = __assign({}, node["x-attribsPrefix"]);
        }
        result = clone_1;
    } else if (isCDATA(node)) {
        var children = recursive ? cloneChildren(node.children) : [];
        var clone_2 = new CDATA(children);
        children.forEach(function(child) {
            return child.parent = clone_2;
        });
        result = clone_2;
    } else if (isDocument(node)) {
        var children = recursive ? cloneChildren(node.children) : [];
        var clone_3 = new Document(children);
        children.forEach(function(child) {
            return child.parent = clone_3;
        });
        if (node["x-mode"]) {
            clone_3["x-mode"] = node["x-mode"];
        }
        result = clone_3;
    } else if (isDirective(node)) {
        var instruction = new ProcessingInstruction(node.name, node.data);
        if (node["x-name"] != null) {
            instruction["x-name"] = node["x-name"];
            instruction["x-publicId"] = node["x-publicId"];
            instruction["x-systemId"] = node["x-systemId"];
        }
        result = instruction;
    } else {
        throw new Error("Not implemented yet: ".concat(node.type));
    }
    result.startIndex = node.startIndex;
    result.endIndex = node.endIndex;
    if (node.sourceCodeLocation != null) {
        result.sourceCodeLocation = node.sourceCodeLocation;
    }
    return result;
}
exports.cloneNode = cloneNode;
function cloneChildren(childs) {
    var children = childs.map(function(child) {
        return cloneNode(child, true);
    });
    for(var i = 1; i < children.length; i++){
        children[i].prev = children[i - 1];
        children[i - 1].next = children[i];
    }
    return children;
}
}),
"[project]/node_modules/.pnpm/domhandler@5.0.3/node_modules/domhandler/lib/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __createBinding = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.DomHandler = void 0;
var domelementtype_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/domelementtype@2.3.0/node_modules/domelementtype/lib/index.js [app-client] (ecmascript)");
var node_js_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/domhandler@5.0.3/node_modules/domhandler/lib/node.js [app-client] (ecmascript)");
__exportStar(__turbopack_context__.r("[project]/node_modules/.pnpm/domhandler@5.0.3/node_modules/domhandler/lib/node.js [app-client] (ecmascript)"), exports);
// Default options
var defaultOpts = {
    withStartIndices: false,
    withEndIndices: false,
    xmlMode: false
};
var DomHandler = function() {
    /**
     * @param callback Called once parsing has completed.
     * @param options Settings for the handler.
     * @param elementCB Callback whenever a tag is closed.
     */ function DomHandler(callback, options, elementCB) {
        /** The elements of the DOM */ this.dom = [];
        /** The root element for the DOM */ this.root = new node_js_1.Document(this.dom);
        /** Indicated whether parsing has been completed. */ this.done = false;
        /** Stack of open tags. */ this.tagStack = [
            this.root
        ];
        /** A data node that is still being written to. */ this.lastNode = null;
        /** Reference to the parser instance. Used for location information. */ this.parser = null;
        // Make it possible to skip arguments, for backwards-compatibility
        if (typeof options === "function") {
            elementCB = options;
            options = defaultOpts;
        }
        if (typeof callback === "object") {
            options = callback;
            callback = undefined;
        }
        this.callback = callback !== null && callback !== void 0 ? callback : null;
        this.options = options !== null && options !== void 0 ? options : defaultOpts;
        this.elementCB = elementCB !== null && elementCB !== void 0 ? elementCB : null;
    }
    DomHandler.prototype.onparserinit = function(parser) {
        this.parser = parser;
    };
    // Resets the handler back to starting state
    DomHandler.prototype.onreset = function() {
        this.dom = [];
        this.root = new node_js_1.Document(this.dom);
        this.done = false;
        this.tagStack = [
            this.root
        ];
        this.lastNode = null;
        this.parser = null;
    };
    // Signals the handler that parsing is done
    DomHandler.prototype.onend = function() {
        if (this.done) return;
        this.done = true;
        this.parser = null;
        this.handleCallback(null);
    };
    DomHandler.prototype.onerror = function(error) {
        this.handleCallback(error);
    };
    DomHandler.prototype.onclosetag = function() {
        this.lastNode = null;
        var elem = this.tagStack.pop();
        if (this.options.withEndIndices) {
            elem.endIndex = this.parser.endIndex;
        }
        if (this.elementCB) this.elementCB(elem);
    };
    DomHandler.prototype.onopentag = function(name, attribs) {
        var type = this.options.xmlMode ? domelementtype_1.ElementType.Tag : undefined;
        var element = new node_js_1.Element(name, attribs, undefined, type);
        this.addNode(element);
        this.tagStack.push(element);
    };
    DomHandler.prototype.ontext = function(data) {
        var lastNode = this.lastNode;
        if (lastNode && lastNode.type === domelementtype_1.ElementType.Text) {
            lastNode.data += data;
            if (this.options.withEndIndices) {
                lastNode.endIndex = this.parser.endIndex;
            }
        } else {
            var node = new node_js_1.Text(data);
            this.addNode(node);
            this.lastNode = node;
        }
    };
    DomHandler.prototype.oncomment = function(data) {
        if (this.lastNode && this.lastNode.type === domelementtype_1.ElementType.Comment) {
            this.lastNode.data += data;
            return;
        }
        var node = new node_js_1.Comment(data);
        this.addNode(node);
        this.lastNode = node;
    };
    DomHandler.prototype.oncommentend = function() {
        this.lastNode = null;
    };
    DomHandler.prototype.oncdatastart = function() {
        var text = new node_js_1.Text("");
        var node = new node_js_1.CDATA([
            text
        ]);
        this.addNode(node);
        text.parent = node;
        this.lastNode = text;
    };
    DomHandler.prototype.oncdataend = function() {
        this.lastNode = null;
    };
    DomHandler.prototype.onprocessinginstruction = function(name, data) {
        var node = new node_js_1.ProcessingInstruction(name, data);
        this.addNode(node);
    };
    DomHandler.prototype.handleCallback = function(error) {
        if (typeof this.callback === "function") {
            this.callback(error, this.dom);
        } else if (error) {
            throw error;
        }
    };
    DomHandler.prototype.addNode = function(node) {
        var parent = this.tagStack[this.tagStack.length - 1];
        var previousSibling = parent.children[parent.children.length - 1];
        if (this.options.withStartIndices) {
            node.startIndex = this.parser.startIndex;
        }
        if (this.options.withEndIndices) {
            node.endIndex = this.parser.endIndex;
        }
        parent.children.push(node);
        if (previousSibling) {
            node.prev = previousSibling;
            previousSibling.next = node;
        }
        node.parent = parent;
        this.lastNode = null;
    };
    return DomHandler;
}();
exports.DomHandler = DomHandler;
exports.default = DomHandler;
}),
"[project]/node_modules/.pnpm/html-dom-parser@5.1.2/node_modules/html-dom-parser/lib/client/constants.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.CARRIAGE_RETURN_PLACEHOLDER_REGEX = exports.CARRIAGE_RETURN_PLACEHOLDER = exports.CARRIAGE_RETURN_REGEX = exports.CARRIAGE_RETURN = exports.CASE_SENSITIVE_TAG_NAMES_MAP = exports.CASE_SENSITIVE_TAG_NAMES = void 0;
/**
 * SVG elements are case-sensitive.
 *
 * @see https://developer.mozilla.org/docs/Web/SVG/Element#svg_elements_a_to_z
 */ exports.CASE_SENSITIVE_TAG_NAMES = [
    'animateMotion',
    'animateTransform',
    'clipPath',
    'feBlend',
    'feColorMatrix',
    'feComponentTransfer',
    'feComposite',
    'feConvolveMatrix',
    'feDiffuseLighting',
    'feDisplacementMap',
    'feDropShadow',
    'feFlood',
    'feFuncA',
    'feFuncB',
    'feFuncG',
    'feFuncR',
    'feGaussianBlur',
    'feImage',
    'feMerge',
    'feMergeNode',
    'feMorphology',
    'feOffset',
    'fePointLight',
    'feSpecularLighting',
    'feSpotLight',
    'feTile',
    'feTurbulence',
    'foreignObject',
    'linearGradient',
    'radialGradient',
    'textPath'
];
exports.CASE_SENSITIVE_TAG_NAMES_MAP = exports.CASE_SENSITIVE_TAG_NAMES.reduce(function(accumulator, tagName) {
    accumulator[tagName.toLowerCase()] = tagName;
    return accumulator;
}, {});
exports.CARRIAGE_RETURN = '\r';
exports.CARRIAGE_RETURN_REGEX = new RegExp(exports.CARRIAGE_RETURN, 'g');
exports.CARRIAGE_RETURN_PLACEHOLDER = "__HTML_DOM_PARSER_CARRIAGE_RETURN_PLACEHOLDER_".concat(Date.now(), "__");
exports.CARRIAGE_RETURN_PLACEHOLDER_REGEX = new RegExp(exports.CARRIAGE_RETURN_PLACEHOLDER, 'g'); //# sourceMappingURL=constants.js.map
}),
"[project]/node_modules/.pnpm/html-dom-parser@5.1.2/node_modules/html-dom-parser/lib/client/utilities.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.formatAttributes = formatAttributes;
exports.escapeSpecialCharacters = escapeSpecialCharacters;
exports.revertEscapedCharacters = revertEscapedCharacters;
exports.formatDOM = formatDOM;
var domhandler_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/domhandler@5.0.3/node_modules/domhandler/lib/index.js [app-client] (ecmascript)");
var constants_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/html-dom-parser@5.1.2/node_modules/html-dom-parser/lib/client/constants.js [app-client] (ecmascript)");
/**
 * Gets case-sensitive tag name.
 *
 * @param tagName - Tag name in lowercase.
 * @returns - Case-sensitive tag name.
 */ function getCaseSensitiveTagName(tagName) {
    return constants_1.CASE_SENSITIVE_TAG_NAMES_MAP[tagName];
}
/**
 * Formats DOM attributes to a hash map.
 *
 * @param attributes - List of attributes.
 * @returns - Map of attribute name to value.
 */ function formatAttributes(attributes) {
    var map = {};
    var index = 0;
    var attributesLength = attributes.length;
    // `NamedNodeMap` is array-like
    for(; index < attributesLength; index++){
        var attribute = attributes[index];
        map[attribute.name] = attribute.value;
    }
    return map;
}
/**
 * Corrects the tag name if it is case-sensitive (SVG).
 * Otherwise, returns the lowercase tag name (HTML).
 *
 * @param tagName - Lowercase tag name.
 * @returns - Formatted tag name.
 */ function formatTagName(tagName) {
    tagName = tagName.toLowerCase();
    var caseSensitiveTagName = getCaseSensitiveTagName(tagName);
    if (caseSensitiveTagName) {
        return caseSensitiveTagName;
    }
    return tagName;
}
/**
 * Escapes special characters before parsing.
 *
 * @param html - The HTML string.
 * @returns - HTML string with escaped special characters.
 */ function escapeSpecialCharacters(html) {
    return html.replace(constants_1.CARRIAGE_RETURN_REGEX, constants_1.CARRIAGE_RETURN_PLACEHOLDER);
}
/**
 * Reverts escaped special characters back to actual characters.
 *
 * @param text - The text with escaped characters.
 * @returns - Text with escaped characters reverted.
 */ function revertEscapedCharacters(text) {
    return text.replace(constants_1.CARRIAGE_RETURN_PLACEHOLDER_REGEX, constants_1.CARRIAGE_RETURN);
}
/**
 * Transforms DOM nodes to `domhandler` nodes.
 *
 * @param nodes - DOM nodes.
 * @param parent - Parent node.
 * @param directive - Directive.
 * @returns - Nodes.
 */ function formatDOM(nodes, parent, directive) {
    if (parent === void 0) {
        parent = null;
    }
    var domNodes = [];
    var current;
    var index = 0;
    var nodesLength = nodes.length;
    for(; index < nodesLength; index++){
        var node = nodes[index];
        // set the node data given the type
        switch(node.nodeType){
            case 1:
                {
                    var tagName = formatTagName(node.nodeName);
                    // script, style, or tag
                    current = new domhandler_1.Element(tagName, formatAttributes(node.attributes));
                    current.children = formatDOM(// template children are on content
                    tagName === 'template' ? node.content.childNodes : node.childNodes, current);
                    break;
                }
            case 3:
                current = new domhandler_1.Text(revertEscapedCharacters(node.nodeValue));
                break;
            case 8:
                current = new domhandler_1.Comment(node.nodeValue);
                break;
            default:
                continue;
        }
        // set previous node next
        var prev = domNodes[index - 1] || null;
        if (prev) {
            prev.next = current;
        }
        // set properties for current node
        current.parent = parent;
        current.prev = prev;
        current.next = null;
        domNodes.push(current);
    }
    if (directive) {
        current = new domhandler_1.ProcessingInstruction(directive.substring(0, directive.indexOf(' ')).toLowerCase(), directive);
        current.next = domNodes[0] || null;
        current.parent = parent;
        domNodes.unshift(current);
        if (domNodes[1]) {
            domNodes[1].prev = domNodes[0];
        }
    }
    return domNodes;
} //# sourceMappingURL=utilities.js.map
}),
"[project]/node_modules/.pnpm/html-dom-parser@5.1.2/node_modules/html-dom-parser/lib/client/domparser.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = domparser;
var utilities_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/html-dom-parser@5.1.2/node_modules/html-dom-parser/lib/client/utilities.js [app-client] (ecmascript)");
// constants
var HTML = 'html';
var HEAD = 'head';
var BODY = 'body';
var FIRST_TAG_REGEX = /<([a-zA-Z]+[0-9]?)/; // e.g., <h1>
// match-all-characters in case of newlines (DOTALL)
var HEAD_TAG_REGEX = /<head[^]*>/i;
var BODY_TAG_REGEX = /<body[^]*>/i;
// falls back to `parseFromString` if `createHTMLDocument` cannot be used
// eslint-disable-next-line @typescript-eslint/no-unused-vars
var parseFromDocument = function(html, tagName) {
    /* istanbul ignore next */ throw new Error('This browser does not support `document.implementation.createHTMLDocument`');
};
// eslint-disable-next-line @typescript-eslint/no-unused-vars
var parseFromString = function(html, tagName) {
    /* istanbul ignore next */ throw new Error('This browser does not support `DOMParser.prototype.parseFromString`');
};
var DOMParser = typeof window === 'object' && window.DOMParser;
/**
 * DOMParser (performance: slow).
 *
 * @see https://developer.mozilla.org/docs/Web/API/DOMParser#Parsing_an_SVG_or_HTML_document
 */ if (typeof DOMParser === 'function') {
    var domParser_1 = new DOMParser();
    var mimeType_1 = 'text/html';
    /**
     * Creates an HTML document using `DOMParser.parseFromString`.
     *
     * @param html - The HTML string.
     * @param tagName - The element to render the HTML (with 'body' as fallback).
     * @returns - Document.
     */ parseFromString = function(html, tagName) {
        if (tagName) {
            /* istanbul ignore next */ html = "<".concat(tagName, ">").concat(html, "</").concat(tagName, ">");
        }
        return domParser_1.parseFromString(html, mimeType_1);
    };
    parseFromDocument = parseFromString;
}
/**
 * DOMImplementation (performance: fair).
 *
 * @see https://developer.mozilla.org/docs/Web/API/DOMImplementation/createHTMLDocument
 */ if (typeof document === 'object' && document.implementation) {
    var htmlDocument_1 = document.implementation.createHTMLDocument();
    /**
     * Use HTML document created by `document.implementation.createHTMLDocument`.
     *
     * @param html - The HTML string.
     * @param tagName - The element to render the HTML (with 'body' as fallback).
     * @returns - Document
     */ parseFromDocument = function(html, tagName) {
        if (tagName) {
            var element = htmlDocument_1.documentElement.querySelector(tagName);
            if (element) {
                element.innerHTML = html;
            }
            return htmlDocument_1;
        }
        htmlDocument_1.documentElement.innerHTML = html;
        return htmlDocument_1;
    };
}
/**
 * Template (performance: fast).
 *
 * @see https://developer.mozilla.org/docs/Web/HTML/Element/template
 */ var template = typeof document === 'object' && document.createElement('template');
var parseFromTemplate;
if (template && template.content) {
    /**
     * Uses a template element (content fragment) to parse HTML.
     *
     * @param html - HTML string.
     * @returns - Nodes.
     */ parseFromTemplate = function(html) {
        template.innerHTML = html;
        return template.content.childNodes;
    };
}
/**
 * Parses HTML string to DOM nodes.
 *
 * @param html - HTML markup.
 * @returns - DOM nodes.
 */ function domparser(html) {
    var _a, _b;
    // Escape special characters before parsing
    html = (0, utilities_1.escapeSpecialCharacters)(html);
    var match = html.match(FIRST_TAG_REGEX);
    var firstTagName = match && match[1] ? match[1].toLowerCase() : '';
    switch(firstTagName){
        case HTML:
            {
                var doc = parseFromString(html);
                // the created document may come with filler head/body elements,
                // so make sure to remove them if they don't actually exist
                if (!HEAD_TAG_REGEX.test(html)) {
                    var element = doc.querySelector(HEAD);
                    (_a = element === null || element === void 0 ? void 0 : element.parentNode) === null || _a === void 0 ? void 0 : _a.removeChild(element);
                }
                if (!BODY_TAG_REGEX.test(html)) {
                    var element = doc.querySelector(BODY);
                    (_b = element === null || element === void 0 ? void 0 : element.parentNode) === null || _b === void 0 ? void 0 : _b.removeChild(element);
                }
                return doc.querySelectorAll(HTML);
            }
        case HEAD:
        case BODY:
            {
                var elements = parseFromDocument(html).querySelectorAll(firstTagName);
                // if there's a sibling element, then return both elements
                if (BODY_TAG_REGEX.test(html) && HEAD_TAG_REGEX.test(html)) {
                    return elements[0].parentNode.childNodes;
                }
                return elements;
            }
        // low-level tag or text
        default:
            {
                if (parseFromTemplate) {
                    return parseFromTemplate(html);
                }
                var element = parseFromDocument(html, BODY).querySelector(BODY);
                return element.childNodes;
            }
    }
} //# sourceMappingURL=domparser.js.map
}),
"[project]/node_modules/.pnpm/html-dom-parser@5.1.2/node_modules/html-dom-parser/lib/client/html-to-dom.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __importDefault = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = HTMLDOMParser;
var domparser_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/html-dom-parser@5.1.2/node_modules/html-dom-parser/lib/client/domparser.js [app-client] (ecmascript)"));
var utilities_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/html-dom-parser@5.1.2/node_modules/html-dom-parser/lib/client/utilities.js [app-client] (ecmascript)");
var DIRECTIVE_REGEX = /<(![a-zA-Z\s]+)>/; // e.g., <!doctype html>
/**
 * Parses HTML string to DOM nodes in browser.
 *
 * @param html - HTML markup.
 * @returns - DOM elements.
 */ function HTMLDOMParser(html) {
    if (typeof html !== 'string') {
        throw new TypeError('First argument must be a string');
    }
    if (!html) {
        return [];
    }
    // match directive
    var match = html.match(DIRECTIVE_REGEX);
    var directive = match ? match[1] : undefined;
    return (0, utilities_1.formatDOM)((0, domparser_1.default)(html), null, directive);
} //# sourceMappingURL=html-to-dom.js.map
}),
"[project]/node_modules/.pnpm/react-property@2.0.2/node_modules/react-property/lib/possibleStandardNamesOptimized.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

// An attribute in which the DOM/SVG standard name is the same as the React prop name (e.g., 'accept').
var SAME = 0;
exports.SAME = SAME;
// An attribute in which the React prop name is the camelcased version of the DOM/SVG standard name (e.g., 'acceptCharset').
var CAMELCASE = 1;
exports.CAMELCASE = CAMELCASE;
exports.possibleStandardNames = {
    accept: 0,
    acceptCharset: 1,
    'accept-charset': 'acceptCharset',
    accessKey: 1,
    action: 0,
    allowFullScreen: 1,
    alt: 0,
    as: 0,
    async: 0,
    autoCapitalize: 1,
    autoComplete: 1,
    autoCorrect: 1,
    autoFocus: 1,
    autoPlay: 1,
    autoSave: 1,
    capture: 0,
    cellPadding: 1,
    cellSpacing: 1,
    challenge: 0,
    charSet: 1,
    checked: 0,
    children: 0,
    cite: 0,
    class: 'className',
    classID: 1,
    className: 1,
    cols: 0,
    colSpan: 1,
    content: 0,
    contentEditable: 1,
    contextMenu: 1,
    controls: 0,
    controlsList: 1,
    coords: 0,
    crossOrigin: 1,
    dangerouslySetInnerHTML: 1,
    data: 0,
    dateTime: 1,
    default: 0,
    defaultChecked: 1,
    defaultValue: 1,
    defer: 0,
    dir: 0,
    disabled: 0,
    disablePictureInPicture: 1,
    disableRemotePlayback: 1,
    download: 0,
    draggable: 0,
    encType: 1,
    enterKeyHint: 1,
    for: 'htmlFor',
    form: 0,
    formMethod: 1,
    formAction: 1,
    formEncType: 1,
    formNoValidate: 1,
    formTarget: 1,
    frameBorder: 1,
    headers: 0,
    height: 0,
    hidden: 0,
    high: 0,
    href: 0,
    hrefLang: 1,
    htmlFor: 1,
    httpEquiv: 1,
    'http-equiv': 'httpEquiv',
    icon: 0,
    id: 0,
    innerHTML: 1,
    inputMode: 1,
    integrity: 0,
    is: 0,
    itemID: 1,
    itemProp: 1,
    itemRef: 1,
    itemScope: 1,
    itemType: 1,
    keyParams: 1,
    keyType: 1,
    kind: 0,
    label: 0,
    lang: 0,
    list: 0,
    loop: 0,
    low: 0,
    manifest: 0,
    marginWidth: 1,
    marginHeight: 1,
    max: 0,
    maxLength: 1,
    media: 0,
    mediaGroup: 1,
    method: 0,
    min: 0,
    minLength: 1,
    multiple: 0,
    muted: 0,
    name: 0,
    noModule: 1,
    nonce: 0,
    noValidate: 1,
    open: 0,
    optimum: 0,
    pattern: 0,
    placeholder: 0,
    playsInline: 1,
    poster: 0,
    preload: 0,
    profile: 0,
    radioGroup: 1,
    readOnly: 1,
    referrerPolicy: 1,
    rel: 0,
    required: 0,
    reversed: 0,
    role: 0,
    rows: 0,
    rowSpan: 1,
    sandbox: 0,
    scope: 0,
    scoped: 0,
    scrolling: 0,
    seamless: 0,
    selected: 0,
    shape: 0,
    size: 0,
    sizes: 0,
    span: 0,
    spellCheck: 1,
    src: 0,
    srcDoc: 1,
    srcLang: 1,
    srcSet: 1,
    start: 0,
    step: 0,
    style: 0,
    summary: 0,
    tabIndex: 1,
    target: 0,
    title: 0,
    type: 0,
    useMap: 1,
    value: 0,
    width: 0,
    wmode: 0,
    wrap: 0,
    about: 0,
    accentHeight: 1,
    'accent-height': 'accentHeight',
    accumulate: 0,
    additive: 0,
    alignmentBaseline: 1,
    'alignment-baseline': 'alignmentBaseline',
    allowReorder: 1,
    alphabetic: 0,
    amplitude: 0,
    arabicForm: 1,
    'arabic-form': 'arabicForm',
    ascent: 0,
    attributeName: 1,
    attributeType: 1,
    autoReverse: 1,
    azimuth: 0,
    baseFrequency: 1,
    baselineShift: 1,
    'baseline-shift': 'baselineShift',
    baseProfile: 1,
    bbox: 0,
    begin: 0,
    bias: 0,
    by: 0,
    calcMode: 1,
    capHeight: 1,
    'cap-height': 'capHeight',
    clip: 0,
    clipPath: 1,
    'clip-path': 'clipPath',
    clipPathUnits: 1,
    clipRule: 1,
    'clip-rule': 'clipRule',
    color: 0,
    colorInterpolation: 1,
    'color-interpolation': 'colorInterpolation',
    colorInterpolationFilters: 1,
    'color-interpolation-filters': 'colorInterpolationFilters',
    colorProfile: 1,
    'color-profile': 'colorProfile',
    colorRendering: 1,
    'color-rendering': 'colorRendering',
    contentScriptType: 1,
    contentStyleType: 1,
    cursor: 0,
    cx: 0,
    cy: 0,
    d: 0,
    datatype: 0,
    decelerate: 0,
    descent: 0,
    diffuseConstant: 1,
    direction: 0,
    display: 0,
    divisor: 0,
    dominantBaseline: 1,
    'dominant-baseline': 'dominantBaseline',
    dur: 0,
    dx: 0,
    dy: 0,
    edgeMode: 1,
    elevation: 0,
    enableBackground: 1,
    'enable-background': 'enableBackground',
    end: 0,
    exponent: 0,
    externalResourcesRequired: 1,
    fill: 0,
    fillOpacity: 1,
    'fill-opacity': 'fillOpacity',
    fillRule: 1,
    'fill-rule': 'fillRule',
    filter: 0,
    filterRes: 1,
    filterUnits: 1,
    floodOpacity: 1,
    'flood-opacity': 'floodOpacity',
    floodColor: 1,
    'flood-color': 'floodColor',
    focusable: 0,
    fontFamily: 1,
    'font-family': 'fontFamily',
    fontSize: 1,
    'font-size': 'fontSize',
    fontSizeAdjust: 1,
    'font-size-adjust': 'fontSizeAdjust',
    fontStretch: 1,
    'font-stretch': 'fontStretch',
    fontStyle: 1,
    'font-style': 'fontStyle',
    fontVariant: 1,
    'font-variant': 'fontVariant',
    fontWeight: 1,
    'font-weight': 'fontWeight',
    format: 0,
    from: 0,
    fx: 0,
    fy: 0,
    g1: 0,
    g2: 0,
    glyphName: 1,
    'glyph-name': 'glyphName',
    glyphOrientationHorizontal: 1,
    'glyph-orientation-horizontal': 'glyphOrientationHorizontal',
    glyphOrientationVertical: 1,
    'glyph-orientation-vertical': 'glyphOrientationVertical',
    glyphRef: 1,
    gradientTransform: 1,
    gradientUnits: 1,
    hanging: 0,
    horizAdvX: 1,
    'horiz-adv-x': 'horizAdvX',
    horizOriginX: 1,
    'horiz-origin-x': 'horizOriginX',
    ideographic: 0,
    imageRendering: 1,
    'image-rendering': 'imageRendering',
    in2: 0,
    in: 0,
    inlist: 0,
    intercept: 0,
    k1: 0,
    k2: 0,
    k3: 0,
    k4: 0,
    k: 0,
    kernelMatrix: 1,
    kernelUnitLength: 1,
    kerning: 0,
    keyPoints: 1,
    keySplines: 1,
    keyTimes: 1,
    lengthAdjust: 1,
    letterSpacing: 1,
    'letter-spacing': 'letterSpacing',
    lightingColor: 1,
    'lighting-color': 'lightingColor',
    limitingConeAngle: 1,
    local: 0,
    markerEnd: 1,
    'marker-end': 'markerEnd',
    markerHeight: 1,
    markerMid: 1,
    'marker-mid': 'markerMid',
    markerStart: 1,
    'marker-start': 'markerStart',
    markerUnits: 1,
    markerWidth: 1,
    mask: 0,
    maskContentUnits: 1,
    maskUnits: 1,
    mathematical: 0,
    mode: 0,
    numOctaves: 1,
    offset: 0,
    opacity: 0,
    operator: 0,
    order: 0,
    orient: 0,
    orientation: 0,
    origin: 0,
    overflow: 0,
    overlinePosition: 1,
    'overline-position': 'overlinePosition',
    overlineThickness: 1,
    'overline-thickness': 'overlineThickness',
    paintOrder: 1,
    'paint-order': 'paintOrder',
    panose1: 0,
    'panose-1': 'panose1',
    pathLength: 1,
    patternContentUnits: 1,
    patternTransform: 1,
    patternUnits: 1,
    pointerEvents: 1,
    'pointer-events': 'pointerEvents',
    points: 0,
    pointsAtX: 1,
    pointsAtY: 1,
    pointsAtZ: 1,
    prefix: 0,
    preserveAlpha: 1,
    preserveAspectRatio: 1,
    primitiveUnits: 1,
    property: 0,
    r: 0,
    radius: 0,
    refX: 1,
    refY: 1,
    renderingIntent: 1,
    'rendering-intent': 'renderingIntent',
    repeatCount: 1,
    repeatDur: 1,
    requiredExtensions: 1,
    requiredFeatures: 1,
    resource: 0,
    restart: 0,
    result: 0,
    results: 0,
    rotate: 0,
    rx: 0,
    ry: 0,
    scale: 0,
    security: 0,
    seed: 0,
    shapeRendering: 1,
    'shape-rendering': 'shapeRendering',
    slope: 0,
    spacing: 0,
    specularConstant: 1,
    specularExponent: 1,
    speed: 0,
    spreadMethod: 1,
    startOffset: 1,
    stdDeviation: 1,
    stemh: 0,
    stemv: 0,
    stitchTiles: 1,
    stopColor: 1,
    'stop-color': 'stopColor',
    stopOpacity: 1,
    'stop-opacity': 'stopOpacity',
    strikethroughPosition: 1,
    'strikethrough-position': 'strikethroughPosition',
    strikethroughThickness: 1,
    'strikethrough-thickness': 'strikethroughThickness',
    string: 0,
    stroke: 0,
    strokeDasharray: 1,
    'stroke-dasharray': 'strokeDasharray',
    strokeDashoffset: 1,
    'stroke-dashoffset': 'strokeDashoffset',
    strokeLinecap: 1,
    'stroke-linecap': 'strokeLinecap',
    strokeLinejoin: 1,
    'stroke-linejoin': 'strokeLinejoin',
    strokeMiterlimit: 1,
    'stroke-miterlimit': 'strokeMiterlimit',
    strokeWidth: 1,
    'stroke-width': 'strokeWidth',
    strokeOpacity: 1,
    'stroke-opacity': 'strokeOpacity',
    suppressContentEditableWarning: 1,
    suppressHydrationWarning: 1,
    surfaceScale: 1,
    systemLanguage: 1,
    tableValues: 1,
    targetX: 1,
    targetY: 1,
    textAnchor: 1,
    'text-anchor': 'textAnchor',
    textDecoration: 1,
    'text-decoration': 'textDecoration',
    textLength: 1,
    textRendering: 1,
    'text-rendering': 'textRendering',
    to: 0,
    transform: 0,
    typeof: 0,
    u1: 0,
    u2: 0,
    underlinePosition: 1,
    'underline-position': 'underlinePosition',
    underlineThickness: 1,
    'underline-thickness': 'underlineThickness',
    unicode: 0,
    unicodeBidi: 1,
    'unicode-bidi': 'unicodeBidi',
    unicodeRange: 1,
    'unicode-range': 'unicodeRange',
    unitsPerEm: 1,
    'units-per-em': 'unitsPerEm',
    unselectable: 0,
    vAlphabetic: 1,
    'v-alphabetic': 'vAlphabetic',
    values: 0,
    vectorEffect: 1,
    'vector-effect': 'vectorEffect',
    version: 0,
    vertAdvY: 1,
    'vert-adv-y': 'vertAdvY',
    vertOriginX: 1,
    'vert-origin-x': 'vertOriginX',
    vertOriginY: 1,
    'vert-origin-y': 'vertOriginY',
    vHanging: 1,
    'v-hanging': 'vHanging',
    vIdeographic: 1,
    'v-ideographic': 'vIdeographic',
    viewBox: 1,
    viewTarget: 1,
    visibility: 0,
    vMathematical: 1,
    'v-mathematical': 'vMathematical',
    vocab: 0,
    widths: 0,
    wordSpacing: 1,
    'word-spacing': 'wordSpacing',
    writingMode: 1,
    'writing-mode': 'writingMode',
    x1: 0,
    x2: 0,
    x: 0,
    xChannelSelector: 1,
    xHeight: 1,
    'x-height': 'xHeight',
    xlinkActuate: 1,
    'xlink:actuate': 'xlinkActuate',
    xlinkArcrole: 1,
    'xlink:arcrole': 'xlinkArcrole',
    xlinkHref: 1,
    'xlink:href': 'xlinkHref',
    xlinkRole: 1,
    'xlink:role': 'xlinkRole',
    xlinkShow: 1,
    'xlink:show': 'xlinkShow',
    xlinkTitle: 1,
    'xlink:title': 'xlinkTitle',
    xlinkType: 1,
    'xlink:type': 'xlinkType',
    xmlBase: 1,
    'xml:base': 'xmlBase',
    xmlLang: 1,
    'xml:lang': 'xmlLang',
    xmlns: 0,
    'xml:space': 'xmlSpace',
    xmlnsXlink: 1,
    'xmlns:xlink': 'xmlnsXlink',
    xmlSpace: 1,
    y1: 0,
    y2: 0,
    y: 0,
    yChannelSelector: 1,
    z: 0,
    zoomAndPan: 1
};
}),
"[project]/node_modules/.pnpm/react-property@2.0.2/node_modules/react-property/lib/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/**
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 * 
 */ // A reserved attribute.
// It is handled by React separately and shouldn't be written to the DOM.
const RESERVED = 0;
// A simple string attribute.
// Attributes that aren't in the filter are presumed to have this type.
const STRING = 1;
// A string attribute that accepts booleans in React. In HTML, these are called
// "enumerated" attributes with "true" and "false" as possible values.
// When true, it should be set to a "true" string.
// When false, it should be set to a "false" string.
const BOOLEANISH_STRING = 2;
// A real boolean attribute.
// When true, it should be present (set either to an empty string or its name).
// When false, it should be omitted.
const BOOLEAN = 3;
// An attribute that can be used as a flag as well as with a value.
// When true, it should be present (set either to an empty string or its name).
// When false, it should be omitted.
// For any other value, should be present with that value.
const OVERLOADED_BOOLEAN = 4;
// An attribute that must be numeric or parse as a numeric.
// When falsy, it should be removed.
const NUMERIC = 5;
// An attribute that must be positive numeric or parse as a positive numeric.
// When falsy, it should be removed.
const POSITIVE_NUMERIC = 6;
function getPropertyInfo(name) {
    return properties.hasOwnProperty(name) ? properties[name] : null;
}
function PropertyInfoRecord(name, type, mustUseProperty, attributeName, attributeNamespace, sanitizeURL, removeEmptyString) {
    this.acceptsBooleans = type === BOOLEANISH_STRING || type === BOOLEAN || type === OVERLOADED_BOOLEAN;
    this.attributeName = attributeName;
    this.attributeNamespace = attributeNamespace;
    this.mustUseProperty = mustUseProperty;
    this.propertyName = name;
    this.type = type;
    this.sanitizeURL = sanitizeURL;
    this.removeEmptyString = removeEmptyString;
}
// When adding attributes to this list, be sure to also add them to
// the `possibleStandardNames` module to ensure casing and incorrect
// name warnings.
const properties = {};
// These props are reserved by React. They shouldn't be written to the DOM.
const reservedProps = [
    'children',
    'dangerouslySetInnerHTML',
    // TODO: This prevents the assignment of defaultValue to regular
    // elements (not just inputs). Now that ReactDOMInput assigns to the
    // defaultValue property -- do we need this?
    'defaultValue',
    'defaultChecked',
    'innerHTML',
    'suppressContentEditableWarning',
    'suppressHydrationWarning',
    'style'
];
reservedProps.forEach((name)=>{
    properties[name] = new PropertyInfoRecord(name, RESERVED, false, name, null, false, false);
});
// A few React string attributes have a different name.
// This is a mapping from React prop names to the attribute names.
[
    [
        'acceptCharset',
        'accept-charset'
    ],
    [
        'className',
        'class'
    ],
    [
        'htmlFor',
        'for'
    ],
    [
        'httpEquiv',
        'http-equiv'
    ]
].forEach(([name, attributeName])=>{
    properties[name] = new PropertyInfoRecord(name, STRING, false, attributeName, null, false, false);
});
// These are "enumerated" HTML attributes that accept "true" and "false".
// In React, we let users pass `true` and `false` even though technically
// these aren't boolean attributes (they are coerced to strings).
[
    'contentEditable',
    'draggable',
    'spellCheck',
    'value'
].forEach((name)=>{
    properties[name] = new PropertyInfoRecord(name, BOOLEANISH_STRING, false, name.toLowerCase(), null, false, false);
});
// These are "enumerated" SVG attributes that accept "true" and "false".
// In React, we let users pass `true` and `false` even though technically
// these aren't boolean attributes (they are coerced to strings).
// Since these are SVG attributes, their attribute names are case-sensitive.
[
    'autoReverse',
    'externalResourcesRequired',
    'focusable',
    'preserveAlpha'
].forEach((name)=>{
    properties[name] = new PropertyInfoRecord(name, BOOLEANISH_STRING, false, name, null, false, false);
});
// These are HTML boolean attributes.
[
    'allowFullScreen',
    'async',
    // Note: there is a special case that prevents it from being written to the DOM
    // on the client side because the browsers are inconsistent. Instead we call focus().
    'autoFocus',
    'autoPlay',
    'controls',
    'default',
    'defer',
    'disabled',
    'disablePictureInPicture',
    'disableRemotePlayback',
    'formNoValidate',
    'hidden',
    'loop',
    'noModule',
    'noValidate',
    'open',
    'playsInline',
    'readOnly',
    'required',
    'reversed',
    'scoped',
    'seamless',
    // Microdata
    'itemScope'
].forEach((name)=>{
    properties[name] = new PropertyInfoRecord(name, BOOLEAN, false, name.toLowerCase(), null, false, false);
});
// These are the few React props that we set as DOM properties
// rather than attributes. These are all booleans.
[
    'checked',
    // Note: `option.selected` is not updated if `select.multiple` is
    // disabled with `removeAttribute`. We have special logic for handling this.
    'multiple',
    'muted',
    'selected'
].forEach((name)=>{
    properties[name] = new PropertyInfoRecord(name, BOOLEAN, true, name, null, false, false);
});
// These are HTML attributes that are "overloaded booleans": they behave like
// booleans, but can also accept a string value.
[
    'capture',
    'download'
].forEach((name)=>{
    properties[name] = new PropertyInfoRecord(name, OVERLOADED_BOOLEAN, false, name, null, false, false);
});
// These are HTML attributes that must be positive numbers.
[
    'cols',
    'rows',
    'size',
    'span'
].forEach((name)=>{
    properties[name] = new PropertyInfoRecord(name, POSITIVE_NUMERIC, false, name, null, false, false);
});
// These are HTML attributes that must be numbers.
[
    'rowSpan',
    'start'
].forEach((name)=>{
    properties[name] = new PropertyInfoRecord(name, NUMERIC, false, name.toLowerCase(), null, false, false);
});
const CAMELIZE = /[\-\:]([a-z])/g;
const capitalize = (token)=>token[1].toUpperCase();
// This is a list of all SVG attributes that need special casing, namespacing,
// or boolean value assignment. Regular attributes that just accept strings
// and have the same names are omitted, just like in the HTML attribute filter.
// Some of these attributes can be hard to find. This list was created by
// scraping the MDN documentation.
[
    'accent-height',
    'alignment-baseline',
    'arabic-form',
    'baseline-shift',
    'cap-height',
    'clip-path',
    'clip-rule',
    'color-interpolation',
    'color-interpolation-filters',
    'color-profile',
    'color-rendering',
    'dominant-baseline',
    'enable-background',
    'fill-opacity',
    'fill-rule',
    'flood-color',
    'flood-opacity',
    'font-family',
    'font-size',
    'font-size-adjust',
    'font-stretch',
    'font-style',
    'font-variant',
    'font-weight',
    'glyph-name',
    'glyph-orientation-horizontal',
    'glyph-orientation-vertical',
    'horiz-adv-x',
    'horiz-origin-x',
    'image-rendering',
    'letter-spacing',
    'lighting-color',
    'marker-end',
    'marker-mid',
    'marker-start',
    'overline-position',
    'overline-thickness',
    'paint-order',
    'panose-1',
    'pointer-events',
    'rendering-intent',
    'shape-rendering',
    'stop-color',
    'stop-opacity',
    'strikethrough-position',
    'strikethrough-thickness',
    'stroke-dasharray',
    'stroke-dashoffset',
    'stroke-linecap',
    'stroke-linejoin',
    'stroke-miterlimit',
    'stroke-opacity',
    'stroke-width',
    'text-anchor',
    'text-decoration',
    'text-rendering',
    'underline-position',
    'underline-thickness',
    'unicode-bidi',
    'unicode-range',
    'units-per-em',
    'v-alphabetic',
    'v-hanging',
    'v-ideographic',
    'v-mathematical',
    'vector-effect',
    'vert-adv-y',
    'vert-origin-x',
    'vert-origin-y',
    'word-spacing',
    'writing-mode',
    'xmlns:xlink',
    'x-height'
].forEach((attributeName)=>{
    const name = attributeName.replace(CAMELIZE, capitalize);
    properties[name] = new PropertyInfoRecord(name, STRING, false, attributeName, null, false, false);
});
// String SVG attributes with the xlink namespace.
[
    'xlink:actuate',
    'xlink:arcrole',
    'xlink:role',
    'xlink:show',
    'xlink:title',
    'xlink:type'
].forEach((attributeName)=>{
    const name = attributeName.replace(CAMELIZE, capitalize);
    properties[name] = new PropertyInfoRecord(name, STRING, false, attributeName, 'http://www.w3.org/1999/xlink', false, false);
});
// String SVG attributes with the xml namespace.
[
    'xml:base',
    'xml:lang',
    'xml:space'
].forEach((attributeName)=>{
    const name = attributeName.replace(CAMELIZE, capitalize);
    properties[name] = new PropertyInfoRecord(name, STRING, false, attributeName, 'http://www.w3.org/XML/1998/namespace', false, false);
});
// These attribute exists both in HTML and SVG.
// The attribute name is case-sensitive in SVG so we can't just use
// the React name like we do for attributes that exist only in HTML.
[
    'tabIndex',
    'crossOrigin'
].forEach((attributeName)=>{
    properties[attributeName] = new PropertyInfoRecord(attributeName, STRING, false, attributeName.toLowerCase(), null, false, false);
});
// These attributes accept URLs. These must not allow javascript: URLS.
// These will also need to accept Trusted Types object in the future.
const xlinkHref = 'xlinkHref';
properties[xlinkHref] = new PropertyInfoRecord('xlinkHref', STRING, false, 'xlink:href', 'http://www.w3.org/1999/xlink', true, false);
[
    'src',
    'href',
    'action',
    'formAction'
].forEach((attributeName)=>{
    properties[attributeName] = new PropertyInfoRecord(attributeName, STRING, false, attributeName.toLowerCase(), null, true, true);
});
// 
const { CAMELCASE, SAME, possibleStandardNames: possibleStandardNamesOptimized } = __turbopack_context__.r("[project]/node_modules/.pnpm/react-property@2.0.2/node_modules/react-property/lib/possibleStandardNamesOptimized.js [app-client] (ecmascript)");
const ATTRIBUTE_NAME_START_CHAR = ':A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD';
const ATTRIBUTE_NAME_CHAR = ATTRIBUTE_NAME_START_CHAR + '\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040';
/**
 * Checks whether a property name is a custom attribute.
 *
 * @see https://github.com/facebook/react/blob/15-stable/src/renderers/dom/shared/HTMLDOMPropertyConfig.js#L23-L25
 *
 * @type {(attribute: string) => boolean}
 */ const isCustomAttribute = RegExp.prototype.test.bind(// eslint-disable-next-line no-misleading-character-class
new RegExp('^(data|aria)-[' + ATTRIBUTE_NAME_CHAR + ']*$'));
/**
 * @type {Record<string, string>}
 */ const possibleStandardNames = Object.keys(possibleStandardNamesOptimized).reduce((accumulator, standardName)=>{
    const propName = possibleStandardNamesOptimized[standardName];
    if (propName === SAME) {
        accumulator[standardName] = standardName;
    } else if (propName === CAMELCASE) {
        accumulator[standardName.toLowerCase()] = standardName;
    } else {
        accumulator[standardName] = propName;
    }
    return accumulator;
}, {});
exports.BOOLEAN = BOOLEAN;
exports.BOOLEANISH_STRING = BOOLEANISH_STRING;
exports.NUMERIC = NUMERIC;
exports.OVERLOADED_BOOLEAN = OVERLOADED_BOOLEAN;
exports.POSITIVE_NUMERIC = POSITIVE_NUMERIC;
exports.RESERVED = RESERVED;
exports.STRING = STRING;
exports.getPropertyInfo = getPropertyInfo;
exports.isCustomAttribute = isCustomAttribute;
exports.possibleStandardNames = possibleStandardNames;
}),
"[project]/node_modules/.pnpm/inline-style-parser@0.2.7/node_modules/inline-style-parser/cjs/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// http://www.w3.org/TR/CSS21/grammar.html
// https://github.com/visionmedia/css-parse/pull/49#issuecomment-30088027
var COMMENT_REGEX = /\/\*[^*]*\*+([^/*][^*]*\*+)*\//g;
var NEWLINE_REGEX = /\n/g;
var WHITESPACE_REGEX = /^\s*/;
// declaration
var PROPERTY_REGEX = /^(\*?[-#/*\\\w]+(\[[0-9a-z_-]+\])?)\s*/;
var COLON_REGEX = /^:\s*/;
var VALUE_REGEX = /^((?:'(?:\\'|.)*?'|"(?:\\"|.)*?"|\([^)]*?\)|[^};])+)/;
var SEMICOLON_REGEX = /^[;\s]*/;
// https://developer.mozilla.org/docs/Web/JavaScript/Reference/Global_Objects/String/Trim#Polyfill
var TRIM_REGEX = /^\s+|\s+$/g;
// strings
var NEWLINE = '\n';
var FORWARD_SLASH = '/';
var ASTERISK = '*';
var EMPTY_STRING = '';
// types
var TYPE_COMMENT = 'comment';
var TYPE_DECLARATION = 'declaration';
/**
 * @param {String} style
 * @param {Object} [options]
 * @return {Object[]}
 * @throws {TypeError}
 * @throws {Error}
 */ function index(style, options) {
    if (typeof style !== 'string') {
        throw new TypeError('First argument must be a string');
    }
    if (!style) return [];
    options = options || {};
    /**
   * Positional.
   */ var lineno = 1;
    var column = 1;
    /**
   * Update lineno and column based on `str`.
   *
   * @param {String} str
   */ function updatePosition(str) {
        var lines = str.match(NEWLINE_REGEX);
        if (lines) lineno += lines.length;
        var i = str.lastIndexOf(NEWLINE);
        column = ~i ? str.length - i : column + str.length;
    }
    /**
   * Mark position and patch `node.position`.
   *
   * @return {Function}
   */ function position() {
        var start = {
            line: lineno,
            column: column
        };
        return function(node) {
            node.position = new Position(start);
            whitespace();
            return node;
        };
    }
    /**
   * Store position information for a node.
   *
   * @constructor
   * @property {Object} start
   * @property {Object} end
   * @property {undefined|String} source
   */ function Position(start) {
        this.start = start;
        this.end = {
            line: lineno,
            column: column
        };
        this.source = options.source;
    }
    /**
   * Non-enumerable source string.
   */ Position.prototype.content = style;
    /**
   * Error `msg`.
   *
   * @param {String} msg
   * @throws {Error}
   */ function error(msg) {
        var err = new Error(options.source + ':' + lineno + ':' + column + ': ' + msg);
        err.reason = msg;
        err.filename = options.source;
        err.line = lineno;
        err.column = column;
        err.source = style;
        if (options.silent) ;
        else {
            throw err;
        }
    }
    /**
   * Match `re` and return captures.
   *
   * @param {RegExp} re
   * @return {undefined|Array}
   */ function match(re) {
        var m = re.exec(style);
        if (!m) return;
        var str = m[0];
        updatePosition(str);
        style = style.slice(str.length);
        return m;
    }
    /**
   * Parse whitespace.
   */ function whitespace() {
        match(WHITESPACE_REGEX);
    }
    /**
   * Parse comments.
   *
   * @param {Object[]} [rules]
   * @return {Object[]}
   */ function comments(rules) {
        var c;
        rules = rules || [];
        while(c = comment()){
            if (c !== false) {
                rules.push(c);
            }
        }
        return rules;
    }
    /**
   * Parse comment.
   *
   * @return {Object}
   * @throws {Error}
   */ function comment() {
        var pos = position();
        if (FORWARD_SLASH != style.charAt(0) || ASTERISK != style.charAt(1)) return;
        var i = 2;
        while(EMPTY_STRING != style.charAt(i) && (ASTERISK != style.charAt(i) || FORWARD_SLASH != style.charAt(i + 1))){
            ++i;
        }
        i += 2;
        if (EMPTY_STRING === style.charAt(i - 1)) {
            return error('End of comment missing');
        }
        var str = style.slice(2, i - 2);
        column += 2;
        updatePosition(str);
        style = style.slice(i);
        column += 2;
        return pos({
            type: TYPE_COMMENT,
            comment: str
        });
    }
    /**
   * Parse declaration.
   *
   * @return {Object}
   * @throws {Error}
   */ function declaration() {
        var pos = position();
        // prop
        var prop = match(PROPERTY_REGEX);
        if (!prop) return;
        comment();
        // :
        if (!match(COLON_REGEX)) return error("property missing ':'");
        // val
        var val = match(VALUE_REGEX);
        var ret = pos({
            type: TYPE_DECLARATION,
            property: trim(prop[0].replace(COMMENT_REGEX, EMPTY_STRING)),
            value: val ? trim(val[0].replace(COMMENT_REGEX, EMPTY_STRING)) : EMPTY_STRING
        });
        // ;
        match(SEMICOLON_REGEX);
        return ret;
    }
    /**
   * Parse declarations.
   *
   * @return {Object[]}
   */ function declarations() {
        var decls = [];
        comments(decls);
        // declarations
        var decl;
        while(decl = declaration()){
            if (decl !== false) {
                decls.push(decl);
                comments(decls);
            }
        }
        return decls;
    }
    whitespace();
    return declarations();
}
/**
 * Trim `str`.
 *
 * @param {String} str
 * @return {String}
 */ function trim(str) {
    return str ? str.replace(TRIM_REGEX, EMPTY_STRING) : EMPTY_STRING;
}
module.exports = index; //# sourceMappingURL=index.js.map
}),
"[project]/node_modules/.pnpm/style-to-object@1.0.14/node_modules/style-to-object/cjs/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __importDefault = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = StyleToObject;
const inline_style_parser_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/inline-style-parser@0.2.7/node_modules/inline-style-parser/cjs/index.js [app-client] (ecmascript)"));
/**
 * Parses inline style to object.
 *
 * @param style - Inline style.
 * @param iterator - Iterator.
 * @returns - Style object or null.
 *
 * @example Parsing inline style to object:
 *
 * ```js
 * import parse from 'style-to-object';
 * parse('line-height: 42;'); // { 'line-height': '42' }
 * ```
 */ function StyleToObject(style, iterator) {
    let styleObject = null;
    if (!style || typeof style !== 'string') {
        return styleObject;
    }
    const declarations = (0, inline_style_parser_1.default)(style);
    const hasIterator = typeof iterator === 'function';
    declarations.forEach((declaration)=>{
        if (declaration.type !== 'declaration') {
            return;
        }
        const { property, value } = declaration;
        if (hasIterator) {
            iterator(property, value, declaration);
        } else if (value) {
            styleObject = styleObject || {};
            styleObject[property] = value;
        }
    });
    return styleObject;
} //# sourceMappingURL=index.js.map
}),
"[project]/node_modules/.pnpm/style-to-js@1.1.21/node_modules/style-to-js/cjs/utilities.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.camelCase = void 0;
var CUSTOM_PROPERTY_REGEX = /^--[a-zA-Z0-9_-]+$/;
var HYPHEN_REGEX = /-([a-z])/g;
var NO_HYPHEN_REGEX = /^[^-]+$/;
var VENDOR_PREFIX_REGEX = /^-(webkit|moz|ms|o|khtml)-/;
var MS_VENDOR_PREFIX_REGEX = /^-(ms)-/;
/**
 * Checks whether to skip camelCase.
 */ var skipCamelCase = function(property) {
    return !property || NO_HYPHEN_REGEX.test(property) || CUSTOM_PROPERTY_REGEX.test(property);
};
/**
 * Replacer that capitalizes first character.
 */ var capitalize = function(match, character) {
    return character.toUpperCase();
};
/**
 * Replacer that removes beginning hyphen of vendor prefix property.
 */ var trimHyphen = function(match, prefix) {
    return "".concat(prefix, "-");
};
/**
 * CamelCases a CSS property.
 */ var camelCase = function(property, options) {
    if (options === void 0) {
        options = {};
    }
    if (skipCamelCase(property)) {
        return property;
    }
    property = property.toLowerCase();
    if (options.reactCompat) {
        // `-ms` vendor prefix should not be capitalized
        property = property.replace(MS_VENDOR_PREFIX_REGEX, trimHyphen);
    } else {
        // for non-React, remove first hyphen so vendor prefix is not capitalized
        property = property.replace(VENDOR_PREFIX_REGEX, trimHyphen);
    }
    return property.replace(HYPHEN_REGEX, capitalize);
};
exports.camelCase = camelCase; //# sourceMappingURL=utilities.js.map
}),
"[project]/node_modules/.pnpm/style-to-js@1.1.21/node_modules/style-to-js/cjs/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __importDefault = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
var style_to_object_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/style-to-object@1.0.14/node_modules/style-to-object/cjs/index.js [app-client] (ecmascript)"));
var utilities_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/style-to-js@1.1.21/node_modules/style-to-js/cjs/utilities.js [app-client] (ecmascript)");
/**
 * Parses CSS inline style to JavaScript object (camelCased).
 */ function StyleToJS(style, options) {
    var output = {};
    if (!style || typeof style !== 'string') {
        return output;
    }
    (0, style_to_object_1.default)(style, function(property, value) {
        // skip CSS comment
        if (property && value) {
            output[(0, utilities_1.camelCase)(property, options)] = value;
        }
    });
    return output;
}
StyleToJS.default = StyleToJS;
module.exports = StyleToJS; //# sourceMappingURL=index.js.map
}),
"[project]/node_modules/.pnpm/html-react-parser@5.2.11_@types+react@19.2.9_react@19.2.1/node_modules/html-react-parser/lib/utilities.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __importDefault = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.returnFirstArg = exports.canTextBeChildOfNode = exports.ELEMENTS_WITH_NO_TEXT_CHILDREN = exports.PRESERVE_CUSTOM_ATTRIBUTES = void 0;
exports.isCustomComponent = isCustomComponent;
exports.setStyleProp = setStyleProp;
var react_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var style_to_js_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/style-to-js@1.1.21/node_modules/style-to-js/cjs/index.js [app-client] (ecmascript)"));
var RESERVED_SVG_MATHML_ELEMENTS = new Set([
    'annotation-xml',
    'color-profile',
    'font-face',
    'font-face-src',
    'font-face-uri',
    'font-face-format',
    'font-face-name',
    'missing-glyph'
]);
/**
 * Check if a tag is a custom component.
 *
 * @see {@link https://github.com/facebook/react/blob/v16.6.3/packages/react-dom/src/shared/isCustomComponent.js}
 *
 * @param tagName - Tag name.
 * @param props - Props passed to the element.
 * @returns - Whether the tag is custom component.
 */ function isCustomComponent(tagName, props) {
    if (!tagName.includes('-')) {
        return Boolean(props && typeof props.is === 'string');
    }
    // These are reserved SVG and MathML elements.
    // We don't mind this whitelist too much because we expect it to never grow.
    // The alternative is to track the namespace in a few places which is convoluted.
    // https://w3c.github.io/webcomponents/spec/custom/#custom-elements-core-concepts
    if (RESERVED_SVG_MATHML_ELEMENTS.has(tagName)) {
        return false;
    }
    return true;
}
var styleOptions = {
    reactCompat: true
};
/**
 * Sets style prop.
 *
 * @param style - Inline style.
 * @param props - Props object.
 */ function setStyleProp(style, props) {
    if (typeof style !== 'string') {
        return;
    }
    if (!style.trim()) {
        props.style = {};
        return;
    }
    try {
        props.style = (0, style_to_js_1.default)(style, styleOptions);
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    } catch (error) {
        props.style = {};
    }
}
/**
 * @see https://reactjs.org/blog/2017/09/08/dom-attributes-in-react-16.html
 */ exports.PRESERVE_CUSTOM_ATTRIBUTES = Number(react_1.version.split('.')[0]) >= 16;
/**
 * @see https://github.com/facebook/react/blob/cae635054e17a6f107a39d328649137b83f25972/packages/react-dom/src/client/validateDOMNesting.js#L213
 */ exports.ELEMENTS_WITH_NO_TEXT_CHILDREN = new Set([
    'tr',
    'tbody',
    'thead',
    'tfoot',
    'colgroup',
    'table',
    'head',
    'html',
    'frameset'
]);
/**
 * Checks if the given node can contain text nodes
 *
 * @param node - Element node.
 * @returns - Whether the node can contain text nodes.
 */ var canTextBeChildOfNode = function(node) {
    return !exports.ELEMENTS_WITH_NO_TEXT_CHILDREN.has(node.name);
};
exports.canTextBeChildOfNode = canTextBeChildOfNode;
/**
 * Returns the first argument as is.
 *
 * @param arg - The argument to be returned.
 * @returns - The input argument `arg`.
 */ var returnFirstArg = function(arg) {
    return arg;
}; // eslint-disable-line @typescript-eslint/no-explicit-any
exports.returnFirstArg = returnFirstArg; //# sourceMappingURL=utilities.js.map
}),
"[project]/node_modules/.pnpm/html-react-parser@5.2.11_@types+react@19.2.9_react@19.2.1/node_modules/html-react-parser/lib/attributes-to-props.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = attributesToProps;
var react_property_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/react-property@2.0.2/node_modules/react-property/lib/index.js [app-client] (ecmascript)");
var utilities_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/html-react-parser@5.2.11_@types+react@19.2.9_react@19.2.1/node_modules/html-react-parser/lib/utilities.js [app-client] (ecmascript)");
// https://react.dev/learn/sharing-state-between-components#controlled-and-uncontrolled-components
// https://developer.mozilla.org/docs/Web/HTML/Attributes
var UNCONTROLLED_COMPONENT_ATTRIBUTES = [
    'checked',
    'value'
];
var UNCONTROLLED_COMPONENT_NAMES = [
    'input',
    'select',
    'textarea'
];
var valueOnlyInputs = {
    reset: true,
    submit: true
};
/**
 * Converts HTML/SVG DOM attributes to React props.
 *
 * @param attributes - HTML/SVG DOM attributes.
 * @param nodeName - DOM node name.
 * @returns - React props.
 */ function attributesToProps(attributes, nodeName) {
    if (attributes === void 0) {
        attributes = {};
    }
    var props = {};
    var isInputValueOnly = Boolean(attributes.type && valueOnlyInputs[attributes.type]);
    for(var attributeName in attributes){
        var attributeValue = attributes[attributeName];
        // ARIA (aria-*) or custom data (data-*) attribute
        if ((0, react_property_1.isCustomAttribute)(attributeName)) {
            props[attributeName] = attributeValue;
            continue;
        }
        // convert HTML/SVG attribute to React prop
        var attributeNameLowerCased = attributeName.toLowerCase();
        var propName = getPropName(attributeNameLowerCased);
        if (propName) {
            var propertyInfo = (0, react_property_1.getPropertyInfo)(propName);
            // convert attribute to uncontrolled component prop (e.g., `value` to `defaultValue`)
            if (UNCONTROLLED_COMPONENT_ATTRIBUTES.includes(propName) && UNCONTROLLED_COMPONENT_NAMES.includes(nodeName) && !isInputValueOnly) {
                propName = getPropName('default' + attributeNameLowerCased);
            }
            props[propName] = attributeValue;
            switch(propertyInfo && propertyInfo.type){
                case react_property_1.BOOLEAN:
                    props[propName] = true;
                    break;
                case react_property_1.OVERLOADED_BOOLEAN:
                    if (attributeValue === '') {
                        props[propName] = true;
                    }
                    break;
            }
            continue;
        }
        // preserve custom attribute if React >=16
        if (utilities_1.PRESERVE_CUSTOM_ATTRIBUTES) {
            props[attributeName] = attributeValue;
        }
    }
    // transform inline style to object
    (0, utilities_1.setStyleProp)(attributes.style, props);
    return props;
}
/**
 * Gets prop name from lowercased attribute name.
 *
 * @param attributeName - Lowercased attribute name.
 * @returns - Prop name.
 */ function getPropName(attributeName) {
    return react_property_1.possibleStandardNames[attributeName];
} //# sourceMappingURL=attributes-to-props.js.map
}),
"[project]/node_modules/.pnpm/html-react-parser@5.2.11_@types+react@19.2.9_react@19.2.1/node_modules/html-react-parser/lib/dom-to-react.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __importDefault = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = domToReact;
var react_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var attributes_to_props_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/html-react-parser@5.2.11_@types+react@19.2.9_react@19.2.1/node_modules/html-react-parser/lib/attributes-to-props.js [app-client] (ecmascript)"));
var utilities_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/html-react-parser@5.2.11_@types+react@19.2.9_react@19.2.1/node_modules/html-react-parser/lib/utilities.js [app-client] (ecmascript)");
var React = {
    cloneElement: react_1.cloneElement,
    createElement: react_1.createElement,
    isValidElement: react_1.isValidElement
};
/**
 * Converts DOM nodes to JSX element(s).
 *
 * @param nodes - DOM nodes.
 * @param options - Options.
 * @returns - String or JSX element(s).
 */ function domToReact(nodes, options) {
    if (options === void 0) {
        options = {};
    }
    var reactElements = [];
    var hasReplace = typeof options.replace === 'function';
    var transform = options.transform || utilities_1.returnFirstArg;
    var _a = options.library || React, cloneElement = _a.cloneElement, createElement = _a.createElement, isValidElement = _a.isValidElement;
    var nodesLength = nodes.length;
    for(var index = 0; index < nodesLength; index++){
        var node = nodes[index];
        // replace with custom React element (if present)
        if (hasReplace) {
            var replaceElement = options.replace(node, index);
            if (isValidElement(replaceElement)) {
                // set "key" prop for sibling elements
                // https://react.dev/learn/rendering-lists#rules-of-keys
                if (nodesLength > 1) {
                    replaceElement = cloneElement(replaceElement, {
                        key: replaceElement.key || index
                    });
                }
                reactElements.push(transform(replaceElement, node, index));
                continue;
            }
        }
        if (node.type === 'text') {
            var isWhitespace = !node.data.trim().length;
            // We have a whitespace node that can't be nested in its parent
            // so skip it
            if (isWhitespace && node.parent && !(0, utilities_1.canTextBeChildOfNode)(node.parent)) {
                continue;
            }
            // Trim is enabled and we have a whitespace node
            // so skip it
            if (options.trim && isWhitespace) {
                continue;
            }
            // We have a text node that's not whitespace and it can be nested
            // in its parent so add it to the results
            reactElements.push(transform(node.data, node, index));
            continue;
        }
        var element = node;
        var props = {};
        if (skipAttributesToProps(element)) {
            (0, utilities_1.setStyleProp)(element.attribs.style, element.attribs);
            props = element.attribs;
        } else if (element.attribs) {
            props = (0, attributes_to_props_1.default)(element.attribs, element.name);
        }
        var children = void 0;
        switch(node.type){
            case 'script':
            case 'style':
                // prevent text in <script> or <style> from being escaped
                // https://react.dev/reference/react-dom/components/common#dangerously-setting-the-inner-html
                if (node.children[0]) {
                    props.dangerouslySetInnerHTML = {
                        __html: node.children[0].data
                    };
                }
                break;
            case 'tag':
                // setting textarea value in children is an antipattern in React
                // https://react.dev/reference/react-dom/components/textarea#caveats
                if (node.name === 'textarea' && node.children[0]) {
                    props.defaultValue = node.children[0].data;
                } else if (node.children && node.children.length) {
                    // continue recursion of creating React elements (if applicable)
                    children = domToReact(node.children, options);
                }
                break;
            // skip all other cases (e.g., comment)
            default:
                continue;
        }
        // set "key" prop for sibling elements
        // https://react.dev/learn/rendering-lists#rules-of-keys
        if (nodesLength > 1) {
            props.key = index;
        }
        reactElements.push(transform(createElement(node.name, props, children), node, index));
    }
    return reactElements.length === 1 ? reactElements[0] : reactElements;
}
/**
 * Determines whether DOM element attributes should be transformed to props.
 * Web Components should not have their attributes transformed except for `style`.
 *
 * @param node - Element node.
 * @returns - Whether the node attributes should be converted to props.
 */ function skipAttributesToProps(node) {
    return utilities_1.PRESERVE_CUSTOM_ATTRIBUTES && node.type === 'tag' && (0, utilities_1.isCustomComponent)(node.name, node.attribs);
} //# sourceMappingURL=dom-to-react.js.map
}),
"[project]/node_modules/.pnpm/html-react-parser@5.2.11_@types+react@19.2.9_react@19.2.1/node_modules/html-react-parser/lib/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __importDefault = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.htmlToDOM = exports.domToReact = exports.attributesToProps = exports.Text = exports.ProcessingInstruction = exports.Element = exports.Comment = void 0;
exports.default = HTMLReactParser;
var html_dom_parser_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/html-dom-parser@5.1.2/node_modules/html-dom-parser/lib/client/html-to-dom.js [app-client] (ecmascript)"));
exports.htmlToDOM = html_dom_parser_1.default;
var attributes_to_props_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/html-react-parser@5.2.11_@types+react@19.2.9_react@19.2.1/node_modules/html-react-parser/lib/attributes-to-props.js [app-client] (ecmascript)"));
exports.attributesToProps = attributes_to_props_1.default;
var dom_to_react_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/html-react-parser@5.2.11_@types+react@19.2.9_react@19.2.1/node_modules/html-react-parser/lib/dom-to-react.js [app-client] (ecmascript)"));
exports.domToReact = dom_to_react_1.default;
var domhandler_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/domhandler@5.0.3/node_modules/domhandler/lib/index.js [app-client] (ecmascript)");
Object.defineProperty(exports, "Comment", {
    enumerable: true,
    get: function() {
        return domhandler_1.Comment;
    }
});
Object.defineProperty(exports, "Element", {
    enumerable: true,
    get: function() {
        return domhandler_1.Element;
    }
});
Object.defineProperty(exports, "ProcessingInstruction", {
    enumerable: true,
    get: function() {
        return domhandler_1.ProcessingInstruction;
    }
});
Object.defineProperty(exports, "Text", {
    enumerable: true,
    get: function() {
        return domhandler_1.Text;
    }
});
var domParserOptions = {
    lowerCaseAttributeNames: false
};
/**
 * Converts HTML string to React elements.
 *
 * @param html - HTML string.
 * @param options - Parser options.
 * @returns - React element(s), empty array, or string.
 */ function HTMLReactParser(html, options) {
    if (typeof html !== 'string') {
        throw new TypeError('First argument must be a string');
    }
    if (!html) {
        return [];
    }
    return (0, dom_to_react_1.default)((0, html_dom_parser_1.default)(html, (options === null || options === void 0 ? void 0 : options.htmlparser2) || domParserOptions), options);
} //# sourceMappingURL=index.js.map
}),
"[project]/node_modules/.pnpm/html-react-parser@5.2.11_@types+react@19.2.9_react@19.2.1/node_modules/html-react-parser/esm/index.mjs [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$html$2d$react$2d$parser$40$5$2e$2$2e$11_$40$types$2b$react$40$19$2e$2$2e$9_react$40$19$2e$2$2e$1$2f$node_modules$2f$html$2d$react$2d$parser$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/html-react-parser@5.2.11_@types+react@19.2.9_react@19.2.1/node_modules/html-react-parser/lib/index.js [app-client] (ecmascript)");
;
;
const __TURBOPACK__default__export__ = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$html$2d$react$2d$parser$40$5$2e$2$2e$11_$40$types$2b$react$40$19$2e$2$2e$9_react$40$19$2e$2$2e$1$2f$node_modules$2f$html$2d$react$2d$parser$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].default || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$html$2d$react$2d$parser$40$5$2e$2$2e$11_$40$types$2b$react$40$19$2e$2$2e$9_react$40$19$2e$2$2e$1$2f$node_modules$2f$html$2d$react$2d$parser$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}),
"[project]/node_modules/.pnpm/react-to-print@3.2.0_react@19.2.1/node_modules/react-to-print/lib/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

!function(e, t) {
    ("TURBOPACK compile-time truthy", 1) ? module.exports = t(__turbopack_context__.r("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)")) : "TURBOPACK unreachable";
}("undefined" != typeof self ? self : /*TURBOPACK member replacement*/ __turbopack_context__.e, function(e) {
    return function() {
        "use strict";
        var t = {
            155: function(t) {
                t.exports = e;
            }
        }, o = {};
        function n(e) {
            var r = o[e];
            if (void 0 !== r) return r.exports;
            var s = o[e] = {
                exports: {}
            };
            return t[e](s, s.exports, n), s.exports;
        }
        n.d = function(e, t) {
            for(var o in t)n.o(t, o) && !n.o(e, o) && Object.defineProperty(e, o, {
                enumerable: !0,
                get: t[o]
            });
        }, n.o = function(e, t) {
            return Object.prototype.hasOwnProperty.call(e, t);
        }, n.r = function(e) {
            "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
                value: "Module"
            }), Object.defineProperty(e, "__esModule", {
                value: !0
            });
        };
        var r = {};
        n.r(r), n.d(r, {
            useReactToPrint: function() {
                return g;
            }
        });
        var s = n(155);
        const i = "printWindow";
        function l({ level: e = "error", messages: t, suppressErrors: o = !1 }) {
            o || ("error" === e ? console.error(t) : "warning" === e ? console.warn(t) : console.debug(t));
        }
        function a(e, t) {
            if (t || !e) {
                const e = document.getElementById(i);
                e && document.body.removeChild(e);
            }
        }
        function c(e) {
            return e instanceof Error ? e : new Error("Unknown Error");
        }
        function d(e, t) {
            const { documentTitle: o, onAfterPrint: n, onPrintError: r, preserveAfterPrint: s, print: i, suppressErrors: d } = t;
            setTimeout(()=>{
                var t, u;
                if (e.contentWindow) {
                    function p() {
                        null == n || n(), a(s);
                    }
                    if (e.contentWindow.focus(), i) i(e).then(p).catch((e)=>{
                        r ? r("print", c(e)) : l({
                            messages: [
                                "An error was thrown by the specified `print` function"
                            ],
                            suppressErrors: d
                        });
                    });
                    else {
                        if (e.contentWindow.print) {
                            const f = null !== (u = null === (t = e.contentDocument) || void 0 === t ? void 0 : t.title) && void 0 !== u ? u : "", h = e.ownerDocument.title;
                            o && (e.ownerDocument.title = o, e.contentDocument && (e.contentDocument.title = o)), e.contentWindow.print(), o && (e.ownerDocument.title = h, e.contentDocument && (e.contentDocument.title = f));
                        } else l({
                            messages: [
                                "Printing for this browser is not currently possible: the browser does not have a `print` method available for iframes."
                            ],
                            suppressErrors: d
                        });
                        [
                            /Android/i,
                            /webOS/i,
                            /iPhone/i,
                            /iPad/i,
                            /iPod/i,
                            /BlackBerry/i,
                            /Windows Phone/i
                        ].some((e)=>{
                            var t, o;
                            return (null !== (o = null !== (t = navigator.userAgent) && void 0 !== t ? t : navigator.vendor) && void 0 !== o ? o : "opera" in window && window.opera).match(e);
                        }) ? setTimeout(p, 500) : p();
                    }
                } else l({
                    messages: [
                        "Printing failed because the `contentWindow` of the print iframe did not load. This is possibly an error with `react-to-print`. Please file an issue: https://github.com/MatthewHerbst/react-to-print/issues/"
                    ],
                    suppressErrors: d
                });
            }, 500);
        }
        function u(e) {
            const t = [], o = document.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, null);
            let n = o.nextNode();
            for(; n;)t.push(n), n = o.nextNode();
            return t;
        }
        function p(e, t, o) {
            const n = u(e), r = u(t);
            if (n.length === r.length) for(let e = 0; e < n.length; e++){
                const t = n[e], s = r[e], i = t.shadowRoot;
                if (null !== i) {
                    const e = s.attachShadow({
                        mode: i.mode
                    });
                    e.innerHTML = i.innerHTML, p(i, e, o);
                }
            }
            else l({
                messages: [
                    "When cloning shadow root content, source and target elements have different size. `onBeforePrint` likely resolved too early.",
                    e,
                    t
                ],
                suppressErrors: o
            });
        }
        const f = '\n    @page {\n        /* Remove browser default header (title) and footer (url) */\n        margin: 0;\n    }\n    @media print {\n        body {\n            /* Tell browsers to print background colors */\n            color-adjust: exact; /* Firefox. This is an older version of "print-color-adjust" */\n            print-color-adjust: exact; /* Firefox/Safari */\n            -webkit-print-color-adjust: exact; /* Chrome/Safari/Edge/Opera */\n        }\n    }\n';
        function h(e, t, o, n) {
            var r, s, i, a, u;
            const { contentNode: h, clonedContentNode: g, clonedImgNodes: m, clonedVideoNodes: b, numResourcesToLoad: y, originalCanvasNodes: v } = o, { bodyClass: w, fonts: E, ignoreGlobalStyles: A, pageStyle: P, nonce: T, suppressErrors: S, copyShadowRoots: x } = n;
            e.onload = null;
            const k = null !== (r = e.contentDocument) && void 0 !== r ? r : null === (s = e.contentWindow) || void 0 === s ? void 0 : s.document;
            if (k) {
                const o = k.body.appendChild(g);
                x && p(h, o, !!S), E && ((null === (i = e.contentDocument) || void 0 === i ? void 0 : i.fonts) && (null === (a = e.contentWindow) || void 0 === a ? void 0 : a.FontFace) ? E.forEach((o)=>{
                    const n = new FontFace(o.family, o.source, {
                        weight: o.weight,
                        style: o.style
                    });
                    e.contentDocument.fonts.add(n), n.loaded.then(()=>{
                        t(n);
                    }).catch((e)=>{
                        t(n, [
                            "Failed loading the font:",
                            n,
                            "Load error:",
                            c(e)
                        ]);
                    });
                }) : (E.forEach((e)=>{
                    t(e);
                }), l({
                    messages: [
                        '"react-to-print" is not able to load custom fonts because the browser does not support the FontFace API but will continue attempting to print the page'
                    ],
                    suppressErrors: S
                })));
                const n = null != P ? P : f, r = k.createElement("style");
                T && (r.setAttribute("nonce", T), k.head.setAttribute("nonce", T)), r.appendChild(k.createTextNode(n)), k.head.appendChild(r), w && k.body.classList.add(...w.split(" "));
                const s = k.querySelectorAll("canvas");
                for(let e = 0; e < v.length; ++e){
                    const t = v[e], o = s[e];
                    if (void 0 === o) {
                        l({
                            messages: [
                                "A canvas element could not be copied for printing, has it loaded? `onBeforePrint` likely resolved too early.",
                                t
                            ],
                            suppressErrors: S
                        });
                        continue;
                    }
                    const n = o.getContext("2d");
                    n && n.drawImage(t, 0, 0);
                }
                for(let e = 0; e < m.length; e++){
                    const o = m[e], n = o.getAttribute("src");
                    if (n) {
                        const e = new Image;
                        e.onload = ()=>{
                            t(o);
                        }, e.onerror = (e, n, r, s, i)=>{
                            t(o, [
                                "Error loading <img>",
                                o,
                                "Error",
                                i
                            ]);
                        }, e.src = n;
                    } else t(o, [
                        'Found an <img> tag with an empty "src" attribute. This prevents pre-loading it.',
                        o
                    ]);
                }
                for(let e = 0; e < b.length; e++){
                    const o = b[e];
                    o.preload = "auto";
                    const n = o.getAttribute("poster");
                    if (n) {
                        const e = new Image;
                        e.onload = ()=>{
                            t(o);
                        }, e.onerror = (e, r, s, i, l)=>{
                            t(o, [
                                "Error loading video poster",
                                n,
                                "for video",
                                o,
                                "Error:",
                                l
                            ]);
                        }, e.src = n;
                    } else o.readyState >= 2 ? t(o) : o.src ? (o.onloadeddata = ()=>{
                        t(o);
                    }, o.onerror = (e, n, r, s, i)=>{
                        t(o, [
                            "Error loading video",
                            o,
                            "Error",
                            i
                        ]);
                    }, o.onstalled = ()=>{
                        t(o, [
                            "Loading video stalled, skipping",
                            o
                        ]);
                    }) : t(o, [
                        "Error loading video, `src` is empty",
                        o
                    ]);
                }
                const d = "select", y = h.querySelectorAll(d), C = k.querySelectorAll(d);
                for(let e = 0; e < y.length; e++)C[e].value = y[e].value;
                if (!A) {
                    const e = document.querySelectorAll("style, link[rel~='stylesheet'], link[as='style']");
                    for(let o = 0, n = e.length; o < n; ++o){
                        const n = e[o];
                        if ("style" === n.tagName.toLowerCase()) {
                            const e = k.createElement(n.tagName), t = n.sheet;
                            if (t) {
                                let r = "";
                                try {
                                    const e = t.cssRules.length;
                                    for(let o = 0; o < e; ++o)"string" == typeof t.cssRules[o].cssText && (r += `${t.cssRules[o].cssText}\r\n`);
                                } catch (e) {
                                    l({
                                        messages: [
                                            "A stylesheet could not be accessed. This is likely due to the stylesheet having cross-origin imports, and many browsers block script access to cross-origin stylesheets. See https://github.com/MatthewHerbst/react-to-print/issues/429 for details. You may be able to load the sheet by both marking the stylesheet with the cross `crossorigin` attribute, and setting the `Access-Control-Allow-Origin` header on the server serving the stylesheet. Alternatively, host the stylesheet on your domain to avoid this issue entirely.",
                                            n,
                                            `Original error: ${c(e).message}`
                                        ],
                                        level: "warning"
                                    });
                                }
                                e.setAttribute("id", `react-to-print-${o}`), T && e.setAttribute("nonce", T), e.appendChild(k.createTextNode(r)), k.head.appendChild(e);
                            }
                        } else if (n.getAttribute("href")) if (n.hasAttribute("disabled")) l({
                            messages: [
                                "`react-to-print` encountered a <link> tag with a `disabled` attribute and will ignore it. Note that the `disabled` attribute is deprecated, and some browsers ignore it. You should stop using it. https://developer.mozilla.org/en-US/docs/Web/HTML/Element/link#attr-disabled. The <link> is:",
                                n
                            ],
                            level: "warning"
                        }), t(n);
                        else {
                            const e = k.createElement(n.tagName);
                            for(let t = 0, o = n.attributes.length; t < o; ++t){
                                const o = n.attributes[t];
                                o && e.setAttribute(o.nodeName, null !== (u = o.nodeValue) && void 0 !== u ? u : "");
                            }
                            e.onload = ()=>{
                                t(e);
                            }, e.onerror = (o, n, r, s, i)=>{
                                t(e, [
                                    "Failed to load",
                                    e,
                                    "Error:",
                                    i
                                ]);
                            }, T && e.setAttribute("nonce", T), k.head.appendChild(e);
                        }
                        else l({
                            messages: [
                                "`react-to-print` encountered a <link> tag with an empty `href` attribute. In addition to being invalid HTML, this can cause problems in many browsers, and so the <link> was not loaded. The <link> is:",
                                n
                            ],
                            level: "warning"
                        }), t(n);
                    }
                }
            }
            0 === y && d(e, n);
        }
        function g({ bodyClass: e, contentRef: t, copyShadowRoots: o, documentTitle: n, fonts: r, ignoreGlobalStyles: u, nonce: p, onAfterPrint: f, onBeforePrint: g, onPrintError: m, pageStyle: b, preserveAfterPrint: y, print: v, printIframeProps: w, suppressErrors: E }) {
            const A = (0, s.useCallback)((s)=>{
                function A() {
                    const a = {
                        bodyClass: e,
                        contentRef: t,
                        copyShadowRoots: o,
                        documentTitle: n,
                        fonts: r,
                        ignoreGlobalStyles: u,
                        nonce: p,
                        onAfterPrint: f,
                        onBeforePrint: g,
                        onPrintError: m,
                        pageStyle: b,
                        preserveAfterPrint: y,
                        print: v,
                        printIframeProps: w,
                        suppressErrors: E
                    }, c = function(e) {
                        const t = document.createElement("iframe");
                        return t.width = `${document.documentElement.clientWidth}px`, t.height = `${document.documentElement.clientHeight}px`, t.style.position = "absolute", t.style.top = `-${document.documentElement.clientHeight + 100}px`, t.style.left = `-${document.documentElement.clientWidth + 100}px`, t.id = i, t.srcdoc = "<!DOCTYPE html>", e && (e.allow && (t.allow = e.allow), void 0 !== e.referrerPolicy && (t.referrerPolicy = e.referrerPolicy), void 0 !== e.sandbox && (t.sandbox = e.sandbox)), t;
                    }(w), A = function(e, t) {
                        const { contentRef: o, fonts: n, ignoreGlobalStyles: r, suppressErrors: s } = t, i = function({ contentRef: e, optionalContent: t, suppressErrors: o }) {
                            return t && "function" == typeof t ? (e && l({
                                level: "warning",
                                messages: [
                                    '"react-to-print" received a `contentRef` option and an optional-content param passed to its callback. The `contentRef` option will be ignored.'
                                ]
                            }), t()) : e ? e.current : void l({
                                messages: [
                                    '"react-to-print" did not receive a `contentRef` option or a optional-content param pass to its callback.'
                                ],
                                suppressErrors: o
                            });
                        }({
                            contentRef: o,
                            optionalContent: e,
                            suppressErrors: s
                        });
                        if (!i) return;
                        const a = i.cloneNode(!0), c = document.querySelectorAll("link[rel~='stylesheet'], link[as='style']"), d = a.querySelectorAll("img"), u = a.querySelectorAll("video"), p = n ? n.length : 0;
                        return {
                            contentNode: i,
                            clonedContentNode: a,
                            clonedImgNodes: d,
                            clonedVideoNodes: u,
                            numResourcesToLoad: (r ? 0 : c.length) + d.length + u.length + p,
                            originalCanvasNodes: i.querySelectorAll("canvas")
                        };
                    }(s, a);
                    if (!A) return void l({
                        messages: [
                            "There is nothing to print"
                        ],
                        suppressErrors: E
                    });
                    const P = function(e, t, o) {
                        const { suppressErrors: n } = e, r = [], s = [];
                        return function(i, a) {
                            r.includes(i) ? l({
                                level: "debug",
                                messages: [
                                    "Tried to mark a resource that has already been handled",
                                    i
                                ],
                                suppressErrors: n
                            }) : (a ? (l({
                                messages: [
                                    '"react-to-print" was unable to load a resource but will continue attempting to print the page',
                                    ...a
                                ],
                                suppressErrors: n
                            }), s.push(i)) : r.push(i), r.length + s.length === t && d(o, e));
                        };
                    }(a, A.numResourcesToLoad, c);
                    !function(e, t, o, n) {
                        e.onload = ()=>{
                            h(e, t, o, n);
                        }, document.body.appendChild(e);
                    }(c, P, A, a);
                }
                a(y, !0), g ? g().then(()=>{
                    A();
                }).catch((e)=>{
                    null == m || m("onBeforePrint", c(e));
                }) : A();
            }, [
                e,
                t,
                o,
                n,
                r,
                u,
                p,
                f,
                g,
                m,
                b,
                y,
                v,
                E
            ]);
            return A;
        }
        return r;
    }();
});
}),
"[project]/node_modules/.pnpm/date-fns-tz@3.2.0_date-fns@4.1.0/node_modules/date-fns-tz/dist/esm/_lib/tzIntlTimeZoneName/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "tzIntlTimeZoneName",
    ()=>tzIntlTimeZoneName
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$getDefaultOptions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/getDefaultOptions.js [app-client] (ecmascript)");
;
function tzIntlTimeZoneName(length, date, options) {
    const defaultOptions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$getDefaultOptions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDefaultOptions"])();
    const dtf = getDTF(length, options.timeZone, options.locale ?? defaultOptions.locale);
    return 'formatToParts' in dtf ? partsTimeZone(dtf, date) : hackyTimeZone(dtf, date);
}
function partsTimeZone(dtf, date) {
    const formatted = dtf.formatToParts(date);
    for(let i = formatted.length - 1; i >= 0; --i){
        if (formatted[i].type === 'timeZoneName') {
            return formatted[i].value;
        }
    }
    return undefined;
}
function hackyTimeZone(dtf, date) {
    const formatted = dtf.format(date).replace(/\u200E/g, '');
    const tzNameMatch = / [\w-+ ]+$/.exec(formatted);
    return tzNameMatch ? tzNameMatch[0].substr(1) : '';
}
// If a locale has been provided `en-US` is used as a fallback in case it is an
// invalid locale, otherwise the locale is left undefined to use the system locale.
function getDTF(length, timeZone, locale) {
    return new Intl.DateTimeFormat(locale ? [
        locale.code,
        'en-US'
    ] : undefined, {
        timeZone: timeZone,
        timeZoneName: length
    });
}
}),
"[project]/node_modules/.pnpm/date-fns-tz@3.2.0_date-fns@4.1.0/node_modules/date-fns-tz/dist/esm/_lib/tzTokenizeDate/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Returns the [year, month, day, hour, minute, seconds] tokens of the provided
 * `date` as it will be rendered in the `timeZone`.
 */ __turbopack_context__.s([
    "tzTokenizeDate",
    ()=>tzTokenizeDate
]);
function tzTokenizeDate(date, timeZone) {
    const dtf = getDateTimeFormat(timeZone);
    return 'formatToParts' in dtf ? partsOffset(dtf, date) : hackyOffset(dtf, date);
}
const typeToPos = {
    year: 0,
    month: 1,
    day: 2,
    hour: 3,
    minute: 4,
    second: 5
};
function partsOffset(dtf, date) {
    try {
        const formatted = dtf.formatToParts(date);
        const filled = [];
        for(let i = 0; i < formatted.length; i++){
            const pos = typeToPos[formatted[i].type];
            if (pos !== undefined) {
                filled[pos] = parseInt(formatted[i].value, 10);
            }
        }
        return filled;
    } catch (error) {
        if (error instanceof RangeError) {
            return [
                NaN
            ];
        }
        throw error;
    }
}
function hackyOffset(dtf, date) {
    const formatted = dtf.format(date);
    // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
    const parsed = /(\d+)\/(\d+)\/(\d+),? (\d+):(\d+):(\d+)/.exec(formatted);
    // const [, fMonth, fDay, fYear, fHour, fMinute, fSecond] = parsed
    // return [fYear, fMonth, fDay, fHour, fMinute, fSecond]
    return [
        parseInt(parsed[3], 10),
        parseInt(parsed[1], 10),
        parseInt(parsed[2], 10),
        parseInt(parsed[4], 10),
        parseInt(parsed[5], 10),
        parseInt(parsed[6], 10)
    ];
}
// Get a cached Intl.DateTimeFormat instance for the IANA `timeZone`. This can be used
// to get deterministic local date/time output according to the `en-US` locale which
// can be used to extract local time parts as necessary.
const dtfCache = {};
// New browsers use `hourCycle`, IE and Chrome <73 does not support it and uses `hour12`
const testDateFormatted = new Intl.DateTimeFormat('en-US', {
    hourCycle: 'h23',
    timeZone: 'America/New_York',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
}).format(new Date('2014-06-25T04:00:00.123Z'));
const hourCycleSupported = testDateFormatted === '06/25/2014, 00:00:00' || testDateFormatted === '‎06‎/‎25‎/‎2014‎ ‎00‎:‎00‎:‎00';
function getDateTimeFormat(timeZone) {
    if (!dtfCache[timeZone]) {
        dtfCache[timeZone] = hourCycleSupported ? new Intl.DateTimeFormat('en-US', {
            hourCycle: 'h23',
            timeZone: timeZone,
            year: 'numeric',
            month: 'numeric',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        }) : new Intl.DateTimeFormat('en-US', {
            hour12: false,
            timeZone: timeZone,
            year: 'numeric',
            month: 'numeric',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        });
    }
    return dtfCache[timeZone];
}
}),
"[project]/node_modules/.pnpm/date-fns-tz@3.2.0_date-fns@4.1.0/node_modules/date-fns-tz/dist/esm/_lib/newDateUTC/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Use instead of `new Date(Date.UTC(...))` to support years below 100 which doesn't work
 * otherwise due to the nature of the
 * [`Date` constructor](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date#interpretation_of_two-digit_years.
 *
 * For `Date.UTC(...)`, use `newDateUTC(...).getTime()`.
 */ __turbopack_context__.s([
    "newDateUTC",
    ()=>newDateUTC
]);
function newDateUTC(fullYear, month, day, hour, minute, second, millisecond) {
    const utcDate = new Date(0);
    utcDate.setUTCFullYear(fullYear, month, day);
    utcDate.setUTCHours(hour, minute, second, millisecond);
    return utcDate;
}
}),
"[project]/node_modules/.pnpm/date-fns-tz@3.2.0_date-fns@4.1.0/node_modules/date-fns-tz/dist/esm/_lib/tzParseTimezone/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "tzParseTimezone",
    ()=>tzParseTimezone
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$_lib$2f$tzTokenizeDate$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns-tz@3.2.0_date-fns@4.1.0/node_modules/date-fns-tz/dist/esm/_lib/tzTokenizeDate/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$_lib$2f$newDateUTC$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns-tz@3.2.0_date-fns@4.1.0/node_modules/date-fns-tz/dist/esm/_lib/newDateUTC/index.js [app-client] (ecmascript)");
;
;
const MILLISECONDS_IN_HOUR = 3600000;
const MILLISECONDS_IN_MINUTE = 60000;
const patterns = {
    timezone: /([Z+-].*)$/,
    timezoneZ: /^(Z)$/,
    timezoneHH: /^([+-]\d{2})$/,
    timezoneHHMM: /^([+-])(\d{2}):?(\d{2})$/
};
function tzParseTimezone(timezoneString, date, isUtcDate) {
    // Empty string
    if (!timezoneString) {
        return 0;
    }
    // Z
    let token = patterns.timezoneZ.exec(timezoneString);
    if (token) {
        return 0;
    }
    let hours;
    let absoluteOffset;
    // ±hh
    token = patterns.timezoneHH.exec(timezoneString);
    if (token) {
        hours = parseInt(token[1], 10);
        if (!validateTimezone(hours)) {
            return NaN;
        }
        return -(hours * MILLISECONDS_IN_HOUR);
    }
    // ±hh:mm or ±hhmm
    token = patterns.timezoneHHMM.exec(timezoneString);
    if (token) {
        hours = parseInt(token[2], 10);
        const minutes = parseInt(token[3], 10);
        if (!validateTimezone(hours, minutes)) {
            return NaN;
        }
        absoluteOffset = Math.abs(hours) * MILLISECONDS_IN_HOUR + minutes * MILLISECONDS_IN_MINUTE;
        return token[1] === '+' ? -absoluteOffset : absoluteOffset;
    }
    // IANA time zone
    if (isValidTimezoneIANAString(timezoneString)) {
        date = new Date(date || Date.now());
        const utcDate = isUtcDate ? date : toUtcDate(date);
        const offset = calcOffset(utcDate, timezoneString);
        const fixedOffset = isUtcDate ? offset : fixOffset(date, offset, timezoneString);
        return -fixedOffset;
    }
    return NaN;
}
function toUtcDate(date) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$_lib$2f$newDateUTC$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newDateUTC"])(date.getFullYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes(), date.getSeconds(), date.getMilliseconds());
}
function calcOffset(date, timezoneString) {
    const tokens = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$_lib$2f$tzTokenizeDate$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tzTokenizeDate"])(date, timezoneString);
    // ms dropped because it's not provided by tzTokenizeDate
    const asUTC = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$_lib$2f$newDateUTC$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newDateUTC"])(tokens[0], tokens[1] - 1, tokens[2], tokens[3] % 24, tokens[4], tokens[5], 0).getTime();
    let asTS = date.getTime();
    const over = asTS % 1000;
    asTS -= over >= 0 ? over : 1000 + over;
    return asUTC - asTS;
}
function fixOffset(date, offset, timezoneString) {
    const localTS = date.getTime();
    // Our UTC time is just a guess because our offset is just a guess
    let utcGuess = localTS - offset;
    // Test whether the zone matches the offset for this ts
    const o2 = calcOffset(new Date(utcGuess), timezoneString);
    // If so, offset didn't change, and we're done
    if (offset === o2) {
        return offset;
    }
    // If not, change the ts by the difference in the offset
    utcGuess -= o2 - offset;
    // If that gives us the local time we want, we're done
    const o3 = calcOffset(new Date(utcGuess), timezoneString);
    if (o2 === o3) {
        return o2;
    }
    // If it's different, we're in a hole time. The offset has changed, but we don't adjust the time
    return Math.max(o2, o3);
}
function validateTimezone(hours, minutes) {
    return -23 <= hours && hours <= 23 && (minutes == null || 0 <= minutes && minutes <= 59);
}
const validIANATimezoneCache = {};
function isValidTimezoneIANAString(timeZoneString) {
    if (validIANATimezoneCache[timeZoneString]) return true;
    try {
        new Intl.DateTimeFormat(undefined, {
            timeZone: timeZoneString
        });
        validIANATimezoneCache[timeZoneString] = true;
        return true;
    } catch (error) {
        return false;
    }
}
}),
"[project]/node_modules/.pnpm/date-fns-tz@3.2.0_date-fns@4.1.0/node_modules/date-fns-tz/dist/esm/format/formatters/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "formatters",
    ()=>formatters
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$_lib$2f$tzIntlTimeZoneName$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns-tz@3.2.0_date-fns@4.1.0/node_modules/date-fns-tz/dist/esm/_lib/tzIntlTimeZoneName/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$_lib$2f$tzParseTimezone$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns-tz@3.2.0_date-fns@4.1.0/node_modules/date-fns-tz/dist/esm/_lib/tzParseTimezone/index.js [app-client] (ecmascript)");
;
;
const MILLISECONDS_IN_MINUTE = 60 * 1000;
const formatters = {
    // Timezone (ISO-8601. If offset is 0, output is always `'Z'`)
    X: function(date, token, options) {
        const timezoneOffset = getTimeZoneOffset(options.timeZone, date);
        if (timezoneOffset === 0) {
            return 'Z';
        }
        switch(token){
            // Hours and optional minutes
            case 'X':
                return formatTimezoneWithOptionalMinutes(timezoneOffset);
            // Hours, minutes and optional seconds without `:` delimeter
            // Note: neither ISO-8601 nor JavaScript supports seconds in timezone offsets
            // so this token always has the same output as `XX`
            case 'XXXX':
            case 'XX':
                return formatTimezone(timezoneOffset);
            // Hours, minutes and optional seconds with `:` delimeter
            // Note: neither ISO-8601 nor JavaScript supports seconds in timezone offsets
            // so this token always has the same output as `XXX`
            case 'XXXXX':
            case 'XXX':
            default:
                return formatTimezone(timezoneOffset, ':');
        }
    },
    // Timezone (ISO-8601. If offset is 0, output is `'+00:00'` or equivalent)
    x: function(date, token, options) {
        const timezoneOffset = getTimeZoneOffset(options.timeZone, date);
        switch(token){
            // Hours and optional minutes
            case 'x':
                return formatTimezoneWithOptionalMinutes(timezoneOffset);
            // Hours, minutes and optional seconds without `:` delimeter
            // Note: neither ISO-8601 nor JavaScript supports seconds in timezone offsets
            // so this token always has the same output as `xx`
            case 'xxxx':
            case 'xx':
                return formatTimezone(timezoneOffset);
            // Hours, minutes and optional seconds with `:` delimeter
            // Note: neither ISO-8601 nor JavaScript supports seconds in timezone offsets
            // so this token always has the same output as `xxx`
            case 'xxxxx':
            case 'xxx':
            default:
                return formatTimezone(timezoneOffset, ':');
        }
    },
    // Timezone (GMT)
    O: function(date, token, options) {
        const timezoneOffset = getTimeZoneOffset(options.timeZone, date);
        switch(token){
            // Short
            case 'O':
            case 'OO':
            case 'OOO':
                return 'GMT' + formatTimezoneShort(timezoneOffset, ':');
            // Long
            case 'OOOO':
            default:
                return 'GMT' + formatTimezone(timezoneOffset, ':');
        }
    },
    // Timezone (specific non-location)
    z: function(date, token, options) {
        switch(token){
            // Short
            case 'z':
            case 'zz':
            case 'zzz':
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$_lib$2f$tzIntlTimeZoneName$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tzIntlTimeZoneName"])('short', date, options);
            // Long
            case 'zzzz':
            default:
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$_lib$2f$tzIntlTimeZoneName$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tzIntlTimeZoneName"])('long', date, options);
        }
    }
};
function getTimeZoneOffset(timeZone, originalDate) {
    const timeZoneOffset = timeZone ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$_lib$2f$tzParseTimezone$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tzParseTimezone"])(timeZone, originalDate, true) / MILLISECONDS_IN_MINUTE : originalDate?.getTimezoneOffset() ?? 0;
    if (Number.isNaN(timeZoneOffset)) {
        throw new RangeError('Invalid time zone specified: ' + timeZone);
    }
    return timeZoneOffset;
}
function addLeadingZeros(number, targetLength) {
    const sign = number < 0 ? '-' : '';
    let output = Math.abs(number).toString();
    while(output.length < targetLength){
        output = '0' + output;
    }
    return sign + output;
}
function formatTimezone(offset, delimiter = '') {
    const sign = offset > 0 ? '-' : '+';
    const absOffset = Math.abs(offset);
    const hours = addLeadingZeros(Math.floor(absOffset / 60), 2);
    const minutes = addLeadingZeros(Math.floor(absOffset % 60), 2);
    return sign + hours + delimiter + minutes;
}
function formatTimezoneWithOptionalMinutes(offset, delimiter) {
    if (offset % 60 === 0) {
        const sign = offset > 0 ? '-' : '+';
        return sign + addLeadingZeros(Math.abs(offset) / 60, 2);
    }
    return formatTimezone(offset, delimiter);
}
function formatTimezoneShort(offset, delimiter = '') {
    const sign = offset > 0 ? '-' : '+';
    const absOffset = Math.abs(offset);
    const hours = Math.floor(absOffset / 60);
    const minutes = absOffset % 60;
    if (minutes === 0) {
        return sign + String(hours);
    }
    return sign + String(hours) + delimiter + addLeadingZeros(minutes, 2);
}
}),
"[project]/node_modules/.pnpm/date-fns-tz@3.2.0_date-fns@4.1.0/node_modules/date-fns-tz/dist/esm/_lib/getTimezoneOffsetInMilliseconds/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Google Chrome as of 67.0.3396.87 introduced timezones with offset that includes seconds.
 * They usually appear for dates that denote time before the timezones were introduced
 * (e.g. for 'Europe/Prague' timezone the offset is GMT+00:57:44 before 1 October 1891
 * and GMT+01:00:00 after that date)
 *
 * Date#getTimezoneOffset returns the offset in minutes and would return 57 for the example above,
 * which would lead to incorrect calculations.
 *
 * This function returns the timezone offset in milliseconds that takes seconds in account.
 */ __turbopack_context__.s([
    "getTimezoneOffsetInMilliseconds",
    ()=>getTimezoneOffsetInMilliseconds
]);
function getTimezoneOffsetInMilliseconds(date) {
    const utcDate = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes(), date.getSeconds(), date.getMilliseconds()));
    utcDate.setUTCFullYear(date.getFullYear());
    return +date - +utcDate;
}
}),
"[project]/node_modules/.pnpm/date-fns-tz@3.2.0_date-fns@4.1.0/node_modules/date-fns-tz/dist/esm/_lib/tzPattern/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/** Regex to identify the presence of a time zone specifier in a date string */ __turbopack_context__.s([
    "tzPattern",
    ()=>tzPattern
]);
const tzPattern = /(Z|[+-]\d{2}(?::?\d{2})?| UTC| [a-zA-Z]+\/[a-zA-Z_]+(?:\/[a-zA-Z_]+)?)$/;
}),
"[project]/node_modules/.pnpm/date-fns-tz@3.2.0_date-fns@4.1.0/node_modules/date-fns-tz/dist/esm/toDate/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "toDate",
    ()=>toDate
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$_lib$2f$getTimezoneOffsetInMilliseconds$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns-tz@3.2.0_date-fns@4.1.0/node_modules/date-fns-tz/dist/esm/_lib/getTimezoneOffsetInMilliseconds/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$_lib$2f$tzParseTimezone$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns-tz@3.2.0_date-fns@4.1.0/node_modules/date-fns-tz/dist/esm/_lib/tzParseTimezone/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$_lib$2f$tzPattern$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns-tz@3.2.0_date-fns@4.1.0/node_modules/date-fns-tz/dist/esm/_lib/tzPattern/index.js [app-client] (ecmascript)");
;
;
;
const MILLISECONDS_IN_HOUR = 3600000;
const MILLISECONDS_IN_MINUTE = 60000;
const DEFAULT_ADDITIONAL_DIGITS = 2;
const patterns = {
    dateTimePattern: /^([0-9W+-]+)(T| )(.*)/,
    datePattern: /^([0-9W+-]+)(.*)/,
    plainTime: /:/,
    // year tokens
    YY: /^(\d{2})$/,
    YYY: [
        /^([+-]\d{2})$/,
        /^([+-]\d{3})$/,
        /^([+-]\d{4})$/
    ],
    YYYY: /^(\d{4})/,
    YYYYY: [
        /^([+-]\d{4})/,
        /^([+-]\d{5})/,
        /^([+-]\d{6})/
    ],
    // date tokens
    MM: /^-(\d{2})$/,
    DDD: /^-?(\d{3})$/,
    MMDD: /^-?(\d{2})-?(\d{2})$/,
    Www: /^-?W(\d{2})$/,
    WwwD: /^-?W(\d{2})-?(\d{1})$/,
    HH: /^(\d{2}([.,]\d*)?)$/,
    HHMM: /^(\d{2}):?(\d{2}([.,]\d*)?)$/,
    HHMMSS: /^(\d{2}):?(\d{2}):?(\d{2}([.,]\d*)?)$/,
    // time zone tokens (to identify the presence of a tz)
    timeZone: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$_lib$2f$tzPattern$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tzPattern"]
};
function toDate(argument, options = {}) {
    if (arguments.length < 1) {
        throw new TypeError('1 argument required, but only ' + arguments.length + ' present');
    }
    if (argument === null) {
        return new Date(NaN);
    }
    const additionalDigits = options.additionalDigits == null ? DEFAULT_ADDITIONAL_DIGITS : Number(options.additionalDigits);
    if (additionalDigits !== 2 && additionalDigits !== 1 && additionalDigits !== 0) {
        throw new RangeError('additionalDigits must be 0, 1 or 2');
    }
    // Clone the date
    if (argument instanceof Date || typeof argument === 'object' && Object.prototype.toString.call(argument) === '[object Date]') {
        // Prevent the date to lose the milliseconds when passed to new Date() in IE10
        return new Date(argument.getTime());
    } else if (typeof argument === 'number' || Object.prototype.toString.call(argument) === '[object Number]') {
        return new Date(argument);
    } else if (!(Object.prototype.toString.call(argument) === '[object String]')) {
        return new Date(NaN);
    }
    const dateStrings = splitDateString(argument);
    const { year, restDateString } = parseYear(dateStrings.date, additionalDigits);
    const date = parseDate(restDateString, year);
    if (date === null || isNaN(date.getTime())) {
        return new Date(NaN);
    }
    if (date) {
        const timestamp = date.getTime();
        let time = 0;
        let offset;
        if (dateStrings.time) {
            time = parseTime(dateStrings.time);
            if (time === null || isNaN(time)) {
                return new Date(NaN);
            }
        }
        if (dateStrings.timeZone || options.timeZone) {
            offset = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$_lib$2f$tzParseTimezone$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tzParseTimezone"])(dateStrings.timeZone || options.timeZone, new Date(timestamp + time));
            if (isNaN(offset)) {
                return new Date(NaN);
            }
        } else {
            // get offset accurate to hour in time zones that change offset
            offset = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$_lib$2f$getTimezoneOffsetInMilliseconds$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTimezoneOffsetInMilliseconds"])(new Date(timestamp + time));
            offset = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$_lib$2f$getTimezoneOffsetInMilliseconds$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTimezoneOffsetInMilliseconds"])(new Date(timestamp + time + offset));
        }
        return new Date(timestamp + time + offset);
    } else {
        return new Date(NaN);
    }
}
function splitDateString(dateString) {
    const dateStrings = {};
    let parts = patterns.dateTimePattern.exec(dateString);
    let timeString;
    if (!parts) {
        parts = patterns.datePattern.exec(dateString);
        if (parts) {
            dateStrings.date = parts[1];
            timeString = parts[2];
        } else {
            dateStrings.date = null;
            timeString = dateString;
        }
    } else {
        dateStrings.date = parts[1];
        timeString = parts[3];
    }
    if (timeString) {
        const token = patterns.timeZone.exec(timeString);
        if (token) {
            dateStrings.time = timeString.replace(token[1], '');
            dateStrings.timeZone = token[1].trim();
        } else {
            dateStrings.time = timeString;
        }
    }
    return dateStrings;
}
function parseYear(dateString, additionalDigits) {
    if (dateString) {
        const patternYYY = patterns.YYY[additionalDigits];
        const patternYYYYY = patterns.YYYYY[additionalDigits];
        // YYYY or ±YYYYY
        let token = patterns.YYYY.exec(dateString) || patternYYYYY.exec(dateString);
        if (token) {
            const yearString = token[1];
            return {
                year: parseInt(yearString, 10),
                restDateString: dateString.slice(yearString.length)
            };
        }
        // YY or ±YYY
        token = patterns.YY.exec(dateString) || patternYYY.exec(dateString);
        if (token) {
            const centuryString = token[1];
            return {
                year: parseInt(centuryString, 10) * 100,
                restDateString: dateString.slice(centuryString.length)
            };
        }
    }
    // Invalid ISO-formatted year
    return {
        year: null
    };
}
function parseDate(dateString, year) {
    // Invalid ISO-formatted year
    if (year === null) {
        return null;
    }
    let date;
    let month;
    let week;
    // YYYY
    if (!dateString || !dateString.length) {
        date = new Date(0);
        date.setUTCFullYear(year);
        return date;
    }
    // YYYY-MM
    let token = patterns.MM.exec(dateString);
    if (token) {
        date = new Date(0);
        month = parseInt(token[1], 10) - 1;
        if (!validateDate(year, month)) {
            return new Date(NaN);
        }
        date.setUTCFullYear(year, month);
        return date;
    }
    // YYYY-DDD or YYYYDDD
    token = patterns.DDD.exec(dateString);
    if (token) {
        date = new Date(0);
        const dayOfYear = parseInt(token[1], 10);
        if (!validateDayOfYearDate(year, dayOfYear)) {
            return new Date(NaN);
        }
        date.setUTCFullYear(year, 0, dayOfYear);
        return date;
    }
    // yyyy-MM-dd or YYYYMMDD
    token = patterns.MMDD.exec(dateString);
    if (token) {
        date = new Date(0);
        month = parseInt(token[1], 10) - 1;
        const day = parseInt(token[2], 10);
        if (!validateDate(year, month, day)) {
            return new Date(NaN);
        }
        date.setUTCFullYear(year, month, day);
        return date;
    }
    // YYYY-Www or YYYYWww
    token = patterns.Www.exec(dateString);
    if (token) {
        week = parseInt(token[1], 10) - 1;
        if (!validateWeekDate(week)) {
            return new Date(NaN);
        }
        return dayOfISOWeekYear(year, week);
    }
    // YYYY-Www-D or YYYYWwwD
    token = patterns.WwwD.exec(dateString);
    if (token) {
        week = parseInt(token[1], 10) - 1;
        const dayOfWeek = parseInt(token[2], 10) - 1;
        if (!validateWeekDate(week, dayOfWeek)) {
            return new Date(NaN);
        }
        return dayOfISOWeekYear(year, week, dayOfWeek);
    }
    // Invalid ISO-formatted date
    return null;
}
function parseTime(timeString) {
    let hours;
    let minutes;
    // hh
    let token = patterns.HH.exec(timeString);
    if (token) {
        hours = parseFloat(token[1].replace(',', '.'));
        if (!validateTime(hours)) {
            return NaN;
        }
        return hours % 24 * MILLISECONDS_IN_HOUR;
    }
    // hh:mm or hhmm
    token = patterns.HHMM.exec(timeString);
    if (token) {
        hours = parseInt(token[1], 10);
        minutes = parseFloat(token[2].replace(',', '.'));
        if (!validateTime(hours, minutes)) {
            return NaN;
        }
        return hours % 24 * MILLISECONDS_IN_HOUR + minutes * MILLISECONDS_IN_MINUTE;
    }
    // hh:mm:ss or hhmmss
    token = patterns.HHMMSS.exec(timeString);
    if (token) {
        hours = parseInt(token[1], 10);
        minutes = parseInt(token[2], 10);
        const seconds = parseFloat(token[3].replace(',', '.'));
        if (!validateTime(hours, minutes, seconds)) {
            return NaN;
        }
        return hours % 24 * MILLISECONDS_IN_HOUR + minutes * MILLISECONDS_IN_MINUTE + seconds * 1000;
    }
    // Invalid ISO-formatted time
    return null;
}
function dayOfISOWeekYear(isoWeekYear, week, day) {
    week = week || 0;
    day = day || 0;
    const date = new Date(0);
    date.setUTCFullYear(isoWeekYear, 0, 4);
    const fourthOfJanuaryDay = date.getUTCDay() || 7;
    const diff = week * 7 + day + 1 - fourthOfJanuaryDay;
    date.setUTCDate(date.getUTCDate() + diff);
    return date;
}
// Validation functions
const DAYS_IN_MONTH = [
    31,
    28,
    31,
    30,
    31,
    30,
    31,
    31,
    30,
    31,
    30,
    31
];
const DAYS_IN_MONTH_LEAP_YEAR = [
    31,
    29,
    31,
    30,
    31,
    30,
    31,
    31,
    30,
    31,
    30,
    31
];
function isLeapYearIndex(year) {
    return year % 400 === 0 || year % 4 === 0 && year % 100 !== 0;
}
function validateDate(year, month, date) {
    if (month < 0 || month > 11) {
        return false;
    }
    if (date != null) {
        if (date < 1) {
            return false;
        }
        const isLeapYear = isLeapYearIndex(year);
        if (isLeapYear && date > DAYS_IN_MONTH_LEAP_YEAR[month]) {
            return false;
        }
        if (!isLeapYear && date > DAYS_IN_MONTH[month]) {
            return false;
        }
    }
    return true;
}
function validateDayOfYearDate(year, dayOfYear) {
    if (dayOfYear < 1) {
        return false;
    }
    const isLeapYear = isLeapYearIndex(year);
    if (isLeapYear && dayOfYear > 366) {
        return false;
    }
    if (!isLeapYear && dayOfYear > 365) {
        return false;
    }
    return true;
}
function validateWeekDate(week, day) {
    if (week < 0 || week > 52) {
        return false;
    }
    if (day != null && (day < 0 || day > 6)) {
        return false;
    }
    return true;
}
function validateTime(hours, minutes, seconds) {
    if (hours < 0 || hours >= 25) {
        return false;
    }
    if (minutes != null && (minutes < 0 || minutes >= 60)) {
        return false;
    }
    if (seconds != null && (seconds < 0 || seconds >= 60)) {
        return false;
    }
    return true;
}
}),
"[project]/node_modules/.pnpm/date-fns-tz@3.2.0_date-fns@4.1.0/node_modules/date-fns-tz/dist/esm/format/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "format",
    ()=>format
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/format.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$format$2f$formatters$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns-tz@3.2.0_date-fns@4.1.0/node_modules/date-fns-tz/dist/esm/format/formatters/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$toDate$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns-tz@3.2.0_date-fns@4.1.0/node_modules/date-fns-tz/dist/esm/toDate/index.js [app-client] (ecmascript)");
;
;
;
const tzFormattingTokensRegExp = /([xXOz]+)|''|'(''|[^'])+('|$)/g;
function format(date, formatStr, options = {}) {
    formatStr = String(formatStr);
    const matches = formatStr.match(tzFormattingTokensRegExp);
    if (matches) {
        const d = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$toDate$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDate"])(options.originalDate || date, options);
        // Work through each match and replace the tz token in the format string with the quoted
        // formatted time zone so the remaining tokens can be filled in by date-fns#format.
        formatStr = matches.reduce(function(result, token) {
            if (token[0] === "'") {
                return result; // This is a quoted portion, matched only to ensure we don't match inside it
            }
            const pos = result.indexOf(token);
            const precededByQuotedSection = result[pos - 1] === "'";
            const replaced = result.replace(token, "'" + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$format$2f$formatters$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatters"][token[0]](d, token, options) + "'");
            // If the replacement results in two adjoining quoted strings, the back to back quotes
            // are removed, so it doesn't look like an escaped quote.
            return precededByQuotedSection ? replaced.substring(0, pos - 1) + replaced.substring(pos + 1) : replaced;
        }, formatStr);
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(date, formatStr, options);
}
}),
"[project]/node_modules/.pnpm/date-fns-tz@3.2.0_date-fns@4.1.0/node_modules/date-fns-tz/dist/esm/toZonedTime/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "toZonedTime",
    ()=>toZonedTime
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$_lib$2f$tzParseTimezone$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns-tz@3.2.0_date-fns@4.1.0/node_modules/date-fns-tz/dist/esm/_lib/tzParseTimezone/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$toDate$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns-tz@3.2.0_date-fns@4.1.0/node_modules/date-fns-tz/dist/esm/toDate/index.js [app-client] (ecmascript)");
;
;
function toZonedTime(date, timeZone, options) {
    date = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$toDate$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDate"])(date, options);
    const offsetMilliseconds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$_lib$2f$tzParseTimezone$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tzParseTimezone"])(timeZone, date, true);
    const d = new Date(date.getTime() - offsetMilliseconds);
    const resultDate = new Date(0);
    resultDate.setFullYear(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate());
    resultDate.setHours(d.getUTCHours(), d.getUTCMinutes(), d.getUTCSeconds(), d.getUTCMilliseconds());
    return resultDate;
}
}),
"[project]/node_modules/.pnpm/date-fns-tz@3.2.0_date-fns@4.1.0/node_modules/date-fns-tz/dist/esm/formatInTimeZone/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "formatInTimeZone",
    ()=>formatInTimeZone
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$format$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns-tz@3.2.0_date-fns@4.1.0/node_modules/date-fns-tz/dist/esm/format/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$toZonedTime$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns-tz@3.2.0_date-fns@4.1.0/node_modules/date-fns-tz/dist/esm/toZonedTime/index.js [app-client] (ecmascript)");
;
;
function formatInTimeZone(date, timeZone, formatStr, options) {
    options = {
        ...options,
        timeZone,
        originalDate: date
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$format$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["format"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$toZonedTime$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toZonedTime"])(date, timeZone, {
        timeZone: options.timeZone
    }), formatStr, options);
}
}),
"[project]/node_modules/.pnpm/date-fns-tz@3.2.0_date-fns@4.1.0/node_modules/date-fns-tz/dist/esm/fromZonedTime/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "fromZonedTime",
    ()=>fromZonedTime
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$toDate$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns-tz@3.2.0_date-fns@4.1.0/node_modules/date-fns-tz/dist/esm/toDate/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$_lib$2f$tzPattern$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns-tz@3.2.0_date-fns@4.1.0/node_modules/date-fns-tz/dist/esm/_lib/tzPattern/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$_lib$2f$tzParseTimezone$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns-tz@3.2.0_date-fns@4.1.0/node_modules/date-fns-tz/dist/esm/_lib/tzParseTimezone/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$_lib$2f$newDateUTC$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns-tz@3.2.0_date-fns@4.1.0/node_modules/date-fns-tz/dist/esm/_lib/newDateUTC/index.js [app-client] (ecmascript)");
;
;
;
;
function fromZonedTime(date, timeZone, options) {
    if (typeof date === 'string' && !date.match(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$_lib$2f$tzPattern$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tzPattern"])) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$toDate$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDate"])(date, {
            ...options,
            timeZone
        });
    }
    date = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$toDate$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toDate"])(date, options);
    const utc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$_lib$2f$newDateUTC$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newDateUTC"])(date.getFullYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes(), date.getSeconds(), date.getMilliseconds()).getTime();
    const offsetMilliseconds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$_lib$2f$tzParseTimezone$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tzParseTimezone"])(timeZone, new Date(utc));
    return new Date(utc + offsetMilliseconds);
}
}),
"[project]/node_modules/.pnpm/date-fns-tz@3.2.0_date-fns@4.1.0/node_modules/date-fns-tz/dist/esm/getTimezoneOffset/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getTimezoneOffset",
    ()=>getTimezoneOffset
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$_lib$2f$tzParseTimezone$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns-tz@3.2.0_date-fns@4.1.0/node_modules/date-fns-tz/dist/esm/_lib/tzParseTimezone/index.js [app-client] (ecmascript)");
;
function getTimezoneOffset(timeZone, date) {
    return -(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$_lib$2f$tzParseTimezone$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tzParseTimezone"])(timeZone, date);
}
}),
"[project]/node_modules/.pnpm/date-fns-tz@3.2.0_date-fns@4.1.0/node_modules/date-fns-tz/dist/esm/index.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$format$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns-tz@3.2.0_date-fns@4.1.0/node_modules/date-fns-tz/dist/esm/format/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$formatInTimeZone$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns-tz@3.2.0_date-fns@4.1.0/node_modules/date-fns-tz/dist/esm/formatInTimeZone/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$fromZonedTime$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns-tz@3.2.0_date-fns@4.1.0/node_modules/date-fns-tz/dist/esm/fromZonedTime/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$toZonedTime$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns-tz@3.2.0_date-fns@4.1.0/node_modules/date-fns-tz/dist/esm/toZonedTime/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$getTimezoneOffset$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns-tz@3.2.0_date-fns@4.1.0/node_modules/date-fns-tz/dist/esm/getTimezoneOffset/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$toDate$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns-tz@3.2.0_date-fns@4.1.0/node_modules/date-fns-tz/dist/esm/toDate/index.js [app-client] (ecmascript)");
;
;
;
;
;
;
}),
"[project]/node_modules/.pnpm/@radix-ui+react-popover@1.1.15_@types+react-dom@19.2.3_@types+react@19.2.9__@types+react@19.2_kcylkicjbhui3y3ce4dfdrkpmm/node_modules/@radix-ui/react-popover/dist/index.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Anchor",
    ()=>Anchor2,
    "Arrow",
    ()=>Arrow2,
    "Close",
    ()=>Close,
    "Content",
    ()=>Content2,
    "Popover",
    ()=>Popover,
    "PopoverAnchor",
    ()=>PopoverAnchor,
    "PopoverArrow",
    ()=>PopoverArrow,
    "PopoverClose",
    ()=>PopoverClose,
    "PopoverContent",
    ()=>PopoverContent,
    "PopoverPortal",
    ()=>PopoverPortal,
    "PopoverTrigger",
    ()=>PopoverTrigger,
    "Portal",
    ()=>Portal,
    "Root",
    ()=>Root2,
    "Trigger",
    ()=>Trigger,
    "createPopoverScope",
    ()=>createPopoverScope
]);
// src/popover.tsx
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$primitive$40$1$2e$1$2e$3$2f$node_modules$2f40$radix$2d$ui$2f$primitive$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@radix-ui+primitive@1.1.3/node_modules/@radix-ui/primitive/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$compose$2d$refs$40$1$2e$1$2e$2_$40$types$2b$react$40$19$2e$2$2e$9_react$40$19$2e$2$2e$1$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$compose$2d$refs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@radix-ui+react-compose-refs@1.1.2_@types+react@19.2.9_react@19.2.1/node_modules/@radix-ui/react-compose-refs/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$context$40$1$2e$1$2e$2_$40$types$2b$react$40$19$2e$2$2e$9_react$40$19$2e$2$2e$1$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$context$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@radix-ui+react-context@1.1.2_@types+react@19.2.9_react@19.2.1/node_modules/@radix-ui/react-context/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$dismissable$2d$layer$40$1$2e$1$2e$11_$40$types$2b$react$2d$dom$40$19$2e$2$2e$3_$40$types$2b$react$40$19$2e$2$2e$9_$5f40$types$2b$_hfuk6ry5yn5547eeyukfvou7ya$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dismissable$2d$layer$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@radix-ui+react-dismissable-layer@1.1.11_@types+react-dom@19.2.3_@types+react@19.2.9__@types+_hfuk6ry5yn5547eeyukfvou7ya/node_modules/@radix-ui/react-dismissable-layer/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$focus$2d$guards$40$1$2e$1$2e$3_$40$types$2b$react$40$19$2e$2$2e$9_react$40$19$2e$2$2e$1$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$focus$2d$guards$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@radix-ui+react-focus-guards@1.1.3_@types+react@19.2.9_react@19.2.1/node_modules/@radix-ui/react-focus-guards/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$focus$2d$scope$40$1$2e$1$2e$7_$40$types$2b$react$2d$dom$40$19$2e$2$2e$3_$40$types$2b$react$40$19$2e$2$2e$9_$5f40$types$2b$react$40$1_v2fubohcxtejszxrvh67r5m7oq$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$focus$2d$scope$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@radix-ui+react-focus-scope@1.1.7_@types+react-dom@19.2.3_@types+react@19.2.9__@types+react@1_v2fubohcxtejszxrvh67r5m7oq/node_modules/@radix-ui/react-focus-scope/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$id$40$1$2e$1$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$40$19$2e$2$2e$1$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$id$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@radix-ui+react-id@1.1.1_@types+react@19.2.9_react@19.2.1/node_modules/@radix-ui/react-id/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$popper$40$1$2e$2$2e$8_$40$types$2b$react$2d$dom$40$19$2e$2$2e$3_$40$types$2b$react$40$19$2e$2$2e$9_$5f40$types$2b$react$40$19$2e$2$2e$9_mdgdke3w2gwcbnrciq6bm2wcfu$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$popper$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@radix-ui+react-popper@1.2.8_@types+react-dom@19.2.3_@types+react@19.2.9__@types+react@19.2.9_mdgdke3w2gwcbnrciq6bm2wcfu/node_modules/@radix-ui/react-popper/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$portal$40$1$2e$1$2e$9_$40$types$2b$react$2d$dom$40$19$2e$2$2e$3_$40$types$2b$react$40$19$2e$2$2e$9_$5f40$types$2b$react$40$19$2e$2$2e$9_xfbzvyrn3advy3xbcqyf3aelx4$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$portal$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@radix-ui+react-portal@1.1.9_@types+react-dom@19.2.3_@types+react@19.2.9__@types+react@19.2.9_xfbzvyrn3advy3xbcqyf3aelx4/node_modules/@radix-ui/react-portal/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$presence$40$1$2e$1$2e$5_$40$types$2b$react$2d$dom$40$19$2e$2$2e$3_$40$types$2b$react$40$19$2e$2$2e$9_$5f40$types$2b$react$40$19$2e$2_phgs7h6oqgeoxa4miq6bppvyby$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$presence$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@radix-ui+react-presence@1.1.5_@types+react-dom@19.2.3_@types+react@19.2.9__@types+react@19.2_phgs7h6oqgeoxa4miq6bppvyby/node_modules/@radix-ui/react-presence/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$primitive$40$2$2e$1$2e$3_$40$types$2b$react$2d$dom$40$19$2e$2$2e$3_$40$types$2b$react$40$19$2e$2$2e$9_$5f40$types$2b$react$40$19$2e$_k2fq5k6sqrqshc6fu65nfm2yfe$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$primitive$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@radix-ui+react-primitive@2.1.3_@types+react-dom@19.2.3_@types+react@19.2.9__@types+react@19._k2fq5k6sqrqshc6fu65nfm2yfe/node_modules/@radix-ui/react-primitive/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$slot$40$1$2e$2$2e$3_$40$types$2b$react$40$19$2e$2$2e$9_react$40$19$2e$2$2e$1$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@radix-ui+react-slot@1.2.3_@types+react@19.2.9_react@19.2.1/node_modules/@radix-ui/react-slot/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$use$2d$controllable$2d$state$40$1$2e$2$2e$2_$40$types$2b$react$40$19$2e$2$2e$9_react$40$19$2e$2$2e$1$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$use$2d$controllable$2d$state$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@radix-ui+react-use-controllable-state@1.2.2_@types+react@19.2.9_react@19.2.1/node_modules/@radix-ui/react-use-controllable-state/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$aria$2d$hidden$40$1$2e$2$2e$6$2f$node_modules$2f$aria$2d$hidden$2f$dist$2f$es2015$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/aria-hidden@1.2.6/node_modules/aria-hidden/dist/es2015/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$remove$2d$scroll$40$2$2e$7$2e$2_$40$types$2b$react$40$19$2e$2$2e$9_react$40$19$2e$2$2e$1$2f$node_modules$2f$react$2d$remove$2d$scroll$2f$dist$2f$es2015$2f$Combination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__RemoveScroll$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-remove-scroll@2.7.2_@types+react@19.2.9_react@19.2.1/node_modules/react-remove-scroll/dist/es2015/Combination.js [app-client] (ecmascript) <export default as RemoveScroll>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
var POPOVER_NAME = "Popover";
var [createPopoverContext, createPopoverScope] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$context$40$1$2e$1$2e$2_$40$types$2b$react$40$19$2e$2$2e$9_react$40$19$2e$2$2e$1$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$context$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContextScope"])(POPOVER_NAME, [
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$popper$40$1$2e$2$2e$8_$40$types$2b$react$2d$dom$40$19$2e$2$2e$3_$40$types$2b$react$40$19$2e$2$2e$9_$5f40$types$2b$react$40$19$2e$2$2e$9_mdgdke3w2gwcbnrciq6bm2wcfu$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$popper$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPopperScope"]
]);
var usePopperScope = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$popper$40$1$2e$2$2e$8_$40$types$2b$react$2d$dom$40$19$2e$2$2e$3_$40$types$2b$react$40$19$2e$2$2e$9_$5f40$types$2b$react$40$19$2e$2$2e$9_mdgdke3w2gwcbnrciq6bm2wcfu$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$popper$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPopperScope"])();
var [PopoverProvider, usePopoverContext] = createPopoverContext(POPOVER_NAME);
var Popover = (props)=>{
    const { __scopePopover, children, open: openProp, defaultOpen, onOpenChange, modal = false } = props;
    const popperScope = usePopperScope(__scopePopover);
    const triggerRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const [hasCustomAnchor, setHasCustomAnchor] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](false);
    const [open, setOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$use$2d$controllable$2d$state$40$1$2e$2$2e$2_$40$types$2b$react$40$19$2e$2$2e$9_react$40$19$2e$2$2e$1$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$use$2d$controllable$2d$state$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useControllableState"])({
        prop: openProp,
        defaultProp: defaultOpen ?? false,
        onChange: onOpenChange,
        caller: POPOVER_NAME
    });
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$popper$40$1$2e$2$2e$8_$40$types$2b$react$2d$dom$40$19$2e$2$2e$3_$40$types$2b$react$40$19$2e$2$2e$9_$5f40$types$2b$react$40$19$2e$2$2e$9_mdgdke3w2gwcbnrciq6bm2wcfu$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$popper$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"], {
        ...popperScope,
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(PopoverProvider, {
            scope: __scopePopover,
            contentId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$id$40$1$2e$1$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$40$19$2e$2$2e$1$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$id$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])(),
            triggerRef,
            open,
            onOpenChange: setOpen,
            onOpenToggle: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
                "Popover.useCallback": ()=>setOpen({
                        "Popover.useCallback": (prevOpen)=>!prevOpen
                    }["Popover.useCallback"])
            }["Popover.useCallback"], [
                setOpen
            ]),
            hasCustomAnchor,
            onCustomAnchorAdd: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
                "Popover.useCallback": ()=>setHasCustomAnchor(true)
            }["Popover.useCallback"], []),
            onCustomAnchorRemove: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
                "Popover.useCallback": ()=>setHasCustomAnchor(false)
            }["Popover.useCallback"], []),
            modal,
            children
        })
    });
};
Popover.displayName = POPOVER_NAME;
var ANCHOR_NAME = "PopoverAnchor";
var PopoverAnchor = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"]((props, forwardedRef)=>{
    const { __scopePopover, ...anchorProps } = props;
    const context = usePopoverContext(ANCHOR_NAME, __scopePopover);
    const popperScope = usePopperScope(__scopePopover);
    const { onCustomAnchorAdd, onCustomAnchorRemove } = context;
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "PopoverAnchor.useEffect": ()=>{
            onCustomAnchorAdd();
            return ({
                "PopoverAnchor.useEffect": ()=>onCustomAnchorRemove()
            })["PopoverAnchor.useEffect"];
        }
    }["PopoverAnchor.useEffect"], [
        onCustomAnchorAdd,
        onCustomAnchorRemove
    ]);
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$popper$40$1$2e$2$2e$8_$40$types$2b$react$2d$dom$40$19$2e$2$2e$3_$40$types$2b$react$40$19$2e$2$2e$9_$5f40$types$2b$react$40$19$2e$2$2e$9_mdgdke3w2gwcbnrciq6bm2wcfu$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$popper$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Anchor"], {
        ...popperScope,
        ...anchorProps,
        ref: forwardedRef
    });
});
PopoverAnchor.displayName = ANCHOR_NAME;
var TRIGGER_NAME = "PopoverTrigger";
var PopoverTrigger = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"]((props, forwardedRef)=>{
    const { __scopePopover, ...triggerProps } = props;
    const context = usePopoverContext(TRIGGER_NAME, __scopePopover);
    const popperScope = usePopperScope(__scopePopover);
    const composedTriggerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$compose$2d$refs$40$1$2e$1$2e$2_$40$types$2b$react$40$19$2e$2$2e$9_react$40$19$2e$2$2e$1$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$compose$2d$refs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useComposedRefs"])(forwardedRef, context.triggerRef);
    const trigger = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$primitive$40$2$2e$1$2e$3_$40$types$2b$react$2d$dom$40$19$2e$2$2e$3_$40$types$2b$react$40$19$2e$2$2e$9_$5f40$types$2b$react$40$19$2e$_k2fq5k6sqrqshc6fu65nfm2yfe$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$primitive$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Primitive"].button, {
        type: "button",
        "aria-haspopup": "dialog",
        "aria-expanded": context.open,
        "aria-controls": context.contentId,
        "data-state": getState(context.open),
        ...triggerProps,
        ref: composedTriggerRef,
        onClick: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$primitive$40$1$2e$1$2e$3$2f$node_modules$2f40$radix$2d$ui$2f$primitive$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["composeEventHandlers"])(props.onClick, context.onOpenToggle)
    });
    return context.hasCustomAnchor ? trigger : /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$popper$40$1$2e$2$2e$8_$40$types$2b$react$2d$dom$40$19$2e$2$2e$3_$40$types$2b$react$40$19$2e$2$2e$9_$5f40$types$2b$react$40$19$2e$2$2e$9_mdgdke3w2gwcbnrciq6bm2wcfu$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$popper$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Anchor"], {
        asChild: true,
        ...popperScope,
        children: trigger
    });
});
PopoverTrigger.displayName = TRIGGER_NAME;
var PORTAL_NAME = "PopoverPortal";
var [PortalProvider, usePortalContext] = createPopoverContext(PORTAL_NAME, {
    forceMount: void 0
});
var PopoverPortal = (props)=>{
    const { __scopePopover, forceMount, children, container } = props;
    const context = usePopoverContext(PORTAL_NAME, __scopePopover);
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(PortalProvider, {
        scope: __scopePopover,
        forceMount,
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$presence$40$1$2e$1$2e$5_$40$types$2b$react$2d$dom$40$19$2e$2$2e$3_$40$types$2b$react$40$19$2e$2$2e$9_$5f40$types$2b$react$40$19$2e$2_phgs7h6oqgeoxa4miq6bppvyby$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$presence$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Presence"], {
            present: forceMount || context.open,
            children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$portal$40$1$2e$1$2e$9_$40$types$2b$react$2d$dom$40$19$2e$2$2e$3_$40$types$2b$react$40$19$2e$2$2e$9_$5f40$types$2b$react$40$19$2e$2$2e$9_xfbzvyrn3advy3xbcqyf3aelx4$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$portal$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Portal"], {
                asChild: true,
                container,
                children
            })
        })
    });
};
PopoverPortal.displayName = PORTAL_NAME;
var CONTENT_NAME = "PopoverContent";
var PopoverContent = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"]((props, forwardedRef)=>{
    const portalContext = usePortalContext(CONTENT_NAME, props.__scopePopover);
    const { forceMount = portalContext.forceMount, ...contentProps } = props;
    const context = usePopoverContext(CONTENT_NAME, props.__scopePopover);
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$presence$40$1$2e$1$2e$5_$40$types$2b$react$2d$dom$40$19$2e$2$2e$3_$40$types$2b$react$40$19$2e$2$2e$9_$5f40$types$2b$react$40$19$2e$2_phgs7h6oqgeoxa4miq6bppvyby$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$presence$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Presence"], {
        present: forceMount || context.open,
        children: context.modal ? /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(PopoverContentModal, {
            ...contentProps,
            ref: forwardedRef
        }) : /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(PopoverContentNonModal, {
            ...contentProps,
            ref: forwardedRef
        })
    });
});
PopoverContent.displayName = CONTENT_NAME;
var Slot = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$slot$40$1$2e$2$2e$3_$40$types$2b$react$40$19$2e$2$2e$9_react$40$19$2e$2$2e$1$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSlot"])("PopoverContent.RemoveScroll");
var PopoverContentModal = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"]((props, forwardedRef)=>{
    const context = usePopoverContext(CONTENT_NAME, props.__scopePopover);
    const contentRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const composedRefs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$compose$2d$refs$40$1$2e$1$2e$2_$40$types$2b$react$40$19$2e$2$2e$9_react$40$19$2e$2$2e$1$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$compose$2d$refs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useComposedRefs"])(forwardedRef, contentRef);
    const isRightClickOutsideRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](false);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "PopoverContentModal.useEffect": ()=>{
            const content = contentRef.current;
            if (content) return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$aria$2d$hidden$40$1$2e$2$2e$6$2f$node_modules$2f$aria$2d$hidden$2f$dist$2f$es2015$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hideOthers"])(content);
        }
    }["PopoverContentModal.useEffect"], []);
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$remove$2d$scroll$40$2$2e$7$2e$2_$40$types$2b$react$40$19$2e$2$2e$9_react$40$19$2e$2$2e$1$2f$node_modules$2f$react$2d$remove$2d$scroll$2f$dist$2f$es2015$2f$Combination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__RemoveScroll$3e$__["RemoveScroll"], {
        as: Slot,
        allowPinchZoom: true,
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(PopoverContentImpl, {
            ...props,
            ref: composedRefs,
            trapFocus: context.open,
            disableOutsidePointerEvents: true,
            onCloseAutoFocus: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$primitive$40$1$2e$1$2e$3$2f$node_modules$2f40$radix$2d$ui$2f$primitive$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["composeEventHandlers"])(props.onCloseAutoFocus, (event)=>{
                event.preventDefault();
                if (!isRightClickOutsideRef.current) context.triggerRef.current?.focus();
            }),
            onPointerDownOutside: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$primitive$40$1$2e$1$2e$3$2f$node_modules$2f40$radix$2d$ui$2f$primitive$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["composeEventHandlers"])(props.onPointerDownOutside, (event)=>{
                const originalEvent = event.detail.originalEvent;
                const ctrlLeftClick = originalEvent.button === 0 && originalEvent.ctrlKey === true;
                const isRightClick = originalEvent.button === 2 || ctrlLeftClick;
                isRightClickOutsideRef.current = isRightClick;
            }, {
                checkForDefaultPrevented: false
            }),
            onFocusOutside: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$primitive$40$1$2e$1$2e$3$2f$node_modules$2f40$radix$2d$ui$2f$primitive$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["composeEventHandlers"])(props.onFocusOutside, (event)=>event.preventDefault(), {
                checkForDefaultPrevented: false
            })
        })
    });
});
var PopoverContentNonModal = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"]((props, forwardedRef)=>{
    const context = usePopoverContext(CONTENT_NAME, props.__scopePopover);
    const hasInteractedOutsideRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](false);
    const hasPointerDownOutsideRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](false);
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(PopoverContentImpl, {
        ...props,
        ref: forwardedRef,
        trapFocus: false,
        disableOutsidePointerEvents: false,
        onCloseAutoFocus: (event)=>{
            props.onCloseAutoFocus?.(event);
            if (!event.defaultPrevented) {
                if (!hasInteractedOutsideRef.current) context.triggerRef.current?.focus();
                event.preventDefault();
            }
            hasInteractedOutsideRef.current = false;
            hasPointerDownOutsideRef.current = false;
        },
        onInteractOutside: (event)=>{
            props.onInteractOutside?.(event);
            if (!event.defaultPrevented) {
                hasInteractedOutsideRef.current = true;
                if (event.detail.originalEvent.type === "pointerdown") {
                    hasPointerDownOutsideRef.current = true;
                }
            }
            const target = event.target;
            const targetIsTrigger = context.triggerRef.current?.contains(target);
            if (targetIsTrigger) event.preventDefault();
            if (event.detail.originalEvent.type === "focusin" && hasPointerDownOutsideRef.current) {
                event.preventDefault();
            }
        }
    });
});
var PopoverContentImpl = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"]((props, forwardedRef)=>{
    const { __scopePopover, trapFocus, onOpenAutoFocus, onCloseAutoFocus, disableOutsidePointerEvents, onEscapeKeyDown, onPointerDownOutside, onFocusOutside, onInteractOutside, ...contentProps } = props;
    const context = usePopoverContext(CONTENT_NAME, __scopePopover);
    const popperScope = usePopperScope(__scopePopover);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$focus$2d$guards$40$1$2e$1$2e$3_$40$types$2b$react$40$19$2e$2$2e$9_react$40$19$2e$2$2e$1$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$focus$2d$guards$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFocusGuards"])();
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$focus$2d$scope$40$1$2e$1$2e$7_$40$types$2b$react$2d$dom$40$19$2e$2$2e$3_$40$types$2b$react$40$19$2e$2$2e$9_$5f40$types$2b$react$40$1_v2fubohcxtejszxrvh67r5m7oq$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$focus$2d$scope$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FocusScope"], {
        asChild: true,
        loop: true,
        trapped: trapFocus,
        onMountAutoFocus: onOpenAutoFocus,
        onUnmountAutoFocus: onCloseAutoFocus,
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$dismissable$2d$layer$40$1$2e$1$2e$11_$40$types$2b$react$2d$dom$40$19$2e$2$2e$3_$40$types$2b$react$40$19$2e$2$2e$9_$5f40$types$2b$_hfuk6ry5yn5547eeyukfvou7ya$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dismissable$2d$layer$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DismissableLayer"], {
            asChild: true,
            disableOutsidePointerEvents,
            onInteractOutside,
            onEscapeKeyDown,
            onPointerDownOutside,
            onFocusOutside,
            onDismiss: ()=>context.onOpenChange(false),
            children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$popper$40$1$2e$2$2e$8_$40$types$2b$react$2d$dom$40$19$2e$2$2e$3_$40$types$2b$react$40$19$2e$2$2e$9_$5f40$types$2b$react$40$19$2e$2$2e$9_mdgdke3w2gwcbnrciq6bm2wcfu$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$popper$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Content"], {
                "data-state": getState(context.open),
                role: "dialog",
                id: context.contentId,
                ...popperScope,
                ...contentProps,
                ref: forwardedRef,
                style: {
                    ...contentProps.style,
                    // re-namespace exposed content custom properties
                    ...{
                        "--radix-popover-content-transform-origin": "var(--radix-popper-transform-origin)",
                        "--radix-popover-content-available-width": "var(--radix-popper-available-width)",
                        "--radix-popover-content-available-height": "var(--radix-popper-available-height)",
                        "--radix-popover-trigger-width": "var(--radix-popper-anchor-width)",
                        "--radix-popover-trigger-height": "var(--radix-popper-anchor-height)"
                    }
                }
            })
        })
    });
});
var CLOSE_NAME = "PopoverClose";
var PopoverClose = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"]((props, forwardedRef)=>{
    const { __scopePopover, ...closeProps } = props;
    const context = usePopoverContext(CLOSE_NAME, __scopePopover);
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$primitive$40$2$2e$1$2e$3_$40$types$2b$react$2d$dom$40$19$2e$2$2e$3_$40$types$2b$react$40$19$2e$2$2e$9_$5f40$types$2b$react$40$19$2e$_k2fq5k6sqrqshc6fu65nfm2yfe$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$primitive$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Primitive"].button, {
        type: "button",
        ...closeProps,
        ref: forwardedRef,
        onClick: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$primitive$40$1$2e$1$2e$3$2f$node_modules$2f40$radix$2d$ui$2f$primitive$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["composeEventHandlers"])(props.onClick, ()=>context.onOpenChange(false))
    });
});
PopoverClose.displayName = CLOSE_NAME;
var ARROW_NAME = "PopoverArrow";
var PopoverArrow = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"]((props, forwardedRef)=>{
    const { __scopePopover, ...arrowProps } = props;
    const popperScope = usePopperScope(__scopePopover);
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$popper$40$1$2e$2$2e$8_$40$types$2b$react$2d$dom$40$19$2e$2$2e$3_$40$types$2b$react$40$19$2e$2$2e$9_$5f40$types$2b$react$40$19$2e$2$2e$9_mdgdke3w2gwcbnrciq6bm2wcfu$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$popper$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Arrow"], {
        ...popperScope,
        ...arrowProps,
        ref: forwardedRef
    });
});
PopoverArrow.displayName = ARROW_NAME;
function getState(open) {
    return open ? "open" : "closed";
}
var Root2 = Popover;
var Anchor2 = PopoverAnchor;
var Trigger = PopoverTrigger;
var Portal = PopoverPortal;
var Content2 = PopoverContent;
var Close = PopoverClose;
var Arrow2 = PopoverArrow;
;
 //# sourceMappingURL=index.mjs.map
}),
"[project]/node_modules/.pnpm/@radix-ui+react-hover-card@1.1.15_@types+react-dom@19.2.3_@types+react@19.2.9__@types+react@1_32tl56rsm6qo3i2mwq6whfflwe/node_modules/@radix-ui/react-hover-card/dist/index.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Arrow",
    ()=>Arrow2,
    "Content",
    ()=>Content2,
    "HoverCard",
    ()=>HoverCard,
    "HoverCardArrow",
    ()=>HoverCardArrow,
    "HoverCardContent",
    ()=>HoverCardContent,
    "HoverCardPortal",
    ()=>HoverCardPortal,
    "HoverCardTrigger",
    ()=>HoverCardTrigger,
    "Portal",
    ()=>Portal,
    "Root",
    ()=>Root2,
    "Trigger",
    ()=>Trigger,
    "createHoverCardScope",
    ()=>createHoverCardScope
]);
// src/hover-card.tsx
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$primitive$40$1$2e$1$2e$3$2f$node_modules$2f40$radix$2d$ui$2f$primitive$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@radix-ui+primitive@1.1.3/node_modules/@radix-ui/primitive/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$context$40$1$2e$1$2e$2_$40$types$2b$react$40$19$2e$2$2e$9_react$40$19$2e$2$2e$1$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$context$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@radix-ui+react-context@1.1.2_@types+react@19.2.9_react@19.2.1/node_modules/@radix-ui/react-context/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$use$2d$controllable$2d$state$40$1$2e$2$2e$2_$40$types$2b$react$40$19$2e$2$2e$9_react$40$19$2e$2$2e$1$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$use$2d$controllable$2d$state$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@radix-ui+react-use-controllable-state@1.2.2_@types+react@19.2.9_react@19.2.1/node_modules/@radix-ui/react-use-controllable-state/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$compose$2d$refs$40$1$2e$1$2e$2_$40$types$2b$react$40$19$2e$2$2e$9_react$40$19$2e$2$2e$1$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$compose$2d$refs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@radix-ui+react-compose-refs@1.1.2_@types+react@19.2.9_react@19.2.1/node_modules/@radix-ui/react-compose-refs/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$popper$40$1$2e$2$2e$8_$40$types$2b$react$2d$dom$40$19$2e$2$2e$3_$40$types$2b$react$40$19$2e$2$2e$9_$5f40$types$2b$react$40$19$2e$2$2e$9_mdgdke3w2gwcbnrciq6bm2wcfu$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$popper$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@radix-ui+react-popper@1.2.8_@types+react-dom@19.2.3_@types+react@19.2.9__@types+react@19.2.9_mdgdke3w2gwcbnrciq6bm2wcfu/node_modules/@radix-ui/react-popper/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$portal$40$1$2e$1$2e$9_$40$types$2b$react$2d$dom$40$19$2e$2$2e$3_$40$types$2b$react$40$19$2e$2$2e$9_$5f40$types$2b$react$40$19$2e$2$2e$9_xfbzvyrn3advy3xbcqyf3aelx4$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$portal$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@radix-ui+react-portal@1.1.9_@types+react-dom@19.2.3_@types+react@19.2.9__@types+react@19.2.9_xfbzvyrn3advy3xbcqyf3aelx4/node_modules/@radix-ui/react-portal/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$presence$40$1$2e$1$2e$5_$40$types$2b$react$2d$dom$40$19$2e$2$2e$3_$40$types$2b$react$40$19$2e$2$2e$9_$5f40$types$2b$react$40$19$2e$2_phgs7h6oqgeoxa4miq6bppvyby$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$presence$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@radix-ui+react-presence@1.1.5_@types+react-dom@19.2.3_@types+react@19.2.9__@types+react@19.2_phgs7h6oqgeoxa4miq6bppvyby/node_modules/@radix-ui/react-presence/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$primitive$40$2$2e$1$2e$3_$40$types$2b$react$2d$dom$40$19$2e$2$2e$3_$40$types$2b$react$40$19$2e$2$2e$9_$5f40$types$2b$react$40$19$2e$_k2fq5k6sqrqshc6fu65nfm2yfe$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$primitive$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@radix-ui+react-primitive@2.1.3_@types+react-dom@19.2.3_@types+react@19.2.9__@types+react@19._k2fq5k6sqrqshc6fu65nfm2yfe/node_modules/@radix-ui/react-primitive/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$dismissable$2d$layer$40$1$2e$1$2e$11_$40$types$2b$react$2d$dom$40$19$2e$2$2e$3_$40$types$2b$react$40$19$2e$2$2e$9_$5f40$types$2b$_hfuk6ry5yn5547eeyukfvou7ya$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dismissable$2d$layer$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@radix-ui+react-dismissable-layer@1.1.11_@types+react-dom@19.2.3_@types+react@19.2.9__@types+_hfuk6ry5yn5547eeyukfvou7ya/node_modules/@radix-ui/react-dismissable-layer/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
var originalBodyUserSelect;
var HOVERCARD_NAME = "HoverCard";
var [createHoverCardContext, createHoverCardScope] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$context$40$1$2e$1$2e$2_$40$types$2b$react$40$19$2e$2$2e$9_react$40$19$2e$2$2e$1$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$context$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContextScope"])(HOVERCARD_NAME, [
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$popper$40$1$2e$2$2e$8_$40$types$2b$react$2d$dom$40$19$2e$2$2e$3_$40$types$2b$react$40$19$2e$2$2e$9_$5f40$types$2b$react$40$19$2e$2$2e$9_mdgdke3w2gwcbnrciq6bm2wcfu$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$popper$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPopperScope"]
]);
var usePopperScope = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$popper$40$1$2e$2$2e$8_$40$types$2b$react$2d$dom$40$19$2e$2$2e$3_$40$types$2b$react$40$19$2e$2$2e$9_$5f40$types$2b$react$40$19$2e$2$2e$9_mdgdke3w2gwcbnrciq6bm2wcfu$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$popper$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPopperScope"])();
var [HoverCardProvider, useHoverCardContext] = createHoverCardContext(HOVERCARD_NAME);
var HoverCard = (props)=>{
    const { __scopeHoverCard, children, open: openProp, defaultOpen, onOpenChange, openDelay = 700, closeDelay = 300 } = props;
    const popperScope = usePopperScope(__scopeHoverCard);
    const openTimerRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](0);
    const closeTimerRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](0);
    const hasSelectionRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](false);
    const isPointerDownOnContentRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](false);
    const [open, setOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$use$2d$controllable$2d$state$40$1$2e$2$2e$2_$40$types$2b$react$40$19$2e$2$2e$9_react$40$19$2e$2$2e$1$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$use$2d$controllable$2d$state$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useControllableState"])({
        prop: openProp,
        defaultProp: defaultOpen ?? false,
        onChange: onOpenChange,
        caller: HOVERCARD_NAME
    });
    const handleOpen = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "HoverCard.useCallback[handleOpen]": ()=>{
            clearTimeout(closeTimerRef.current);
            openTimerRef.current = window.setTimeout({
                "HoverCard.useCallback[handleOpen]": ()=>setOpen(true)
            }["HoverCard.useCallback[handleOpen]"], openDelay);
        }
    }["HoverCard.useCallback[handleOpen]"], [
        openDelay,
        setOpen
    ]);
    const handleClose = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "HoverCard.useCallback[handleClose]": ()=>{
            clearTimeout(openTimerRef.current);
            if (!hasSelectionRef.current && !isPointerDownOnContentRef.current) {
                closeTimerRef.current = window.setTimeout({
                    "HoverCard.useCallback[handleClose]": ()=>setOpen(false)
                }["HoverCard.useCallback[handleClose]"], closeDelay);
            }
        }
    }["HoverCard.useCallback[handleClose]"], [
        closeDelay,
        setOpen
    ]);
    const handleDismiss = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "HoverCard.useCallback[handleDismiss]": ()=>setOpen(false)
    }["HoverCard.useCallback[handleDismiss]"], [
        setOpen
    ]);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "HoverCard.useEffect": ()=>{
            return ({
                "HoverCard.useEffect": ()=>{
                    clearTimeout(openTimerRef.current);
                    clearTimeout(closeTimerRef.current);
                }
            })["HoverCard.useEffect"];
        }
    }["HoverCard.useEffect"], []);
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(HoverCardProvider, {
        scope: __scopeHoverCard,
        open,
        onOpenChange: setOpen,
        onOpen: handleOpen,
        onClose: handleClose,
        onDismiss: handleDismiss,
        hasSelectionRef,
        isPointerDownOnContentRef,
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$popper$40$1$2e$2$2e$8_$40$types$2b$react$2d$dom$40$19$2e$2$2e$3_$40$types$2b$react$40$19$2e$2$2e$9_$5f40$types$2b$react$40$19$2e$2$2e$9_mdgdke3w2gwcbnrciq6bm2wcfu$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$popper$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"], {
            ...popperScope,
            children
        })
    });
};
HoverCard.displayName = HOVERCARD_NAME;
var TRIGGER_NAME = "HoverCardTrigger";
var HoverCardTrigger = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"]((props, forwardedRef)=>{
    const { __scopeHoverCard, ...triggerProps } = props;
    const context = useHoverCardContext(TRIGGER_NAME, __scopeHoverCard);
    const popperScope = usePopperScope(__scopeHoverCard);
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$popper$40$1$2e$2$2e$8_$40$types$2b$react$2d$dom$40$19$2e$2$2e$3_$40$types$2b$react$40$19$2e$2$2e$9_$5f40$types$2b$react$40$19$2e$2$2e$9_mdgdke3w2gwcbnrciq6bm2wcfu$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$popper$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Anchor"], {
        asChild: true,
        ...popperScope,
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$primitive$40$2$2e$1$2e$3_$40$types$2b$react$2d$dom$40$19$2e$2$2e$3_$40$types$2b$react$40$19$2e$2$2e$9_$5f40$types$2b$react$40$19$2e$_k2fq5k6sqrqshc6fu65nfm2yfe$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$primitive$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Primitive"].a, {
            "data-state": context.open ? "open" : "closed",
            ...triggerProps,
            ref: forwardedRef,
            onPointerEnter: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$primitive$40$1$2e$1$2e$3$2f$node_modules$2f40$radix$2d$ui$2f$primitive$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["composeEventHandlers"])(props.onPointerEnter, excludeTouch(context.onOpen)),
            onPointerLeave: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$primitive$40$1$2e$1$2e$3$2f$node_modules$2f40$radix$2d$ui$2f$primitive$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["composeEventHandlers"])(props.onPointerLeave, excludeTouch(context.onClose)),
            onFocus: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$primitive$40$1$2e$1$2e$3$2f$node_modules$2f40$radix$2d$ui$2f$primitive$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["composeEventHandlers"])(props.onFocus, context.onOpen),
            onBlur: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$primitive$40$1$2e$1$2e$3$2f$node_modules$2f40$radix$2d$ui$2f$primitive$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["composeEventHandlers"])(props.onBlur, context.onClose),
            onTouchStart: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$primitive$40$1$2e$1$2e$3$2f$node_modules$2f40$radix$2d$ui$2f$primitive$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["composeEventHandlers"])(props.onTouchStart, (event)=>event.preventDefault())
        })
    });
});
HoverCardTrigger.displayName = TRIGGER_NAME;
var PORTAL_NAME = "HoverCardPortal";
var [PortalProvider, usePortalContext] = createHoverCardContext(PORTAL_NAME, {
    forceMount: void 0
});
var HoverCardPortal = (props)=>{
    const { __scopeHoverCard, forceMount, children, container } = props;
    const context = useHoverCardContext(PORTAL_NAME, __scopeHoverCard);
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(PortalProvider, {
        scope: __scopeHoverCard,
        forceMount,
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$presence$40$1$2e$1$2e$5_$40$types$2b$react$2d$dom$40$19$2e$2$2e$3_$40$types$2b$react$40$19$2e$2$2e$9_$5f40$types$2b$react$40$19$2e$2_phgs7h6oqgeoxa4miq6bppvyby$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$presence$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Presence"], {
            present: forceMount || context.open,
            children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$portal$40$1$2e$1$2e$9_$40$types$2b$react$2d$dom$40$19$2e$2$2e$3_$40$types$2b$react$40$19$2e$2$2e$9_$5f40$types$2b$react$40$19$2e$2$2e$9_xfbzvyrn3advy3xbcqyf3aelx4$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$portal$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Portal"], {
                asChild: true,
                container,
                children
            })
        })
    });
};
HoverCardPortal.displayName = PORTAL_NAME;
var CONTENT_NAME = "HoverCardContent";
var HoverCardContent = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"]((props, forwardedRef)=>{
    const portalContext = usePortalContext(CONTENT_NAME, props.__scopeHoverCard);
    const { forceMount = portalContext.forceMount, ...contentProps } = props;
    const context = useHoverCardContext(CONTENT_NAME, props.__scopeHoverCard);
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$presence$40$1$2e$1$2e$5_$40$types$2b$react$2d$dom$40$19$2e$2$2e$3_$40$types$2b$react$40$19$2e$2$2e$9_$5f40$types$2b$react$40$19$2e$2_phgs7h6oqgeoxa4miq6bppvyby$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$presence$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Presence"], {
        present: forceMount || context.open,
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(HoverCardContentImpl, {
            "data-state": context.open ? "open" : "closed",
            ...contentProps,
            onPointerEnter: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$primitive$40$1$2e$1$2e$3$2f$node_modules$2f40$radix$2d$ui$2f$primitive$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["composeEventHandlers"])(props.onPointerEnter, excludeTouch(context.onOpen)),
            onPointerLeave: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$primitive$40$1$2e$1$2e$3$2f$node_modules$2f40$radix$2d$ui$2f$primitive$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["composeEventHandlers"])(props.onPointerLeave, excludeTouch(context.onClose)),
            ref: forwardedRef
        })
    });
});
HoverCardContent.displayName = CONTENT_NAME;
var HoverCardContentImpl = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"]((props, forwardedRef)=>{
    const { __scopeHoverCard, onEscapeKeyDown, onPointerDownOutside, onFocusOutside, onInteractOutside, ...contentProps } = props;
    const context = useHoverCardContext(CONTENT_NAME, __scopeHoverCard);
    const popperScope = usePopperScope(__scopeHoverCard);
    const ref = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const composedRefs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$compose$2d$refs$40$1$2e$1$2e$2_$40$types$2b$react$40$19$2e$2$2e$9_react$40$19$2e$2$2e$1$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$compose$2d$refs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useComposedRefs"])(forwardedRef, ref);
    const [containSelection, setContainSelection] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](false);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "HoverCardContentImpl.useEffect": ()=>{
            if (containSelection) {
                const body = document.body;
                originalBodyUserSelect = body.style.userSelect || body.style.webkitUserSelect;
                body.style.userSelect = "none";
                body.style.webkitUserSelect = "none";
                return ({
                    "HoverCardContentImpl.useEffect": ()=>{
                        body.style.userSelect = originalBodyUserSelect;
                        body.style.webkitUserSelect = originalBodyUserSelect;
                    }
                })["HoverCardContentImpl.useEffect"];
            }
        }
    }["HoverCardContentImpl.useEffect"], [
        containSelection
    ]);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "HoverCardContentImpl.useEffect": ()=>{
            if (ref.current) {
                const handlePointerUp = {
                    "HoverCardContentImpl.useEffect.handlePointerUp": ()=>{
                        setContainSelection(false);
                        context.isPointerDownOnContentRef.current = false;
                        setTimeout({
                            "HoverCardContentImpl.useEffect.handlePointerUp": ()=>{
                                const hasSelection = document.getSelection()?.toString() !== "";
                                if (hasSelection) context.hasSelectionRef.current = true;
                            }
                        }["HoverCardContentImpl.useEffect.handlePointerUp"]);
                    }
                }["HoverCardContentImpl.useEffect.handlePointerUp"];
                document.addEventListener("pointerup", handlePointerUp);
                return ({
                    "HoverCardContentImpl.useEffect": ()=>{
                        document.removeEventListener("pointerup", handlePointerUp);
                        context.hasSelectionRef.current = false;
                        context.isPointerDownOnContentRef.current = false;
                    }
                })["HoverCardContentImpl.useEffect"];
            }
        }
    }["HoverCardContentImpl.useEffect"], [
        context.isPointerDownOnContentRef,
        context.hasSelectionRef
    ]);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "HoverCardContentImpl.useEffect": ()=>{
            if (ref.current) {
                const tabbables = getTabbableNodes(ref.current);
                tabbables.forEach({
                    "HoverCardContentImpl.useEffect": (tabbable)=>tabbable.setAttribute("tabindex", "-1")
                }["HoverCardContentImpl.useEffect"]);
            }
        }
    }["HoverCardContentImpl.useEffect"]);
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$dismissable$2d$layer$40$1$2e$1$2e$11_$40$types$2b$react$2d$dom$40$19$2e$2$2e$3_$40$types$2b$react$40$19$2e$2$2e$9_$5f40$types$2b$_hfuk6ry5yn5547eeyukfvou7ya$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dismissable$2d$layer$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DismissableLayer"], {
        asChild: true,
        disableOutsidePointerEvents: false,
        onInteractOutside,
        onEscapeKeyDown,
        onPointerDownOutside,
        onFocusOutside: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$primitive$40$1$2e$1$2e$3$2f$node_modules$2f40$radix$2d$ui$2f$primitive$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["composeEventHandlers"])(onFocusOutside, (event)=>{
            event.preventDefault();
        }),
        onDismiss: context.onDismiss,
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$popper$40$1$2e$2$2e$8_$40$types$2b$react$2d$dom$40$19$2e$2$2e$3_$40$types$2b$react$40$19$2e$2$2e$9_$5f40$types$2b$react$40$19$2e$2$2e$9_mdgdke3w2gwcbnrciq6bm2wcfu$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$popper$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Content"], {
            ...popperScope,
            ...contentProps,
            onPointerDown: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$primitive$40$1$2e$1$2e$3$2f$node_modules$2f40$radix$2d$ui$2f$primitive$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["composeEventHandlers"])(contentProps.onPointerDown, (event)=>{
                if (event.currentTarget.contains(event.target)) {
                    setContainSelection(true);
                }
                context.hasSelectionRef.current = false;
                context.isPointerDownOnContentRef.current = true;
            }),
            ref: composedRefs,
            style: {
                ...contentProps.style,
                userSelect: containSelection ? "text" : void 0,
                // Safari requires prefix
                WebkitUserSelect: containSelection ? "text" : void 0,
                // re-namespace exposed content custom properties
                ...{
                    "--radix-hover-card-content-transform-origin": "var(--radix-popper-transform-origin)",
                    "--radix-hover-card-content-available-width": "var(--radix-popper-available-width)",
                    "--radix-hover-card-content-available-height": "var(--radix-popper-available-height)",
                    "--radix-hover-card-trigger-width": "var(--radix-popper-anchor-width)",
                    "--radix-hover-card-trigger-height": "var(--radix-popper-anchor-height)"
                }
            }
        })
    });
});
var ARROW_NAME = "HoverCardArrow";
var HoverCardArrow = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"]((props, forwardedRef)=>{
    const { __scopeHoverCard, ...arrowProps } = props;
    const popperScope = usePopperScope(__scopeHoverCard);
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$popper$40$1$2e$2$2e$8_$40$types$2b$react$2d$dom$40$19$2e$2$2e$3_$40$types$2b$react$40$19$2e$2$2e$9_$5f40$types$2b$react$40$19$2e$2$2e$9_mdgdke3w2gwcbnrciq6bm2wcfu$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$popper$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Arrow"], {
        ...popperScope,
        ...arrowProps,
        ref: forwardedRef
    });
});
HoverCardArrow.displayName = ARROW_NAME;
function excludeTouch(eventHandler) {
    return (event)=>event.pointerType === "touch" ? void 0 : eventHandler();
}
function getTabbableNodes(container) {
    const nodes = [];
    const walker = document.createTreeWalker(container, NodeFilter.SHOW_ELEMENT, {
        acceptNode: (node)=>{
            return node.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
        }
    });
    while(walker.nextNode())nodes.push(walker.currentNode);
    return nodes;
}
var Root2 = HoverCard;
var Trigger = HoverCardTrigger;
var Portal = HoverCardPortal;
var Content2 = HoverCardContent;
var Arrow2 = HoverCardArrow;
;
 //# sourceMappingURL=index.mjs.map
}),
"[project]/node_modules/.pnpm/nav-faker@3.2.4/node_modules/nav-faker/dist/dato/dato.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
var Dato = function() {
    function Dato(faker) {
        this.faker = faker;
    }
    Dato.prototype.mellom = function(fra, til) {
        var fraMilli = Date.parse(fra.toString());
        var dateOffset = this.faker.random.integer(Date.parse(til.toString()) - fraMilli);
        return new Date(fraMilli + dateOffset);
    };
    Dato.prototype.forÅrSiden = function(årSiden) {
        var start = new Date();
        start.setFullYear(start.getFullYear() - årSiden, 0, 1);
        var end = new Date();
        end.setFullYear(end.getFullYear() - årSiden, 11, 31);
        return this.mellom(start, end);
    };
    return Dato;
}();
exports.default = Dato;
}),
"[project]/node_modules/.pnpm/nav-faker@3.2.4/node_modules/nav-faker/dist/personidentifikator/helpers/config-helper.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getConfigOrDefault = void 0;
function getConfigOrDefault(navFaker, options, erDnummer) {
    var fødselsdato = options.fødselsdato;
    var kjønn = options.kjønn;
    if (!fødselsdato) {
        fødselsdato = navFaker.dato.mellom(new Date('1900-01-01'), new Date());
    }
    if (!kjønn) {
        kjønn = navFaker.person.kjønn();
    }
    return {
        erDnummer: erDnummer,
        fødselsdato: fødselsdato,
        kjønn: kjønn
    };
}
exports.getConfigOrDefault = getConfigOrDefault;
}),
"[project]/node_modules/.pnpm/nav-faker@3.2.4/node_modules/nav-faker/dist/utils/string-utils.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.replaceSymbolWithNumber = exports.padLeft = exports.padLeftNumber = void 0;
function padLeftNumber(tall, width) {
    return padLeft(tall.toString(), width, '0');
}
exports.padLeftNumber = padLeftNumber;
function padLeft(streng, width, symbol) {
    if (streng.length >= width) {
        return streng;
    }
    var leadingSymbol = symbol.length > 0 ? symbol.charAt(0) : ' ';
    return leadingSymbol.repeat(width - streng.length) + streng;
}
exports.padLeft = padLeft;
function replaceSymbolWithNumber(streng, navfaker) {
    return streng.split('').map(function(char) {
        return char === '#' ? String(navfaker.random.integer(9)) : char;
    }).join('');
}
exports.replaceSymbolWithNumber = replaceSymbolWithNumber;
}),
"[project]/node_modules/.pnpm/nav-faker@3.2.4/node_modules/nav-faker/dist/personidentifikator/helpers/fodselsnummer-utils.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.erGyldigFødselsnummer = exports.erDnummer = exports.beregnKontrollsiffer2 = exports.beregnKontrollsiffer1 = void 0;
function beregnKontrollsiffer1(fodselsnummer) {
    var kontrollSiffer1Multiplikatorer = [
        3,
        7,
        6,
        1,
        8,
        9,
        4,
        5,
        2
    ];
    return beregnKontrollsiffer(fodselsnummer, kontrollSiffer1Multiplikatorer);
}
exports.beregnKontrollsiffer1 = beregnKontrollsiffer1;
function beregnKontrollsiffer2(fodselsnummer) {
    var kontrollSiffer2Multiplikatorer = [
        5,
        4,
        3,
        2,
        7,
        6,
        5,
        4,
        3,
        2
    ];
    return beregnKontrollsiffer(fodselsnummer, kontrollSiffer2Multiplikatorer);
}
exports.beregnKontrollsiffer2 = beregnKontrollsiffer2;
function beregnKontrollsiffer(fodselsnummer, multiplikatorTabell) {
    var sum = 0;
    for(var i = 0; i < multiplikatorTabell.length; i++){
        sum += parseInt(fodselsnummer[i], 10) * multiplikatorTabell[i];
    }
    var rest = sum % 11;
    if (rest === 0) {
        return 0;
    }
    return 11 - rest;
}
function erDnummer(fødselsnummer) {
    var dag = Number(fødselsnummer.substring(0, 2));
    return dag > 40 && dag <= 71;
}
exports.erDnummer = erDnummer;
function erGyldigFødselsnummer(fødselsnummer) {
    if (fødselsnummer.length !== 11) {
        return false;
    }
    var k1 = Number(fødselsnummer.charAt(9));
    var k2 = Number(fødselsnummer.charAt(10));
    if (k1 !== beregnKontrollsiffer1(fødselsnummer)) {
        return false;
    }
    if (k2 !== beregnKontrollsiffer2(fødselsnummer)) {
        return false;
    }
    return true;
}
exports.erGyldigFødselsnummer = erGyldigFødselsnummer;
}),
"[project]/node_modules/.pnpm/nav-faker@3.2.4/node_modules/nav-faker/dist/personidentifikator/helpers/fodselsdato-beregner.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.fødselsnummerTilDato = void 0;
var string_utils_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/nav-faker@3.2.4/node_modules/nav-faker/dist/utils/string-utils.js [app-client] (ecmascript)");
var fodselsnummer_utils_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/nav-faker@3.2.4/node_modules/nav-faker/dist/personidentifikator/helpers/fodselsnummer-utils.js [app-client] (ecmascript)");
function fødselsnummerTilDato(fødselsnummer) {
    if (fødselsnummer.length !== 11) {
        throw Error('Ugyldig lengde på personIdentifikator: ' + fødselsnummer);
    }
    var dag = getDag(fødselsnummer);
    var fireSifretÅr = getFiresifretÅr(fødselsnummer);
    var måned = fødselsnummer.substring(2, 4);
    return new Date(fireSifretÅr + "-" + måned + "-" + dag);
}
exports.fødselsnummerTilDato = fødselsnummerTilDato;
function getDag(fødselsnummer) {
    var dag = Number(fødselsnummer.substring(0, 2));
    if (fodselsnummer_utils_1.erDnummer(fødselsnummer)) {
        dag = dag - 40;
    } else if (dag >= 72) {
        throw Error('Fødselsnummer er av ukjent format: ' + fødselsnummer);
    }
    return string_utils_1.padLeft(String(dag), 2, '0');
}
function getFiresifretÅr(fødselsnummer) {
    var year = Number(fødselsnummer.substring(4, 6));
    var individnummer = Number(fødselsnummer.substring(6, 9));
    if (individnummer < 500) {
        return year + 1900;
    } else if (individnummer < 750 && 54 < year) {
        return year + 1800;
    } else if (individnummer < 1000 && year < 40) {
        return year + 2000;
    } else if (900 < individnummer || individnummer > 1000 || 39 >= year) {
        throw new Error('Ugyldig personIdentifikator: ' + fødselsnummer);
    } else {
        return year + 1900;
    }
}
}),
"[project]/node_modules/.pnpm/nav-faker@3.2.4/node_modules/nav-faker/dist/personidentifikator/helpers/fodselsnummerBeregner.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
var string_utils_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/nav-faker@3.2.4/node_modules/nav-faker/dist/utils/string-utils.js [app-client] (ecmascript)");
var fodselsnummer_utils_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/nav-faker@3.2.4/node_modules/nav-faker/dist/personidentifikator/helpers/fodselsnummer-utils.js [app-client] (ecmascript)");
function erMellom(tall, min, max) {
    return tall >= min && tall <= max;
}
function getLøpenummerSomListe(start, end) {
    return Array(end - start + 1).fill(0).map(function(_, index) {
        return string_utils_1.padLeftNumber(start + index, 3);
    });
}
function datoSomStreng(dato) {
    var dd = dato.getDate();
    var mm = dato.getMonth() + 1;
    var yy = dato.getFullYear() % 100;
    return "" + (string_utils_1.padLeftNumber(dd, 2) + string_utils_1.padLeftNumber(mm, 2) + string_utils_1.padLeftNumber(yy, 2));
}
var FødselsnummerBeregner = function() {
    function FødselsnummerBeregner(faker, options) {
        this.faker = faker;
        this.options = options;
    }
    FødselsnummerBeregner.prototype.tilfeldigFødselsnummer = function() {
        var gyldigeIndividNummere = this.getGyldigeIndividnummere();
        var tilfeldigIndividNummer = gyldigeIndividNummere[this.faker.random.integer(gyldigeIndividNummere.length - 1)];
        var justertFødselsdato = this.justerFødselsdatoForDnummer();
        var k1 = fodselsnummer_utils_1.beregnKontrollsiffer1(justertFødselsdato + tilfeldigIndividNummer);
        var k2 = fodselsnummer_utils_1.beregnKontrollsiffer2(justertFødselsdato + tilfeldigIndividNummer + k1);
        return justertFødselsdato + tilfeldigIndividNummer + k1 + k2;
    };
    FødselsnummerBeregner.prototype.getGyldigeIndividnummere = function() {
        var _this = this;
        return this.getIndividsiffereForÅrstall().filter(function(individSiffer) {
            return _this.individsifferHarRiktigKjønn(individSiffer);
        }).filter(function(individSiffer) {
            return _this.gyldigeKontrollsiffere(individSiffer);
        });
    };
    FødselsnummerBeregner.prototype.getIndividsiffereForÅrstall = function() {
        var year = this.options.fødselsdato.getFullYear();
        if (erMellom(year, 1854, 1899)) {
            return getLøpenummerSomListe(500, 749);
        } else if (erMellom(year, 1900, 1999)) {
            return getLøpenummerSomListe(0, 500);
        } else if (erMellom(year, 2000, 2039)) {
            return getLøpenummerSomListe(500, 999);
        } else {
            throw new Error('Ugyldig dato');
        }
    };
    FødselsnummerBeregner.prototype.individsifferHarRiktigKjønn = function(individnummer) {
        var kjønnSiffer = Number(individnummer.charAt(2));
        return kjønnSiffer % 2 === this.options.kjønn;
    };
    FødselsnummerBeregner.prototype.gyldigeKontrollsiffere = function(individnummer) {
        var fødselsdato = this.justerFødselsdatoForDnummer();
        var fødselsnummer = fødselsdato + individnummer;
        var k1 = fodselsnummer_utils_1.beregnKontrollsiffer1(fødselsnummer);
        if (k1 === 10) {
            return false;
        }
        if (fodselsnummer_utils_1.beregnKontrollsiffer2(fødselsnummer + k1) === 10) {
            return false;
        }
        return true;
    };
    FødselsnummerBeregner.prototype.justerFødselsdatoForDnummer = function() {
        var fødselsdato = datoSomStreng(this.options.fødselsdato);
        if (!this.options.erDnummer) {
            return fødselsdato;
        }
        var førsteSiffer = Number(fødselsdato.charAt(0)) + 4;
        return String(førsteSiffer).concat(fødselsdato.substring(1));
    };
    return FødselsnummerBeregner;
}();
exports.default = FødselsnummerBeregner;
}),
"[project]/node_modules/.pnpm/nav-faker@3.2.4/node_modules/nav-faker/dist/personidentifikator/personIdentifikator.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __importDefault = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Kjønn = void 0;
var config_helper_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/nav-faker@3.2.4/node_modules/nav-faker/dist/personidentifikator/helpers/config-helper.js [app-client] (ecmascript)");
var fodselsdato_beregner_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/nav-faker@3.2.4/node_modules/nav-faker/dist/personidentifikator/helpers/fodselsdato-beregner.js [app-client] (ecmascript)");
var fodselsnummerBeregner_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/nav-faker@3.2.4/node_modules/nav-faker/dist/personidentifikator/helpers/fodselsnummerBeregner.js [app-client] (ecmascript)"));
var Kjønn;
(function(Kjønn) {
    Kjønn[Kjønn["KVINNE"] = 0] = "KVINNE";
    Kjønn[Kjønn["MANN"] = 1] = "MANN";
})(Kjønn = exports.Kjønn || (exports.Kjønn = {}));
var PersonIdentifikator = function() {
    function PersonIdentifikator(faker) {
        this.faker = faker;
    }
    PersonIdentifikator.prototype.fødselsnummer = function(fødselsdato, kjønn) {
        var parsedOptions = config_helper_1.getConfigOrDefault(this.faker, {
            fødselsdato: fødselsdato,
            kjønn: kjønn
        }, false);
        return new fodselsnummerBeregner_1.default(this.faker, parsedOptions).tilfeldigFødselsnummer();
    };
    PersonIdentifikator.prototype.dnummer = function(fødselsdato, kjønn) {
        var parsedOptions = config_helper_1.getConfigOrDefault(this.faker, {
            fødselsdato: fødselsdato,
            kjønn: kjønn
        }, true);
        return new fodselsnummerBeregner_1.default(this.faker, parsedOptions).tilfeldigFødselsnummer();
    };
    PersonIdentifikator.prototype.myndigFødselsnummer = function(kjønn) {
        var maxAlder = new Date();
        maxAlder.setFullYear(maxAlder.getFullYear() - 100, 0, 1);
        var minAlder = new Date();
        minAlder.setFullYear(minAlder.getFullYear() - 18, 0, 1);
        var fødselsdato = this.faker.dato.mellom(maxAlder, minAlder);
        return this.fødselsnummer(fødselsdato, kjønn);
    };
    PersonIdentifikator.prototype.getFødselsdato = function(fødselsnummer) {
        return fodselsdato_beregner_1.fødselsnummerTilDato(fødselsnummer);
    };
    return PersonIdentifikator;
}();
exports.default = PersonIdentifikator;
}),
"[project]/node_modules/.pnpm/nav-faker@3.2.4/node_modules/nav-faker/dist/navn/data/guttenavn.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
var navn = [
    'Markus',
    'Mathias',
    'Kristian',
    'Jonas',
    'Andreas',
    'Alexander',
    'Martin',
    'Sander',
    'Daniel',
    'Magnus',
    'Henrik',
    'Tobias',
    'Kristoffer',
    'Emil',
    'Adrian',
    'Sebastian',
    'Marius',
    'Elias',
    'Fredrik',
    'Thomas',
    'Sondre',
    'Benjamin',
    'Jakob',
    'Oliver',
    'Lucas',
    'Oskar',
    'Nikolai',
    'Filip',
    'Mats',
    'William',
    'Erik',
    'Simen',
    'Ole',
    'Eirik',
    'Isak',
    'Kasper',
    'Noah',
    'Lars',
    'Joakim',
    'Johannes',
    'Håkon',
    'Sindre',
    'Jørgen',
    'Herman',
    'Anders',
    'Jonathan',
    'Even',
    'Theodor',
    'Mikkel',
    'Aksel'
];
exports.default = navn;
}),
"[project]/node_modules/.pnpm/nav-faker@3.2.4/node_modules/nav-faker/dist/navn/data/jentenavn.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
var jentenavn = [
    'Emma',
    'Sara',
    'Thea',
    'Ida',
    'Julie',
    'Nora',
    'Emilie',
    'Ingrid',
    'Hanna',
    'Maria',
    'Sofie',
    'Anna',
    'Malin',
    'Amalie',
    'Vilde',
    'Frida',
    'Andrea',
    'Tuva',
    'Victoria',
    'Mia',
    'Karoline',
    'Mathilde',
    'Martine',
    'Linnea',
    'Marte',
    'Hedda',
    'Marie',
    'Helene',
    'Silje',
    'Leah',
    'Maja',
    'Elise',
    'Oda',
    'Kristine',
    'Aurora',
    'Kaja',
    'Camilla',
    'Mari',
    'Maren',
    'Mina',
    'Selma',
    'Jenny',
    'Celine',
    'Eline',
    'Sunniva',
    'Natalie',
    'Tiril',
    'Synne',
    'Sandra',
    'Madeleine'
];
exports.default = jentenavn;
}),
"[project]/node_modules/.pnpm/nav-faker@3.2.4/node_modules/nav-faker/dist/navn/navn.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __importDefault = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
var personIdentifikator_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/nav-faker@3.2.4/node_modules/nav-faker/dist/personidentifikator/personIdentifikator.js [app-client] (ecmascript)");
var guttenavn_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/nav-faker@3.2.4/node_modules/nav-faker/dist/navn/data/guttenavn.js [app-client] (ecmascript)"));
var jentenavn_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/nav-faker@3.2.4/node_modules/nav-faker/dist/navn/data/jentenavn.js [app-client] (ecmascript)"));
var Navn = function() {
    function Navn(faker) {
        this.navfaker = faker;
    }
    Navn.prototype.fornavn = function(kjønn) {
        return this.getFornavnForKjønn(kjønn !== undefined ? kjønn : this.navfaker.person.kjønn());
    };
    Navn.prototype.getFornavnForKjønn = function(kjønn) {
        if (kjønn === personIdentifikator_1.Kjønn.MANN) {
            return this.navfaker.random.arrayElement(guttenavn_1.default);
        } else {
            return this.navfaker.random.arrayElement(jentenavn_1.default);
        }
    };
    return Navn;
}();
exports.default = Navn;
}),
"[project]/node_modules/.pnpm/nav-faker@3.2.4/node_modules/nav-faker/dist/person/person.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
var personIdentifikator_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/nav-faker@3.2.4/node_modules/nav-faker/dist/personidentifikator/personIdentifikator.js [app-client] (ecmascript)");
var Person = function() {
    function Person(faker) {
        this.faker = faker;
    }
    Person.prototype.kjønn = function() {
        return this.faker.random.vektetSjanse(0.5) ? personIdentifikator_1.Kjønn.KVINNE : personIdentifikator_1.Kjønn.MANN;
    };
    Person.prototype.antallBarn = function(fødselsdato) {
        var alder = new Date(new Date().getTime() - fødselsdato.getTime()).getFullYear() - 1970;
        return this.kalkulerAntallBarn(alder);
    };
    Person.prototype.kalkulerAntallBarn = function(foreldresAlder) {
        if (foreldresAlder < 18) {
            return 0;
        }
        var maksAntallBarn = foreldresAlder - 18;
        if (this.faker.random.vektetSjanse(0.05)) {
            var max = Math.min(maksAntallBarn, 15);
            var min = 6;
            return this.faker.random.integer(max, min);
        } else if (this.faker.random.vektetSjanse(0.75)) {
            return this.faker.random.integer(Math.min(maksAntallBarn, 5));
        }
        return 0;
    };
    return Person;
}();
exports.default = Person;
}),
"[project]/node_modules/.pnpm/nav-faker@3.2.4/node_modules/nav-faker/dist/random/random.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
var seedrandom = __turbopack_context__.r("[project]/node_modules/.pnpm/seedrandom@2.4.4/node_modules/seedrandom/index.js [app-client] (ecmascript)");
var Random = function() {
    function Random(seed) {
        this.randomGenerator = seedrandom(seed);
    }
    Random.prototype.integer = function(max, min) {
        var parsedMin = 0;
        var parsedMax = Number.MAX_SAFE_INTEGER;
        if (min !== undefined) {
            parsedMin = min;
        }
        if (max !== undefined) {
            parsedMax = max;
        }
        return this.randomNumber(parsedMin, parsedMax);
    };
    Random.prototype.vektetSjanse = function(vekt) {
        return this.randomGenerator.double() <= vekt;
    };
    Random.prototype.arrayElement = function(elements) {
        return elements[this.integer(elements.length - 1)];
    };
    // The maximum is inclusive and the minimum is inclusive
    Random.prototype.randomNumber = function(min, max) {
        min = Math.ceil(min);
        max = Math.floor(max);
        return Math.floor(this.randomGenerator() * (max - min + 1)) + min;
    };
    return Random;
}();
exports.default = Random;
}),
"[project]/node_modules/.pnpm/nav-faker@3.2.4/node_modules/nav-faker/dist/telefon/telefon.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
var string_utils_1 = __turbopack_context__.r("[project]/node_modules/.pnpm/nav-faker@3.2.4/node_modules/nav-faker/dist/utils/string-utils.js [app-client] (ecmascript)");
var Telefon = function() {
    function Telefon(faker) {
        this.faker = faker;
    }
    Telefon.prototype.mobil = function() {
        var muligeFørsteSiffere = [
            '4',
            '9'
        ];
        var førsteSiffer = muligeFørsteSiffere[this.faker.random.integer(muligeFørsteSiffere.length - 1)];
        return string_utils_1.replaceSymbolWithNumber(førsteSiffer + "#######", this.faker);
    };
    Telefon.prototype.jobb = function() {
        var muligeFørsteSiffere = [
            '1',
            '2',
            '3',
            '5',
            '6',
            '7',
            '8'
        ];
        var førsteSiffer = muligeFørsteSiffere[this.faker.random.integer(muligeFørsteSiffere.length - 1)];
        return string_utils_1.replaceSymbolWithNumber(førsteSiffer + "#######", this.faker);
    };
    return Telefon;
}();
exports.default = Telefon;
}),
"[project]/node_modules/.pnpm/nav-faker@3.2.4/node_modules/nav-faker/dist/nav/nav.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
var Nav = function() {
    function Nav(faker) {
        this.faker = faker;
    }
    Nav.prototype.ytelse = function() {
        var ytelser = [
            'Foreldrepenger',
            'Dagpenger',
            'Arbeidsavklaringspenger',
            'Sykepenger',
            'Avtalefestet pensjon',
            'Alderspensjon',
            'Grunn-og hjelpestønad',
            'Barnetrygd',
            'Enslig forsørger'
        ];
        return this.faker.random.arrayElement(ytelser);
    };
    return Nav;
}();
exports.default = Nav;
}),
"[project]/node_modules/.pnpm/nav-faker@3.2.4/node_modules/nav-faker/dist/navfaker.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __importDefault = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
var dato_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/nav-faker@3.2.4/node_modules/nav-faker/dist/dato/dato.js [app-client] (ecmascript)"));
var navn_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/nav-faker@3.2.4/node_modules/nav-faker/dist/navn/navn.js [app-client] (ecmascript)"));
var person_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/nav-faker@3.2.4/node_modules/nav-faker/dist/person/person.js [app-client] (ecmascript)"));
var personIdentifikator_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/nav-faker@3.2.4/node_modules/nav-faker/dist/personidentifikator/personIdentifikator.js [app-client] (ecmascript)"));
var random_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/nav-faker@3.2.4/node_modules/nav-faker/dist/random/random.js [app-client] (ecmascript)"));
var telefon_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/nav-faker@3.2.4/node_modules/nav-faker/dist/telefon/telefon.js [app-client] (ecmascript)"));
var nav_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/nav-faker@3.2.4/node_modules/nav-faker/dist/nav/nav.js [app-client] (ecmascript)"));
var NavFaker = function() {
    function NavFaker() {
        this.personIdentifikator = new personIdentifikator_1.default(this);
        this.random = new random_1.default();
        this.dato = new dato_1.default(this);
        this.person = new person_1.default(this);
        this.telefon = new telefon_1.default(this);
        this.nav = new nav_1.default(this);
        this.navn = new navn_1.default(this);
    }
    NavFaker.prototype.seed = function(seed) {
        this.random = new random_1.default(seed);
    };
    return NavFaker;
}();
exports.default = NavFaker;
}),
"[project]/node_modules/.pnpm/nav-faker@3.2.4/node_modules/nav-faker/dist/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __importDefault = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
var navfaker_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/nav-faker@3.2.4/node_modules/nav-faker/dist/navfaker.js [app-client] (ecmascript)"));
var navfaker = new navfaker_1.default();
exports.default = navfaker;
}),
"[project]/node_modules/.pnpm/seedrandom@2.4.4/node_modules/seedrandom/lib/alea.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

// A port of an algorithm by Johannes Baagøe <baagoe@baagoe.com>, 2010
// http://baagoe.com/en/RandomMusings/javascript/
// https://github.com/nquinlan/better-random-numbers-for-javascript-mirror
// Original work is under MIT license -
// Copyright (C) 2010 by Johannes Baagøe <baagoe@baagoe.org>
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
(function(global, module1, define1) {
    function Alea(seed) {
        var me = this, mash = Mash();
        me.next = function() {
            var t = 2091639 * me.s0 + me.c * 2.3283064365386963e-10; // 2^-32
            me.s0 = me.s1;
            me.s1 = me.s2;
            return me.s2 = t - (me.c = t | 0);
        };
        // Apply the seeding algorithm from Baagoe.
        me.c = 1;
        me.s0 = mash(' ');
        me.s1 = mash(' ');
        me.s2 = mash(' ');
        me.s0 -= mash(seed);
        if (me.s0 < 0) {
            me.s0 += 1;
        }
        me.s1 -= mash(seed);
        if (me.s1 < 0) {
            me.s1 += 1;
        }
        me.s2 -= mash(seed);
        if (me.s2 < 0) {
            me.s2 += 1;
        }
        mash = null;
    }
    function copy(f, t) {
        t.c = f.c;
        t.s0 = f.s0;
        t.s1 = f.s1;
        t.s2 = f.s2;
        return t;
    }
    function impl(seed, opts) {
        var xg = new Alea(seed), state = opts && opts.state, prng = xg.next;
        prng.int32 = function() {
            return xg.next() * 0x100000000 | 0;
        };
        prng.double = function() {
            return prng() + (prng() * 0x200000 | 0) * 1.1102230246251565e-16; // 2^-53
        };
        prng.quick = prng;
        if (state) {
            if (typeof state == 'object') copy(state, xg);
            prng.state = function() {
                return copy(xg, {});
            };
        }
        return prng;
    }
    function Mash() {
        var n = 0xefc8249d;
        var mash = function(data) {
            data = data.toString();
            for(var i = 0; i < data.length; i++){
                n += data.charCodeAt(i);
                var h = 0.02519603282416938 * n;
                n = h >>> 0;
                h -= n;
                h *= n;
                n = h >>> 0;
                h -= n;
                n += h * 0x100000000; // 2^32
            }
            return (n >>> 0) * 2.3283064365386963e-10; // 2^-32
        };
        return mash;
    }
    if (module1 && module1.exports) {
        module1.exports = impl;
    } else if (define1 && define1.amd) {
        ((r)=>r !== undefined && __turbopack_context__.v(r))(function() {
            return impl;
        }(__turbopack_context__.r, exports, module));
    } else {
        this.alea = impl;
    }
})(/*TURBOPACK member replacement*/ __turbopack_context__.e, ("TURBOPACK compile-time value", "object") == 'object' && module, typeof define == 'function' && define // present with an AMD loader
);
}),
"[project]/node_modules/.pnpm/seedrandom@2.4.4/node_modules/seedrandom/lib/xor128.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

// A Javascript implementaion of the "xor128" prng algorithm by
// George Marsaglia.  See http://www.jstatsoft.org/v08/i14/paper
(function(global, module1, define1) {
    function XorGen(seed) {
        var me = this, strseed = '';
        me.x = 0;
        me.y = 0;
        me.z = 0;
        me.w = 0;
        // Set up generator function.
        me.next = function() {
            var t = me.x ^ me.x << 11;
            me.x = me.y;
            me.y = me.z;
            me.z = me.w;
            return me.w ^= me.w >>> 19 ^ t ^ t >>> 8;
        };
        if (seed === (seed | 0)) {
            // Integer seed.
            me.x = seed;
        } else {
            // String seed.
            strseed += seed;
        }
        // Mix in string seed, then discard an initial batch of 64 values.
        for(var k = 0; k < strseed.length + 64; k++){
            me.x ^= strseed.charCodeAt(k) | 0;
            me.next();
        }
    }
    function copy(f, t) {
        t.x = f.x;
        t.y = f.y;
        t.z = f.z;
        t.w = f.w;
        return t;
    }
    function impl(seed, opts) {
        var xg = new XorGen(seed), state = opts && opts.state, prng = function() {
            return (xg.next() >>> 0) / 0x100000000;
        };
        prng.double = function() {
            do {
                var top = xg.next() >>> 11, bot = (xg.next() >>> 0) / 0x100000000, result = (top + bot) / (1 << 21);
            }while (result === 0)
            return result;
        };
        prng.int32 = xg.next;
        prng.quick = prng;
        if (state) {
            if (typeof state == 'object') copy(state, xg);
            prng.state = function() {
                return copy(xg, {});
            };
        }
        return prng;
    }
    if (module1 && module1.exports) {
        module1.exports = impl;
    } else if (define1 && define1.amd) {
        ((r)=>r !== undefined && __turbopack_context__.v(r))(function() {
            return impl;
        }(__turbopack_context__.r, exports, module));
    } else {
        this.xor128 = impl;
    }
})(/*TURBOPACK member replacement*/ __turbopack_context__.e, ("TURBOPACK compile-time value", "object") == 'object' && module, typeof define == 'function' && define // present with an AMD loader
);
}),
"[project]/node_modules/.pnpm/seedrandom@2.4.4/node_modules/seedrandom/lib/xorwow.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

// A Javascript implementaion of the "xorwow" prng algorithm by
// George Marsaglia.  See http://www.jstatsoft.org/v08/i14/paper
(function(global, module1, define1) {
    function XorGen(seed) {
        var me = this, strseed = '';
        // Set up generator function.
        me.next = function() {
            var t = me.x ^ me.x >>> 2;
            me.x = me.y;
            me.y = me.z;
            me.z = me.w;
            me.w = me.v;
            return (me.d = me.d + 362437 | 0) + (me.v = me.v ^ me.v << 4 ^ (t ^ t << 1)) | 0;
        };
        me.x = 0;
        me.y = 0;
        me.z = 0;
        me.w = 0;
        me.v = 0;
        if (seed === (seed | 0)) {
            // Integer seed.
            me.x = seed;
        } else {
            // String seed.
            strseed += seed;
        }
        // Mix in string seed, then discard an initial batch of 64 values.
        for(var k = 0; k < strseed.length + 64; k++){
            me.x ^= strseed.charCodeAt(k) | 0;
            if (k == strseed.length) {
                me.d = me.x << 10 ^ me.x >>> 4;
            }
            me.next();
        }
    }
    function copy(f, t) {
        t.x = f.x;
        t.y = f.y;
        t.z = f.z;
        t.w = f.w;
        t.v = f.v;
        t.d = f.d;
        return t;
    }
    function impl(seed, opts) {
        var xg = new XorGen(seed), state = opts && opts.state, prng = function() {
            return (xg.next() >>> 0) / 0x100000000;
        };
        prng.double = function() {
            do {
                var top = xg.next() >>> 11, bot = (xg.next() >>> 0) / 0x100000000, result = (top + bot) / (1 << 21);
            }while (result === 0)
            return result;
        };
        prng.int32 = xg.next;
        prng.quick = prng;
        if (state) {
            if (typeof state == 'object') copy(state, xg);
            prng.state = function() {
                return copy(xg, {});
            };
        }
        return prng;
    }
    if (module1 && module1.exports) {
        module1.exports = impl;
    } else if (define1 && define1.amd) {
        ((r)=>r !== undefined && __turbopack_context__.v(r))(function() {
            return impl;
        }(__turbopack_context__.r, exports, module));
    } else {
        this.xorwow = impl;
    }
})(/*TURBOPACK member replacement*/ __turbopack_context__.e, ("TURBOPACK compile-time value", "object") == 'object' && module, typeof define == 'function' && define // present with an AMD loader
);
}),
"[project]/node_modules/.pnpm/seedrandom@2.4.4/node_modules/seedrandom/lib/xorshift7.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

// A Javascript implementaion of the "xorshift7" algorithm by
// François Panneton and Pierre L'ecuyer:
// "On the Xorgshift Random Number Generators"
// http://saluc.engr.uconn.edu/refs/crypto/rng/panneton05onthexorshift.pdf
(function(global, module1, define1) {
    function XorGen(seed) {
        var me = this;
        // Set up generator function.
        me.next = function() {
            // Update xor generator.
            var X = me.x, i = me.i, t, v, w;
            t = X[i];
            t ^= t >>> 7;
            v = t ^ t << 24;
            t = X[i + 1 & 7];
            v ^= t ^ t >>> 10;
            t = X[i + 3 & 7];
            v ^= t ^ t >>> 3;
            t = X[i + 4 & 7];
            v ^= t ^ t << 7;
            t = X[i + 7 & 7];
            t = t ^ t << 13;
            v ^= t ^ t << 9;
            X[i] = v;
            me.i = i + 1 & 7;
            return v;
        };
        function init(me, seed) {
            var j, w, X = [];
            if (seed === (seed | 0)) {
                // Seed state array using a 32-bit integer.
                w = X[0] = seed;
            } else {
                // Seed state using a string.
                seed = '' + seed;
                for(j = 0; j < seed.length; ++j){
                    X[j & 7] = X[j & 7] << 15 ^ seed.charCodeAt(j) + X[j + 1 & 7] << 13;
                }
            }
            // Enforce an array length of 8, not all zeroes.
            while(X.length < 8)X.push(0);
            for(j = 0; j < 8 && X[j] === 0; ++j);
            if (j == 8) w = X[7] = -1;
            else w = X[j];
            me.x = X;
            me.i = 0;
            // Discard an initial 256 values.
            for(j = 256; j > 0; --j){
                me.next();
            }
        }
        init(me, seed);
    }
    function copy(f, t) {
        t.x = f.x.slice();
        t.i = f.i;
        return t;
    }
    function impl(seed, opts) {
        if (seed == null) seed = +new Date;
        var xg = new XorGen(seed), state = opts && opts.state, prng = function() {
            return (xg.next() >>> 0) / 0x100000000;
        };
        prng.double = function() {
            do {
                var top = xg.next() >>> 11, bot = (xg.next() >>> 0) / 0x100000000, result = (top + bot) / (1 << 21);
            }while (result === 0)
            return result;
        };
        prng.int32 = xg.next;
        prng.quick = prng;
        if (state) {
            if (state.x) copy(state, xg);
            prng.state = function() {
                return copy(xg, {});
            };
        }
        return prng;
    }
    if (module1 && module1.exports) {
        module1.exports = impl;
    } else if (define1 && define1.amd) {
        ((r)=>r !== undefined && __turbopack_context__.v(r))(function() {
            return impl;
        }(__turbopack_context__.r, exports, module));
    } else {
        this.xorshift7 = impl;
    }
})(/*TURBOPACK member replacement*/ __turbopack_context__.e, ("TURBOPACK compile-time value", "object") == 'object' && module, typeof define == 'function' && define // present with an AMD loader
);
}),
"[project]/node_modules/.pnpm/seedrandom@2.4.4/node_modules/seedrandom/lib/xor4096.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

// A Javascript implementaion of Richard Brent's Xorgens xor4096 algorithm.
//
// This fast non-cryptographic random number generator is designed for
// use in Monte-Carlo algorithms. It combines a long-period xorshift
// generator with a Weyl generator, and it passes all common batteries
// of stasticial tests for randomness while consuming only a few nanoseconds
// for each prng generated.  For background on the generator, see Brent's
// paper: "Some long-period random number generators using shifts and xors."
// http://arxiv.org/pdf/1004.3115v1.pdf
//
// Usage:
//
// var xor4096 = require('xor4096');
// random = xor4096(1);                        // Seed with int32 or string.
// assert.equal(random(), 0.1520436450538547); // (0, 1) range, 53 bits.
// assert.equal(random.int32(), 1806534897);   // signed int32, 32 bits.
//
// For nonzero numeric keys, this impelementation provides a sequence
// identical to that by Brent's xorgens 3 implementaion in C.  This
// implementation also provides for initalizing the generator with
// string seeds, or for saving and restoring the state of the generator.
//
// On Chrome, this prng benchmarks about 2.1 times slower than
// Javascript's built-in Math.random().
(function(global, module1, define1) {
    function XorGen(seed) {
        var me = this;
        // Set up generator function.
        me.next = function() {
            var w = me.w, X = me.X, i = me.i, t, v;
            // Update Weyl generator.
            me.w = w = w + 0x61c88647 | 0;
            // Update xor generator.
            v = X[i + 34 & 127];
            t = X[i = i + 1 & 127];
            v ^= v << 13;
            t ^= t << 17;
            v ^= v >>> 15;
            t ^= t >>> 12;
            // Update Xor generator array state.
            v = X[i] = v ^ t;
            me.i = i;
            // Result is the combination.
            return v + (w ^ w >>> 16) | 0;
        };
        function init(me, seed) {
            var t, v, i, j, w, X = [], limit = 128;
            if (seed === (seed | 0)) {
                // Numeric seeds initialize v, which is used to generates X.
                v = seed;
                seed = null;
            } else {
                // String seeds are mixed into v and X one character at a time.
                seed = seed + '\0';
                v = 0;
                limit = Math.max(limit, seed.length);
            }
            // Initialize circular array and weyl value.
            for(i = 0, j = -32; j < limit; ++j){
                // Put the unicode characters into the array, and shuffle them.
                if (seed) v ^= seed.charCodeAt((j + 32) % seed.length);
                // After 32 shuffles, take v as the starting w value.
                if (j === 0) w = v;
                v ^= v << 10;
                v ^= v >>> 15;
                v ^= v << 4;
                v ^= v >>> 13;
                if (j >= 0) {
                    w = w + 0x61c88647 | 0; // Weyl.
                    t = X[j & 127] ^= v + w; // Combine xor and weyl to init array.
                    i = 0 == t ? i + 1 : 0; // Count zeroes.
                }
            }
            // We have detected all zeroes; make the key nonzero.
            if (i >= 128) {
                X[(seed && seed.length || 0) & 127] = -1;
            }
            // Run the generator 512 times to further mix the state before using it.
            // Factoring this as a function slows the main generator, so it is just
            // unrolled here.  The weyl generator is not advanced while warming up.
            i = 127;
            for(j = 4 * 128; j > 0; --j){
                v = X[i + 34 & 127];
                t = X[i = i + 1 & 127];
                v ^= v << 13;
                t ^= t << 17;
                v ^= v >>> 15;
                t ^= t >>> 12;
                X[i] = v ^ t;
            }
            // Storing state as object members is faster than using closure variables.
            me.w = w;
            me.X = X;
            me.i = i;
        }
        init(me, seed);
    }
    function copy(f, t) {
        t.i = f.i;
        t.w = f.w;
        t.X = f.X.slice();
        return t;
    }
    ;
    function impl(seed, opts) {
        if (seed == null) seed = +new Date;
        var xg = new XorGen(seed), state = opts && opts.state, prng = function() {
            return (xg.next() >>> 0) / 0x100000000;
        };
        prng.double = function() {
            do {
                var top = xg.next() >>> 11, bot = (xg.next() >>> 0) / 0x100000000, result = (top + bot) / (1 << 21);
            }while (result === 0)
            return result;
        };
        prng.int32 = xg.next;
        prng.quick = prng;
        if (state) {
            if (state.X) copy(state, xg);
            prng.state = function() {
                return copy(xg, {});
            };
        }
        return prng;
    }
    if (module1 && module1.exports) {
        module1.exports = impl;
    } else if (define1 && define1.amd) {
        ((r)=>r !== undefined && __turbopack_context__.v(r))(function() {
            return impl;
        }(__turbopack_context__.r, exports, module));
    } else {
        this.xor4096 = impl;
    }
})(/*TURBOPACK member replacement*/ __turbopack_context__.e, ("TURBOPACK compile-time value", "object") == 'object' && module, typeof define == 'function' && define // present with an AMD loader
);
}),
"[project]/node_modules/.pnpm/seedrandom@2.4.4/node_modules/seedrandom/lib/tychei.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

// A Javascript implementaion of the "Tyche-i" prng algorithm by
// Samuel Neves and Filipe Araujo.
// See https://eden.dei.uc.pt/~sneves/pubs/2011-snfa2.pdf
(function(global, module1, define1) {
    function XorGen(seed) {
        var me = this, strseed = '';
        // Set up generator function.
        me.next = function() {
            var b = me.b, c = me.c, d = me.d, a = me.a;
            b = b << 25 ^ b >>> 7 ^ c;
            c = c - d | 0;
            d = d << 24 ^ d >>> 8 ^ a;
            a = a - b | 0;
            me.b = b = b << 20 ^ b >>> 12 ^ c;
            me.c = c = c - d | 0;
            me.d = d << 16 ^ c >>> 16 ^ a;
            return me.a = a - b | 0;
        };
        /* The following is non-inverted tyche, which has better internal
   * bit diffusion, but which is about 25% slower than tyche-i in JS.
  me.next = function() {
    var a = me.a, b = me.b, c = me.c, d = me.d;
    a = (me.a + me.b | 0) >>> 0;
    d = me.d ^ a; d = d << 16 ^ d >>> 16;
    c = me.c + d | 0;
    b = me.b ^ c; b = b << 12 ^ d >>> 20;
    me.a = a = a + b | 0;
    d = d ^ a; me.d = d = d << 8 ^ d >>> 24;
    me.c = c = c + d | 0;
    b = b ^ c;
    return me.b = (b << 7 ^ b >>> 25);
  }
  */ me.a = 0;
        me.b = 0;
        me.c = 2654435769 | 0;
        me.d = 1367130551;
        if (seed === Math.floor(seed)) {
            // Integer seed.
            me.a = seed / 0x100000000 | 0;
            me.b = seed | 0;
        } else {
            // String seed.
            strseed += seed;
        }
        // Mix in string seed, then discard an initial batch of 64 values.
        for(var k = 0; k < strseed.length + 20; k++){
            me.b ^= strseed.charCodeAt(k) | 0;
            me.next();
        }
    }
    function copy(f, t) {
        t.a = f.a;
        t.b = f.b;
        t.c = f.c;
        t.d = f.d;
        return t;
    }
    ;
    function impl(seed, opts) {
        var xg = new XorGen(seed), state = opts && opts.state, prng = function() {
            return (xg.next() >>> 0) / 0x100000000;
        };
        prng.double = function() {
            do {
                var top = xg.next() >>> 11, bot = (xg.next() >>> 0) / 0x100000000, result = (top + bot) / (1 << 21);
            }while (result === 0)
            return result;
        };
        prng.int32 = xg.next;
        prng.quick = prng;
        if (state) {
            if (typeof state == 'object') copy(state, xg);
            prng.state = function() {
                return copy(xg, {});
            };
        }
        return prng;
    }
    if (module1 && module1.exports) {
        module1.exports = impl;
    } else if (define1 && define1.amd) {
        ((r)=>r !== undefined && __turbopack_context__.v(r))(function() {
            return impl;
        }(__turbopack_context__.r, exports, module));
    } else {
        this.tychei = impl;
    }
})(/*TURBOPACK member replacement*/ __turbopack_context__.e, ("TURBOPACK compile-time value", "object") == 'object' && module, typeof define == 'function' && define // present with an AMD loader
);
}),
"[project]/node_modules/.pnpm/seedrandom@2.4.4/node_modules/seedrandom/seedrandom.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/*
Copyright 2014 David Bau.

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

*/ (function(pool, math) {
    //
    // The following constants are related to IEEE 754 limits.
    //
    // Detect the global object, even if operating in strict mode.
    // http://stackoverflow.com/a/14387057/265298
    var global = (0, eval)('this'), width = 256, chunks = 6, digits = 52, rngname = 'random', startdenom = math.pow(width, chunks), significance = math.pow(2, digits), overflow = significance * 2, mask = width - 1, nodecrypto; // node.js crypto module, initialized at the bottom.
    //
    // seedrandom()
    // This is the seedrandom function described above.
    //
    function seedrandom(seed, options, callback) {
        var key = [];
        options = options == true ? {
            entropy: true
        } : options || {};
        // Flatten the seed string or build one from local entropy if needed.
        var shortseed = mixkey(flatten(options.entropy ? [
            seed,
            tostring(pool)
        ] : seed == null ? autoseed() : seed, 3), key);
        // Use the seed to initialize an ARC4 generator.
        var arc4 = new ARC4(key);
        // This function returns a random double in [0, 1) that contains
        // randomness in every bit of the mantissa of the IEEE 754 value.
        var prng = function() {
            var n = arc4.g(chunks), d = startdenom, x = 0; //   and no 'extra last byte'.
            while(n < significance){
                n = (n + x) * width; //   shifting numerator and
                d *= width; //   denominator and generating a
                x = arc4.g(1); //   new least-significant-byte.
            }
            while(n >= overflow){
                n /= 2; //   last byte, shift everything
                d /= 2; //   right using integer math until
                x >>>= 1; //   we have exactly the desired bits.
            }
            return (n + x) / d; // Form the number within [0, 1).
        };
        prng.int32 = function() {
            return arc4.g(4) | 0;
        };
        prng.quick = function() {
            return arc4.g(4) / 0x100000000;
        };
        prng.double = prng;
        // Mix the randomness into accumulated entropy.
        mixkey(tostring(arc4.S), pool);
        // Calling convention: what to return as a function of prng, seed, is_math.
        return (options.pass || callback || function(prng, seed, is_math_call, state) {
            if (state) {
                // Load the arc4 state from the given state if it has an S array.
                if (state.S) {
                    copy(state, arc4);
                }
                // Only provide the .state method if requested via options.state.
                prng.state = function() {
                    return copy(arc4, {});
                };
            }
            // If called as a method of Math (Math.seedrandom()), mutate
            // Math.random because that is how seedrandom.js has worked since v1.0.
            if (is_math_call) {
                math[rngname] = prng;
                return seed;
            } else return prng;
        })(prng, shortseed, 'global' in options ? options.global : this == math, options.state);
    }
    math['seed' + rngname] = seedrandom;
    //
    // ARC4
    //
    // An ARC4 implementation.  The constructor takes a key in the form of
    // an array of at most (width) integers that should be 0 <= x < (width).
    //
    // The g(count) method returns a pseudorandom integer that concatenates
    // the next (count) outputs from ARC4.  Its return value is a number x
    // that is in the range 0 <= x < (width ^ count).
    //
    function ARC4(key) {
        var t, keylen = key.length, me = this, i = 0, j = me.i = me.j = 0, s = me.S = [];
        // The empty key [] is treated as [0].
        if (!keylen) {
            key = [
                keylen++
            ];
        }
        // Set up S using the standard key scheduling algorithm.
        while(i < width){
            s[i] = i++;
        }
        for(i = 0; i < width; i++){
            s[i] = s[j = mask & j + key[i % keylen] + (t = s[i])];
            s[j] = t;
        }
        // The "g" method returns the next (count) outputs as one number.
        (me.g = function(count) {
            // Using instance members instead of closure state nearly doubles speed.
            var t, r = 0, i = me.i, j = me.j, s = me.S;
            while(count--){
                t = s[i = mask & i + 1];
                r = r * width + s[mask & (s[i] = s[j = mask & j + t]) + (s[j] = t)];
            }
            me.i = i;
            me.j = j;
            return r;
        // For robust unpredictability, the function call below automatically
        // discards an initial batch of values.  This is called RC4-drop[256].
        // See http://google.com/search?q=rsa+fluhrer+response&btnI
        })(width);
    }
    //
    // copy()
    // Copies internal state of ARC4 to or from a plain object.
    //
    function copy(f, t) {
        t.i = f.i;
        t.j = f.j;
        t.S = f.S.slice();
        return t;
    }
    ;
    //
    // flatten()
    // Converts an object tree to nested arrays of strings.
    //
    function flatten(obj, depth) {
        var result = [], typ = typeof obj, prop;
        if (depth && typ == 'object') {
            for(prop in obj){
                try {
                    result.push(flatten(obj[prop], depth - 1));
                } catch (e) {}
            }
        }
        return result.length ? result : typ == 'string' ? obj : obj + '\0';
    }
    //
    // mixkey()
    // Mixes a string seed into a key that is an array of integers, and
    // returns a shortened string seed that is equivalent to the result key.
    //
    function mixkey(seed, key) {
        var stringseed = seed + '', smear, j = 0;
        while(j < stringseed.length){
            key[mask & j] = mask & (smear ^= key[mask & j] * 19) + stringseed.charCodeAt(j++);
        }
        return tostring(key);
    }
    //
    // autoseed()
    // Returns an object for autoseeding, using window.crypto and Node crypto
    // module if available.
    //
    function autoseed() {
        try {
            var out;
            if (nodecrypto && (out = nodecrypto.randomBytes)) {
                // The use of 'out' to remember randomBytes makes tight minified code.
                out = out(width);
            } else {
                out = new Uint8Array(width);
                (global.crypto || global.msCrypto).getRandomValues(out);
            }
            return tostring(out);
        } catch (e) {
            var browser = global.navigator, plugins = browser && browser.plugins;
            return [
                +new Date,
                global,
                plugins,
                global.screen,
                tostring(pool)
            ];
        }
    }
    //
    // tostring()
    // Converts an array of charcodes to a string
    //
    function tostring(a) {
        return String.fromCharCode.apply(0, a);
    }
    //
    // When seedrandom.js is loaded, we immediately mix a few bits
    // from the built-in RNG into the entropy pool.  Because we do
    // not want to interfere with deterministic PRNG state later,
    // seedrandom will not call math.random on its own again after
    // initialization.
    //
    mixkey(math.random(), pool);
    //
    // Nodejs and AMD support: export the implementation as a module using
    // either convention.
    //
    if (("TURBOPACK compile-time value", "object") == 'object' && module.exports) {
        module.exports = seedrandom;
        // When in node.js, try using crypto package for autoseeding.
        try {
            nodecrypto = {};
        } catch (ex) {}
    } else if (typeof define == 'function' && define.amd) {
        ((r)=>r !== undefined && __turbopack_context__.v(r))(function() {
            return seedrandom;
        }(__turbopack_context__.r, exports, module));
    }
// End anonymous scope, and pass initial values.
})([], Math // math: package containing random, pow, and seedrandom
);
}),
"[project]/node_modules/.pnpm/seedrandom@2.4.4/node_modules/seedrandom/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

// A library of seedable RNGs implemented in Javascript.
//
// Usage:
//
// var seedrandom = require('seedrandom');
// var random = seedrandom(1); // or any seed.
// var x = random();       // 0 <= x < 1.  Every bit is random.
// var x = random.quick(); // 0 <= x < 1.  32 bits of randomness.
// alea, a 53-bit multiply-with-carry generator by Johannes Baagøe.
// Period: ~2^116
// Reported to pass all BigCrush tests.
var alea = __turbopack_context__.r("[project]/node_modules/.pnpm/seedrandom@2.4.4/node_modules/seedrandom/lib/alea.js [app-client] (ecmascript)");
// xor128, a pure xor-shift generator by George Marsaglia.
// Period: 2^128-1.
// Reported to fail: MatrixRank and LinearComp.
var xor128 = __turbopack_context__.r("[project]/node_modules/.pnpm/seedrandom@2.4.4/node_modules/seedrandom/lib/xor128.js [app-client] (ecmascript)");
// xorwow, George Marsaglia's 160-bit xor-shift combined plus weyl.
// Period: 2^192-2^32
// Reported to fail: CollisionOver, SimpPoker, and LinearComp.
var xorwow = __turbopack_context__.r("[project]/node_modules/.pnpm/seedrandom@2.4.4/node_modules/seedrandom/lib/xorwow.js [app-client] (ecmascript)");
// xorshift7, by François Panneton and Pierre L'ecuyer, takes
// a different approach: it adds robustness by allowing more shifts
// than Marsaglia's original three.  It is a 7-shift generator
// with 256 bits, that passes BigCrush with no systmatic failures.
// Period 2^256-1.
// No systematic BigCrush failures reported.
var xorshift7 = __turbopack_context__.r("[project]/node_modules/.pnpm/seedrandom@2.4.4/node_modules/seedrandom/lib/xorshift7.js [app-client] (ecmascript)");
// xor4096, by Richard Brent, is a 4096-bit xor-shift with a
// very long period that also adds a Weyl generator. It also passes
// BigCrush with no systematic failures.  Its long period may
// be useful if you have many generators and need to avoid
// collisions.
// Period: 2^4128-2^32.
// No systematic BigCrush failures reported.
var xor4096 = __turbopack_context__.r("[project]/node_modules/.pnpm/seedrandom@2.4.4/node_modules/seedrandom/lib/xor4096.js [app-client] (ecmascript)");
// Tyche-i, by Samuel Neves and Filipe Araujo, is a bit-shifting random
// number generator derived from ChaCha, a modern stream cipher.
// https://eden.dei.uc.pt/~sneves/pubs/2011-snfa2.pdf
// Period: ~2^127
// No systematic BigCrush failures reported.
var tychei = __turbopack_context__.r("[project]/node_modules/.pnpm/seedrandom@2.4.4/node_modules/seedrandom/lib/tychei.js [app-client] (ecmascript)");
// The original ARC4-based prng included in this library.
// Period: ~2^1600
var sr = __turbopack_context__.r("[project]/node_modules/.pnpm/seedrandom@2.4.4/node_modules/seedrandom/seedrandom.js [app-client] (ecmascript)");
sr.alea = alea;
sr.xor128 = xor128;
sr.xorwow = xorwow;
sr.xorshift7 = xorshift7;
sr.xor4096 = xor4096;
sr.tychei = tychei;
module.exports = sr;
}),
]);

//# sourceMappingURL=node_modules__pnpm_847d9ace._.js.map