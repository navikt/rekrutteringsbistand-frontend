(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/app/stilling/[stillingsId]/StillingsContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "StillingsContextMedData",
    ()=>StillingsContextMedData,
    "StillingsContextProvider",
    ()=>StillingsContextProvider,
    "useNullableStillingsContext",
    ()=>useNullableStillingsContext,
    "useStillingsContext",
    ()=>useStillingsContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2f$useKandidatlisteInfo$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/kandidat/useKandidatlisteInfo.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stilling$2f$rekrutteringsbistandstilling$2f5b$slug$5d2f$useStilling$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/stilling/rekrutteringsbistandstilling/[slug]/useStilling.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_util$2f$stillingInfoUtil$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/_util/stillingInfoUtil.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$SWRLaster$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/SWRLaster.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$feil$2d$lenke$2f$FeilLenkeMelding$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/feil-lenke/FeilLenkeMelding.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$tilgangskontroll$2f$erEier$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/tilgangskontroll/erEier.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$tilgangskontroll$2f$roller$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/tilgangskontroll/roller.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$ApplikasjonContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/providers/ApplikasjonContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$rekbisError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/util/rekbisError.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature(), _s3 = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
const StillingsContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
const StillingsContextProvider = ({ stillingsId, children })=>{
    _s();
    const stillingHook = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stilling$2f$rekrutteringsbistandstilling$2f5b$slug$5d2f$useStilling$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStilling"])(stillingsId);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$SWRLaster$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        hooks: [
            stillingHook
        ],
        egenFeilmelding: ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "m-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$feil$2d$lenke$2f$FeilLenkeMelding$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/app/stilling/[stillingsId]/StillingsContext.tsx",
                    lineNumber: 59,
                    columnNumber: 11
                }, void 0)
            }, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/StillingsContext.tsx",
                lineNumber: 58,
                columnNumber: 9
            }, void 0),
        children: (stillingsData)=>{
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(StillingsContextMedData, {
                stillingsData: stillingsData,
                refetch: stillingHook.mutate,
                children: children
            }, stillingsData?.stilling?.updated, false, {
                fileName: "[project]/app/stilling/[stillingsId]/StillingsContext.tsx",
                lineNumber: 65,
                columnNumber: 11
            }, ("TURBOPACK compile-time value", void 0));
        }
    }, void 0, false, {
        fileName: "[project]/app/stilling/[stillingsId]/StillingsContext.tsx",
        lineNumber: 55,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(StillingsContextProvider, "ddDvtlfyS1khI3UJUUR3d3fR/MI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stilling$2f$rekrutteringsbistandstilling$2f5b$slug$5d2f$useStilling$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStilling"]
    ];
});
_c = StillingsContextProvider;
const StillingsContextMedData = ({ stillingsData, children, refetch })=>{
    _s1();
    const { brukerData: { ident }, harRolle } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$ApplikasjonContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useApplikasjonContext"])();
    const kandidatListeInfoHook = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2f$useKandidatlisteInfo$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useKandidatlisteInfo"])(stillingsData?.stilling?.publishedByAdmin ? stillingsData?.stillingsinfo?.stillingsid : null);
    const [forhåndsvisData, setForhåndsvisData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const erEier = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "StillingsContextMedData.useMemo[erEier]": ()=>harRolle([
                __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$tilgangskontroll$2f$roller$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Roller"].AD_GRUPPE_REKRUTTERINGSBISTAND_UTVIKLER
            ]) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$tilgangskontroll$2f$erEier$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["eierStilling"])({
                stillingsData: stillingsData,
                navIdent: ident
            })
    }["StillingsContextMedData.useMemo[erEier]"], [
        stillingsData,
        ident,
        harRolle
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(StillingsContext.Provider, {
        value: {
            omStilling: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_util$2f$stillingInfoUtil$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["visStillingsDataInfo"])(stillingsData),
            stillingsData: forhåndsvisData ? forhåndsvisData : stillingsData,
            erEier,
            stillingsId: stillingsData?.stilling?.uuid,
            forhåndsvisData,
            setForhåndsvisData,
            refetch,
            kandidatlisteInfo: kandidatListeInfoHook?.data ?? null,
            kandidatlisteLaster: kandidatListeInfoHook?.isLoading ?? false,
            refetchKandidatliste: kandidatListeInfoHook?.mutate
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/app/stilling/[stillingsId]/StillingsContext.tsx",
        lineNumber: 113,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s1(StillingsContextMedData, "HzdxvUBQIU3DyIFijO/2b+HcLJA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$ApplikasjonContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useApplikasjonContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2f$useKandidatlisteInfo$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useKandidatlisteInfo"]
    ];
});
_c1 = StillingsContextMedData;
const useNullableStillingsContext = ()=>{
    _s2();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(StillingsContext);
    if (context === undefined) {
        return null;
    }
    return context;
};
_s2(useNullableStillingsContext, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
const useStillingsContext = ()=>{
    _s3();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(StillingsContext);
    if (context === undefined) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$rekbisError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RekbisError"]({
            message: 'useStillingsContext må være i scope: StillingsContextProvider'
        });
    }
    return context;
};
_s3(useStillingsContext, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c, _c1;
__turbopack_context__.k.register(_c, "StillingsContextProvider");
__turbopack_context__.k.register(_c1, "StillingsContextMedData");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/[stillingsId]/StillingVisning.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>StillingVisning
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$kandidat$2f5b$kandidatNr$5d2f$LeggKandidatTilKandidatliste$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/kandidat/[kandidatNr]/LeggKandidatTilKandidatliste.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$StillingsContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/StillingsContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$_ui$2f$StillingsBanner$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/_ui/StillingsBanner.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$_ui$2f$om$2d$stillingen$2f$OmStillingen$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/_ui/om-stillingen/OmStillingen.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$_ui$2f$stilling$2d$handlinger$2f$StillingHandlinger$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/_ui/stilling-handlinger/StillingHandlinger.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$_ui$2f$tabs$2f$StillingTabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/_ui/tabs/StillingTabs.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$FiltrertKandidatListeVisning$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/FiltrertKandidatListeVisning.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatlisteWrapper$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/KandidatlisteWrapper.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_util$2f$stillingInfoUtil$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/_util/stillingInfoUtil.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$layout$2f$PanelHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/layout/PanelHeader.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$layout$2f$SideInnhold$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/layout/SideInnhold.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$layout$2f$SideLayout$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/layout/SideLayout.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$layout$2f$SidepanelTrigger$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/layout/SidepanelTrigger.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$tilgangskontroll$2f$TilgangskontrollForInnhold$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/tilgangskontroll/TilgangskontrollForInnhold.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$tilgangskontroll$2f$roller$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/tilgangskontroll/roller.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$SidebarRight$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__SidebarRightIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/SidebarRight.js [app-client] (ecmascript) <export default as SidebarRightIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/alert/Alert.js [app-client] (ecmascript) <export default as Alert>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$Heading$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Heading$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/Heading.js [app-client] (ecmascript) <export default as Heading>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$Tabs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tabs$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/tabs/Tabs.js [app-client] (ecmascript) <export default as Tabs>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/nuqs@2.8.6_next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_re_zj4u4m4nn2sly5cvn6ecp7cj4u/node_modules/nuqs/dist/index.js [app-client] (ecmascript) <locals>");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
var StillingFane = /*#__PURE__*/ function(StillingFane) {
    StillingFane["STILLING"] = "stilling";
    StillingFane["KANDIDATER"] = "kandidater";
    return StillingFane;
}(StillingFane || {});
function StillingVisning({ kandidatId }) {
    _s();
    const [fane, setFane] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useQueryState"])('stillingFane', {
        defaultValue: "stilling",
        clearOnDefault: true
    });
    const { erEier, kandidatlisteInfo, stillingsData } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$StillingsContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStillingsContext"])();
    const info = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_util$2f$stillingInfoUtil$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["visStillingsDataInfo"])(stillingsData);
    const ugyldigStilling = !info.erUtkast && stillingsData?.stilling?.medium === 'DIR' && (stillingsData?.stilling?.employer?.orgnr ?? null) === null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-testid": "stilling-side",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$Tabs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tabs$3e$__["Tabs"], {
            defaultValue: fane,
            onChange: (val)=>setFane(val),
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$layout$2f$SideLayout$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                header: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$layout$2f$PanelHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    fullskjermUrl: info.erFormidling ? `/etterregistrering/${stillingsData.stilling.uuid}` : `/stilling/${stillingsData.stilling.uuid}`,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$layout$2f$PanelHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Section, {
                        tabs: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$_ui$2f$StillingsBanner$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/app/stilling/[stillingsId]/StillingVisning.tsx",
                                    lineNumber: 60,
                                    columnNumber: 21
                                }, void 0),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex",
                                    children: [
                                        kandidatId ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$_ui$2f$tabs$2f$StillingTabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                                    fileName: "[project]/app/stilling/[stillingsId]/StillingVisning.tsx",
                                                    lineNumber: 64,
                                                    columnNumber: 27
                                                }, void 0),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "mt-3 ml-auto shrink-0",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$kandidat$2f5b$kandidatNr$5d2f$LeggKandidatTilKandidatliste$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                        kandidatId: kandidatId,
                                                        stillingId: stillingsData.stilling.uuid
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/stilling/[stillingsId]/StillingVisning.tsx",
                                                        lineNumber: 66,
                                                        columnNumber: 29
                                                    }, void 0)
                                                }, void 0, false, {
                                                    fileName: "[project]/app/stilling/[stillingsId]/StillingVisning.tsx",
                                                    lineNumber: 65,
                                                    columnNumber: 27
                                                }, void 0)
                                            ]
                                        }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$_ui$2f$tabs$2f$StillingTabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                            fileName: "[project]/app/stilling/[stillingsId]/StillingVisning.tsx",
                                            lineNumber: 73,
                                            columnNumber: 25
                                        }, void 0),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$layout$2f$SidepanelTrigger$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SidepanelTrigger"], {
                                            className: "mt-2",
                                            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$SidebarRight$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__SidebarRightIcon$3e$__["SidebarRightIcon"], {}, void 0, false, {
                                                fileName: "[project]/app/stilling/[stillingsId]/StillingVisning.tsx",
                                                lineNumber: 77,
                                                columnNumber: 31
                                            }, void 0),
                                            children: "Vis sidepanel"
                                        }, void 0, false, {
                                            fileName: "[project]/app/stilling/[stillingsId]/StillingVisning.tsx",
                                            lineNumber: 75,
                                            columnNumber: 23
                                        }, void 0)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/stilling/[stillingsId]/StillingVisning.tsx",
                                    lineNumber: 61,
                                    columnNumber: 21
                                }, void 0)
                            ]
                        }, void 0, true),
                        actionsRight: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$_ui$2f$stilling$2d$handlinger$2f$StillingHandlinger$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/app/stilling/[stillingsId]/StillingVisning.tsx",
                            lineNumber: 84,
                            columnNumber: 31
                        }, void 0)
                    }, void 0, false, {
                        fileName: "[project]/app/stilling/[stillingsId]/StillingVisning.tsx",
                        lineNumber: 57,
                        columnNumber: 15
                    }, void 0)
                }, void 0, false, {
                    fileName: "[project]/app/stilling/[stillingsId]/StillingVisning.tsx",
                    lineNumber: 50,
                    columnNumber: 13
                }, void 0),
                children: [
                    ugyldigStilling && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__["Alert"], {
                        variant: "error",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$Heading$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Heading$3e$__["Heading"], {
                                spacing: true,
                                size: "small",
                                level: "3",
                                children: "Ugyldig stilling"
                            }, void 0, false, {
                                fileName: "[project]/app/stilling/[stillingsId]/StillingVisning.tsx",
                                lineNumber: 91,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                children: "Denne stillingen er ikke gyldig da det er en intern stilling som mangler organisasjonsnummer."
                            }, void 0, false, {
                                fileName: "[project]/app/stilling/[stillingsId]/StillingVisning.tsx",
                                lineNumber: 94,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                children: " Stillingen er derfor ikke tilgjengelig for rekruttering."
                            }, void 0, false, {
                                fileName: "[project]/app/stilling/[stillingsId]/StillingVisning.tsx",
                                lineNumber: 98,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/stilling/[stillingsId]/StillingVisning.tsx",
                        lineNumber: 90,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$Tabs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tabs$3e$__["Tabs"].Panel, {
                        value: "stilling",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$_ui$2f$om$2d$stillingen$2f$OmStillingen$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/app/stilling/[stillingsId]/StillingVisning.tsx",
                            lineNumber: 102,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/stilling/[stillingsId]/StillingVisning.tsx",
                        lineNumber: 101,
                        columnNumber: 11
                    }, this),
                    kandidatlisteInfo?.kandidatlisteId && erEier && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$tilgangskontroll$2f$TilgangskontrollForInnhold$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TilgangskontrollForInnhold"], {
                        kreverEnAvRollene: [
                            __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$tilgangskontroll$2f$roller$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Roller"].AD_GRUPPE_REKRUTTERINGSBISTAND_ARBEIDSGIVERRETTET
                        ],
                        skjulVarsel: true,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$layout$2f$SideInnhold$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            utenScroll: true,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$Tabs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tabs$3e$__["Tabs"].Panel, {
                                value: "kandidater",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatlisteWrapper$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$FiltrertKandidatListeVisning$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        kunVisning: kandidatId !== undefined
                                    }, void 0, false, {
                                        fileName: "[project]/app/stilling/[stillingsId]/StillingVisning.tsx",
                                        lineNumber: 114,
                                        columnNumber: 21
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/stilling/[stillingsId]/StillingVisning.tsx",
                                    lineNumber: 113,
                                    columnNumber: 19
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/stilling/[stillingsId]/StillingVisning.tsx",
                                lineNumber: 112,
                                columnNumber: 17
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/stilling/[stillingsId]/StillingVisning.tsx",
                            lineNumber: 111,
                            columnNumber: 15
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/stilling/[stillingsId]/StillingVisning.tsx",
                        lineNumber: 105,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/stilling/[stillingsId]/StillingVisning.tsx",
                lineNumber: 48,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/stilling/[stillingsId]/StillingVisning.tsx",
            lineNumber: 47,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/stilling/[stillingsId]/StillingVisning.tsx",
        lineNumber: 46,
        columnNumber: 5
    }, this);
}
_s(StillingVisning, "Q1rAzdTzbyCGePN36GDGmZa/3/o=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useQueryState"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$StillingsContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStillingsContext"]
    ];
});
_c = StillingVisning;
var _c;
__turbopack_context__.k.register(_c, "StillingVisning");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/[stillingsId]/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>FinnStillingPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$StillingVisning$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/StillingVisning.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatlisteKandidatView$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/KandidatlisteKandidatView.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$window$2f$WindowView$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/window/WindowView.tsx [app-client] (ecmascript)");
'use client';
;
;
;
;
function FinnStillingPage({ kandidatId }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$window$2f$WindowView$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        param: "visKandidatId",
        window: (kandidatNr)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatlisteKandidatView$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                kandidatId: kandidatNr
            }, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/page.tsx",
                lineNumber: 16,
                columnNumber: 9
            }, void 0),
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$StillingVisning$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            kandidatId: kandidatId
        }, void 0, false, {
            fileName: "[project]/app/stilling/[stillingsId]/page.tsx",
            lineNumber: 19,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/stilling/[stillingsId]/page.tsx",
        lineNumber: 13,
        columnNumber: 5
    }, this);
}
_c = FinnStillingPage;
var _c;
__turbopack_context__.k.register(_c, "FinnStillingPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=app_stilling_%5BstillingsId%5D_14882a6c._.js.map