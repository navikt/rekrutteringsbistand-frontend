(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/app/stilling/_util/stillingInfoUtil.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "VisningsStatus",
    ()=>VisningsStatus,
    "visStillingsDataInfo",
    ()=>visStillingsDataInfo
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$stilling$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/_ui/stilling-typer.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$startOfDay$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/startOfDay.js [app-client] (ecmascript)");
;
;
var VisningsStatus = /*#__PURE__*/ function(VisningsStatus) {
    VisningsStatus["IkkePublisert"] = "Ikke publisert";
    VisningsStatus["ApenForSokere"] = "Åpen for søkere";
    VisningsStatus["StengtForSokere"] = "Stengt for søkere";
    VisningsStatus["UtloptStengtForSokere"] = "Utløpt - Stengt for søkere";
    VisningsStatus["Fullfort"] = "Fullført";
    VisningsStatus["Slettet"] = "Slettet";
    VisningsStatus["Ukjent"] = "Ukjent status";
    return VisningsStatus;
}({});
const visStillingsDataInfo = (stillingsData)=>{
    const stilling = stillingsData.stilling;
    const stillingStatus = stilling.status;
    const published = stilling.published ?? null;
    const expires = stilling.expires ?? null;
    const publishedByAdmin = stilling.publishedByAdmin ?? null;
    const harStillingsinfo = stillingsData.stillingsinfo !== null;
    const adminStatus = stilling.administration?.status ?? null;
    const erUtkast = stillingsData?.stilling?.status === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$stilling$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StillingsStatus"].Inaktiv && stillingsData?.stilling?.publishedByAdmin === null && stillingsData?.stilling?.source === 'DIR';
    const erUtløpt = ()=>{
        if (expires === null) {
            return false;
        }
        const startenAvDøgnet = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$startOfDay$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["startOfDay"])(new Date());
        return new Date(expires) <= startenAvDøgnet;
    };
    let visningsStatus = "Ukjent status";
    if (stillingStatus === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$stilling$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StillingsStatus"].Slettet) {
        visningsStatus = "Slettet";
    } else if (stillingStatus === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$stilling$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StillingsStatus"].Stoppet && publishedByAdmin !== null && published !== null) {
        visningsStatus = "Fullført";
    } else if (stillingStatus === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$stilling$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StillingsStatus"].Inaktiv && publishedByAdmin !== null && erUtløpt()) {
        visningsStatus = "Utløpt - Stengt for søkere";
    } else if (stillingStatus === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$stilling$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StillingsStatus"].Inaktiv && (adminStatus === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$stilling$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AdminStatus"].Pending || adminStatus === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$stilling$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AdminStatus"].Done) && publishedByAdmin !== null) {
        visningsStatus = "Stengt for søkere";
    } else if (stillingStatus === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$stilling$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StillingsStatus"].Aktiv && publishedByAdmin !== null && published !== null && harStillingsinfo) {
        visningsStatus = "Åpen for søkere";
    } else if (stillingStatus === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$stilling$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StillingsStatus"].Inaktiv && publishedByAdmin === null) {
        visningsStatus = "Ikke publisert";
    }
    return {
        erJobbmesse: stillingsData?.stillingsinfo?.stillingskategori === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$stilling$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Stillingskategori"].Jobbmesse,
        erFormidling: stillingsData?.stillingsinfo?.stillingskategori === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$stilling$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Stillingskategori"].Formidling,
        erJobbMesse: stillingsData?.stillingsinfo?.stillingskategori === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$stilling$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Stillingskategori"].Jobbmesse,
        erPåArbeidsplassen: stillingsData?.stilling?.privacy === 'SHOW_ALL',
        erDirektemeldt: stillingsData?.stilling?.source === 'DIR',
        // Ny status
        visningsStatus,
        erUtkast
    };
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/_util/stillingssøk-typer.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "StillingsSøkPortefølje",
    ()=>StillingsSøkPortefølje,
    "StillingsSøkQueryparam",
    ()=>StillingsSøkQueryparam
]);
var StillingsSøkQueryparam = /*#__PURE__*/ function(StillingsSøkQueryparam) {
    // Filtre
    StillingsSøkQueryparam["Tekst"] = "fritekst";
    StillingsSøkQueryparam["Publisert"] = "publisert";
    StillingsSøkQueryparam["Side"] = "side";
    StillingsSøkQueryparam["Fylker"] = "fylker";
    StillingsSøkQueryparam["Kommuner"] = "kommuner";
    StillingsSøkQueryparam["Statuser"] = "statuser";
    StillingsSøkQueryparam["Stillingskategorier"] = "stillingskategori";
    StillingsSøkQueryparam["HovedInkluderingTags"] = "inkludering";
    StillingsSøkQueryparam["SubInkluderingTags"] = "inkluderingUnderkategori";
    StillingsSøkQueryparam["Felter"] = "felter";
    StillingsSøkQueryparam["Sortering"] = "sortering";
    StillingsSøkQueryparam["HarKandidatliste"] = "utenOppdrag";
    // Valgmuligheter
    StillingsSøkQueryparam["BrukStandardsøk"] = "brukStandardsok";
    StillingsSøkQueryparam["BrukKriterierFraKandidat"] = "brukKriterierFraKandidat";
    StillingsSøkQueryparam["Portefølje"] = "portefolje";
    StillingsSøkQueryparam["Modal"] = "modal";
    return StillingsSøkQueryparam;
}({});
var StillingsSøkPortefølje = /*#__PURE__*/ function(StillingsSøkPortefølje) {
    StillingsSøkPortefølje["INTERN"] = "intern";
    StillingsSøkPortefølje["VIS_MINE"] = "visMine";
    StillingsSøkPortefølje["MITT_KONTOR"] = "mittKontor";
    StillingsSøkPortefølje["ARBEIDSPLASSEN_NO"] = "arbeidsplassen";
    return StillingsSøkPortefølje;
}({});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/_util/stillingssøk-util.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "formaterEiernavn",
    ()=>formaterEiernavn,
    "hentArbeidssted",
    ()=>hentArbeidssted,
    "hentEierFraStilling",
    ()=>hentEierFraStilling,
    "hentIdentFraStilling",
    ()=>hentIdentFraStilling
]);
const formaterEiernavn = (eierNavn)=>{
    if (eierNavn == null) return null;
    const navnDel = eierNavn.split(',');
    return navnDel.length !== 2 ? eierNavn : navnDel[1].trim() + ' ' + navnDel[0].trim();
};
const hentEierFraStilling = (rekrutteringsbistandstilling)=>{
    const eierNavn = rekrutteringsbistandstilling.stillingsinfo?.eierNavn;
    const reportee = rekrutteringsbistandstilling.stilling.administration?.reportee;
    return eierNavn != null ? eierNavn : reportee != null ? reportee : null;
};
const hentIdentFraStilling = (rekrutteringsbistandstilling)=>{
    if (rekrutteringsbistandstilling && 'administration' in rekrutteringsbistandstilling && rekrutteringsbistandstilling?.administration?.navIdent) {
        return rekrutteringsbistandstilling?.administration?.navIdent;
    } else if (rekrutteringsbistandstilling && 'eierNavident' in rekrutteringsbistandstilling && rekrutteringsbistandstilling?.eierNavident) {
        return rekrutteringsbistandstilling?.eierNavident;
    } else if (rekrutteringsbistandstilling && 'stilling' in rekrutteringsbistandstilling && rekrutteringsbistandstilling?.stilling?.administration?.navIdent) {
        return rekrutteringsbistandstilling?.stilling?.administration?.navIdent;
    } else if (rekrutteringsbistandstilling && 'stillingsinfo' in rekrutteringsbistandstilling && rekrutteringsbistandstilling?.stillingsinfo?.eierNavident) {
        return rekrutteringsbistandstilling?.stillingsinfo?.eierNavident;
    }
    return '';
};
const hentArbeidssted = (locations)=>{
    const filtrerteLocations = [];
    locations.forEach((location)=>{
        if (location.municipal) {
            filtrerteLocations.push(location.municipal);
        } else if (location.county) {
            filtrerteLocations.push(location.county);
        }
    });
    return filtrerteLocations.join(', ');
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/_util/normaliserStillingProperties.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

//TODO Kan bytte ut opprett stilling sin logikk men sentralisert serialisering?
__turbopack_context__.s([
    "coerceArrayOrValueToString",
    ()=>coerceArrayOrValueToString,
    "normaliserPropertiesTilStrenger",
    ()=>normaliserPropertiesTilStrenger
]);
const coerceArrayOrValueToString = (value)=>{
    if (value === null || value === undefined) return undefined;
    if (Array.isArray(value)) return JSON.stringify(value);
    if (typeof value === 'string') return value;
    try {
        return JSON.stringify(value);
    } catch  {
        return String(value);
    }
};
const SPESIFIKKE_ARRAYNØKLER = new Set([
    'workhours',
    'workday',
    'tags',
    'searchtags'
]);
const normaliserPropertiesTilStrenger = (props)=>{
    if (!props) return props;
    const next = {};
    Object.entries(props).forEach(([key, value])=>{
        const coerced = coerceArrayOrValueToString(value);
        if (coerced !== undefined) next[key] = coerced;
    });
    // (valgfritt) sørg for at kjente “array-nøkler” faktisk er JSON-array-strenger
    SPESIFIKKE_ARRAYNØKLER.forEach((k)=>{
        if (next[k] && !next[k].trim().startsWith('[')) {
            // pakk enkel verdi inn i array
            next[k] = JSON.stringify([
                next[k]
            ]);
        }
    });
    return next;
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/_util/parsJsonArray.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "parseJsonArray",
    ()=>parseJsonArray
]);
const parseJsonArray = (value, separator = ', ')=>{
    if (!value) return '';
    const trimmed = value.trim();
    if (trimmed.startsWith('[') && trimmed.endsWith(']')) {
        try {
            const parsed = JSON.parse(trimmed);
            if (Array.isArray(parsed)) return parsed.filter(Boolean).join(separator);
        } catch  {
        /* ignore */ }
    }
    return value;
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/_util/stilling-util.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>capitalizeEmployerName,
    "kategoriTilVisningsnavn",
    ()=>kategoriTilVisningsnavn,
    "navnEierAvAstilling",
    ()=>navnEierAvAstilling
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$stilling$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/_ui/stilling-typer.ts [app-client] (ecmascript)");
;
const kategoriTilVisningsnavn = (kategori)=>{
    switch(kategori){
        case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$stilling$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Stillingskategori"].Stilling:
            return 'Stilling';
        case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$stilling$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Stillingskategori"].Formidling:
            return 'Formidling';
        case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$stilling$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Stillingskategori"].Arbeidstrening:
            return 'Arbeidstrening';
        case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$stilling$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Stillingskategori"].Jobbmesse:
            return 'Jobbmesse';
        default:
            return 'Stilling';
    }
};
function capitalizeEmployerName(text) {
    const separators = [
        ' ',
        '-',
        '(',
        '/'
    ];
    const ignore = [
        'i',
        'og',
        'for',
        'på',
        'avd',
        'av'
    ];
    const keep = [
        'as',
        'ab',
        'asa',
        'ba',
        'sa'
    ];
    if (text) {
        let capitalized = text.toLowerCase();
        for(let i = 0, len = separators.length; i < len; i += 1){
            const fragments = capitalized.split(separators[i]);
            for(let j = 0, x = fragments.length; j < x; j += 1){
                if (keep.includes(fragments[j])) {
                    fragments[j] = fragments[j].toUpperCase();
                } else if (!ignore.includes(fragments[j])) {
                    if (fragments[j][0] !== undefined) {
                        fragments[j] = fragments[j][0].toUpperCase() + fragments[j].substr(1);
                    }
                }
            }
            capitalized = fragments.join(separators[i]);
        }
        return capitalized;
    }
    return text;
}
const navnEierAvAstilling = (stillingsData)=>{
    if (stillingsData?.stilling?.administration?.navIdent !== null) {
        return stillingsData?.stilling?.administration?.reportee ?? null;
    }
    return stillingsData?.stillingsinfo?.eierNavn ?? null;
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/StillingsSøkContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "StillingsSøkProvider",
    ()=>StillingsSøkProvider,
    "useStillingsSøkFilter",
    ()=>useStillingsSøkFilter
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$StillingsS$f8$kFilter$2f$InkluderingFilter$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/_ui/StillingsSøkFilter/InkluderingFilter.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_util$2f$stillingInfoUtil$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/_util/stillingInfoUtil.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_util$2f$stillingss$f8$k$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/_util/stillingssøk-typer.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$tilgangskontroll$2f$roller$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/tilgangskontroll/roller.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$ApplikasjonContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/providers/ApplikasjonContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$rekbisError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/util/rekbisError.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/nuqs@2.8.6_next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_re_zj4u4m4nn2sly5cvn6ecp7cj4u/node_modules/nuqs/dist/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
const StillingsSøkContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
const StillingsSøkProvider = ({ children, formidlinger })=>{
    _s();
    const { harRolle } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$ApplikasjonContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useApplikasjonContext"])();
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const brukStandardSøk = searchParams.get('brukStandardsok') !== null;
    const harArbeidsgiverrettetRolle = harRolle([
        __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$tilgangskontroll$2f$roller$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Roller"].AD_GRUPPE_REKRUTTERINGSBISTAND_ARBEIDSGIVERRETTET
    ]);
    // Set fritekst som lokal state for å hindre fritekst i searchparam
    const [fritekst, setFritekstListeInternal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const setFritekst = (val)=>{
        // Unngå å legge til fritekst når brukStandardsok er aktivt
        if (brukStandardSøk) return;
        setFritekstListeInternal((prevFritekst)=>[
                ...prevFritekst,
                val
            ]);
        setSide(1);
    };
    const setFritekstListe = (val)=>{
        setFritekstListeInternal(val);
        setSide(1);
    };
    const setStatuser = (value)=>{
        if (!formidlinger && !harArbeidsgiverrettetRolle) {
            // Tving default til Åpen for søkere (tidligere 'publisert')
            setStatuserOriginal([
                __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_util$2f$stillingInfoUtil$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VisningsStatus"].ApenForSokere
            ]);
            setSide(1);
        } else {
            setStatuserOriginal(value);
            setSide(1);
        }
    };
    const [utenOppdrag, setUtenOppdrag] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useQueryState"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_util$2f$stillingss$f8$k$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StillingsSøkQueryparam"].HarKandidatliste, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["parseAsBoolean"].withDefault(false).withOptions({
        clearOnDefault: false
    }));
    const [statuser, setStatuserOriginal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useQueryState"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_util$2f$stillingss$f8$k$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StillingsSøkQueryparam"].Statuser, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["parseAsArrayOf"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["parseAsString"]).withDefault([]).withOptions({
        clearOnDefault: true,
        shallow: true
    }));
    const [fylker, setFylker] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useQueryState"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_util$2f$stillingss$f8$k$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StillingsSøkQueryparam"].Fylker, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["parseAsArrayOf"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["parseAsString"]).withDefault([]).withOptions({
        clearOnDefault: true
    }));
    const [kommuner, setKommuner] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useQueryState"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_util$2f$stillingss$f8$k$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StillingsSøkQueryparam"].Kommuner, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["parseAsArrayOf"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["parseAsString"]).withDefault([]).withOptions({
        clearOnDefault: true
    }));
    const [side, setSide] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useQueryState"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_util$2f$stillingss$f8$k$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StillingsSøkQueryparam"].Side, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["parseAsInteger"].withDefault(1).withOptions({
        clearOnDefault: true
    }));
    const [portefølje, setPortefølje] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useQueryState"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_util$2f$stillingss$f8$k$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StillingsSøkQueryparam"].Portefølje, {
        defaultValue: 'intern',
        clearOnDefault: true
    });
    const [sortering, setSortering] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useQueryState"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_util$2f$stillingss$f8$k$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StillingsSøkQueryparam"].Sortering, {
        defaultValue: 'publiseringsdato',
        clearOnDefault: true
    });
    const [inkludering, setInkludering] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useQueryState"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_util$2f$stillingss$f8$k$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StillingsSøkQueryparam"].HovedInkluderingTags, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["parseAsArrayOf"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["parseAsString"]).withDefault([]).withOptions({
        clearOnDefault: true,
        shallow: true
    }));
    const [inkluderingUnderkategori, setInkluderingUnderkategori] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useQueryState"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_util$2f$stillingss$f8$k$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StillingsSøkQueryparam"].SubInkluderingTags, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["parseAsArrayOf"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["parseAsString"]).withDefault([]).withOptions({
        clearOnDefault: true,
        shallow: true
    }));
    const [kategori, setKategori] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useQueryState"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_util$2f$stillingss$f8$k$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StillingsSøkQueryparam"].Stillingskategorier, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["parseAsArrayOf"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["parseAsString"]).withDefault([]).withOptions({
        clearOnDefault: true,
        shallow: true
    }));
    const [publisert, setPublisert] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useQueryState"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_util$2f$stillingss$f8$k$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StillingsSøkQueryparam"].Publisert, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["parseAsArrayOf"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["parseAsString"]).withDefault([]).withOptions({
        clearOnDefault: true
    }));
    // useEffect(() => {
    //   // For ikke-formidlinger uten arbeidsgiverrettet rolle: lås til kun Åpen for søkere
    //   if (
    //     !formidlinger &&
    //     !harArbeidsgiverrettetRolle &&
    //     (!statuser.includes(VisningsStatus.ApenForSokere) || statuser.length > 1)
    //   ) {
    //     setStatuserOriginal([VisningsStatus.ApenForSokere]);
    //   }
    // }, [harArbeidsgiverrettetRolle, statuser, setStatuserOriginal, formidlinger]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "StillingsSøkProvider.useEffect": ()=>{
            // Fjern ugyldige statuser som ikke finnes i VisningsStatus enum
            const gyldigeVisningsStatuser = Object.values(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_util$2f$stillingInfoUtil$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VisningsStatus"]);
            const ugyldige = statuser.filter({
                "StillingsSøkProvider.useEffect.ugyldige": (status)=>!gyldigeVisningsStatuser.includes(status)
            }["StillingsSøkProvider.useEffect.ugyldige"]);
            if (ugyldige.length > 0) {
                const filtrerteStatuser = statuser.filter({
                    "StillingsSøkProvider.useEffect.filtrerteStatuser": (status)=>gyldigeVisningsStatuser.includes(status)
                }["StillingsSøkProvider.useEffect.filtrerteStatuser"]);
                setStatuserOriginal(filtrerteStatuser);
            }
        }
    }["StillingsSøkProvider.useEffect"], [
        statuser,
        setStatuserOriginal
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "StillingsSøkProvider.useEffect": ()=>{
            if (inkluderingUnderkategori.length !== 0) {
                let newInkluderingUnderkategori = inkluderingUnderkategori;
                // Fjern hovedtag hvis undertag er valgt
                __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$StillingsS$f8$kFilter$2f$InkluderingFilter$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hierarkiAvTagsForFilter"].forEach({
                    "StillingsSøkProvider.useEffect": (gruppeMedTags)=>{
                        if (!inkludering.includes(gruppeMedTags.hovedtag)) {
                            newInkluderingUnderkategori = newInkluderingUnderkategori.filter({
                                "StillingsSøkProvider.useEffect": (subtag)=>!gruppeMedTags.subtags.includes(subtag)
                            }["StillingsSøkProvider.useEffect"]);
                        }
                    }
                }["StillingsSøkProvider.useEffect"]);
                // Bare oppdater når det er endringer
                if (newInkluderingUnderkategori.length !== inkluderingUnderkategori.length) {
                    setInkluderingUnderkategori(newInkluderingUnderkategori);
                }
            }
        }
    }["StillingsSøkProvider.useEffect"], [
        inkludering,
        inkluderingUnderkategori,
        setInkluderingUnderkategori
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "StillingsSøkProvider.useEffect": ()=>{
            if (kommuner.length !== 0) {
                const filteredKommuner = kommuner.filter({
                    "StillingsSøkProvider.useEffect.filteredKommuner": (kommune)=>{
                        const prefix = kommune.slice(0, 2);
                        return fylker.some({
                            "StillingsSøkProvider.useEffect.filteredKommuner": (fylke)=>fylke === prefix
                        }["StillingsSøkProvider.useEffect.filteredKommuner"]);
                    }
                }["StillingsSøkProvider.useEffect.filteredKommuner"]);
                if (filteredKommuner.length !== kommuner.length) {
                    setKommuner(filteredKommuner);
                }
            }
        }
    }["StillingsSøkProvider.useEffect"], [
        kommuner,
        fylker,
        setKommuner
    ]);
    const wrapWithPageReset = (setter)=>{
        return async (value)=>{
            await setter(value);
            if (side !== 1) {
                await setSide(1);
            }
        };
    };
    // Når brukStandardsok er aktivt: eksponer alltid tom fritekst uten å trigge ekstra render via effect
    const effektiveFritekst = brukStandardSøk ? [] : fritekst;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(StillingsSøkContext.Provider, {
        value: {
            fritekst: effektiveFritekst,
            setFritekst: setFritekst,
            setFritekstListe,
            sortering,
            setSortering: wrapWithPageReset(setSortering),
            side,
            setSide,
            statuser,
            setStatuser,
            fylker,
            setFylker: wrapWithPageReset(setFylker),
            kommuner,
            setKommuner: wrapWithPageReset(setKommuner),
            portefølje,
            setPortefølje: wrapWithPageReset(setPortefølje),
            inkludering,
            setInkludering: wrapWithPageReset(setInkludering),
            inkluderingUnderkategori,
            setInkluderingUnderkategori: wrapWithPageReset(setInkluderingUnderkategori),
            utenOppdrag,
            setUtenOppdrag: wrapWithPageReset(setUtenOppdrag),
            kategori,
            setKategori: wrapWithPageReset(setKategori),
            publisert,
            setPublisert: wrapWithPageReset(setPublisert),
            formidlinger
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/app/stilling/StillingsSøkContext.tsx",
        lineNumber: 254,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(StillingsSøkProvider, "BEPEZRj+Ex4qNbov1c1k36A0OyI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$ApplikasjonContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useApplikasjonContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useQueryState"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useQueryState"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useQueryState"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useQueryState"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useQueryState"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useQueryState"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useQueryState"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useQueryState"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useQueryState"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useQueryState"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useQueryState"]
    ];
});
_c = StillingsSøkProvider;
const useStillingsSøkFilter = ()=>{
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(StillingsSøkContext);
    if (context === undefined) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$rekbisError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RekbisError"]({
            message: 'useStillingsSøk må være i scope: StillingsSøkProvider'
        });
    }
    return context;
};
_s1(useStillingsSøkFilter, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_context__.k.register(_c, "StillingsSøkProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/store/stillingssokTotalData.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useStillingssokTotalData",
    ()=>useStillingssokTotalData
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zustand$40$5$2e$0$2e$10_$40$types$2b$react$40$19$2e$2$2e$9_react$40$19$2e$2$2e$1_use$2d$sync$2d$external$2d$store$40$1$2e$6$2e$0_react$40$19$2e$2$2e$1_$2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zustand@5.0.10_@types+react@19.2.9_react@19.2.1_use-sync-external-store@1.6.0_react@19.2.1_/node_modules/zustand/esm/react.mjs [app-client] (ecmascript)");
;
const useStillingssokTotalData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zustand$40$5$2e$0$2e$10_$40$types$2b$react$40$19$2e$2$2e$9_react$40$19$2e$2$2e$1_use$2d$sync$2d$external$2d$store$40$1$2e$6$2e$0_react$40$19$2e$2$2e$1_$2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["create"])((set)=>({
        antall: null,
        setAntall: (t)=>set({
                antall: t
            }),
        patchAntall: ()=>undefined,
        resetAntall: ()=>set({
                antall: null
            })
    }));
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/StillingsSøkeresultat.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$StillingsS$f8$kContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/StillingsSøkContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$StillingsKort$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/_ui/StillingsKort.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$elastic$2d$search$2f$elasticSearchQueryBuilder$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/stillings-sok/elastic-search/elasticSearchQueryBuilder.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$useStillingss$f8$k$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/stillings-sok/useStillingssøk.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$StillingsS$f8$kChips$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/_ui/StillingsSøkChips.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$StillingsS$f8$kNavigasjon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/_ui/StillingsSøkNavigasjon.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$store$2f$stillingssokTotalData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/store/stillingssokTotalData.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$SWRLaster$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/SWRLaster.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$SideScroll$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/SideScroll.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$layout$2f$SideInnhold$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/layout/SideInnhold.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$layout$2f$SkeletonKort$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/layout/SkeletonKort.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$paginering$2f$LitenPaginering$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/paginering/LitenPaginering.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$ApplikasjonContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/providers/ApplikasjonContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/BodyShort.js [app-client] (ecmascript) <export default as BodyShort>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const lagFilterSignatur = (filter, { inkluderSide })=>{
    const normalisert = {
        sortering: filter.sortering,
        statuser: [
            ...filter.statuser
        ].sort(),
        fylker: [
            ...filter.fylker
        ].sort(),
        kommuner: [
            ...filter.kommuner
        ].sort(),
        portefølje: filter.portefølje,
        inkludering: [
            ...filter.inkludering
        ].sort(),
        inkluderingUnderkategori: [
            ...filter.inkluderingUnderkategori
        ].sort(),
        kategori: [
            ...filter.kategori
        ].sort(),
        publisert: [
            ...filter.publisert
        ].sort(),
        fritekst: [
            ...filter.fritekst
        ],
        utenOppdrag: filter.utenOppdrag,
        formidlinger: filter.formidlinger ?? false
    };
    const normalisertMedSide = inkluderSide ? {
        ...normalisert,
        side: filter.side
    } : normalisert;
    return JSON.stringify(normalisertMedSide);
};
const StillingsSøkeresultat = ({ kandidatId })=>{
    _s();
    // Abonner kun på setteren for å unngå re-render ved antall-endringer her.
    const setAntall = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$store$2f$stillingssokTotalData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStillingssokTotalData"])({
        "StillingsSøkeresultat.useStillingssokTotalData[setAntall]": (s)=>s.setAntall
    }["StillingsSøkeresultat.useStillingssokTotalData[setAntall]"]);
    const filter = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$StillingsS$f8$kContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStillingsSøkFilter"])();
    const { valgtNavKontor, brukerData: { ident } } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$ApplikasjonContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useApplikasjonContext"])();
    const finnStillingerForKandidat = !!kandidatId;
    const combinedHook = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$useStillingss$f8$k$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStillingssøk"])({
        filter,
        eierNavKontorEnhetId: valgtNavKontor?.navKontor,
        navIdent: ident,
        formidlinger: filter.formidlinger,
        finnStillingerForKandidat
    });
    const antallVisning = (total)=>{
        if (!total) {
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__["BodyShort"], {
                className: "mt-8",
                children: "Ingen treff på søk"
            }, void 0, false, {
                fileName: "[project]/app/stilling/StillingsSøkeresultat.tsx",
                lineNumber: 71,
                columnNumber: 14
            }, ("TURBOPACK compile-time value", void 0));
        }
        const treffFra = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$elastic$2d$search$2f$elasticSearchQueryBuilder$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["regnUtFørsteTreffFra"])(filter.side ?? 0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$elastic$2d$search$2f$elasticSearchQueryBuilder$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["maksAntallTreffPerSøk"] ?? 0);
        const fraAntall = treffFra + 1;
        const tilAntall = treffFra + __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$elastic$2d$search$2f$elasticSearchQueryBuilder$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["maksAntallTreffPerSøk"];
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$paginering$2f$LitenPaginering$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            fraAntall: fraAntall,
            tilAntall: tilAntall,
            total: total,
            side: filter.side,
            setSide: filter.setSide
        }, void 0, false, {
            fileName: "[project]/app/stilling/StillingsSøkeresultat.tsx",
            lineNumber: 82,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0));
    };
    // Oppdater totals i en effekt (ikke i render) for å unngå React warning.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "StillingsSøkeresultat.useEffect": ()=>{
            const data = combinedHook.data;
            if (!data?.antall) return;
            setAntall({});
        }
    }["StillingsSøkeresultat.useEffect"], [
        combinedHook.data,
        setAntall
    ]);
    const filterKey = lagFilterSignatur(filter, {
        inkluderSide: false
    });
    const scrollKey = lagFilterSignatur(filter, {
        inkluderSide: true
    });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "ml-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$StillingsS$f8$kChips$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/app/stilling/StillingsSøkeresultat.tsx",
                    lineNumber: 103,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/app/stilling/StillingsSøkeresultat.tsx",
                lineNumber: 102,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$SWRLaster$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                hooks: [
                    combinedHook
                ],
                skeleton: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mt-16",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$layout$2f$SideInnhold$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$layout$2f$SkeletonKort$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/app/stilling/StillingsSøkeresultat.tsx",
                            lineNumber: 110,
                            columnNumber: 15
                        }, void 0)
                    }, void 0, false, {
                        fileName: "[project]/app/stilling/StillingsSøkeresultat.tsx",
                        lineNumber: 109,
                        columnNumber: 13
                    }, void 0)
                }, void 0, false, {
                    fileName: "[project]/app/stilling/StillingsSøkeresultat.tsx",
                    lineNumber: 108,
                    columnNumber: 11
                }, void 0),
                children: (data)=>{
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-4 ml-4 flex flex-wrap items-center justify-between gap-x-4 gap-y-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$StillingsS$f8$kNavigasjon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                        fileName: "[project]/app/stilling/StillingsSøkeresultat.tsx",
                                        lineNumber: 119,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "ml-auto",
                                        children: antallVisning(data.hits?.total?.value)
                                    }, void 0, false, {
                                        fileName: "[project]/app/stilling/StillingsSøkeresultat.tsx",
                                        lineNumber: 120,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/stilling/StillingsSøkeresultat.tsx",
                                lineNumber: 118,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "min-h-0 flex-1",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$SideScroll$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    lagreScrollNøkkel: `stillinger-${kandidatId ?? scrollKey}`,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex flex-col gap-1",
                                        children: data.hits?.hits?.map((hit)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$StillingsKort$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                stillingData: hit._source,
                                                kandidatId: kandidatId
                                            }, hit._id, false, {
                                                fileName: "[project]/app/stilling/StillingsSøkeresultat.tsx",
                                                lineNumber: 131,
                                                columnNumber: 23
                                            }, ("TURBOPACK compile-time value", void 0)))
                                    }, void 0, false, {
                                        fileName: "[project]/app/stilling/StillingsSøkeresultat.tsx",
                                        lineNumber: 129,
                                        columnNumber: 19
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, filterKey, false, {
                                    fileName: "[project]/app/stilling/StillingsSøkeresultat.tsx",
                                    lineNumber: 125,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/app/stilling/StillingsSøkeresultat.tsx",
                                lineNumber: 124,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true);
                }
            }, void 0, false, {
                fileName: "[project]/app/stilling/StillingsSøkeresultat.tsx",
                lineNumber: 105,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true);
};
_s(StillingsSøkeresultat, "zw6HKe1+oT/06P7R0+S0rXv6JHU=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$store$2f$stillingssokTotalData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStillingssokTotalData"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$StillingsS$f8$kContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStillingsSøkFilter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$ApplikasjonContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useApplikasjonContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$useStillingss$f8$k$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStillingssøk"]
    ];
});
_c = StillingsSøkeresultat;
const __TURBOPACK__default__export__ = StillingsSøkeresultat;
var _c;
__turbopack_context__.k.register(_c, "StillingsSøkeresultat");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/StillingsSøkLayout.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$StillingsS$f8$keresultat$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/StillingsSøkeresultat.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$StillingsS$f8$kFilter$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/_ui/StillingsSøkFilter.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$kandidat$2f5b$kandidatNr$5d2f$useStillingForKandidat$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/kandidat/[kandidatNr]/useStillingForKandidat.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$StillingsS$f8$kFilter$2f$GeografiFilter$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/_ui/StillingsSøkFilter/GeografiFilter.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$StillingsS$f8$kFilter$2f$InkluderingFilter$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/_ui/StillingsSøkFilter/InkluderingFilter.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$StillingsS$f8$kFilter$2f$KategoriFilter$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/_ui/StillingsSøkFilter/KategoriFilter.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$StillingsS$f8$kFilter$2f$StatusFilter$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/_ui/StillingsSøkFilter/StatusFilter.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$StillingsS$f8$kFilter$2f$StillingS$f8$kebar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/_ui/StillingsSøkFilter/StillingSøkebar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$StillingsS$f8$kSortering$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/_ui/StillingsSøkSortering.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$standards$f8$k$2f$MittStandards$f8$k$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/_ui/standardsøk/MittStandardsøk.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$stilling$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/_ui/stilling-typer.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$layout$2f$PanelHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/layout/PanelHeader.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$layout$2f$SideInnhold$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/layout/SideInnhold.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$layout$2f$SideLayout$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/layout/SideLayout.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$layout$2f$Sidelaster$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/layout/Sidelaster.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$opprett$2f$OpprettKnapp$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/opprett/OpprettKnapp.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$tilgangskontroll$2f$TilgangskontrollForInnhold$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/tilgangskontroll/TilgangskontrollForInnhold.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$tilgangskontroll$2f$roller$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/tilgangskontroll/roller.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$UmamiContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/providers/UmamiContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$umamiEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/util/umamiEvents.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/navigation.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const StillingsSøkLayout = ({ formidlinger, forKandidatNr })=>{
    _s();
    const { track } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$UmamiContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUmami"])();
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"])();
    // Sjekk om det finnes andre parametere enn den vi forventer
    const harAndreParametere = searchParams.size > 0;
    const skalHenteKandidatData = forKandidatNr && !harAndreParametere;
    const kandidatStillingssøkData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$kandidat$2f5b$kandidatNr$5d2f$useStillingForKandidat$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStillingForKandidat"])(skalHenteKandidatData ? forKandidatNr : null);
    if (forKandidatNr) {
        track(__TURBOPACK__imported__module__$5b$project$5d2f$util$2f$umamiEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UmamiEvent"].Stilling.forslag_til_stilling_fane);
    }
    if (forKandidatNr && kandidatStillingssøkData?.isLoading) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$layout$2f$Sidelaster$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/app/stilling/StillingsSøkLayout.tsx",
            lineNumber: 52,
            columnNumber: 12
        }, ("TURBOPACK compile-time value", void 0));
    }
    if (kandidatStillingssøkData && kandidatStillingssøkData.kandidatStillingssøk?.yrkeJobbonskerObj?.length) {
        const antallYrkesJobbØnsker = kandidatStillingssøkData.kandidatStillingssøk?.yrkeJobbonskerObj[0]?.sokeTitler?.length;
        if (antallYrkesJobbØnsker > 0) {
            track(__TURBOPACK__imported__module__$5b$project$5d2f$util$2f$umamiEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UmamiEvent"].Stilling.antall_yrkesjobbønsker_fra_kandidat, {
                antall: antallYrkesJobbØnsker
            });
        }
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$layout$2f$SideLayout$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        venstrePanel: true,
        sidepanelTittel: "Filtrer",
        header: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$layout$2f$PanelHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$layout$2f$PanelHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Section, {
                actionsRight: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$tilgangskontroll$2f$TilgangskontrollForInnhold$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TilgangskontrollForInnhold"], {
                    skjulVarsel: true,
                    kreverEnAvRollene: [
                        __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$tilgangskontroll$2f$roller$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Roller"].AD_GRUPPE_REKRUTTERINGSBISTAND_ARBEIDSGIVERRETTET,
                        __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$tilgangskontroll$2f$roller$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Roller"].AD_GRUPPE_REKRUTTERINGSBISTAND_UTVIKLER
                    ],
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$opprett$2f$OpprettKnapp$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OpprettKnapp"], {
                        kategori: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$stilling$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Stillingskategori"].Stilling
                    }, void 0, false, {
                        fileName: "[project]/app/stilling/StillingsSøkLayout.tsx",
                        lineNumber: 84,
                        columnNumber: 17
                    }, void 0)
                }, void 0, false, {
                    fileName: "[project]/app/stilling/StillingsSøkLayout.tsx",
                    lineNumber: 77,
                    columnNumber: 15
                }, void 0)
            }, void 0, false, {
                fileName: "[project]/app/stilling/StillingsSøkLayout.tsx",
                lineNumber: 75,
                columnNumber: 11
            }, void 0)
        }, void 0, false, {
            fileName: "[project]/app/stilling/StillingsSøkLayout.tsx",
            lineNumber: 74,
            columnNumber: 9
        }, void 0),
        sidepanelBredde: "250px",
        sidepanel: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col gap-4",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$StillingsS$f8$kFilter$2f$StillingS$f8$kebar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    alltidÅpen: false
                }, void 0, false, {
                    fileName: "[project]/app/stilling/StillingsSøkLayout.tsx",
                    lineNumber: 93,
                    columnNumber: 11
                }, void 0),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$standards$f8$k$2f$MittStandards$f8$k$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/app/stilling/StillingsSøkLayout.tsx",
                    lineNumber: 94,
                    columnNumber: 11
                }, void 0),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$StillingsS$f8$kSortering$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/app/stilling/StillingsSøkLayout.tsx",
                    lineNumber: 95,
                    columnNumber: 11
                }, void 0),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$StillingsS$f8$kFilter$2f$StatusFilter$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/app/stilling/StillingsSøkLayout.tsx",
                    lineNumber: 96,
                    columnNumber: 11
                }, void 0),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$StillingsS$f8$kFilter$2f$GeografiFilter$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/app/stilling/StillingsSøkLayout.tsx",
                    lineNumber: 97,
                    columnNumber: 11
                }, void 0),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$StillingsS$f8$kFilter$2f$KategoriFilter$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/app/stilling/StillingsSøkLayout.tsx",
                    lineNumber: 98,
                    columnNumber: 11
                }, void 0),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$StillingsS$f8$kFilter$2f$InkluderingFilter$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/app/stilling/StillingsSøkLayout.tsx",
                    lineNumber: 99,
                    columnNumber: 11
                }, void 0)
            ]
        }, void 0, true, {
            fileName: "[project]/app/stilling/StillingsSøkLayout.tsx",
            lineNumber: 92,
            columnNumber: 9
        }, void 0),
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$layout$2f$SideInnhold$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            utenScroll: true,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "@container flex contain-layout",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "min-w-0 flex-grow",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$StillingsS$f8$kFilter$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            formidlinger: formidlinger,
                            stillingForKandidat: forKandidatNr
                        }, void 0, false, {
                            fileName: "[project]/app/stilling/StillingsSøkLayout.tsx",
                            lineNumber: 106,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "@container flex contain-layout",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "min-w-0 flex-grow",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$StillingsS$f8$keresultat$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    kandidatId: forKandidatNr
                                }, void 0, false, {
                                    fileName: "[project]/app/stilling/StillingsSøkLayout.tsx",
                                    lineNumber: 112,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/app/stilling/StillingsSøkLayout.tsx",
                                lineNumber: 111,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/app/stilling/StillingsSøkLayout.tsx",
                            lineNumber: 110,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/stilling/StillingsSøkLayout.tsx",
                    lineNumber: 105,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/app/stilling/StillingsSøkLayout.tsx",
                lineNumber: 104,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/app/stilling/StillingsSøkLayout.tsx",
            lineNumber: 103,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/app/stilling/StillingsSøkLayout.tsx",
        lineNumber: 70,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(StillingsSøkLayout, "kNdMM1PE+xoOIp7l6dsz6vBQxu8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$UmamiContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUmami"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$kandidat$2f5b$kandidatNr$5d2f$useStillingForKandidat$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStillingForKandidat"]
    ];
});
_c = StillingsSøkLayout;
const __TURBOPACK__default__export__ = StillingsSøkLayout;
var _c;
__turbopack_context__.k.register(_c, "StillingsSøkLayout");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>StillingsSøkIndex
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stilling$2f$standardsok$2f$useBrukersStandards$f8$k$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/stilling/standardsok/useBrukersStandardsøk.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$StillingsS$f8$kContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/StillingsSøkContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$StillingsS$f8$kLayout$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/StillingsSøkLayout.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$StillingsContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/StillingsContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$page$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/page.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$standards$f8$k$2f$standardSokUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/_ui/standardsøk/standardSokUtils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$layout$2f$Sidelaster$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/layout/Sidelaster.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$window$2f$WindowView$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/window/WindowView.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
function StillingsSøkIndex() {
    _s();
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const brukerStandardSøkData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stilling$2f$standardsok$2f$useBrukersStandards$f8$k$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUseBrukerStandardSøk"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "StillingsSøkIndex.useEffect": ()=>{
            if (searchParams.get('brukStandardsok') !== null && !brukerStandardSøkData.isLoading) {
                const newSearch = brukerStandardSøkData.data?.søk || 'publisert=intern&statuser=publisert';
                const eksludert = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$standards$f8$k$2f$standardSokUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EKSKLUDERTE_STANDARDSOK_PARAMETERE"];
                const urlSearchParams = new URLSearchParams(newSearch);
                eksludert.forEach({
                    "StillingsSøkIndex.useEffect": (param)=>{
                        if (urlSearchParams.has(param)) {
                            urlSearchParams.delete(param);
                        }
                    }
                }["StillingsSøkIndex.useEffect"]);
                window.history.replaceState({}, '', `${window.location.pathname}?${urlSearchParams.toString()}`);
            }
        }
    }["StillingsSøkIndex.useEffect"], [
        searchParams,
        brukerStandardSøkData
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Suspense"], {
        fallback: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$layout$2f$Sidelaster$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/app/stilling/page.tsx",
            lineNumber: 44,
            columnNumber: 25
        }, void 0),
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$window$2f$WindowView$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            param: "visStillingId",
            window: (stillingsId)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$StillingsContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StillingsContextProvider"], {
                    stillingsId: stillingsId,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$page$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/app/stilling/page.tsx",
                        lineNumber: 49,
                        columnNumber: 13
                    }, void 0)
                }, void 0, false, {
                    fileName: "[project]/app/stilling/page.tsx",
                    lineNumber: 48,
                    columnNumber: 11
                }, void 0),
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$StillingsS$f8$kContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StillingsSøkProvider"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$StillingsS$f8$kLayout$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/app/stilling/page.tsx",
                    lineNumber: 54,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/stilling/page.tsx",
                lineNumber: 53,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/stilling/page.tsx",
            lineNumber: 45,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/stilling/page.tsx",
        lineNumber: 44,
        columnNumber: 5
    }, this);
}
_s(StillingsSøkIndex, "bKu211EYCkt8guWiDaHY+ul2vTc=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stilling$2f$standardsok$2f$useBrukersStandards$f8$k$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUseBrukerStandardSøk"]
    ];
});
_c = StillingsSøkIndex;
var _c;
__turbopack_context__.k.register(_c, "StillingsSøkIndex");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=app_stilling_5f8dda08._.js.map