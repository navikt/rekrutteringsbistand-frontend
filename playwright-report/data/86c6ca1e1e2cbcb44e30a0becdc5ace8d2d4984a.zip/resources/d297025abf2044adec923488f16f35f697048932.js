(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/app/etterregistrering/[stillingsId]/OmEtterregistrering.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>OmEtterregistrering
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$StillingsContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/StillingsContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$_ui$2f$om$2d$stillingen$2f$StillingSidebar$2f$StillingInkludering$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/_ui/om-stillingen/StillingSidebar/StillingInkludering.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_util$2f$parsJsonArray$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/_util/parsJsonArray.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$InfoBoks$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/InfoBoks.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$TekstMedIkon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/TekstMedIkon.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$locationUtil$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/util/locationUtil.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$Calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CalendarIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/Calendar.js [app-client] (ecmascript) <export default as CalendarIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$Clock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ClockIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/Clock.js [app-client] (ecmascript) <export default as ClockIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$LocationPin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LocationPinIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/LocationPin.js [app-client] (ecmascript) <export default as LocationPinIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$Percent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PercentIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/Percent.js [app-client] (ecmascript) <export default as PercentIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$Heading$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Heading$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/Heading.js [app-client] (ecmascript) <export default as Heading>");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
function OmEtterregistrering() {
    _s();
    const { stillingsData } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$StillingsContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStillingsContext"])();
    const stillingEgenskaper = stillingsData?.stilling?.properties;
    const lokasjon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$locationUtil$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getWorkLocationsAsString"])(stillingsData.stilling.locationList);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$InfoBoks$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "space-y-5",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$Heading$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Heading$3e$__["Heading"], {
                    size: "small",
                    level: "3",
                    children: "Om etterregistreringen"
                }, void 0, false, {
                    fileName: "[project]/app/etterregistrering/[stillingsId]/OmEtterregistrering.tsx",
                    lineNumber: 29,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "grid grid-cols-2 gap-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$TekstMedIkon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            // Lokasjon
                            tekst: lokasjon ?? '-',
                            ikon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$LocationPin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LocationPinIcon$3e$__["LocationPinIcon"], {}, void 0, false, {
                                fileName: "[project]/app/etterregistrering/[stillingsId]/OmEtterregistrering.tsx",
                                lineNumber: 36,
                                columnNumber: 19
                            }, void 0)
                        }, void 0, false, {
                            fileName: "[project]/app/etterregistrering/[stillingsId]/OmEtterregistrering.tsx",
                            lineNumber: 33,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$TekstMedIkon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            // Ansettelsesform
                            tekst: `${stillingEgenskaper?.engagementtype ?? '-'} ${stillingEgenskaper?.extent ? `- ${stillingEgenskaper.extent}` : ''}`,
                            ikon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$Clock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ClockIcon$3e$__["ClockIcon"], {}, void 0, false, {
                                fileName: "[project]/app/etterregistrering/[stillingsId]/OmEtterregistrering.tsx",
                                lineNumber: 41,
                                columnNumber: 19
                            }, void 0)
                        }, void 0, false, {
                            fileName: "[project]/app/etterregistrering/[stillingsId]/OmEtterregistrering.tsx",
                            lineNumber: 38,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$TekstMedIkon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            // Prosent stilling
                            tekst: (()=>{
                                const verdi = stillingEgenskaper?.jobpercentage ?? stillingEgenskaper?.jobpercentagerange;
                                if (!verdi) return '- stilling';
                                return verdi.toString().includes('%') ? `${verdi} stilling` : `${verdi}% stilling`;
                            })(),
                            ikon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$Percent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PercentIcon$3e$__["PercentIcon"], {}, void 0, false, {
                                fileName: "[project]/app/etterregistrering/[stillingsId]/OmEtterregistrering.tsx",
                                lineNumber: 54,
                                columnNumber: 19
                            }, void 0)
                        }, void 0, false, {
                            fileName: "[project]/app/etterregistrering/[stillingsId]/OmEtterregistrering.tsx",
                            lineNumber: 43,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$TekstMedIkon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            // Arbeidstid
                            tekst: `${stillingEgenskaper?.workday ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_util$2f$parsJsonArray$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseJsonArray"])(stillingEgenskaper.workday) : '-'} ${stillingEgenskaper?.workhours ? `- ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_util$2f$parsJsonArray$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseJsonArray"])(stillingEgenskaper.workhours)}` : ''}`,
                            ikon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$Calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CalendarIcon$3e$__["CalendarIcon"], {}, void 0, false, {
                                fileName: "[project]/app/etterregistrering/[stillingsId]/OmEtterregistrering.tsx",
                                lineNumber: 59,
                                columnNumber: 19
                            }, void 0)
                        }, void 0, false, {
                            fileName: "[project]/app/etterregistrering/[stillingsId]/OmEtterregistrering.tsx",
                            lineNumber: 56,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$_ui$2f$om$2d$stillingen$2f$StillingSidebar$2f$StillingInkludering$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/app/etterregistrering/[stillingsId]/OmEtterregistrering.tsx",
                            lineNumber: 61,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/etterregistrering/[stillingsId]/OmEtterregistrering.tsx",
                    lineNumber: 32,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/etterregistrering/[stillingsId]/OmEtterregistrering.tsx",
            lineNumber: 28,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/etterregistrering/[stillingsId]/OmEtterregistrering.tsx",
        lineNumber: 27,
        columnNumber: 5
    }, this);
}
_s(OmEtterregistrering, "j1b3wKFjZkoMny4dfDpk25t93NY=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$StillingsContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStillingsContext"]
    ];
});
_c = OmEtterregistrering;
var _c;
__turbopack_context__.k.register(_c, "OmEtterregistrering");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/rekrutteringstreff/[rekrutteringstreffId]/finn-kandidater/_ui/lagre-i-rekrutteringstreff/lagre-i-rekrutteringstreff.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "lagreKandidaterIRekrutteringstreff",
    ()=>lagreKandidaterIRekrutteringstreff
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$rekrutteringstreff$2f5b2e2e2e$slug$5d2f$jobbs$f8$kere$2f$mutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/rekrutteringstreff/[...slug]/jobbsøkere/mutations.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$rekbisError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/util/rekbisError.ts [app-client] (ecmascript)");
;
;
async function lagreKandidaterIRekrutteringstreff(params, callbacks) {
    const { markerteKandidater, kandidatsokKandidater, rekrutteringstreffId, selectedRows } = params;
    const { visVarsel, fjernMarkerteKandidater, mutateJobbsøkere, mutateRekrutteringstreffOversikt } = callbacks;
    if (!markerteKandidater || markerteKandidater.length === 0) {
        return {
            suksess: false,
            feil: [
                'Ingen kandidater markert'
            ]
        };
    }
    const feil = [];
    const dto = markerteKandidater.map((kandidatnummer)=>{
        const kandidat = kandidatsokKandidater.find((k)=>k.arenaKandidatnr === kandidatnummer);
        if (!kandidat) {
            feil.push(`Fant ikke kandidat med kandidatnummer: ${kandidatnummer}`);
            return null;
        }
        if (!kandidat.fodselsnummer) {
            feil.push(`Kandidat mangler fødselsnummer (${kandidatnummer})`);
        }
        return {
            fødselsnummer: kandidat.fodselsnummer,
            fornavn: kandidat.fornavn ?? null,
            etternavn: kandidat.etternavn ?? null
        };
    }).filter((kandidat)=>kandidat && kandidat.fødselsnummer);
    try {
        if (rekrutteringstreffId) {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$rekrutteringstreff$2f5b2e2e2e$slug$5d2f$jobbs$f8$kere$2f$mutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["opprettJobbsøkere"])(rekrutteringstreffId, dto);
            mutateJobbsøkere?.();
        } else if (selectedRows && selectedRows.length > 0) {
            await Promise.all(selectedRows.map((id)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$rekrutteringstreff$2f5b2e2e2e$slug$5d2f$jobbs$f8$kere$2f$mutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["opprettJobbsøkere"])(id, dto)));
            mutateRekrutteringstreffOversikt?.();
        } else {
            visVarsel({
                type: 'info',
                tekst: 'Velg minst ett rekrutteringstreff'
            });
            return {
                suksess: false,
                feil: [
                    'Ingen rekrutteringstreff valgt'
                ]
            };
        }
        visVarsel({
            type: 'success',
            tekst: `${markerteKandidater.length} kandidat${markerteKandidater.length > 1 ? 'er' : ''} lagret i rekrutteringstreff`
        });
        fjernMarkerteKandidater();
        return {
            suksess: true,
            feil
        };
    } catch (error) {
        new __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$rekbisError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RekbisError"]({
            message: 'Feil ved lagring av kandidater i rekrutteringstreff',
            error
        });
        visVarsel({
            type: 'error',
            tekst: 'Feil ved lagring av kandidater i rekrutteringstreff'
        });
        return {
            suksess: false,
            feil: [
                'Feil ved lagring'
            ]
        };
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/rekrutteringstreff/_types/constants.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Sentraliserte typer og konstanter (1:1 med backend) for rekrutteringstreff-domenet
// Jobbsøker-hendelser
__turbopack_context__.s([
    "AktørType",
    ()=>AktørType,
    "ArbeidsgiverHendelsestype",
    ()=>ArbeidsgiverHendelsestype,
    "ArbeidsgiverHendelsestypeLabel",
    ()=>ArbeidsgiverHendelsestypeLabel,
    "JobbsøkerHendelsestype",
    ()=>JobbsøkerHendelsestype,
    "JobbsøkerHendelsestypeLabel",
    ()=>JobbsøkerHendelsestypeLabel,
    "JobbsøkerStatus",
    ()=>JobbsøkerStatus,
    "RekrutteringstreffHendelsestype",
    ()=>RekrutteringstreffHendelsestype,
    "RekrutteringstreffHendelsestypeLabel",
    ()=>RekrutteringstreffHendelsestypeLabel,
    "RekrutteringstreffStatus",
    ()=>RekrutteringstreffStatus,
    "RelevanteJobbsøkerHendelser",
    ()=>RelevanteJobbsøkerHendelser,
    "RelevanteStegHendelser",
    ()=>RelevanteStegHendelser
]);
const JobbsøkerHendelsestype = {
    OPPRETTET: 'OPPRETTET',
    OPPDATERT: 'OPPDATERT',
    SLETTET: 'SLETTET',
    INVITERT: 'INVITERT',
    SVART_JA_TIL_INVITASJON: 'SVART_JA_TIL_INVITASJON',
    SVART_NEI_TIL_INVITASJON: 'SVART_NEI_TIL_INVITASJON',
    SVART_JA_TREFF_AVLYST: 'SVART_JA_TREFF_AVLYST',
    SVART_JA_TREFF_FULLFØRT: 'SVART_JA_TREFF_FULLFØRT',
    IKKE_SVART_TREFF_AVLYST: 'IKKE_SVART_TREFF_AVLYST',
    IKKE_SVART_TREFF_FULLFØRT: 'IKKE_SVART_TREFF_FULLFØRT',
    AKTIVITETSKORT_OPPRETTELSE_FEIL: 'AKTIVITETSKORT_OPPRETTELSE_FEIL',
    MOTTATT_SVAR_FRA_MINSIDE: 'MOTTATT_SVAR_FRA_MINSIDE',
    TREFF_ENDRET_ETTER_PUBLISERING_NOTIFIKASJON: 'TREFF_ENDRET_ETTER_PUBLISERING_NOTIFIKASJON'
};
const ArbeidsgiverHendelsestype = {
    OPPRETTET: 'OPPRETTET',
    OPPDATERT: 'OPPDATERT',
    SLETTET: 'SLETTET'
};
const RekrutteringstreffHendelsestype = {
    OPPRETTET: 'OPPRETTET',
    OPPDATERT: 'OPPDATERT',
    SLETTET: 'SLETTET',
    PUBLISERT: 'PUBLISERT',
    GJENÅPNET: 'GJENÅPNET',
    FULLFØRT: 'FULLFØRT',
    AVLYST: 'AVLYST',
    AVPUBLISERT: 'AVPUBLISERT',
    TREFF_ENDRET_ETTER_PUBLISERING: 'TREFF_ENDRET_ETTER_PUBLISERING',
    TREFF_ENDRET_ETTER_PUBLISERING_NOTIFIKASJON: 'TREFF_ENDRET_ETTER_PUBLISERING_NOTIFIKASJON'
};
const AktørType = {
    ARRANGØR: 'ARRANGØR',
    JOBBSØKER: 'JOBBSØKER',
    ARBEIDSGIVER: 'ARBEIDSGIVER',
    SYSTEM: 'SYSTEM'
};
const RelevanteStegHendelser = new Set([
    RekrutteringstreffHendelsestype.PUBLISERT,
    RekrutteringstreffHendelsestype.FULLFØRT,
    RekrutteringstreffHendelsestype.GJENÅPNET,
    RekrutteringstreffHendelsestype.AVLYST,
    RekrutteringstreffHendelsestype.AVPUBLISERT
]);
const RelevanteJobbsøkerHendelser = new Set([
    JobbsøkerHendelsestype.OPPRETTET,
    JobbsøkerHendelsestype.INVITERT,
    JobbsøkerHendelsestype.SVART_JA_TIL_INVITASJON,
    JobbsøkerHendelsestype.SVART_NEI_TIL_INVITASJON,
    JobbsøkerHendelsestype.AKTIVITETSKORT_OPPRETTELSE_FEIL
]);
const JobbsøkerHendelsestypeLabel = {
    [JobbsøkerHendelsestype.OPPRETTET]: 'lagt til',
    [JobbsøkerHendelsestype.OPPDATERT]: 'oppdatert',
    [JobbsøkerHendelsestype.SLETTET]: 'slettet',
    [JobbsøkerHendelsestype.INVITERT]: 'invitert',
    [JobbsøkerHendelsestype.SVART_JA_TIL_INVITASJON]: 'svart ja',
    [JobbsøkerHendelsestype.SVART_NEI_TIL_INVITASJON]: 'svart nei',
    [JobbsøkerHendelsestype.SVART_JA_TREFF_AVLYST]: 'treff avlyst',
    [JobbsøkerHendelsestype.SVART_JA_TREFF_FULLFØRT]: 'treff fullført',
    [JobbsøkerHendelsestype.IKKE_SVART_TREFF_AVLYST]: 'ikke svart, treff avlyst',
    [JobbsøkerHendelsestype.IKKE_SVART_TREFF_FULLFØRT]: 'ikke svart, treff fullført',
    [JobbsøkerHendelsestype.AKTIVITETSKORT_OPPRETTELSE_FEIL]: 'opprettelse feilet',
    [JobbsøkerHendelsestype.MOTTATT_SVAR_FRA_MINSIDE]: 'mottatt svar',
    [JobbsøkerHendelsestype.TREFF_ENDRET_ETTER_PUBLISERING_NOTIFIKASJON]: 'treff endret etter publisering notifikasjon'
};
const ArbeidsgiverHendelsestypeLabel = {
    [ArbeidsgiverHendelsestype.OPPRETTET]: 'lagt til',
    [ArbeidsgiverHendelsestype.OPPDATERT]: 'oppdatert',
    [ArbeidsgiverHendelsestype.SLETTET]: 'slettet'
};
const RekrutteringstreffHendelsestypeLabel = {
    [RekrutteringstreffHendelsestype.OPPRETTET]: 'lagt til',
    [RekrutteringstreffHendelsestype.OPPDATERT]: 'oppdatert',
    [RekrutteringstreffHendelsestype.SLETTET]: 'slettet',
    [RekrutteringstreffHendelsestype.PUBLISERT]: 'publisert',
    [RekrutteringstreffHendelsestype.AVPUBLISERT]: 'avpublisert',
    [RekrutteringstreffHendelsestype.GJENÅPNET]: 'gjenåpnet',
    [RekrutteringstreffHendelsestype.FULLFØRT]: 'fullført',
    [RekrutteringstreffHendelsestype.AVLYST]: 'avlyst',
    [RekrutteringstreffHendelsestype.TREFF_ENDRET_ETTER_PUBLISERING]: 'endret etter publisering',
    [RekrutteringstreffHendelsestype.TREFF_ENDRET_ETTER_PUBLISERING_NOTIFIKASJON]: 'endret etter publisering notifikasjon'
};
const RekrutteringstreffStatus = {
    UTKAST: 'UTKAST',
    PUBLISERT: 'PUBLISERT',
    FULLFØRT: 'FULLFØRT',
    AVLYST: 'AVLYST',
    SLETTET: 'SLETTET'
};
const JobbsøkerStatus = {
    LAGT_TIL: 'LAGT_TIL',
    INVITERT: 'INVITERT',
    SVART_JA: 'SVART_JA',
    SVART_NEI: 'SVART_NEI',
    SLETTET: 'SLETTET'
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/rekrutteringstreff/[rekrutteringstreffId]/finn-kandidater/_ui/lagre-i-rekrutteringstreff/LagreIRekrutteringstreffModal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>LagreIRekrutteringstreffModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$rekrutteringstreff$2f5b$rekrutteringstreffId$5d2f$finn$2d$kandidater$2f$_ui$2f$lagre$2d$i$2d$rekrutteringstreff$2f$lagre$2d$i$2d$rekrutteringstreff$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/rekrutteringstreff/[rekrutteringstreffId]/finn-kandidater/_ui/lagre-i-rekrutteringstreff/lagre-i-rekrutteringstreff.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$rekrutteringstreff$2f5b2e2e2e$slug$5d2f$jobbs$f8$kere$2f$useJobbs$f8$kere$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/rekrutteringstreff/[...slug]/jobbsøkere/useJobbsøkere.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$rekrutteringstreff$2f$mittkontor$2f$useRekrutteringstreffMittKontor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/rekrutteringstreff/mittkontor/useRekrutteringstreffMittKontor.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$kandidat$2f$KandidatS$f8$kMarkerteContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/kandidat/KandidatSøkMarkerteContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$SWRLaster$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/SWRLaster.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$ApplikasjonContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/providers/ApplikasjonContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$checkbox$2f$Checkbox$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Checkbox$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/checkbox/Checkbox.js [app-client] (ecmascript) <export default as Checkbox>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$link$2f$Link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Link$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/link/Link.js [app-client] (ecmascript) <export default as Link>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$loader$2f$Loader$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/loader/Loader.js [app-client] (ecmascript) <export default as Loader>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/modal/Modal.js [app-client] (ecmascript) <export default as Modal>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/table/Table.js [app-client] (ecmascript) <export default as Table>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
function LagreIRekrutteringstreffModal({ rekrutteringstreffId, kandidatsokKandidater, onClose }) {
    _s();
    const [selectedRows, setSelectedRows] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [laster, setLaster] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const { visVarsel } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$ApplikasjonContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useApplikasjonContext"])();
    const { markerteKandidater, fjernMarkerteKandidater } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$kandidat$2f$KandidatS$f8$kMarkerteContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useKandidatSøkMarkerteContext"])();
    const jobbsøkerHook = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$rekrutteringstreff$2f5b2e2e2e$slug$5d2f$jobbs$f8$kere$2f$useJobbs$f8$kere$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useJobbsøkere"])(rekrutteringstreffId);
    const rekrutteringstreffOversiktHook = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$rekrutteringstreff$2f$mittkontor$2f$useRekrutteringstreffMittKontor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRekrutteringstreffMittKontor"])();
    const toggleSelectedRow = (stillingsId)=>setSelectedRows((list)=>list.includes(stillingsId) ? list.filter((id)=>id !== stillingsId) : [
                ...list,
                stillingsId
            ]);
    const lagreKandidater = async (valgteTreff)=>{
        if (!markerteKandidater || markerteKandidater.length === 0) return;
        if (laster) return;
        setLaster(true);
        const resultat = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$rekrutteringstreff$2f5b$rekrutteringstreffId$5d2f$finn$2d$kandidater$2f$_ui$2f$lagre$2d$i$2d$rekrutteringstreff$2f$lagre$2d$i$2d$rekrutteringstreff$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["lagreKandidaterIRekrutteringstreff"])({
            markerteKandidater,
            kandidatsokKandidater,
            rekrutteringstreffId,
            selectedRows: valgteTreff
        }, {
            visVarsel,
            fjernMarkerteKandidater,
            mutateJobbsøkere: jobbsøkerHook.mutate,
            mutateRekrutteringstreffOversikt: rekrutteringstreffOversiktHook.mutate
        });
        setLaster(false);
        if (resultat.suksess) {
            onClose();
            if (rekrutteringstreffId) {
                router.push(`/rekrutteringstreff/${rekrutteringstreffId}?visFane=jobbsøkere`);
            }
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"], {
        width: 600,
        onClose: ()=>{
            if (!laster) {
                onClose();
            }
        },
        open: true,
        header: {
            heading: `Lagre ${markerteKandidater?.length || 0} kandidat i rekrutteringstreff`
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"].Body, {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$SWRLaster$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    hooks: [
                        rekrutteringstreffOversiktHook
                    ],
                    children: (rekrutteringstreffOversikt)=>{
                        return laster ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$loader$2f$Loader$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader$3e$__["Loader"], {}, void 0, false, {
                            fileName: "[project]/app/rekrutteringstreff/[rekrutteringstreffId]/finn-kandidater/_ui/lagre-i-rekrutteringstreff/LagreIRekrutteringstreffModal.tsx",
                            lineNumber: 91,
                            columnNumber: 15
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__["Table"], {
                                zebraStripes: true,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__["Table"].Header, {
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__["Table"].Row, {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__["Table"].DataCell, {
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$checkbox$2f$Checkbox$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Checkbox$3e$__["Checkbox"], {
                                                        checked: selectedRows.length === rekrutteringstreffOversikt.length,
                                                        indeterminate: selectedRows.length > 0 && selectedRows.length !== rekrutteringstreffOversikt.length,
                                                        onChange: ()=>{
                                                            if (selectedRows.length) {
                                                                setSelectedRows([]);
                                                            } else {
                                                                setSelectedRows(rekrutteringstreffOversikt.map((rekrutteringstreffOversikt)=>rekrutteringstreffOversikt.id));
                                                            }
                                                        },
                                                        hideLabel: true,
                                                        children: "Velg alle rader"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/rekrutteringstreff/[rekrutteringstreffId]/finn-kandidater/_ui/lagre-i-rekrutteringstreff/LagreIRekrutteringstreffModal.tsx",
                                                        lineNumber: 98,
                                                        columnNumber: 25
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/app/rekrutteringstreff/[rekrutteringstreffId]/finn-kandidater/_ui/lagre-i-rekrutteringstreff/LagreIRekrutteringstreffModal.tsx",
                                                    lineNumber: 97,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__["Table"].HeaderCell, {
                                                    scope: "col",
                                                    children: "Rekrutteringstreff"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/rekrutteringstreff/[rekrutteringstreffId]/finn-kandidater/_ui/lagre-i-rekrutteringstreff/LagreIRekrutteringstreffModal.tsx",
                                                    lineNumber: 125,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/rekrutteringstreff/[rekrutteringstreffId]/finn-kandidater/_ui/lagre-i-rekrutteringstreff/LagreIRekrutteringstreffModal.tsx",
                                            lineNumber: 96,
                                            columnNumber: 21
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/rekrutteringstreff/[rekrutteringstreffId]/finn-kandidater/_ui/lagre-i-rekrutteringstreff/LagreIRekrutteringstreffModal.tsx",
                                        lineNumber: 95,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__["Table"].Body, {
                                        children: rekrutteringstreffOversikt.map((rekrutteringstreffOversikt, i)=>{
                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__["Table"].Row, {
                                                selected: selectedRows.includes(rekrutteringstreffOversikt.id),
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__["Table"].DataCell, {
                                                        className: "w-3",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$checkbox$2f$Checkbox$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Checkbox$3e$__["Checkbox"], {
                                                            hideLabel: true,
                                                            checked: selectedRows.includes(rekrutteringstreffOversikt.id),
                                                            onChange: ()=>toggleSelectedRow(rekrutteringstreffOversikt.id),
                                                            "aria-labelledby": `id-${rekrutteringstreffOversikt.id}`,
                                                            children: ' '
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/rekrutteringstreff/[rekrutteringstreffId]/finn-kandidater/_ui/lagre-i-rekrutteringstreff/LagreIRekrutteringstreffModal.tsx",
                                                            lineNumber: 141,
                                                            columnNumber: 31
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/rekrutteringstreff/[rekrutteringstreffId]/finn-kandidater/_ui/lagre-i-rekrutteringstreff/LagreIRekrutteringstreffModal.tsx",
                                                        lineNumber: 140,
                                                        columnNumber: 29
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__["Table"].HeaderCell, {
                                                        scope: "row",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$link$2f$Link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Link$3e$__["Link"], {
                                                            href: `rekrutteringstreff/${rekrutteringstreffOversikt.id}`,
                                                            children: rekrutteringstreffOversikt.tittel ?? 'Ukjent tittel'
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/rekrutteringstreff/[rekrutteringstreffId]/finn-kandidater/_ui/lagre-i-rekrutteringstreff/LagreIRekrutteringstreffModal.tsx",
                                                            lineNumber: 157,
                                                            columnNumber: 31
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/rekrutteringstreff/[rekrutteringstreffId]/finn-kandidater/_ui/lagre-i-rekrutteringstreff/LagreIRekrutteringstreffModal.tsx",
                                                        lineNumber: 156,
                                                        columnNumber: 29
                                                    }, this)
                                                ]
                                            }, rekrutteringstreffOversikt.id + i, true, {
                                                fileName: "[project]/app/rekrutteringstreff/[rekrutteringstreffId]/finn-kandidater/_ui/lagre-i-rekrutteringstreff/LagreIRekrutteringstreffModal.tsx",
                                                lineNumber: 134,
                                                columnNumber: 27
                                            }, this);
                                        })
                                    }, void 0, false, {
                                        fileName: "[project]/app/rekrutteringstreff/[rekrutteringstreffId]/finn-kandidater/_ui/lagre-i-rekrutteringstreff/LagreIRekrutteringstreffModal.tsx",
                                        lineNumber: 130,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/rekrutteringstreff/[rekrutteringstreffId]/finn-kandidater/_ui/lagre-i-rekrutteringstreff/LagreIRekrutteringstreffModal.tsx",
                                lineNumber: 94,
                                columnNumber: 17
                            }, this)
                        }, void 0, false);
                    }
                }, void 0, false, {
                    fileName: "[project]/app/rekrutteringstreff/[rekrutteringstreffId]/finn-kandidater/_ui/lagre-i-rekrutteringstreff/LagreIRekrutteringstreffModal.tsx",
                    lineNumber: 88,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/rekrutteringstreff/[rekrutteringstreffId]/finn-kandidater/_ui/lagre-i-rekrutteringstreff/LagreIRekrutteringstreffModal.tsx",
                lineNumber: 87,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"].Footer, {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                        disabled: laster || selectedRows.length === 0,
                        type: "button",
                        size: "small",
                        loading: laster,
                        onClick: ()=>void lagreKandidater(selectedRows),
                        children: "Lagre"
                    }, void 0, false, {
                        fileName: "[project]/app/rekrutteringstreff/[rekrutteringstreffId]/finn-kandidater/_ui/lagre-i-rekrutteringstreff/LagreIRekrutteringstreffModal.tsx",
                        lineNumber: 176,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                        disabled: laster,
                        type: "button",
                        size: "small",
                        variant: "secondary",
                        onClick: onClose,
                        children: "Avbryt"
                    }, void 0, false, {
                        fileName: "[project]/app/rekrutteringstreff/[rekrutteringstreffId]/finn-kandidater/_ui/lagre-i-rekrutteringstreff/LagreIRekrutteringstreffModal.tsx",
                        lineNumber: 185,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/rekrutteringstreff/[rekrutteringstreffId]/finn-kandidater/_ui/lagre-i-rekrutteringstreff/LagreIRekrutteringstreffModal.tsx",
                lineNumber: 175,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/rekrutteringstreff/[rekrutteringstreffId]/finn-kandidater/_ui/lagre-i-rekrutteringstreff/LagreIRekrutteringstreffModal.tsx",
        lineNumber: 75,
        columnNumber: 5
    }, this);
}
_s(LagreIRekrutteringstreffModal, "xLjdH7IRXYRLEOlIHit/kusGs5M=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$ApplikasjonContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useApplikasjonContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$kandidat$2f$KandidatS$f8$kMarkerteContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useKandidatSøkMarkerteContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$rekrutteringstreff$2f5b2e2e2e$slug$5d2f$jobbs$f8$kere$2f$useJobbs$f8$kere$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useJobbsøkere"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$rekrutteringstreff$2f$mittkontor$2f$useRekrutteringstreffMittKontor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRekrutteringstreffMittKontor"]
    ];
});
_c = LagreIRekrutteringstreffModal;
var _c;
__turbopack_context__.k.register(_c, "LagreIRekrutteringstreffModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/rekrutteringstreff/[rekrutteringstreffId]/finn-kandidater/_ui/lagre-i-rekrutteringstreff/LagreIRekrutteringstreffKnapp.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$rekrutteringstreff$2f5b$rekrutteringstreffId$5d2f$finn$2d$kandidater$2f$_ui$2f$lagre$2d$i$2d$rekrutteringstreff$2f$lagre$2d$i$2d$rekrutteringstreff$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/rekrutteringstreff/[rekrutteringstreffId]/finn-kandidater/_ui/lagre-i-rekrutteringstreff/lagre-i-rekrutteringstreff.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$rekrutteringstreff$2f5b2e2e2e$slug$5d2f$jobbs$f8$kere$2f$useJobbs$f8$kere$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/rekrutteringstreff/[...slug]/jobbsøkere/useJobbsøkere.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$kandidat$2f$KandidatS$f8$kMarkerteContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/kandidat/KandidatSøkMarkerteContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$rekrutteringstreff$2f5b$rekrutteringstreffId$5d2f$finn$2d$kandidater$2f$_ui$2f$lagre$2d$i$2d$rekrutteringstreff$2f$LagreIRekrutteringstreffModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/rekrutteringstreff/[rekrutteringstreffId]/finn-kandidater/_ui/lagre-i-rekrutteringstreff/LagreIRekrutteringstreffModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$lenke$2d$kort$2f$LenkeKortMedIkon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/lenke-kort/LenkeKortMedIkon.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$ApplikasjonContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/providers/ApplikasjonContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$PersonPlus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PersonPlusIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/PersonPlus.js [app-client] (ecmascript) <export default as PersonPlusIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
const LagreIRekrutteringstreffKnapp = ({ rekrutteringstreffId, kandidatsokKandidater, lenkeKort })=>{
    _s();
    const [visModal, setVisModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [laster, setLaster] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const { visVarsel } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$ApplikasjonContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useApplikasjonContext"])();
    const { markerteKandidater, fjernMarkerteKandidater } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$kandidat$2f$KandidatS$f8$kMarkerteContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useKandidatSøkMarkerteContext"])();
    const jobbsøkerHook = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$rekrutteringstreff$2f5b2e2e2e$slug$5d2f$jobbs$f8$kere$2f$useJobbs$f8$kere$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useJobbsøkere"])(rekrutteringstreffId);
    const lagreKandidater = async (valgteTreff)=>{
        setLaster(true);
        const resultat = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$rekrutteringstreff$2f5b$rekrutteringstreffId$5d2f$finn$2d$kandidater$2f$_ui$2f$lagre$2d$i$2d$rekrutteringstreff$2f$lagre$2d$i$2d$rekrutteringstreff$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["lagreKandidaterIRekrutteringstreff"])({
            markerteKandidater,
            kandidatsokKandidater,
            rekrutteringstreffId,
            selectedRows: valgteTreff
        }, {
            visVarsel,
            fjernMarkerteKandidater,
            mutateJobbsøkere: jobbsøkerHook.mutate
        });
        setLaster(false);
        if (resultat.suksess) {
            setVisModal(false);
            if (rekrutteringstreffId) {
                router.push(`/rekrutteringstreff/${rekrutteringstreffId}?visFane=jobbsøkere`);
            }
        }
    };
    const handleButtonClick = ()=>{
        if (rekrutteringstreffId) {
            void lagreKandidater();
        } else {
            setVisModal(true);
        }
    };
    const lagreKandidaterDirekte = async ()=>{
        const kandidatnumre = kandidatsokKandidater.map((k)=>k.arenaKandidatnr).filter(Boolean);
        setLaster(true);
        const resultat = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$rekrutteringstreff$2f5b$rekrutteringstreffId$5d2f$finn$2d$kandidater$2f$_ui$2f$lagre$2d$i$2d$rekrutteringstreff$2f$lagre$2d$i$2d$rekrutteringstreff$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["lagreKandidaterIRekrutteringstreff"])({
            markerteKandidater: kandidatnumre,
            kandidatsokKandidater,
            rekrutteringstreffId
        }, {
            visVarsel,
            fjernMarkerteKandidater,
            mutateJobbsøkere: jobbsøkerHook.mutate
        });
        setLaster(false);
        if (resultat.suksess && rekrutteringstreffId) {
            router.push(`/rekrutteringstreff/${rekrutteringstreffId}?visFane=jobbsøkere`);
        }
    };
    if (lenkeKort) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$lenke$2d$kort$2f$LenkeKortMedIkon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            onClick: lagreKandidaterDirekte,
            loading: laster,
            tittel: "Legg til jobbsøker i rekrutteringstreff",
            beskrivelse: "Lagrer valgt jobbsøker i listen for rekrutteringstreff",
            ikon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$PersonPlus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PersonPlusIcon$3e$__["PersonPlusIcon"], {
                "aria-hidden": true
            }, void 0, false, {
                fileName: "[project]/app/rekrutteringstreff/[rekrutteringstreffId]/finn-kandidater/_ui/lagre-i-rekrutteringstreff/LagreIRekrutteringstreffKnapp.tsx",
                lineNumber: 103,
                columnNumber: 15
            }, void 0)
        }, void 0, false, {
            fileName: "[project]/app/rekrutteringstreff/[rekrutteringstreffId]/finn-kandidater/_ui/lagre-i-rekrutteringstreff/LagreIRekrutteringstreffKnapp.tsx",
            lineNumber: 98,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0));
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                size: "small",
                variant: "tertiary",
                onClick: handleButtonClick,
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$PersonPlus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PersonPlusIcon$3e$__["PersonPlusIcon"], {
                    "aria-hidden": true
                }, void 0, false, {
                    fileName: "[project]/app/rekrutteringstreff/[rekrutteringstreffId]/finn-kandidater/_ui/lagre-i-rekrutteringstreff/LagreIRekrutteringstreffKnapp.tsx",
                    lineNumber: 114,
                    columnNumber: 15
                }, void 0),
                disabled: markerteKandidater?.length === 0 || laster,
                loading: laster,
                children: rekrutteringstreffId ? 'Legg til jobbsøkere og fullfør' : 'Lagre i rekrutteringstreff'
            }, void 0, false, {
                fileName: "[project]/app/rekrutteringstreff/[rekrutteringstreffId]/finn-kandidater/_ui/lagre-i-rekrutteringstreff/LagreIRekrutteringstreffKnapp.tsx",
                lineNumber: 110,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            visModal && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$rekrutteringstreff$2f5b$rekrutteringstreffId$5d2f$finn$2d$kandidater$2f$_ui$2f$lagre$2d$i$2d$rekrutteringstreff$2f$LagreIRekrutteringstreffModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                kandidatsokKandidater: [],
                onClose: ()=>setVisModal(false)
            }, void 0, false, {
                fileName: "[project]/app/rekrutteringstreff/[rekrutteringstreffId]/finn-kandidater/_ui/lagre-i-rekrutteringstreff/LagreIRekrutteringstreffKnapp.tsx",
                lineNumber: 123,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true);
};
_s(LagreIRekrutteringstreffKnapp, "hng1aRLktgqV+EQxOAp5HqVGFZk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$ApplikasjonContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useApplikasjonContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$kandidat$2f$KandidatS$f8$kMarkerteContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useKandidatSøkMarkerteContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$rekrutteringstreff$2f5b2e2e2e$slug$5d2f$jobbs$f8$kere$2f$useJobbs$f8$kere$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useJobbsøkere"]
    ];
});
_c = LagreIRekrutteringstreffKnapp;
const __TURBOPACK__default__export__ = LagreIRekrutteringstreffKnapp;
var _c;
__turbopack_context__.k.register(_c, "LagreIRekrutteringstreffKnapp");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/rekrutteringstreff/_providers/RekrutteringstreffContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RekrutteringstreffProvider",
    ()=>RekrutteringstreffProvider,
    "useNullableRekrutteringstreffContext",
    ()=>useNullableRekrutteringstreffContext,
    "useRekrutteringstreffContext",
    ()=>useRekrutteringstreffContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$rekbisError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/util/rekbisError.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
;
const RekrutteringstreffContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
const RekrutteringstreffProvider = ({ children, rekrutteringstreffId })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(RekrutteringstreffContext.Provider, {
        value: {
            rekrutteringstreffId
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/app/rekrutteringstreff/_providers/RekrutteringstreffContext.tsx",
        lineNumber: 24,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = RekrutteringstreffProvider;
const useNullableRekrutteringstreffContext = ()=>{
    _s();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(RekrutteringstreffContext);
    if (context === undefined) {
        return null;
    }
    return context;
};
_s(useNullableRekrutteringstreffContext, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
const useRekrutteringstreffContext = ()=>{
    _s1();
    const contekst = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(RekrutteringstreffContext);
    if (!contekst) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$rekbisError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RekbisError"]({
            message: 'useRekrutteringstreffContext må være i scope: RekrutteringstreffProvider'
        });
    }
    if (!contekst.rekrutteringstreffId) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$rekbisError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RekbisError"]({
            message: 'RekrutteringstreffId mangler i conteksten!'
        });
    }
    return contekst;
};
_s1(useRekrutteringstreffContext, "627IX5aF2GJLmvS2KzIRz/8v0Nk=");
var _c;
__turbopack_context__.k.register(_c, "RekrutteringstreffProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=app_6d85dcc1._.js.map