(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/app/stilling/[stillingsId]/kandidatliste/KandidatTyper.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "InternKandidatstatus",
    ()=>InternKandidatstatus,
    "KandidatutfallTyper",
    ()=>KandidatutfallTyper,
    "TilstandPåForespørsel",
    ()=>TilstandPåForespørsel
]);
var KandidatutfallTyper = /*#__PURE__*/ function(KandidatutfallTyper) {
    KandidatutfallTyper["IKKE_PRESENTERT"] = "IKKE_PRESENTERT";
    KandidatutfallTyper["PRESENTERT"] = "PRESENTERT";
    KandidatutfallTyper["FATT_JOBBEN"] = "FATT_JOBBEN";
    return KandidatutfallTyper;
}({});
var TilstandPåForespørsel = /*#__PURE__*/ function(TilstandPåForespørsel) {
    TilstandPåForespørsel["KAN_IKKE_OPPRETTE"] = "KAN_IKKE_OPPRETTE";
    TilstandPåForespørsel["PROVER_VARSLING"] = "PROVER_VARSLING";
    TilstandPåForespørsel["HAR_VARSLET"] = "HAR_VARSLET";
    TilstandPåForespørsel["KAN_IKKE_VARSLE"] = "KAN_IKKE_VARSLE";
    TilstandPåForespørsel["HAR_SVART"] = "HAR_SVART";
    TilstandPåForespørsel["AVBRUTT"] = "AVBRUTT";
    TilstandPåForespørsel["IKKE_SENDT"] = "IKKE_SENDT";
    return TilstandPåForespørsel;
}({});
var InternKandidatstatus = /*#__PURE__*/ function(InternKandidatstatus) {
    InternKandidatstatus["VURDERES"] = "VURDERES";
    InternKandidatstatus["KONTAKTET"] = "KONTAKTET";
    InternKandidatstatus["AKTUELL"] = "AKTUELL";
    InternKandidatstatus["TIL_INTERVJU"] = "TIL_INTERVJU";
    InternKandidatstatus["UAKTUELL"] = "UAKTUELL";
    InternKandidatstatus["UINTERESSERT"] = "UINTERESSERT";
    return InternKandidatstatus;
}({});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/[stillingsId]/kandidatliste/_ui/OrganisasjonsnummerAlert.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/alert/Alert.js [app-client] (ecmascript) <export default as Alert>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyLong$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyLong$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/BodyLong.js [app-client] (ecmascript) <export default as BodyLong>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$Heading$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Heading$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/Heading.js [app-client] (ecmascript) <export default as Heading>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$link$2f$Link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Link$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/link/Link.js [app-client] (ecmascript) <export default as Link>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$list$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/list/List.js [app-client] (ecmascript) <export default as List>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$layout$2f$stack$2f$VStack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__VStack$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/layout/stack/VStack.js [app-client] (ecmascript) <export default as VStack>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$layout$2f$box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/layout/box/Box.js [app-client] (ecmascript) <export default as Box>");
;
;
const OrganisasjonsnummerAlert = ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__["Alert"], {
        variant: "warning",
        className: "max-w-3xl",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$layout$2f$stack$2f$VStack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__VStack$3e$__["VStack"], {
            gap: "space-16",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$Heading$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Heading$3e$__["Heading"], {
                            level: "3",
                            size: "medium",
                            spacing: true,
                            children: "Stillingen har fått nytt organisasjonsnummer"
                        }, void 0, false, {
                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/OrganisasjonsnummerAlert.tsx",
                            lineNumber: 15,
                            columnNumber: 9
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyLong$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyLong$3e$__["BodyLong"], {
                            children: "Organisasjonsnummeret til stillingen har blitt endret i et annet system, men ikke i kandidatlisten. Det kan føre til at CVer deles med feil organisasjon, siden det ikke er mulig å endre organisasjonsnummer på kandidatlisten."
                        }, void 0, false, {
                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/OrganisasjonsnummerAlert.tsx",
                            lineNumber: 18,
                            columnNumber: 9
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/OrganisasjonsnummerAlert.tsx",
                    lineNumber: 14,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$Heading$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Heading$3e$__["Heading"], {
                            level: "4",
                            size: "small",
                            children: "Hva betyr det for meg?"
                        }, void 0, false, {
                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/OrganisasjonsnummerAlert.tsx",
                            lineNumber: 27,
                            columnNumber: 9
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyLong$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyLong$3e$__["BodyLong"], {
                            children: "Legger du til kandidater på stillingen og deler CV med arbeidsgiver blir de delt med den forrige organisasjonen. Deler du CVene deres, vil det føre til personvernsbrudd."
                        }, void 0, false, {
                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/OrganisasjonsnummerAlert.tsx",
                            lineNumber: 30,
                            columnNumber: 9
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/OrganisasjonsnummerAlert.tsx",
                    lineNumber: 26,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$Heading$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Heading$3e$__["Heading"], {
                            level: "4",
                            size: "small",
                            children: "Hva kan jeg gjøre med det?"
                        }, void 0, false, {
                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/OrganisasjonsnummerAlert.tsx",
                            lineNumber: 38,
                            columnNumber: 9
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyLong$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyLong$3e$__["BodyLong"], {
                            children: "For å dele CVene til disse kandidatene må du:"
                        }, void 0, false, {
                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/OrganisasjonsnummerAlert.tsx",
                            lineNumber: 41,
                            columnNumber: 9
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mt-4",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$layout$2f$box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                marginBlock: "space-16",
                                asChild: true,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$list$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__["List"], {
                                    "data-aksel-migrated-v8": true,
                                    as: "ol",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$list$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__["List"].Item, {
                                            children: "Slett kandidatene fra denne stillingen."
                                        }, void 0, false, {
                                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/OrganisasjonsnummerAlert.tsx",
                                            lineNumber: 45,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$list$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__["List"].Item, {
                                            children: "Opprette en direktemeldt stilling med det nye organisasjonsnummeret"
                                        }, void 0, false, {
                                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/OrganisasjonsnummerAlert.tsx",
                                            lineNumber: 46,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$list$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__["List"].Item, {
                                            children: "Legge til kandidatene igjen på den nye stillingen."
                                        }, void 0, false, {
                                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/OrganisasjonsnummerAlert.tsx",
                                            lineNumber: 50,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/OrganisasjonsnummerAlert.tsx",
                                    lineNumber: 44,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/OrganisasjonsnummerAlert.tsx",
                                lineNumber: 43,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/OrganisasjonsnummerAlert.tsx",
                            lineNumber: 42,
                            columnNumber: 9
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/OrganisasjonsnummerAlert.tsx",
                    lineNumber: 37,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$Heading$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Heading$3e$__["Heading"], {
                            level: "4",
                            size: "small",
                            children: "Hva hvis jeg har delt CVene til disse kandidatene allerede?"
                        }, void 0, false, {
                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/OrganisasjonsnummerAlert.tsx",
                            lineNumber: 59,
                            columnNumber: 9
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mt-4",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$layout$2f$box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                marginBlock: "space-16",
                                asChild: true,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$list$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__["List"], {
                                    "data-aksel-migrated-v8": true,
                                    as: "ol",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$list$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__["List"].Item, {
                                            children: 'Slett delingen: Finn kandidatene i listen, trykk på redigeringsknappen, og velg "Slett CV hos arbeidsgiver".'
                                        }, void 0, false, {
                                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/OrganisasjonsnummerAlert.tsx",
                                            lineNumber: 65,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$list$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__["List"].Item, {
                                            children: [
                                                "Meld avvik i",
                                                ' ',
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$link$2f$Link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Link$3e$__["Link"], {
                                                    target: "_blank",
                                                    rel: "noreferrer noopener",
                                                    href: "https://navno.sharepoint.com/sites/intranett-avvik",
                                                    children: "avviksrapporteringssystemet"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/OrganisasjonsnummerAlert.tsx",
                                                    lineNumber: 72,
                                                    columnNumber: 17
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                ' ',
                                                "med informasjon om hva som skjedde."
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/OrganisasjonsnummerAlert.tsx",
                                            lineNumber: 70,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/OrganisasjonsnummerAlert.tsx",
                                    lineNumber: 64,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/OrganisasjonsnummerAlert.tsx",
                                lineNumber: 63,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/OrganisasjonsnummerAlert.tsx",
                            lineNumber: 62,
                            columnNumber: 9
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/OrganisasjonsnummerAlert.tsx",
                    lineNumber: 58,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/OrganisasjonsnummerAlert.tsx",
            lineNumber: 13,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/OrganisasjonsnummerAlert.tsx",
        lineNumber: 12,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
_c = OrganisasjonsnummerAlert;
const __TURBOPACK__default__export__ = OrganisasjonsnummerAlert;
var _c;
__turbopack_context__.k.register(_c, "OrganisasjonsnummerAlert");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/KandidatHendelseTag.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "KandidatHendelseTag",
    ()=>KandidatHendelseTag,
    "KandidatHendelseType",
    ()=>KandidatHendelseType
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$ArrowUndo$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowUndoIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/ArrowUndo.js [app-client] (ecmascript) <export default as ArrowUndoIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$Calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CalendarIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/Calendar.js [app-client] (ecmascript) <export default as CalendarIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$ChatCheckmark$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChatCheckmarkIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/ChatCheckmark.js [app-client] (ecmascript) <export default as ChatCheckmarkIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$ChatExclamationmark$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChatExclamationmarkIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/ChatExclamationmark.js [app-client] (ecmascript) <export default as ChatExclamationmarkIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$ExclamationmarkTriangle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ExclamationmarkTriangleIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/ExclamationmarkTriangle.js [app-client] (ecmascript) <export default as ExclamationmarkTriangleIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$FileXMark$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FileXMarkIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/FileXMark.js [app-client] (ecmascript) <export default as FileXMarkIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$HandShakeHeart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__HandShakeHeartIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/HandShakeHeart.js [app-client] (ecmascript) <export default as HandShakeHeartIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$Paperplane$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PaperplaneIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/Paperplane.js [app-client] (ecmascript) <export default as PaperplaneIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TableIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/Table.js [app-client] (ecmascript) <export default as TableIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$ThumbDown$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ThumbDownIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/ThumbDown.js [app-client] (ecmascript) <export default as ThumbDownIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$ThumbUp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ThumbUpIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/ThumbUp.js [app-client] (ecmascript) <export default as ThumbUpIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$Trash$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TrashIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/Trash.js [app-client] (ecmascript) <export default as TrashIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tag$2f$Tag$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tag$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/tag/Tag.js [app-client] (ecmascript) <export default as Tag>");
;
;
;
var KandidatHendelseType = /*#__PURE__*/ function(KandidatHendelseType) {
    KandidatHendelseType["Spurt_om_å_dele_CV"] = "Spurt om å dele CV: Frist";
    KandidatHendelseType["Spurt_om_å_dele_CV_IKKE_DIGITAL"] = "Spurt om å dele CV (ikke digital): Frist";
    KandidatHendelseType["Deling_Av_CV_Feilet"] = "Deling av CV feilet";
    KandidatHendelseType["Deling_av_CV_JA"] = "Deling av CV: Ja";
    KandidatHendelseType["Deling_av_CV_NEI"] = "Deling av CV: Nei";
    KandidatHendelseType["Frist_for_deling_av_cv_utløpt"] = "Frist for deling av CV utløpt";
    KandidatHendelseType["CV_delt_med_arbeidsgiver"] = "CV delt med arbeidsgiver";
    KandidatHendelseType["Fått_jobben"] = "Fått jobben";
    KandidatHendelseType["Avbrutt_i_aktivitetsplanen"] = "Avbrutt i aktivitetsplanen";
    KandidatHendelseType["Fjernet_fått_jobben"] = "Fjernet fått jobben";
    KandidatHendelseType["Slettet"] = "Slettet";
    KandidatHendelseType["CV_slettet_hos_arbeidsgiver"] = "CV slettet hos arbeidsgiver";
    KandidatHendelseType["SMS_OK"] = "SMS";
    KandidatHendelseType["SMS_FEIL"] = "SMS feilet";
    KandidatHendelseType["PRESENTERT"] = "PRESENTERT";
    KandidatHendelseType["IKKE_PRESENTERT"] = "IKKE_PRESENTERT";
    return KandidatHendelseType;
}({});
const hendelseVariant = (type)=>{
    switch(type){
        case "Spurt om å dele CV: Frist":
            return 'neutral';
        case "Deling av CV feilet":
        case "Spurt om å dele CV (ikke digital): Frist":
        case "Fjernet fått jobben":
            return 'warning';
        case "Deling av CV: Ja":
            return 'success-moderate';
        case "Deling av CV: Nei":
            return 'error-moderate';
        case "Frist for deling av CV utløpt":
            return 'warning-moderate';
        case "CV delt med arbeidsgiver":
            return 'info-moderate';
        case "Fått jobben":
            return 'success';
        case "Avbrutt i aktivitetsplanen":
            return 'error';
        case "Slettet":
            return 'alt2-moderate';
        case "CV slettet hos arbeidsgiver":
            return 'alt2';
        case "SMS":
            return 'success-filled';
        case "SMS feilet":
            return 'error-filled';
        default:
            return 'alt1-filled';
    }
};
const hendelseIkon = (type)=>{
    switch(type){
        case "Spurt om å dele CV: Frist":
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TableIcon$3e$__["TableIcon"], {}, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/KandidatHendelseTag.tsx",
                lineNumber: 73,
                columnNumber: 14
            }, ("TURBOPACK compile-time value", void 0));
        case "Deling av CV feilet":
        case "Avbrutt i aktivitetsplanen":
        case "Spurt om å dele CV (ikke digital): Frist":
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$ExclamationmarkTriangle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ExclamationmarkTriangleIcon$3e$__["ExclamationmarkTriangleIcon"], {}, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/KandidatHendelseTag.tsx",
                lineNumber: 77,
                columnNumber: 14
            }, ("TURBOPACK compile-time value", void 0));
        case "Deling av CV: Ja":
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$ThumbUp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ThumbUpIcon$3e$__["ThumbUpIcon"], {}, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/KandidatHendelseTag.tsx",
                lineNumber: 79,
                columnNumber: 14
            }, ("TURBOPACK compile-time value", void 0));
        case "Deling av CV: Nei":
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$ThumbDown$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ThumbDownIcon$3e$__["ThumbDownIcon"], {}, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/KandidatHendelseTag.tsx",
                lineNumber: 81,
                columnNumber: 14
            }, ("TURBOPACK compile-time value", void 0));
        case "Frist for deling av CV utløpt":
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$Calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CalendarIcon$3e$__["CalendarIcon"], {}, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/KandidatHendelseTag.tsx",
                lineNumber: 83,
                columnNumber: 14
            }, ("TURBOPACK compile-time value", void 0));
        case "CV delt med arbeidsgiver":
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$Paperplane$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PaperplaneIcon$3e$__["PaperplaneIcon"], {}, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/KandidatHendelseTag.tsx",
                lineNumber: 85,
                columnNumber: 14
            }, ("TURBOPACK compile-time value", void 0));
        case "Fått jobben":
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$HandShakeHeart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__HandShakeHeartIcon$3e$__["HandShakeHeartIcon"], {}, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/KandidatHendelseTag.tsx",
                lineNumber: 87,
                columnNumber: 14
            }, ("TURBOPACK compile-time value", void 0));
        case "Fjernet fått jobben":
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$ArrowUndo$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowUndoIcon$3e$__["ArrowUndoIcon"], {}, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/KandidatHendelseTag.tsx",
                lineNumber: 89,
                columnNumber: 14
            }, ("TURBOPACK compile-time value", void 0));
        case "Slettet":
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$Trash$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TrashIcon$3e$__["TrashIcon"], {}, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/KandidatHendelseTag.tsx",
                lineNumber: 91,
                columnNumber: 14
            }, ("TURBOPACK compile-time value", void 0));
        case "CV slettet hos arbeidsgiver":
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$FileXMark$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FileXMarkIcon$3e$__["FileXMarkIcon"], {}, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/KandidatHendelseTag.tsx",
                lineNumber: 93,
                columnNumber: 14
            }, ("TURBOPACK compile-time value", void 0));
        case "SMS":
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$ChatCheckmark$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChatCheckmarkIcon$3e$__["ChatCheckmarkIcon"], {}, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/KandidatHendelseTag.tsx",
                lineNumber: 95,
                columnNumber: 14
            }, ("TURBOPACK compile-time value", void 0));
        case "SMS feilet":
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$ChatExclamationmark$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChatExclamationmarkIcon$3e$__["ChatExclamationmarkIcon"], {}, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/KandidatHendelseTag.tsx",
                lineNumber: 97,
                columnNumber: 14
            }, ("TURBOPACK compile-time value", void 0));
        default:
            return null;
    }
};
const KandidatHendelseTag = ({ type, dato })=>{
    if (!type) {
        return null;
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tag$2f$Tag$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tag$3e$__["Tag"], {
        variant: hendelseVariant(type),
        icon: hendelseIkon(type),
        className: "inline-flex",
        size: "small",
        children: [
            type,
            " ",
            dato
        ]
    }, void 0, true, {
        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/KandidatHendelseTag.tsx",
        lineNumber: 115,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = KandidatHendelseTag;
var _c;
__turbopack_context__.k.register(_c, "KandidatHendelseTag");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/mapCVhendelers.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "mapCVHendele",
    ()=>mapCVHendele
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/KandidatHendelseTag.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/KandidatTyper.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$dato$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/util/dato.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$isBefore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/isBefore.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$parseISO$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/parseISO.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns-tz@3.2.0_date-fns@4.1.0/node_modules/date-fns-tz/dist/esm/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$formatInTimeZone$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns-tz@3.2.0_date-fns@4.1.0/node_modules/date-fns-tz/dist/esm/formatInTimeZone/index.js [app-client] (ecmascript)");
;
;
;
;
;
;
const mapCVHendele = (forespørsel)=>{
    // Svarfrist er zulu tid og er ved midnatt, så må formateres for å vise riktig dato
    const svarfristISOTid = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$parseISO$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseISO"])(forespørsel.svarfrist);
    const svarFrist = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$formatInTimeZone$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatInTimeZone"])(svarfristISOTid, 'UTC', 'dd.MM.yy');
    const svarTidspunktISO = forespørsel.svar?.svarTidspunkt ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$parseISO$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseISO"])(forespørsel.svar.svarTidspunkt) : null;
    const svarTidspunkt = svarTidspunktISO ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$2d$tz$40$3$2e$2$2e$0_date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2d$tz$2f$dist$2f$esm$2f$formatInTimeZone$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatInTimeZone"])(svarTidspunktISO, 'UTC', 'dd.MM.yy') : null;
    const erFristUtløpt = forespørsel.svarfrist ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$isBefore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isBefore"])(new Date(forespørsel.svarfrist), new Date()) : false;
    const defaultData = {
        dato: new Date(forespørsel.deltTidspunkt),
        raw: forespørsel
    };
    switch(forespørsel.tilstand){
        case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TilstandPåForespørsel"].IKKE_SENDT:
        case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TilstandPåForespørsel"].PROVER_VARSLING:
            return {
                tag: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseTag"], {
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseType"].Spurt_om_å_dele_CV,
                    dato: svarFrist
                }, void 0, false, {
                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/mapCVhendelers.tsx",
                    lineNumber: 39,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0)),
                type: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseType"].Spurt_om_å_dele_CV,
                tekst: 'Prøver varsling',
                ...defaultData
            };
        case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TilstandPåForespørsel"].HAR_VARSLET:
            return {
                tag: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseTag"], {
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseType"].Spurt_om_å_dele_CV,
                    dato: svarFrist
                }, void 0, false, {
                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/mapCVhendelers.tsx",
                    lineNumber: 51,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0)),
                type: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseType"].Spurt_om_å_dele_CV,
                dato: new Date(forespørsel.deltTidspunkt),
                tekst: `av ${forespørsel.deltAv}`,
                raw: forespørsel
            };
        case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TilstandPåForespørsel"].KAN_IKKE_VARSLE:
            return {
                tag: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseTag"], {
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseType"].Spurt_om_å_dele_CV_IKKE_DIGITAL,
                    dato: svarFrist
                }, void 0, false, {
                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/mapCVhendelers.tsx",
                    lineNumber: 64,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0)),
                type: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseType"].Spurt_om_å_dele_CV_IKKE_DIGITAL,
                tekst: 'Kandidaten bruker ikke digitale tjenester fra Nav. Du må ringe og registrere svaret i stillingskortet i Aktivitetsplanen.',
                ...defaultData
            };
        case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TilstandPåForespørsel"].KAN_IKKE_OPPRETTE:
            return {
                tag: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseTag"], {
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseType"].Deling_Av_CV_Feilet,
                    dato: svarFrist
                }, void 0, false, {
                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/mapCVhendelers.tsx",
                    lineNumber: 77,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0)),
                type: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseType"].Deling_Av_CV_Feilet,
                tekst: 'Kan ikke opprette forespørsel',
                ...defaultData
            };
        case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TilstandPåForespørsel"].AVBRUTT:
            if (forespørsel.deltStatus === 'SENDT' && erFristUtløpt) {
                return {
                    tag: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseTag"], {
                        type: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseType"].Frist_for_deling_av_cv_utløpt,
                        dato: svarFrist
                    }, void 0, false, {
                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/mapCVhendelers.tsx",
                        lineNumber: 90,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0)),
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseType"].Frist_for_deling_av_cv_utløpt,
                    tekst: `Frist for deling av CV utløpt ${forespørsel.svarfrist && (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$dato$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formaterNorskDato"])({
                        dato: forespørsel.svarfrist
                    })}`,
                    ...defaultData
                };
            }
            return {
                type: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseType"].Avbrutt_i_aktivitetsplanen,
                tag: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseTag"], {
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseType"].Avbrutt_i_aktivitetsplanen
                }, void 0, false, {
                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/mapCVhendelers.tsx",
                    lineNumber: 103,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0)),
                ...defaultData
            };
        case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TilstandPåForespørsel"].HAR_SVART:
            if (forespørsel.svar?.harSvartJa) {
                return {
                    tag: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseTag"], {
                        type: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseType"].Deling_av_CV_JA,
                        dato: svarTidspunkt
                    }, void 0, false, {
                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/mapCVhendelers.tsx",
                        lineNumber: 113,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0)),
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseType"].Deling_av_CV_JA,
                    tekst: `${forespørsel.svar?.svartAv.ident && `svart av ${forespørsel.svar?.svartAv.ident}`} ${forespørsel.svar?.svarTidspunkt && (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$dato$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formaterNorskDato"])({
                        dato: forespørsel.svar?.svarTidspunkt
                    })}`,
                    ...defaultData
                };
            } else {
                return {
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseType"].Deling_av_CV_NEI,
                    tag: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseTag"], {
                        type: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseType"].Deling_av_CV_NEI,
                        dato: svarTidspunkt
                    }, void 0, false, {
                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/mapCVhendelers.tsx",
                        lineNumber: 126,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0)),
                    tekst: `${forespørsel.svar?.svartAv.ident && `svart av ${forespørsel.svar?.svartAv.ident}`} ${forespørsel.svar?.svarTidspunkt && (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$dato$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formaterNorskDato"])({
                        dato: forespørsel.svar?.svarTidspunkt
                    })}`,
                    ...defaultData
                };
            }
        default:
            return {
                type: null,
                tag: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseTag"], {
                    type: null
                }, void 0, false, {
                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/mapCVhendelers.tsx",
                    lineNumber: 138,
                    columnNumber: 14
                }, ("TURBOPACK compile-time value", void 0)),
                ...defaultData
            };
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/mapUtfallsendringer.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "mapUtfallsendringer",
    ()=>mapUtfallsendringer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/KandidatHendelseTag.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/KandidatTyper.ts [app-client] (ecmascript)");
;
;
;
const mapUtfallsendringer = (utfallseendring, cvErBlittDelt = false, alleUtfallsendringer, index)=>{
    const defaultData = {
        dato: new Date(utfallseendring.tidspunkt),
        raw: utfallseendring
    };
    // Sjekk om dette er en "fjernet fått jobben" hendelse
    const fjernetFåttJobben = alleUtfallsendringer && index === 0 && alleUtfallsendringer.length >= 2 && utfallseendring.utfall === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatutfallTyper"].PRESENTERT && alleUtfallsendringer[1].utfall === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatutfallTyper"].FATT_JOBBEN;
    if (fjernetFåttJobben) {
        return {
            type: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseType"].Fjernet_fått_jobben,
            ...defaultData,
            tag: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseTag"], {
                type: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseType"].Fjernet_fått_jobben
            }, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/mapUtfallsendringer.tsx",
                lineNumber: 33,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            tekst: ''
        };
    }
    switch(utfallseendring.utfall){
        case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatutfallTyper"].FATT_JOBBEN:
            return {
                type: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseType"].Fått_jobben,
                ...defaultData,
                tag: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseTag"], {
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseType"].Fått_jobben
                }, void 0, false, {
                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/mapUtfallsendringer.tsx",
                    lineNumber: 44,
                    columnNumber: 14
                }, ("TURBOPACK compile-time value", void 0))
            };
        case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatutfallTyper"].IKKE_PRESENTERT:
            if (utfallseendring.sendtTilArbeidsgiversKandidatliste === false && cvErBlittDelt) {
                return {
                    ...defaultData,
                    tag: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseTag"], {
                        type: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseType"].CV_slettet_hos_arbeidsgiver
                    }, void 0, false, {
                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/mapUtfallsendringer.tsx",
                        lineNumber: 54,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0)),
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseType"].CV_slettet_hos_arbeidsgiver,
                    tekst: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseType"].CV_slettet_hos_arbeidsgiver
                };
            }
            return {
                type: null,
                ...defaultData
            };
        case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatutfallTyper"].PRESENTERT:
            if (utfallseendring.sendtTilArbeidsgiversKandidatliste) {
                return {
                    ...defaultData,
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseType"].CV_delt_med_arbeidsgiver,
                    tag: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseTag"], {
                        type: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseType"].CV_delt_med_arbeidsgiver
                    }, void 0, false, {
                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/mapUtfallsendringer.tsx",
                        lineNumber: 72,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0))
                };
            }
            return {
                ...defaultData,
                type: null
            };
        default:
            return {
                ...defaultData,
                type: null,
                tag: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseTag"], {
                    type: null
                }, void 0, false, {
                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/mapUtfallsendringer.tsx",
                    lineNumber: 83,
                    columnNumber: 14
                }, ("TURBOPACK compile-time value", void 0))
            };
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/mapTilKandidatHendelser.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "mapTilKandidatHendelser",
    ()=>mapTilKandidatHendelser
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/KandidatHendelseTag.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$mapCVhendelers$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/mapCVhendelers.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$mapUtfallsendringer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/mapUtfallsendringer.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$kandidat$2f$util$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/kandidat/util.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/KandidatTyper.ts [app-client] (ecmascript)");
;
;
;
;
;
;
const mapTilKandidatHendelser = ({ kandidat, forespørselCvForKandidat, beskjedForKandidat })=>{
    const cvErBlittDelt = kandidat.utfallsendringer?.some((endring)=>endring.utfall === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatutfallTyper"].PRESENTERT && endring.sendtTilArbeidsgiversKandidatliste);
    const utfallsendringer = kandidat.utfallsendringer?.map((endring, index)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$mapUtfallsendringer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mapUtfallsendringer"])(endring, cvErBlittDelt, kandidat.utfallsendringer, index));
    const cvHendelser = forespørselCvForKandidat?.map((forespørsel)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$mapCVhendelers$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mapCVHendele"])(forespørsel));
    // Det er foreløpig bare en varsel hendelse.
    let varsel = null;
    if (beskjedForKandidat !== null && beskjedForKandidat?.opprettet) {
        varsel = {
            type: beskjedForKandidat?.eksternStatus?.includes('FEIL') ? __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseType"].SMS_FEIL : __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseType"].SMS_OK,
            tag: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseTag"], {
                type: beskjedForKandidat?.eksternStatus?.includes('FEIL') ? __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseType"].SMS_FEIL : __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseType"].SMS_OK
            }, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/mapTilKandidatHendelser.tsx",
                lineNumber: 54,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            tekst: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$kandidat$2f$util$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storForbokstavString"])((beskjedForKandidat?.eksternFeilmelding || '').replace(/[_-]/g, ' ')),
            dato: new Date(beskjedForKandidat?.opprettet),
            raw: beskjedForKandidat
        };
    }
    const varsler = varsel ? [
        varsel
    ] : [];
    const sisteHendelse = [
        ...cvHendelser ?? [],
        ...utfallsendringer ?? []
    ].filter((hendelse)=>hendelse.type !== null).sort((a, b)=>(b.dato?.getTime() || 0) - (a.dato?.getTime() || 0))[0];
    const sisteSms = varsler ? varsler.sort((a, b)=>(b.dato?.getTime() || 0) - (a.dato?.getTime() || 0))[0] : null;
    const kandidatHendelser = {
        utfallsendringer,
        cvHendelser,
        varsler,
        sisteSms,
        sisteHendelse
    };
    return kandidatHendelser;
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/[stillingsId]/kandidatliste/util.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "mapKandidatListeKandidatTilVisning",
    ()=>mapKandidatListeKandidatTilVisning
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$mapTilKandidatHendelser$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/mapTilKandidatHendelser.tsx [app-client] (ecmascript)");
;
const mapKandidatListeKandidatTilVisning = (kandidat, forespurteKandidater, beskjeder)=>{
    const forespørselCvForKandidat = kandidat.aktørid && forespurteKandidater ? forespurteKandidater[kandidat.aktørid] : null;
    const beskjedForKandidat = beskjeder && beskjeder[kandidat.fodselsnr ?? ''];
    const kandidatHendelser = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$mapTilKandidatHendelser$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mapTilKandidatHendelser"])({
        kandidat,
        forespørselCvForKandidat,
        beskjedForKandidat
    });
    return {
        ...kandidat,
        kandidatHendelser
    };
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/[stillingsId]/kandidatliste/KandidatlisteContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "KandidatlisteContextProvider",
    ()=>KandidatlisteContextProvider,
    "useKandidatlisteContext",
    ()=>useKandidatlisteContext,
    "useNullableKandidatlisteContext",
    ()=>useNullableKandidatlisteContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$OrganisasjonsnummerAlert$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/OrganisasjonsnummerAlert.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$util$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/util.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$StillingsContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/StillingsContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$rekbisError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/util/rekbisError.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
const KandidatListeContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
const KandidatlisteContextProvider = ({ children, kandidatliste, forespurteKandidater, beskjeder, reFetchKandidatliste })=>{
    _s();
    const { stillingsData, kandidatlisteInfo } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$StillingsContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStillingsContext"])();
    const [markerteKandidater, setMarkerteKandidater] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const lukketKandidatliste = kandidatlisteInfo?.kandidatlisteStatus === 'LUKKET';
    const organisasjonsnummerFraKandidatliste = kandidatliste?.organisasjonReferanse;
    const organisasjonsnummerFraStilling = stillingsData?.stilling?.employer?.orgnr;
    const orgnummerDivergererMellomStillingOgKandidatliste = Boolean(organisasjonsnummerFraKandidatliste && organisasjonsnummerFraStilling && organisasjonsnummerFraKandidatliste !== organisasjonsnummerFraStilling);
    const toggleMarkerKandidat = (kandidat)=>{
        if (setMarkerteKandidater && markerteKandidater) {
            const nyListe = markerteKandidater.some((k)=>k.fodselsnr === kandidat.fodselsnr) ? markerteKandidater.filter((k)=>k.fodselsnr !== kandidat.fodselsnr) : [
                ...markerteKandidater,
                kandidat
            ];
            setMarkerteKandidater(nyListe);
        }
    };
    const kandidater = kandidatliste.kandidater ? kandidatliste.kandidater.map((kandidat)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$util$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mapKandidatListeKandidatTilVisning"])(kandidat, forespurteKandidater, beskjeder)) : [];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(KandidatListeContext.Provider, {
        value: {
            forespurteKandidater,
            beskjeder,
            markerteKandidater,
            setMarkerteKandidater,
            lukketKandidatliste,
            reFetchKandidatliste,
            toggleMarkerKandidat,
            kandidatlisteId: kandidatliste.kandidatlisteId,
            usynligeKandidater: kandidatliste.formidlingerAvUsynligKandidat,
            kandidater,
            kandidatlisteRawData: kandidatliste
        },
        children: [
            orgnummerDivergererMellomStillingOgKandidatliste && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$OrganisasjonsnummerAlert$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/KandidatlisteContext.tsx",
                lineNumber: 109,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            children
        ]
    }, void 0, true, {
        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/KandidatlisteContext.tsx",
        lineNumber: 93,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(KandidatlisteContextProvider, "qgol/ZDHduQsJqIM7ZMfh7HnLNA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$StillingsContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStillingsContext"]
    ];
});
_c = KandidatlisteContextProvider;
const useNullableKandidatlisteContext = ()=>{
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(KandidatListeContext);
    if (context === undefined) {
        return null;
    }
    return context;
};
_s1(useNullableKandidatlisteContext, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
const useKandidatlisteContext = ()=>{
    _s2();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(KandidatListeContext);
    if (context === undefined) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$rekbisError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RekbisError"]({
            message: 'Context er undefined, må være children av KandidatlisteContextProvider.'
        });
    }
    return context;
};
_s2(useKandidatlisteContext, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_context__.k.register(_c, "KandidatlisteContextProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/_ui/KandidatCheckbox.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatlisteContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/KandidatlisteContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$checkbox$2f$Checkbox$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Checkbox$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/checkbox/Checkbox.js [app-client] (ecmascript) <export default as Checkbox>");
;
var _s = __turbopack_context__.k.signature();
;
;
const KandidatCheckbox = ({ kandidat, slettet })=>{
    _s();
    const { markerteKandidater, toggleMarkerKandidat, lukketKandidatliste } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatlisteContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useKandidatlisteContext"])();
    if (!kandidat || slettet) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$checkbox$2f$Checkbox$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Checkbox$3e$__["Checkbox"], {
            hideLabel: true,
            disabled: true,
            children: ' '
        }, void 0, false, {
            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/_ui/KandidatCheckbox.tsx",
            lineNumber: 17,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0));
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$checkbox$2f$Checkbox$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Checkbox$3e$__["Checkbox"], {
        hideLabel: true,
        disabled: !kandidat.fodselsnr || lukketKandidatliste,
        checked: markerteKandidater.some((k)=>k.fodselsnr === kandidat.fodselsnr),
        onChange: ()=>toggleMarkerKandidat(kandidat),
        "aria-labelledby": `id-${kandidat.fornavn}-${kandidat.etternavn}`,
        children: ' '
    }, kandidat.fodselsdato, false, {
        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/_ui/KandidatCheckbox.tsx",
        lineNumber: 24,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(KandidatCheckbox, "Ez46cl7FVAh5osc4p92iRQgG39o=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatlisteContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useKandidatlisteContext"]
    ];
});
_c = KandidatCheckbox;
const __TURBOPACK__default__export__ = KandidatCheckbox;
var _c;
__turbopack_context__.k.register(_c, "KandidatCheckbox");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/[stillingsId]/kandidatliste/_ui/EndreArkivertStatusModal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "EndreArkivertStatusKnapp",
    ()=>EndreArkivertStatusKnapp,
    "EndreArkivertStatusModal",
    ()=>EndreArkivertStatusModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/api-routes.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/fetcher.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatlisteContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/KandidatlisteContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$ApplikasjonContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/providers/ApplikasjonContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$rekbisError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/util/rekbisError.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$ArrowUndo$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowUndoIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/ArrowUndo.js [app-client] (ecmascript) <export default as ArrowUndoIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$Trash$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TrashIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/Trash.js [app-client] (ecmascript) <export default as TrashIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$overlays$2f$action$2d$menu$2f$ActionMenu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/overlays/action-menu/ActionMenu.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyLong$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyLong$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/BodyLong.js [app-client] (ecmascript) <export default as BodyLong>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/modal/Modal.js [app-client] (ecmascript) <export default as Modal>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
const EndreArkivertStatusKnapp = ({ modalRef, lukketKandidatliste, actionMenu, slettet })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: actionMenu ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$overlays$2f$action$2d$menu$2f$ActionMenu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionMenu"].Item, {
            variant: "danger",
            onClick: ()=>modalRef.current?.showModal(),
            children: [
                slettet ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$ArrowUndo$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowUndoIcon$3e$__["ArrowUndoIcon"], {
                    title: "Angre sletting"
                }, void 0, false, {
                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/EndreArkivertStatusModal.tsx",
                    lineNumber: 32,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$Trash$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TrashIcon$3e$__["TrashIcon"], {
                    title: "Slett"
                }, void 0, false, {
                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/EndreArkivertStatusModal.tsx",
                    lineNumber: 34,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0)),
                ' ',
                slettet ? 'Gjenopprett' : 'Slett'
            ]
        }, void 0, true, {
            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/EndreArkivertStatusModal.tsx",
            lineNumber: 27,
            columnNumber: 9
        }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
            disabled: lukketKandidatliste,
            variant: "tertiary",
            size: "small",
            onClick: ()=>modalRef.current?.showModal(),
            icon: slettet ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$ArrowUndo$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowUndoIcon$3e$__["ArrowUndoIcon"], {
                title: "Angre sletting"
            }, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/EndreArkivertStatusModal.tsx",
                lineNumber: 46,
                columnNumber: 15
            }, void 0) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$Trash$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TrashIcon$3e$__["TrashIcon"], {
                title: "Slett"
            }, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/EndreArkivertStatusModal.tsx",
                lineNumber: 48,
                columnNumber: 15
            }, void 0),
            children: slettet ? 'Gjenopprett' : 'Slett'
        }, void 0, false, {
            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/EndreArkivertStatusModal.tsx",
            lineNumber: 39,
            columnNumber: 9
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false);
};
_c = EndreArkivertStatusKnapp;
const EndreArkivertStatusModal = ({ modalRef, kandidat, kandidatlisteId })=>{
    _s();
    const { valgtNavKontor } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$ApplikasjonContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useApplikasjonContext"])();
    const slettet = kandidat.arkivert;
    const { reFetchKandidatliste } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatlisteContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useKandidatlisteContext"])();
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const setArkivertStatus = async (status)=>{
        setIsLoading(true);
        try {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["putApi"])(`${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatAPI"].internUrl}/veileder/kandidatlister/${kandidatlisteId}/kandidater/${kandidat.kandidatnr}/arkivert`, {
                arkivert: status,
                navKontor: valgtNavKontor?.navKontor
            });
            reFetchKandidatliste();
            modalRef.current?.close();
        } catch  {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$rekbisError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RekbisError"]({
                message: 'Feil ved sletting av kandidat'
            });
        } finally{
            setIsLoading(false);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"], {
        ref: modalRef,
        header: {
            heading: 'Bekreft sletting',
            closeButton: false
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"].Body, {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyLong$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyLong$3e$__["BodyLong"], {
                    children: [
                        "Er du sikker på at du vil ",
                        slettet ? 'gjenopprette' : 'slette',
                        ' ',
                        "kandidaten ",
                        kandidat.fornavn,
                        " ",
                        kandidat.etternavn,
                        "?"
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/EndreArkivertStatusModal.tsx",
                    lineNumber: 100,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/EndreArkivertStatusModal.tsx",
                lineNumber: 99,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"].Footer, {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                        loading: isLoading,
                        type: "button",
                        onClick: ()=>setArkivertStatus(slettet ? false : true),
                        variant: slettet ? 'primary' : 'danger',
                        children: [
                            slettet ? 'Gjenopprett' : 'Slett',
                            " kandidat"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/EndreArkivertStatusModal.tsx",
                        lineNumber: 106,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                        disabled: isLoading,
                        type: "button",
                        variant: "tertiary",
                        onClick: ()=>modalRef.current?.close(),
                        children: "Avbryt"
                    }, void 0, false, {
                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/EndreArkivertStatusModal.tsx",
                        lineNumber: 115,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/EndreArkivertStatusModal.tsx",
                lineNumber: 105,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/EndreArkivertStatusModal.tsx",
        lineNumber: 95,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(EndreArkivertStatusModal, "h2kyi1XhRipOGchNiCBCc7zW8gc=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$ApplikasjonContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useApplikasjonContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatlisteContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useKandidatlisteContext"]
    ];
});
_c1 = EndreArkivertStatusModal;
var _c, _c1;
__turbopack_context__.k.register(_c, "EndreArkivertStatusKnapp");
__turbopack_context__.k.register(_c1, "EndreArkivertStatusModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/[stillingsId]/kandidatliste/_ui/FjernFåttJobbenKnapp.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/KandidatTyper.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$MinusCircle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MinusCircleIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/MinusCircle.js [app-client] (ecmascript) <export default as MinusCircleIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$overlays$2f$action$2d$menu$2f$ActionMenu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/overlays/action-menu/ActionMenu.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/button/Button.js [app-client] (ecmascript) <export default as Button>");
;
;
;
;
const FjernFåttJobbenKnapp = ({ endreUtfallForKandidat, loading, lukketKandidatliste, actionMenu })=>{
    if (actionMenu) {
        if (actionMenu) {
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$overlays$2f$action$2d$menu$2f$ActionMenu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionMenu"].Item, {
                onSelect: ()=>endreUtfallForKandidat(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatutfallTyper"].PRESENTERT),
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$MinusCircle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MinusCircleIcon$3e$__["MinusCircleIcon"], {}, void 0, false, {
                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/FjernFåttJobbenKnapp.tsx",
                        lineNumber: 27,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    " Fjern registrer fått jobben"
                ]
            }, void 0, true, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/FjernFåttJobbenKnapp.tsx",
                lineNumber: 22,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0));
        }
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
        disabled: lukketKandidatliste,
        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$MinusCircle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MinusCircleIcon$3e$__["MinusCircleIcon"], {}, void 0, false, {
            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/FjernFåttJobbenKnapp.tsx",
            lineNumber: 36,
            columnNumber: 13
        }, void 0),
        variant: "tertiary",
        size: "small",
        loading: loading,
        onClick: ()=>endreUtfallForKandidat(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatutfallTyper"].PRESENTERT),
        children: "Fjern fått jobben registreringen"
    }, void 0, false, {
        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/FjernFåttJobbenKnapp.tsx",
        lineNumber: 34,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = FjernFåttJobbenKnapp;
const __TURBOPACK__default__export__ = FjernFåttJobbenKnapp;
var _c;
__turbopack_context__.k.register(_c, "FjernFåttJobbenKnapp");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/[stillingsId]/kandidatliste/_ui/RegistrerFåttJobbenKnapp.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2f$useKandidatlisteForEier$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/kandidat/useKandidatlisteForEier.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$StillingsContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/StillingsContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/KandidatTyper.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$CheckmarkCircle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckmarkCircleIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/CheckmarkCircle.js [app-client] (ecmascript) <export default as CheckmarkCircleIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$overlays$2f$action$2d$menu$2f$ActionMenu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/overlays/action-menu/ActionMenu.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/button/Button.js [app-client] (ecmascript) <export default as Button>");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
const RegistrerFåttJobbenKnapp = ({ loading, lukketKandidatliste, endreUtfallForKandidat, actionMenu, visFullførStillingModal })=>{
    _s();
    const { stillingsData, refetch, erEier } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$StillingsContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStillingsContext"])();
    const kandidatlisteForEier = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2f$useKandidatlisteForEier$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useKandidatlisteForEier"])(stillingsData, erEier);
    const håndterKnappetrykk = async ()=>{
        endreUtfallForKandidat(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatutfallTyper"].FATT_JOBBEN);
        await kandidatlisteForEier.mutate();
        refetch?.();
        const ikkeArkiverteKandidater = kandidatlisteForEier.data?.kandidater?.filter((k)=>!k.arkivert) ?? [];
        const antallKandidaterSomHarFåttJobb = ikkeArkiverteKandidater.filter((k)=>k.utfall === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatutfallTyper"].FATT_JOBBEN).length + (kandidatlisteForEier.data?.formidlingerAvUsynligKandidat?.filter((k)=>k.utfall === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatutfallTyper"].FATT_JOBBEN)?.length || 0);
        const antallStillinger = kandidatlisteForEier.data?.antallStillinger;
        const alleStillingerBesatt = antallStillinger ? antallKandidaterSomHarFåttJobb >= antallStillinger : false;
        if (visFullførStillingModal && alleStillingerBesatt) {
            visFullførStillingModal(true);
        }
    };
    if (actionMenu) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$overlays$2f$action$2d$menu$2f$ActionMenu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionMenu"].Item, {
                onSelect: ()=>håndterKnappetrykk(),
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$CheckmarkCircle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckmarkCircleIcon$3e$__["CheckmarkCircleIcon"], {}, void 0, false, {
                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/RegistrerFåttJobbenKnapp.tsx",
                        lineNumber: 55,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    " Registrer fått jobben"
                ]
            }, void 0, true, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/RegistrerFåttJobbenKnapp.tsx",
                lineNumber: 54,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
        size: "small",
        variant: "secondary",
        disabled: lukketKandidatliste,
        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$CheckmarkCircle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckmarkCircleIcon$3e$__["CheckmarkCircleIcon"], {}, void 0, false, {
            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/RegistrerFåttJobbenKnapp.tsx",
            lineNumber: 66,
            columnNumber: 13
        }, void 0),
        onClick: ()=>håndterKnappetrykk(),
        loading: loading,
        children: "Registrer fått jobben"
    }, void 0, false, {
        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/RegistrerFåttJobbenKnapp.tsx",
        lineNumber: 62,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(RegistrerFåttJobbenKnapp, "Xke4tSXgx8sTLj5Z11cb2w/Wp1E=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$StillingsContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStillingsContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2f$useKandidatlisteForEier$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useKandidatlisteForEier"]
    ];
});
_c = RegistrerFåttJobbenKnapp;
const __TURBOPACK__default__export__ = RegistrerFåttJobbenKnapp;
var _c;
__turbopack_context__.k.register(_c, "RegistrerFåttJobbenKnapp");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsKnapp.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$ArrowForward$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowForwardIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/ArrowForward.js [app-client] (ecmascript) <export default as ArrowForwardIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$overlays$2f$action$2d$menu$2f$ActionMenu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/overlays/action-menu/ActionMenu.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/button/Button.js [app-client] (ecmascript) <export default as Button>");
;
;
;
const SendSmsKnapp = ({ markerteKandidater, knappVariant, actionMenu, setVisSendSmsModal })=>{
    const håndterKnappetrykk = ()=>{
        if (setVisSendSmsModal && markerteKandidater.length > 0) {
            setVisSendSmsModal(true);
        }
    };
    if (actionMenu) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$overlays$2f$action$2d$menu$2f$ActionMenu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionMenu"].Item, {
            onSelect: håndterKnappetrykk,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$ArrowForward$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowForwardIcon$3e$__["ArrowForwardIcon"], {}, void 0, false, {
                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsKnapp.tsx",
                    lineNumber: 28,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                " Tips om stilling"
            ]
        }, void 0, true, {
            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsKnapp.tsx",
            lineNumber: 27,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0));
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
        disabled: markerteKandidater.length === 0,
        onClick: håndterKnappetrykk,
        size: 'xsmall',
        variant: knappVariant || 'tertiary',
        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$ArrowForward$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowForwardIcon$3e$__["ArrowForwardIcon"], {
            title: "Tips om stilling"
        }, void 0, false, {
            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsKnapp.tsx",
            lineNumber: 38,
            columnNumber: 13
        }, void 0),
        iconPosition: "left",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "hidden lg:inline",
            children: "Send tips"
        }, void 0, false, {
            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsKnapp.tsx",
            lineNumber: 41,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsKnapp.tsx",
        lineNumber: 33,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = SendSmsKnapp;
const __TURBOPACK__default__export__ = SendSmsKnapp;
var _c;
__turbopack_context__.k.register(_c, "SendSmsKnapp");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "alleredeSendtAdvarsel": "SendSmsModal-module__3mmcRG__alleredeSendtAdvarsel",
  "alleredeSendtAdvarselListe": "SendSmsModal-module__3mmcRG__alleredeSendtAdvarselListe",
  "kontortidAdvarsel": "SendSmsModal-module__3mmcRG__kontortidAdvarsel",
  "sendSmsModal": "SendSmsModal-module__3mmcRG__sendSmsModal",
  "velgMal": "SendSmsModal-module__3mmcRG__velgMal",
});
}),
"[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$SendSMS$2f$SendSmsModal$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.module.css [app-client] (css module)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidatvarsel$2f$hentMeldingsmaler$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/kandidatvarsel/hentMeldingsmaler.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidatvarsel$2f$kandidatvarsel$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/kandidatvarsel/kandidatvarsel.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$StillingsContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/StillingsContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$stilling$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/_ui/stilling-typer.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$PopoverModal$2f$PopoverModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/PopoverModal/PopoverModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$ApplikasjonContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/providers/ApplikasjonContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$UmamiContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/providers/UmamiContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$rekbisError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/util/rekbisError.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$umamiEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/util/umamiEvents.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$ArrowForward$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowForwardIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/ArrowForward.js [app-client] (ecmascript) <export default as ArrowForwardIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Accordion$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/accordion/Accordion.js [app-client] (ecmascript) <export default as Accordion>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/alert/Alert.js [app-client] (ecmascript) <export default as Alert>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/BodyShort.js [app-client] (ecmascript) <export default as BodyShort>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$layout$2f$box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/layout/box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$Label$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Label$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/Label.js [app-client] (ecmascript) <export default as Label>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/modal/Modal.js [app-client] (ecmascript) <export default as Modal>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$select$2f$Select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Select$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/select/Select.js [app-client] (ecmascript) <export default as Select>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/table/Table.js [app-client] (ecmascript) <export default as Table>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$popover$40$1$2e$1$2e$15_$40$types$2b$react$2d$dom$40$19$2e$2$2e$3_$40$types$2b$react$40$19$2e$2$2e$9_$5f40$types$2b$react$40$19$2e$2_kcylkicjbhui3y3ce4dfdrkpmm$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$popover$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@radix-ui+react-popover@1.1.15_@types+react-dom@19.2.3_@types+react@19.2.9__@types+react@19.2_kcylkicjbhui3y3ce4dfdrkpmm/node_modules/@radix-ui/react-popover/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const SendSmsModal = (props)=>{
    _s();
    const { visVarsel } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$ApplikasjonContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useApplikasjonContext"])();
    const { fjernAllMarkering, markerteKandidater, popover, knappVariant, setVisSendSmsModal } = props;
    const { track } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$UmamiContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUmami"])();
    const { stillingsData } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$StillingsContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStillingsContext"])();
    const stillingskategori = stillingsData?.stillingsinfo?.stillingskategori;
    const stillingId = stillingsData.stilling.uuid;
    const { data: smser = {} } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidatvarsel$2f$kandidatvarsel$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSmserForStilling"])(stillingskategori === 'FORMIDLING' ? null : stillingsData.stilling.uuid);
    const postSmsTilKandidater = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidatvarsel$2f$kandidatvarsel$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePostSmsTilKandidater"])();
    const [sendSmsLoading, setSendSmsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const kandidaterSomHarFåttSms = markerteKandidater.filter((kandidat)=>kandidat.fodselsnr && smser[kandidat.fodselsnr]);
    const kandidaterSomIkkeHarFåttSms = markerteKandidater.filter((kandidat)=>!(kandidat.fodselsnr && smser[kandidat.fodselsnr]));
    const harInaktiveKandidater = markerteKandidater.some((kandidat)=>kandidat.fodselsnr === null);
    const [valgtMal, setValgtMal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(stillingskategori === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$stilling$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Stillingskategori"].Jobbmesse ? __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidatvarsel$2f$kandidatvarsel$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Meldingsmal"].Jobbarrangement : __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidatvarsel$2f$kandidatvarsel$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Meldingsmal"].VurdertSomAktuell);
    const { data: meldingsmaler } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidatvarsel$2f$hentMeldingsmaler$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useHentMeldingsmaler"])();
    const kandidaterSomMottarBeskjed = markerteKandidater.map((kandidat)=>kandidat.fodselsnr);
    const onSendSms = async ()=>{
        setSendSmsLoading(true);
        if (kandidaterSomMottarBeskjed.length === 0) {
            visVarsel({
                tekst: 'Ingen kandidater valgt',
                type: 'warning'
            });
            return;
        }
        try {
            await postSmsTilKandidater({
                mal: valgtMal,
                fnr: kandidaterSomMottarBeskjed.filter((fodselsnr)=>fodselsnr !== null),
                stillingId
            });
            track(__TURBOPACK__imported__module__$5b$project$5d2f$util$2f$umamiEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UmamiEvent"].Stilling.send_beskjed_til_kandidat, {
                antall: kandidaterSomMottarBeskjed.length
            });
            visVarsel({
                tekst: 'Beskjed er sendt',
                type: 'success'
            });
            fjernAllMarkering();
            setVisSendSmsModal?.(false);
        } catch (error) {
            new __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$rekbisError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RekbisError"]({
                message: 'Klarte ikke å sende SMS:',
                error
            });
            visVarsel({
                tekst: error instanceof Error ? `Feil ved sending: ${error.message}` : 'Det skjedde en uventet feil ved sending av beskjed',
                type: 'error'
            });
        } finally{
            setSendSmsLoading(false);
        }
    };
    const sendSMSInnhold = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "send-sms-modal__innhold",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__["Alert"], {
                variant: "info",
                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$SendSMS$2f$SendSmsModal$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].kontortidAdvarsel,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$Label$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Label$3e$__["Label"], {
                    size: "small",
                    children: "SMS sendes ut mellom 09:00 og 17:15 hver dag. Det kan oppstå forsinkelser."
                }, void 0, false, {
                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                    lineNumber: 143,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                lineNumber: 142,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            stillingskategori !== __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$stilling$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Stillingskategori"].Jobbmesse && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$select$2f$Select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Select$3e$__["Select"], {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$SendSMS$2f$SendSmsModal$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].velgMal,
                label: "Velg hva som skal vises i beskjeden",
                onChange: (e)=>{
                    setValgtMal(e.target.value);
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                        value: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidatvarsel$2f$kandidatvarsel$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Meldingsmal"].VurdertSomAktuell,
                        children: "Tips en aktuell kandidat om stilling"
                    }, void 0, false, {
                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                        lineNumber: 157,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                        value: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidatvarsel$2f$kandidatvarsel$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Meldingsmal"].FunnetPassendeStilling,
                        children: "Oppfordre kandidat til å søke på stilling"
                    }, void 0, false, {
                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                        lineNumber: 160,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                lineNumber: 150,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$Label$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Label$3e$__["Label"], {
                htmlFor: "forhåndsvisning",
                children: "Meldingen som vil bli sendt til kandidatene"
            }, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                lineNumber: 165,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                id: "forhåndsvisning",
                className: 'py-4',
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$layout$2f$box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    background: 'neutral-softA',
                    borderRadius: "8",
                    padding: "space-16",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__["BodyShort"], {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            children: [
                                meldingsmaler ? genererMeldingUtenLenke(valgtMal, meldingsmaler) : 'Klarte ikke å hente meldingsmaler',
                                ' '
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                            lineNumber: 171,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                        lineNumber: 170,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                    lineNumber: 169,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                lineNumber: 168,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
        lineNumber: 141,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
    if (popover) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$PopoverModal$2f$PopoverModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    tittel: "Tips om stilling",
                    åpneKnapp: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                        disabled: markerteKandidater.length === 0,
                        size: 'small',
                        variant: knappVariant || 'secondary',
                        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$ArrowForward$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowForwardIcon$3e$__["ArrowForwardIcon"], {
                            title: "Tips om stilling"
                        }, void 0, false, {
                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                            lineNumber: 192,
                            columnNumber: 21
                        }, void 0),
                        children: "Tips om stillingen"
                    }, void 0, false, {
                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                        lineNumber: 188,
                        columnNumber: 13
                    }, void 0),
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                        children: [
                            sendSMSInnhold,
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex justify-end",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                    disabled: kandidaterSomHarFåttSms.length === markerteKandidater.length || kandidaterSomIkkeHarFåttSms.length === 0,
                                    variant: "primary",
                                    loading: sendSmsLoading,
                                    onClick: onSendSms,
                                    children: "Send tips"
                                }, void 0, false, {
                                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                                    lineNumber: 201,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                                lineNumber: 200,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true)
                }, void 0, false, {
                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                    lineNumber: 185,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$popover$40$1$2e$1$2e$15_$40$types$2b$react$2d$dom$40$19$2e$2$2e$3_$40$types$2b$react$40$19$2e$2$2e$9_$5f40$types$2b$react$40$19$2e$2_kcylkicjbhui3y3ce4dfdrkpmm$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$popover$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Popover"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$popover$40$1$2e$1$2e$15_$40$types$2b$react$2d$dom$40$19$2e$2$2e$3_$40$types$2b$react$40$19$2e$2$2e$9_$5f40$types$2b$react$40$19$2e$2_kcylkicjbhui3y3ce4dfdrkpmm$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$popover$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PopoverTrigger"], {}, void 0, false, {
                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                            lineNumber: 217,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$popover$40$1$2e$1$2e$15_$40$types$2b$react$2d$dom$40$19$2e$2$2e$3_$40$types$2b$react$40$19$2e$2$2e$9_$5f40$types$2b$react$40$19$2e$2_kcylkicjbhui3y3ce4dfdrkpmm$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$popover$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PopoverContent"], {
                            className: "z-999",
                            side: "bottom",
                            align: "start",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$layout$2f$box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                background: "raised",
                                borderRadius: '12',
                                padding: "space-20",
                                shadow: "dialog",
                                borderColor: "neutral-subtle",
                                borderWidth: "1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex justify-between",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$popover$40$1$2e$1$2e$15_$40$types$2b$react$2d$dom$40$19$2e$2$2e$3_$40$types$2b$react$40$19$2e$2$2e$9_$5f40$types$2b$react$40$19$2e$2_kcylkicjbhui3y3ce4dfdrkpmm$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$popover$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PopoverClose"], {
                                            children: "asd"
                                        }, void 0, false, {
                                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                                            lineNumber: 228,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, void 0, false, {
                                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                                        lineNumber: 227,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    sendSMSInnhold,
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex justify-end",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                            disabled: kandidaterSomHarFåttSms.length === markerteKandidater.length || kandidaterSomIkkeHarFåttSms.length === 0,
                                            variant: "primary",
                                            loading: sendSmsLoading,
                                            onClick: onSendSms,
                                            children: "Send tips"
                                        }, void 0, false, {
                                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                                            lineNumber: 232,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, void 0, false, {
                                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                                        lineNumber: 231,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                                lineNumber: 219,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                            lineNumber: 218,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                    lineNumber: 216,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true);
    } else if (setVisSendSmsModal) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"], {
                open: true,
                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$SendSMS$2f$SendSmsModal$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sendSmsModal,
                onClose: ()=>setVisSendSmsModal(false),
                "aria-label": `Tips ${markerteKandidater.length} kandidater om stillingen`,
                header: {
                    heading: 'Tips om stillingen'
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"].Body, {
                        children: [
                            (kandidaterSomHarFåttSms.length > 0 || harInaktiveKandidater) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__["Alert"], {
                                variant: "warning",
                                size: "small",
                                className: "my-4",
                                children: "Ikke alle kandidatene vil motta beskjeden"
                            }, void 0, false, {
                                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                                lineNumber: 264,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__["BodyShort"], {
                                children: [
                                    "Det vil bli sendt beskjed til",
                                    ' ',
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("b", {
                                        children: kandidaterSomIkkeHarFåttSms.length
                                    }, void 0, false, {
                                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                                        lineNumber: 270,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    ' ',
                                    kandidaterSomIkkeHarFåttSms.length === 1 ? 'kandidat' : 'kandidater'
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                                lineNumber: 268,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__["BodyShort"], {
                                size: "small",
                                children: "Telefonnummerene/e-postene blir hentet fra Kontakt- og reservasjonsregisteret."
                            }, void 0, false, {
                                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                                lineNumber: 275,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Accordion$3e$__["Accordion"], {
                                size: "small",
                                className: "my-4",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Accordion$3e$__["Accordion"].Item, {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Accordion$3e$__["Accordion"].Header, {
                                            children: "Vis kandidater"
                                        }, void 0, false, {
                                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                                            lineNumber: 281,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Accordion$3e$__["Accordion"].Content, {
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__["Table"], {
                                                size: "small",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__["Table"].Header, {
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__["Table"].Row, {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__["Table"].HeaderCell, {
                                                                    scope: "col",
                                                                    children: "Navn"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                                                                    lineNumber: 286,
                                                                    columnNumber: 25
                                                                }, ("TURBOPACK compile-time value", void 0)),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__["Table"].HeaderCell, {
                                                                    scope: "col",
                                                                    children: "Fødselsnr."
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                                                                    lineNumber: 287,
                                                                    columnNumber: 25
                                                                }, ("TURBOPACK compile-time value", void 0)),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__["Table"].HeaderCell, {
                                                                    scope: "col",
                                                                    children: "Kan sende tips"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                                                                    lineNumber: 290,
                                                                    columnNumber: 25
                                                                }, ("TURBOPACK compile-time value", void 0))
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                                                            lineNumber: 285,
                                                            columnNumber: 23
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                                                        lineNumber: 284,
                                                        columnNumber: 21
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__["Table"].Body, {
                                                        children: markerteKandidater?.map(({ fornavn, etternavn, fodselsnr }, i)=>{
                                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__["Table"].Row, {
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__["Table"].HeaderCell, {
                                                                        scope: "row",
                                                                        children: [
                                                                            fornavn,
                                                                            " ",
                                                                            etternavn
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                                                                        lineNumber: 300,
                                                                        columnNumber: 31
                                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__["Table"].DataCell, {
                                                                        children: fodselsnr
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                                                                        lineNumber: 303,
                                                                        columnNumber: 31
                                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__["Table"].DataCell, {
                                                                        children: kandidaterSomHarFåttSms.some((k)=>k.fodselsnr === fodselsnr) ? 'Nei' : 'Ja'
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                                                                        lineNumber: 304,
                                                                        columnNumber: 31
                                                                    }, ("TURBOPACK compile-time value", void 0))
                                                                ]
                                                            }, i, true, {
                                                                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                                                                lineNumber: 299,
                                                                columnNumber: 29
                                                            }, ("TURBOPACK compile-time value", void 0));
                                                        })
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                                                        lineNumber: 295,
                                                        columnNumber: 21
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                                                lineNumber: 283,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                                            lineNumber: 282,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                                    lineNumber: 280,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                                lineNumber: 279,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            sendSMSInnhold
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                        lineNumber: 262,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"].Footer, {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                disabled: kandidaterSomHarFåttSms.length === markerteKandidater.length || kandidaterSomIkkeHarFåttSms.length === 0,
                                variant: "primary",
                                loading: sendSmsLoading,
                                onClick: onSendSms,
                                children: "Send tips"
                            }, void 0, false, {
                                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                                lineNumber: 324,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                variant: "secondary",
                                onClick: ()=>setVisSendSmsModal(false),
                                children: "Avbryt"
                            }, void 0, false, {
                                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                                lineNumber: 335,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                        lineNumber: 323,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx",
                lineNumber: 253,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false);
    }
    return null;
};
_s(SendSmsModal, "YHO5RjJP2q81/7Y9o2Fmr+xH898=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$ApplikasjonContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useApplikasjonContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$UmamiContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUmami"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$StillingsContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStillingsContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidatvarsel$2f$kandidatvarsel$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSmserForStilling"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidatvarsel$2f$kandidatvarsel$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePostSmsTilKandidater"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidatvarsel$2f$hentMeldingsmaler$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useHentMeldingsmaler"]
    ];
});
_c = SendSmsModal;
const genererMeldingUtenLenke = (valgtMal, meldingsmaler)=>{
    if (valgtMal === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidatvarsel$2f$kandidatvarsel$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Meldingsmal"].VurdertSomAktuell) {
        return meldingsmaler.vurdertSomAktuell?.smsTekst;
    } else if (valgtMal === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidatvarsel$2f$kandidatvarsel$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Meldingsmal"].FunnetPassendeStilling) {
        return meldingsmaler.passendeStilling?.smsTekst;
    } else if (valgtMal === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidatvarsel$2f$kandidatvarsel$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Meldingsmal"].Jobbarrangement) {
        return meldingsmaler.passendeJobbarrangement?.smsTekst;
    }
};
const __TURBOPACK__default__export__ = SendSmsModal;
var _c;
__turbopack_context__.k.register(_c, "SendSmsModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/_ui/KandidatListeKortValg.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2f$endreKandidatUtfall$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/kandidat/endreKandidatUtfall.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$kandidat$2f$_ui$2f$ActionLinks$2f$NavigerTilAktivitetsplanenKnapp$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/kandidat/_ui/ActionLinks/NavigerTilAktivitetsplanenKnapp.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$StillingsContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/StillingsContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$_ui$2f$stilling$2d$handlinger$2f$fullf$f8$r$2d$oppdrag$2f$Fullf$f8$rStillingModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/_ui/stilling-handlinger/fullfør-oppdrag/FullførStillingModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/KandidatTyper.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatlisteContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/KandidatlisteContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$EndreArkivertStatusModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/EndreArkivertStatusModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$FjernF$e5$ttJobbenKnapp$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/FjernFåttJobbenKnapp.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$RegistrerF$e5$ttJobbenKnapp$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/RegistrerFåttJobbenKnapp.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$SendSMS$2f$SendSmsKnapp$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsKnapp.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$SendSMS$2f$SendSmsModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$stilling$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/_ui/stilling-typer.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$ApplikasjonContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/providers/ApplikasjonContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$rekbisError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/util/rekbisError.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$MenuElipsisVertical$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuElipsisVerticalIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/MenuElipsisVertical.js [app-client] (ecmascript) <export default as MenuElipsisVerticalIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$overlays$2f$action$2d$menu$2f$ActionMenu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/overlays/action-menu/ActionMenu.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const KandidatListeKortValg = ({ kandidat, kandidatlisteId })=>{
    _s();
    const { valgtNavKontor } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$ApplikasjonContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useApplikasjonContext"])();
    const { stillingsData } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$StillingsContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStillingsContext"])();
    const { reFetchKandidatliste, lukketKandidatliste } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatlisteContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useKandidatlisteContext"])();
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const modalRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [visFullførStillingModal, setVisFullførStillingModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [visSendSmsModal, setVisSendSmsModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const endreUtfallForKandidat = async (utfall)=>{
        setLoading(true);
        try {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2f$endreKandidatUtfall$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["endreUtfallKandidat"])(utfall, valgtNavKontor?.navKontor ?? '', kandidatlisteId, kandidat.kandidatnr);
            reFetchKandidatliste();
        } catch (error) {
            new __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$rekbisError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RekbisError"]({
                message: 'Feil ved endring av utfall',
                error
            });
        }
        setLoading(false);
    };
    if (lukketKandidatliste) {
        return null;
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$overlays$2f$action$2d$menu$2f$ActionMenu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionMenu"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$overlays$2f$action$2d$menu$2f$ActionMenu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionMenu"].Trigger, {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                            "data-color": "neutral",
                            variant: "tertiary",
                            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$MenuElipsisVertical$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuElipsisVerticalIcon$3e$__["MenuElipsisVerticalIcon"], {
                                title: "Saksmeny"
                            }, void 0, false, {
                                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/_ui/KandidatListeKortValg.tsx",
                                lineNumber: 67,
                                columnNumber: 19
                            }, void 0),
                            size: "small"
                        }, void 0, false, {
                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/_ui/KandidatListeKortValg.tsx",
                            lineNumber: 64,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/_ui/KandidatListeKortValg.tsx",
                        lineNumber: 63,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$overlays$2f$action$2d$menu$2f$ActionMenu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionMenu"].Content, {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$overlays$2f$action$2d$menu$2f$ActionMenu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionMenu"].Group, {
                                label: '',
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$kandidat$2f$_ui$2f$ActionLinks$2f$NavigerTilAktivitetsplanenKnapp$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    actionMenu: true,
                                    fnr: kandidat.fodselsnr
                                }, void 0, false, {
                                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/_ui/KandidatListeKortValg.tsx",
                                    lineNumber: 73,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/_ui/KandidatListeKortValg.tsx",
                                lineNumber: 72,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$overlays$2f$action$2d$menu$2f$ActionMenu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionMenu"].Group, {
                                label: '',
                                children: [
                                    stillingsData.stillingsinfo?.stillingskategori !== __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$stilling$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Stillingskategori"].Jobbmesse && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                        children: kandidat.utfall !== __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatutfallTyper"].FATT_JOBBEN ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$RegistrerF$e5$ttJobbenKnapp$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            actionMenu: true,
                                            loading: loading,
                                            endreUtfallForKandidat: endreUtfallForKandidat,
                                            lukketKandidatliste: lukketKandidatliste,
                                            visFullførStillingModal: setVisFullførStillingModal
                                        }, void 0, false, {
                                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/_ui/KandidatListeKortValg.tsx",
                                            lineNumber: 83,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$FjernF$e5$ttJobbenKnapp$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            actionMenu: true,
                                            loading: loading,
                                            endreUtfallForKandidat: endreUtfallForKandidat,
                                            lukketKandidatliste: lukketKandidatliste
                                        }, void 0, false, {
                                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/_ui/KandidatListeKortValg.tsx",
                                            lineNumber: 91,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, void 0, false),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$overlays$2f$action$2d$menu$2f$ActionMenu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionMenu"].Divider, {}, void 0, false, {
                                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/_ui/KandidatListeKortValg.tsx",
                                        lineNumber: 101,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    kandidat.fodselsnr != null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$SendSMS$2f$SendSmsKnapp$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                markerteKandidater: [
                                                    kandidat
                                                ],
                                                actionMenu: true,
                                                setVisSendSmsModal: setVisSendSmsModal
                                            }, void 0, false, {
                                                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/_ui/KandidatListeKortValg.tsx",
                                                lineNumber: 104,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$overlays$2f$action$2d$menu$2f$ActionMenu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionMenu"].Divider, {}, void 0, false, {
                                                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/_ui/KandidatListeKortValg.tsx",
                                                lineNumber: 109,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$EndreArkivertStatusModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EndreArkivertStatusKnapp"], {
                                        actionMenu: true,
                                        lukketKandidatliste: lukketKandidatliste,
                                        slettet: kandidat.arkivert,
                                        modalRef: modalRef
                                    }, void 0, false, {
                                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/_ui/KandidatListeKortValg.tsx",
                                        lineNumber: 113,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/_ui/KandidatListeKortValg.tsx",
                                lineNumber: 78,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/_ui/KandidatListeKortValg.tsx",
                        lineNumber: 71,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/_ui/KandidatListeKortValg.tsx",
                lineNumber: 62,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$EndreArkivertStatusModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EndreArkivertStatusModal"], {
                modalRef: modalRef,
                kandidat: kandidat,
                kandidatlisteId: kandidatlisteId
            }, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/_ui/KandidatListeKortValg.tsx",
                lineNumber: 122,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            visFullførStillingModal && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$_ui$2f$stilling$2d$handlinger$2f$fullf$f8$r$2d$oppdrag$2f$Fullf$f8$rStillingModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                setVisModal: ()=>setVisFullførStillingModal(false)
            }, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/_ui/KandidatListeKortValg.tsx",
                lineNumber: 128,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            visSendSmsModal && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$SendSMS$2f$SendSmsModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                markerteKandidater: [
                    kandidat
                ],
                fjernAllMarkering: ()=>{},
                setVisSendSmsModal: ()=>setVisSendSmsModal(false)
            }, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/_ui/KandidatListeKortValg.tsx",
                lineNumber: 133,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true);
};
_s(KandidatListeKortValg, "PzNmJaFbCC5LwWUlmX6ad5CIxxE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$ApplikasjonContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useApplikasjonContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$StillingsContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStillingsContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatlisteContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useKandidatlisteContext"]
    ];
});
_c = KandidatListeKortValg;
const __TURBOPACK__default__export__ = KandidatListeKortValg;
var _c;
__turbopack_context__.k.register(_c, "KandidatListeKortValg");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/_ui/KandidatlisteNavn.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$kandidat$2f$util$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/kandidat/util.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/BodyShort.js [app-client] (ecmascript) <export default as BodyShort>");
;
;
;
const KandidatlisteNavn = ({ kandidat, usynligKandidat, slettet })=>{
    if (usynligKandidat) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: `flex flex-col`,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__["BodyShort"], {
                    children: [
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$kandidat$2f$util$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storForbokstav"])(usynligKandidat.etternavn),
                        ",",
                        ' ',
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$kandidat$2f$util$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storForbokstav"])(usynligKandidat.fornavn)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/_ui/KandidatlisteNavn.tsx",
                    lineNumber: 21,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__["BodyShort"], {
                    textColor: "subtle",
                    children: "Usynlig kandidat"
                }, void 0, false, {
                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/_ui/KandidatlisteNavn.tsx",
                    lineNumber: 25,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/_ui/KandidatlisteNavn.tsx",
            lineNumber: 20,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0));
    }
    if (!kandidat) {
        return null;
    }
    if (!kandidat?.fodselsnr) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: `flex flex-col`,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__["BodyShort"], {
                    children: [
                        kandidat.etternavn,
                        ", ",
                        kandidat.fornavn
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/_ui/KandidatlisteNavn.tsx",
                    lineNumber: 37,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__["BodyShort"], {
                    textColor: "subtle",
                    children: "Inaktiv kandidat"
                }, void 0, false, {
                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/_ui/KandidatlisteNavn.tsx",
                    lineNumber: 40,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/_ui/KandidatlisteNavn.tsx",
            lineNumber: 36,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0));
    }
    if (slettet) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: `flex flex-col`,
            children: [
                kandidat.etternavn,
                ", ",
                kandidat.fornavn,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__["BodyShort"], {
                    textColor: "subtle",
                    children: [
                        "Slettet av ",
                        kandidat.arkivertAv?.navn
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/_ui/KandidatlisteNavn.tsx",
                    lineNumber: 49,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/_ui/KandidatlisteNavn.tsx",
            lineNumber: 47,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0));
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `flex flex-col`,
        children: [
            kandidat.etternavn,
            ", ",
            kandidat.fornavn,
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__["BodyShort"], {
                textColor: "subtle",
                children: [
                    "f.nr. ",
                    kandidat.fodselsnr
                ]
            }, void 0, true, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/_ui/KandidatlisteNavn.tsx",
                lineNumber: 59,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/_ui/KandidatlisteNavn.tsx",
        lineNumber: 57,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = KandidatlisteNavn;
const __TURBOPACK__default__export__ = KandidatlisteNavn;
var _c;
__turbopack_context__.k.register(_c, "KandidatlisteNavn");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelseTagVisning.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SlettetTag",
    ()=>SlettetTag,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$dato$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/util/dato.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$Trash$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TrashIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/Trash.js [app-client] (ecmascript) <export default as TrashIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/BodyShort.js [app-client] (ecmascript) <export default as BodyShort>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tag$2f$Tag$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tag$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/tag/Tag.js [app-client] (ecmascript) <export default as Tag>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/tooltip/Tooltip.js [app-client] (ecmascript) <export default as Tooltip>");
;
;
;
;
const SlettetTag = ({ kandidat, topBar })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: 'flex flex-col items-start',
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tag$2f$Tag$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tag$3e$__["Tag"], {
                "data-color": "meta-lime",
                variant: 'outline',
                size: "small",
                className: "inline-flex",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$Trash$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TrashIcon$3e$__["TrashIcon"], {}, void 0, false, {
                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelseTagVisning.tsx",
                            lineNumber: 29,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        " Slettet"
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelseTagVisning.tsx",
                    lineNumber: 28,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelseTagVisning.tsx",
                lineNumber: 22,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            !topBar && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__["BodyShort"], {
                textColor: "subtle",
                size: "small",
                className: "mt-1",
                children: kandidat.arkivertTidspunkt && (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$dato$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formaterNorskDato"])({
                    dato: kandidat.arkivertTidspunkt,
                    visning: 'kortMåned'
                })
            }, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelseTagVisning.tsx",
                lineNumber: 33,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelseTagVisning.tsx",
        lineNumber: 21,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = SlettetTag;
const KandidatHendelseTagVisning = ({ kandidatHendelse, topBar })=>{
    if (!kandidatHendelse) {
        return null;
    }
    if (!kandidatHendelse.tag) {
        return null;
    }
    if (topBar) {
        return kandidatHendelse.tag;
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
        content: kandidatHendelse.tekst ?? '',
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: [
                kandidatHendelse.tag,
                kandidatHendelse.dato && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__["BodyShort"], {
                    textColor: "subtle",
                    children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$dato$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formaterNorskDato"])({
                        dato: kandidatHendelse.dato
                    })
                }, void 0, false, {
                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelseTagVisning.tsx",
                    lineNumber: 65,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelseTagVisning.tsx",
            lineNumber: 62,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelseTagVisning.tsx",
        lineNumber: 61,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c1 = KandidatHendelseTagVisning;
const __TURBOPACK__default__export__ = KandidatHendelseTagVisning;
var _c, _c1;
__turbopack_context__.k.register(_c, "SlettetTag");
__turbopack_context__.k.register(_c1, "KandidatHendelseTagVisning");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/[stillingsId]/kandidatliste/_ui/InternStatusTag.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "internStatusIcon",
    ()=>internStatusIcon,
    "internStatusTekst",
    ()=>internStatusTekst
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/KandidatTyper.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$CircleSlash$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CircleSlashIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/CircleSlash.js [app-client] (ecmascript) <export default as CircleSlashIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$MagnifyingGlass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MagnifyingGlassIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/MagnifyingGlass.js [app-client] (ecmascript) <export default as MagnifyingGlassIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$PersonChat$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PersonChatIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/PersonChat.js [app-client] (ecmascript) <export default as PersonChatIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$Reception$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ReceptionIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/Reception.js [app-client] (ecmascript) <export default as ReceptionIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$SealCheckmark$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__SealCheckmarkIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/SealCheckmark.js [app-client] (ecmascript) <export default as SealCheckmarkIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$XMarkOctagon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XMarkOctagonIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/XMarkOctagon.js [app-client] (ecmascript) <export default as XMarkOctagonIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tag$2f$Tag$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tag$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/tag/Tag.js [app-client] (ecmascript) <export default as Tag>");
;
;
;
;
const internStatusTekst = (status)=>{
    switch(status){
        case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InternKandidatstatus"].VURDERES:
            return 'Vurderes';
        case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InternKandidatstatus"].KONTAKTET:
            return 'Kontaktet';
        case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InternKandidatstatus"].AKTUELL:
            return 'Aktuell';
        case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InternKandidatstatus"].TIL_INTERVJU:
            return 'Til intervju';
        case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InternKandidatstatus"].UAKTUELL:
            return 'Ikke aktuell';
        case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InternKandidatstatus"].UINTERESSERT:
            return 'Ikke interessert';
        default:
            return '-';
    }
};
const internStatusIcon = (status)=>{
    switch(status){
        case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InternKandidatstatus"].VURDERES:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$MagnifyingGlass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MagnifyingGlassIcon$3e$__["MagnifyingGlassIcon"], {}, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/InternStatusTag.tsx",
                lineNumber: 39,
                columnNumber: 14
            }, ("TURBOPACK compile-time value", void 0));
        case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InternKandidatstatus"].KONTAKTET:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$PersonChat$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PersonChatIcon$3e$__["PersonChatIcon"], {}, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/InternStatusTag.tsx",
                lineNumber: 41,
                columnNumber: 14
            }, ("TURBOPACK compile-time value", void 0));
        case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InternKandidatstatus"].AKTUELL:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$SealCheckmark$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__SealCheckmarkIcon$3e$__["SealCheckmarkIcon"], {}, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/InternStatusTag.tsx",
                lineNumber: 43,
                columnNumber: 14
            }, ("TURBOPACK compile-time value", void 0));
        case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InternKandidatstatus"].TIL_INTERVJU:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$Reception$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ReceptionIcon$3e$__["ReceptionIcon"], {}, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/InternStatusTag.tsx",
                lineNumber: 45,
                columnNumber: 14
            }, ("TURBOPACK compile-time value", void 0));
        case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InternKandidatstatus"].UAKTUELL:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$XMarkOctagon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XMarkOctagonIcon$3e$__["XMarkOctagonIcon"], {}, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/InternStatusTag.tsx",
                lineNumber: 47,
                columnNumber: 14
            }, ("TURBOPACK compile-time value", void 0));
        case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InternKandidatstatus"].UINTERESSERT:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$CircleSlash$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CircleSlashIcon$3e$__["CircleSlashIcon"], {}, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/InternStatusTag.tsx",
                lineNumber: 49,
                columnNumber: 14
            }, ("TURBOPACK compile-time value", void 0));
        default:
            return '';
    }
};
const internStatusVariant = (status)=>{
    switch(status){
        case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InternKandidatstatus"].VURDERES:
            return 'neutral';
        case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InternKandidatstatus"].KONTAKTET:
            return 'alt1';
        case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InternKandidatstatus"].AKTUELL:
            return 'success';
        case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InternKandidatstatus"].TIL_INTERVJU:
            return 'alt3';
        case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InternKandidatstatus"].UAKTUELL:
            return 'error';
        case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InternKandidatstatus"].UINTERESSERT:
            return 'warning';
        default:
            return 'neutral';
    }
};
const InternStatusTag = ({ status })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tag$2f$Tag$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Tag$3e$__["Tag"], {
        size: "small",
        variant: internStatusVariant(status),
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex gap-1",
            children: [
                internStatusIcon(status),
                " ",
                internStatusTekst(status)
            ]
        }, void 0, true, {
            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/InternStatusTag.tsx",
            lineNumber: 77,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/InternStatusTag.tsx",
        lineNumber: 76,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = InternStatusTag;
const __TURBOPACK__default__export__ = InternStatusTag;
var _c;
__turbopack_context__.k.register(_c, "InternStatusTag");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/[stillingsId]/kandidatliste/_ui/VelgInternStatus.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$InternStatusTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/InternStatusTag.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2f$endreKandidatStatus$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/kandidat/endreKandidatStatus.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/KandidatTyper.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatlisteContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/KandidatlisteContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$Pencil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PencilIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/Pencil.js [app-client] (ecmascript) <export default as PencilIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dropdown$2f$Dropdown$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Dropdown$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/dropdown/Dropdown.js [app-client] (ecmascript) <export default as Dropdown>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
const alleStatuser = Object.values(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InternKandidatstatus"]);
const VelgInternStatus = ({ kandidatnr, status, lukketKandidatliste })=>{
    _s();
    const { reFetchKandidatliste, kandidatlisteId } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatlisteContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useKandidatlisteContext"])();
    const [pending, setPending] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const endreStatus = async (ny)=>{
        if (pending || ny === status) return;
        setPending(true);
        try {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2f$endreKandidatStatus$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["endreKandidatStatus"])(kandidatlisteId, kandidatnr, ny);
            reFetchKandidatliste();
        } finally{
            setPending(false);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dropdown$2f$Dropdown$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Dropdown$3e$__["Dropdown"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$InternStatusTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    status: status
                }, void 0, false, {
                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/VelgInternStatus.tsx",
                    lineNumber: 44,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "justify-left flex",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                        "data-color": "neutral",
                        disabled: lukketKandidatliste || pending,
                        size: "small",
                        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$Pencil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PencilIcon$3e$__["PencilIcon"], {
                            "aria-hidden": true
                        }, void 0, false, {
                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/VelgInternStatus.tsx",
                            lineNumber: 50,
                            columnNumber: 19
                        }, void 0),
                        variant: "tertiary",
                        "aria-label": "Endre intern status",
                        as: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dropdown$2f$Dropdown$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Dropdown$3e$__["Dropdown"].Toggle
                    }, void 0, false, {
                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/VelgInternStatus.tsx",
                        lineNumber: 46,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/VelgInternStatus.tsx",
                    lineNumber: 45,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dropdown$2f$Dropdown$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Dropdown$3e$__["Dropdown"].Menu, {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dropdown$2f$Dropdown$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Dropdown$3e$__["Dropdown"].Menu.GroupedList, {
                        children: alleStatuser.map((s)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dropdown$2f$Dropdown$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Dropdown$3e$__["Dropdown"].Menu.GroupedList.Item, {
                                onClick: ()=>endreStatus(s),
                                children: [
                                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$InternStatusTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["internStatusIcon"])(s),
                                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$InternStatusTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["internStatusTekst"])(s)
                                ]
                            }, s, true, {
                                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/VelgInternStatus.tsx",
                                lineNumber: 59,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0)))
                    }, void 0, false, {
                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/VelgInternStatus.tsx",
                        lineNumber: 57,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/VelgInternStatus.tsx",
                    lineNumber: 56,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                ' '
            ]
        }, void 0, true, {
            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/VelgInternStatus.tsx",
            lineNumber: 43,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/VelgInternStatus.tsx",
        lineNumber: 42,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(VelgInternStatus, "jrhhmi5ODAJVZ0W6zJrXZ1fsAhs=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatlisteContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useKandidatlisteContext"]
    ];
});
_c = VelgInternStatus;
const __TURBOPACK__default__export__ = VelgInternStatus;
var _c;
__turbopack_context__.k.register(_c, "VelgInternStatus");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/KandidatlisteKort.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$Kandidatkort$2f$_ui$2f$KandidatCheckbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/_ui/KandidatCheckbox.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$Kandidatkort$2f$_ui$2f$KandidatListeKortValg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/_ui/KandidatListeKortValg.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$Kandidatkort$2f$_ui$2f$KandidatlisteNavn$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/_ui/KandidatlisteNavn.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$StillingsContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/StillingsContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$FiltrertKandidatListeVisning$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/FiltrertKandidatListeVisning.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/KandidatTyper.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatlisteContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/KandidatlisteContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelseTagVisning$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelseTagVisning.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/KandidatHendelseTag.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$VelgInternStatus$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/VelgInternStatus.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$layout$2f$ListeKort$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/layout/ListeKort.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$window$2f$WindowAnker$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/window/WindowAnker.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$window$2f$ankerLenker$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/window/ankerLenker.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$dato$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/util/dato.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/BodyShort.js [app-client] (ecmascript) <export default as BodyShort>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$layout$2f$box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/layout/box/Box.js [app-client] (ecmascript) <export default as Box>");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const kolonneStyling = 'break-words';
const KandidatListeKort = ({ kandidat, usynligKandidat, kunVisning })=>{
    _s();
    const { lukketKandidatliste, kandidatlisteId } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatlisteContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useKandidatlisteContext"])();
    const { stillingsData } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$StillingsContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStillingsContext"])();
    if (usynligKandidat) {
        const fåttJobben = usynligKandidat.utfall === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatutfallTyper"].FATT_JOBBEN;
        const usynligHendelse = fåttJobben ? {
            type: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseType"].Fått_jobben,
            tag: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseTag"], {
                type: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseType"].Fått_jobben
            }, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/KandidatlisteKort.tsx",
                lineNumber: 49,
                columnNumber: 16
            }, ("TURBOPACK compile-time value", void 0)),
            tekst: (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$dato$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formaterNorskDato"])({
                dato: usynligKandidat.lagtTilTidspunkt,
                visning: 'kortMåned'
            }) ?? '',
            dato: new Date(usynligKandidat.lagtTilTidspunkt),
            raw: usynligKandidat
        } : {
            type: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseType"].Fjernet_fått_jobben,
            tag: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseTag"], {
                type: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseType"].Fjernet_fått_jobben
            }, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/KandidatlisteKort.tsx",
                lineNumber: 61,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0)),
            tekst: (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$dato$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formaterNorskDato"])({
                dato: usynligKandidat.lagtTilTidspunkt,
                visning: 'kortMåned'
            }) ?? '',
            dato: null,
            raw: usynligKandidat
        };
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$layout$2f$box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            padding: "space-16",
            background: "neutral-moderate",
            borderRadius: "12",
            "data-testid": "stillings-kort",
            className: "min-w-fit",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `grid ${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$FiltrertKandidatListeVisning$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KANDIDATLISTE_COLUMN_LAYOUT"]} items-center gap-x-3`,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: kolonneStyling,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex gap-4",
                            children: [
                                !kunVisning && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$Kandidatkort$2f$_ui$2f$KandidatCheckbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/KandidatlisteKort.tsx",
                                    lineNumber: 86,
                                    columnNumber: 31
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$Kandidatkort$2f$_ui$2f$KandidatlisteNavn$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    usynligKandidat: usynligKandidat
                                }, void 0, false, {
                                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/KandidatlisteKort.tsx",
                                    lineNumber: 87,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/KandidatlisteKort.tsx",
                            lineNumber: 85,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/KandidatlisteKort.tsx",
                        lineNumber: 84,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: kolonneStyling,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: 'flex flex-col items-start',
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__["BodyShort"], {
                                    children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$dato$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formaterNorskDato"])({
                                        dato: usynligKandidat.lagtTilTidspunkt,
                                        visning: 'kortMåned'
                                    })
                                }, void 0, false, {
                                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/KandidatlisteKort.tsx",
                                    lineNumber: 92,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__["BodyShort"], {
                                    textColor: "subtle",
                                    children: usynligKandidat.lagtTilAvNavn
                                }, void 0, false, {
                                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/KandidatlisteKort.tsx",
                                    lineNumber: 98,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/KandidatlisteKort.tsx",
                            lineNumber: 91,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/KandidatlisteKort.tsx",
                        lineNumber: 90,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: usynligHendelse?.tag
                    }, void 0, false, {
                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/KandidatlisteKort.tsx",
                        lineNumber: 103,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/KandidatlisteKort.tsx",
                lineNumber: 81,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/KandidatlisteKort.tsx",
            lineNumber: 74,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0));
    }
    const slettet = kandidat?.arkivert;
    const inaktiv = kandidat?.fodselsnr === null || kunVisning;
    const stopPropagation = (e)=>{
        e.stopPropagation();
        e.preventDefault();
    };
    if (kandidat) {
        const anker = kandidat.kandidatnr ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$window$2f$ankerLenker$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["kandidatlisteAnker"])(stillingsData.stilling.uuid, kandidat.kandidatnr) : null;
        // const aktiv = visKandidatnr === kandidat.kandidatnr;
        const aktiv = false;
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$window$2f$WindowAnker$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            disabled: inaktiv,
            windowRef: anker?.windowRef ?? '#',
            href: anker?.href ?? '#',
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$layout$2f$ListeKort$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: `${("TURBOPACK compile-time truthy", 1) ? 'cursor-pointer hover:bg-[var(--ax-bg-neutral-moderate-hover)]' : "TURBOPACK unreachable"} ${("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : ''}`,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: `grid ${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$FiltrertKandidatListeVisning$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KANDIDATLISTE_COLUMN_LAYOUT"]} items-center gap-x-3`,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: `${kolonneStyling} flex flex-col gap-2`,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex gap-4",
                                children: [
                                    !kunVisning && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$Kandidatkort$2f$_ui$2f$KandidatCheckbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        kandidat: kandidat,
                                        slettet: slettet
                                    }, void 0, false, {
                                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/KandidatlisteKort.tsx",
                                        lineNumber: 139,
                                        columnNumber: 19
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$Kandidatkort$2f$_ui$2f$KandidatlisteNavn$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        kandidat: kandidat,
                                        slettet: slettet
                                    }, void 0, false, {
                                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/KandidatlisteKort.tsx",
                                        lineNumber: 141,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/KandidatlisteKort.tsx",
                                lineNumber: 137,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/KandidatlisteKort.tsx",
                            lineNumber: 136,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: `${kolonneStyling} flex flex-col`,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__["BodyShort"], {
                                    children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$dato$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formaterNorskDato"])({
                                        dato: kandidat.lagtTilTidspunkt,
                                        visning: 'kortMåned'
                                    })
                                }, void 0, false, {
                                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/KandidatlisteKort.tsx",
                                    lineNumber: 145,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__["BodyShort"], {
                                    textColor: "subtle",
                                    children: kandidat.lagtTilAv.navn
                                }, void 0, false, {
                                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/KandidatlisteKort.tsx",
                                    lineNumber: 151,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/KandidatlisteKort.tsx",
                            lineNumber: 144,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: `${kolonneStyling} flex flex-col`,
                            children: slettet ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelseTagVisning$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SlettetTag"], {
                                kandidat: kandidat
                            }, void 0, false, {
                                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/KandidatlisteKort.tsx",
                                lineNumber: 157,
                                columnNumber: 17
                            }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelseTagVisning$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                kandidatHendelse: kandidat.kandidatHendelser.sisteHendelse
                            }, void 0, false, {
                                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/KandidatlisteKort.tsx",
                                lineNumber: 159,
                                columnNumber: 17
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/KandidatlisteKort.tsx",
                            lineNumber: 155,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: `${kolonneStyling} flex flex-col`,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: kandidat.kandidatHendelser.sisteSms?.tag
                                }, void 0, false, {
                                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/KandidatlisteKort.tsx",
                                    lineNumber: 165,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {}, void 0, false, {
                                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/KandidatlisteKort.tsx",
                                    lineNumber: 166,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/KandidatlisteKort.tsx",
                            lineNumber: 164,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: kolonneStyling,
                            onClick: stopPropagation,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$VelgInternStatus$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                lukketKandidatliste: lukketKandidatliste || kunVisning === true,
                                kandidatnr: kandidat.kandidatnr,
                                status: kandidat.status
                            }, void 0, false, {
                                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/KandidatlisteKort.tsx",
                                lineNumber: 169,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/KandidatlisteKort.tsx",
                            lineNumber: 168,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        !kunVisning && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: `${kolonneStyling} flex items-center justify-center`,
                            onClick: stopPropagation,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$Kandidatkort$2f$_ui$2f$KandidatListeKortValg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                kandidat: kandidat,
                                kandidatlisteId: kandidatlisteId
                            }, void 0, false, {
                                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/KandidatlisteKort.tsx",
                                lineNumber: 180,
                                columnNumber: 17
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/KandidatlisteKort.tsx",
                            lineNumber: 176,
                            columnNumber: 15
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/KandidatlisteKort.tsx",
                    lineNumber: 133,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/KandidatlisteKort.tsx",
                lineNumber: 130,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/KandidatlisteKort.tsx",
            lineNumber: 125,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0));
    }
    return null;
};
_s(KandidatListeKort, "r2yhjtv/SFYkBwbhjmIHeCzbQb0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatlisteContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useKandidatlisteContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$StillingsContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStillingsContext"]
    ];
});
_c = KandidatListeKort;
const __TURBOPACK__default__export__ = KandidatListeKort;
var _c;
__turbopack_context__.k.register(_c, "KandidatListeKort");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteFilter/KandidatlisteFilterContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "KandidatlisteFilterContextProvider",
    ()=>KandidatlisteFilterContextProvider,
    "KandidatlisteSortering",
    ()=>KandidatlisteSortering,
    "useKandidatlisteFilterContext",
    ()=>useKandidatlisteFilterContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_util$2f$stillingss$f8$k$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/_util/stillingssøk-typer.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/nuqs@2.8.6_next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_re_zj4u4m4nn2sly5cvn6ecp7cj4u/node_modules/nuqs/dist/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
;
;
var KandidatlisteFilterParam = /*#__PURE__*/ function(KandidatlisteFilterParam) {
    KandidatlisteFilterParam["SIDE"] = "kandidatlisteSide";
    KandidatlisteFilterParam["SORTERING"] = "kandidatlisteSortering";
    KandidatlisteFilterParam["INTERN_STATUS"] = "kandidatlsiteInternStatus";
    KandidatlisteFilterParam["VIS_SLETTEDE"] = "visSlettedeKandidater";
    KandidatlisteFilterParam["HENDELSE_TYPE"] = "kandidatlisteHendelseType";
    return KandidatlisteFilterParam;
}(KandidatlisteFilterParam || {});
var KandidatlisteSortering = /*#__PURE__*/ function(KandidatlisteSortering) {
    KandidatlisteSortering["NAVN_ASC"] = "navn-asc";
    KandidatlisteSortering["NAVN_DESC"] = "navn-desc";
    KandidatlisteSortering["LAGT_TIL_ASC"] = "lagt-til-asc";
    KandidatlisteSortering["LAGT_TIL_DESC"] = "lagt-til-desc";
    KandidatlisteSortering["HENDELSE_ASC"] = "hendelse-asc";
    KandidatlisteSortering["HENDELSE_DESC"] = "hendelse-desc";
    KandidatlisteSortering["VARSEL_ASC"] = "varsel-asc";
    KandidatlisteSortering["VARSEL_DESC"] = "varsel-desc";
    KandidatlisteSortering["INTERN_STATUS_ASC"] = "intern-status-asc";
    KandidatlisteSortering["INTERN_STATUS_DESC"] = "intern-status-desc";
    return KandidatlisteSortering;
}({});
const KandidatlisteFilterContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
const KandidatlisteFilterContextProvider = ({ children })=>{
    _s();
    const [sortering, setSortering] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useQueryState"])("kandidatlisteSortering", {
        defaultValue: '',
        clearOnDefault: true
    });
    const [fritekstSøk, setFritekstSøk] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [side, setSide] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useQueryState"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_util$2f$stillingss$f8$k$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StillingsSøkQueryparam"].Side, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["parseAsInteger"].withDefault(1).withOptions({
        clearOnDefault: true
    }));
    const [internStatus, setInternStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useQueryState"])("kandidatlsiteInternStatus", (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["parseAsArrayOf"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["parseAsString"]).withDefault([]).withOptions({
        clearOnDefault: true
    }));
    const [hendelseFilter, setHendelseFilter] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useQueryState"])("kandidatlisteHendelseType", (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["parseAsArrayOf"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["parseAsString"]).withDefault([]).withOptions({
        clearOnDefault: true
    }));
    const [visSlettede, setVisSlettede] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useQueryState"])("visSlettedeKandidater", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["parseAsString"].withDefault('false').withOptions({
        clearOnDefault: true
    }));
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(KandidatlisteFilterContext.Provider, {
        value: {
            sortering,
            setSortering,
            side,
            setSide,
            internStatus,
            setInternStatus,
            fritekstSøk,
            setFritekstSøk,
            visSlettede,
            setVisSlettede,
            hendelseFilter,
            setHendelseFilter
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteFilter/KandidatlisteFilterContext.tsx",
        lineNumber: 100,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(KandidatlisteFilterContextProvider, "PERLohdqYy4MDatzJfmqR4FHJu0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useQueryState"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useQueryState"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useQueryState"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useQueryState"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nuqs$40$2$2e$8$2e$6_next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_re_zj4u4m4nn2sly5cvn6ecp7cj4u$2f$node_modules$2f$nuqs$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useQueryState"]
    ];
});
_c = KandidatlisteFilterContextProvider;
const useKandidatlisteFilterContext = ()=>{
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(KandidatlisteFilterContext);
    if (context === undefined) {
        throw new Error('KandidatlisteFilterContext must be used within a KandidatlisteFilterContextProvider');
    }
    return context;
};
_s1(useKandidatlisteFilterContext, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_context__.k.register(_c, "KandidatlisteFilterContextProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteFilter/HendelseTypeFilter.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>HendelseTypeFilter
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteFilter/KandidatlisteFilterContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$kandidat$2f$util$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/kandidat/util.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/KandidatHendelseTag.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$checkbox$2f$Checkbox$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Checkbox$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/checkbox/Checkbox.js [app-client] (ecmascript) <export default as Checkbox>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$checkbox$2f$CheckboxGroup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckboxGroup$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/checkbox/CheckboxGroup.js [app-client] (ecmascript) <export default as CheckboxGroup>");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
function HendelseTypeFilter() {
    _s();
    const { hendelseFilter, setHendelseFilter } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useKandidatlisteFilterContext"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$checkbox$2f$CheckboxGroup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckboxGroup$3e$__["CheckboxGroup"], {
        legend: "Hendelse",
        children: Object.entries(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseType"]).filter(([key])=>key !== 'PRESENTERT' && key !== 'IKKE_PRESENTERT').map(([key, value])=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$checkbox$2f$Checkbox$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Checkbox$3e$__["Checkbox"], {
                value: key,
                defaultChecked: hendelseFilter?.includes(key),
                onChange: ()=>{
                    if (hendelseFilter.includes(key)) {
                        setHendelseFilter(hendelseFilter.filter((status)=>status !== key));
                    } else {
                        setHendelseFilter([
                            ...hendelseFilter,
                            key
                        ]);
                    }
                },
                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$kandidat$2f$util$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storForbokstavString"])(value ?? '').replace(/_/g, ' ')
            }, key, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteFilter/HendelseTypeFilter.tsx",
                lineNumber: 14,
                columnNumber: 11
            }, this))
    }, void 0, false, {
        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteFilter/HendelseTypeFilter.tsx",
        lineNumber: 10,
        columnNumber: 5
    }, this);
}
_s(HendelseTypeFilter, "vnrxmq0qMm4OdxjrtMAp9KhFg0k=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useKandidatlisteFilterContext"]
    ];
});
_c = HendelseTypeFilter;
var _c;
__turbopack_context__.k.register(_c, "HendelseTypeFilter");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteFilter/InternStatusFilter.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>InternStatusFilter
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteFilter/KandidatlisteFilterContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/KandidatTyper.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$InternStatusTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/InternStatusTag.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$checkbox$2f$Checkbox$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Checkbox$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/checkbox/Checkbox.js [app-client] (ecmascript) <export default as Checkbox>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$checkbox$2f$CheckboxGroup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckboxGroup$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/checkbox/CheckboxGroup.js [app-client] (ecmascript) <export default as CheckboxGroup>");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
function InternStatusFilter() {
    _s();
    const { internStatus, setInternStatus } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useKandidatlisteFilterContext"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$checkbox$2f$CheckboxGroup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckboxGroup$3e$__["CheckboxGroup"], {
        legend: "Intern status",
        children: Object.entries(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InternKandidatstatus"]).map(([key, value])=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$checkbox$2f$Checkbox$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Checkbox$3e$__["Checkbox"], {
                value: key,
                defaultChecked: internStatus.includes(key),
                onChange: ()=>{
                    if (internStatus.includes(key)) {
                        setInternStatus(internStatus.filter((status)=>status !== key));
                    } else {
                        setInternStatus([
                            ...internStatus,
                            key
                        ]);
                    }
                },
                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$InternStatusTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["internStatusTekst"])(value ?? '')
            }, key, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteFilter/InternStatusFilter.tsx",
                lineNumber: 12,
                columnNumber: 9
            }, this))
    }, void 0, false, {
        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteFilter/InternStatusFilter.tsx",
        lineNumber: 10,
        columnNumber: 5
    }, this);
}
_s(InternStatusFilter, "mg/+/dhYvCz94M76tB8207VOVm4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useKandidatlisteFilterContext"]
    ];
});
_c = InternStatusFilter;
var _c;
__turbopack_context__.k.register(_c, "InternStatusFilter");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteFilter/KandidatlisteChips.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>KandidatlisteChips
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteFilter/KandidatlisteFilterContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$filter$2f$FilterChip$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/filter/FilterChip.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$filter$2f$T$f8$mFiltre$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/filter/TømFiltre.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$chips$2f$Chips$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chips$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/chips/Chips.js [app-client] (ecmascript) <export default as Chips>");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
function KandidatlisteChips() {
    _s();
    const filter = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useKandidatlisteFilterContext"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "relative mt-4 w-full",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$chips$2f$Chips$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Chips$3e$__["Chips"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-row flex-wrap gap-2 pb-2",
                children: [
                    Object.values(filter).some((value)=>Array.isArray(value) && value.length > 0) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$filter$2f$T$f8$mFiltre$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        exlude: [
                            'stillingFane'
                        ]
                    }, void 0, false, {
                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteFilter/KandidatlisteChips.tsx",
                        lineNumber: 15,
                        columnNumber: 16
                    }, this),
                    filter.hendelseFilter && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$filter$2f$FilterChip$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        type: filter.hendelseFilter,
                        setVerdi: filter.setHendelseFilter
                    }, void 0, false, {
                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteFilter/KandidatlisteChips.tsx",
                        lineNumber: 18,
                        columnNumber: 13
                    }, this),
                    filter.internStatus && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$filter$2f$FilterChip$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        type: filter.internStatus,
                        setVerdi: filter.setInternStatus
                    }, void 0, false, {
                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteFilter/KandidatlisteChips.tsx",
                        lineNumber: 24,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteFilter/KandidatlisteChips.tsx",
                lineNumber: 12,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteFilter/KandidatlisteChips.tsx",
            lineNumber: 11,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteFilter/KandidatlisteChips.tsx",
        lineNumber: 10,
        columnNumber: 5
    }, this);
}
_s(KandidatlisteChips, "qFqYwdOh8BwxXk38PJE66iw9EvA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useKandidatlisteFilterContext"]
    ];
});
_c = KandidatlisteChips;
var _c;
__turbopack_context__.k.register(_c, "KandidatlisteChips");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteFilter/KandidatlisteFilterrad.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>KandidatlisteFilterrad
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$HendelseTypeFilter$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteFilter/HendelseTypeFilter.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$InternStatusFilter$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteFilter/InternStatusFilter.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteChips$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteFilter/KandidatlisteChips.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteFilter/KandidatlisteFilterContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$filter$2f$AlleFilterKomponent$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/filter/AlleFilterKomponent.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$filter$2f$FilterKomponent$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/filter/FilterKomponent.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$search$2f$Search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/search/Search.js [app-client] (ecmascript) <export default as Search>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$switch$2f$Switch$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Switch$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/switch/Switch.js [app-client] (ecmascript) <export default as Switch>");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
function KandidatlisteFilterrad() {
    _s();
    const { fritekstSøk, setFritekstSøk, visSlettede, setVisSlettede } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useKandidatlisteFilterContext"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "md:w-[15rem]",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$search$2f$Search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__["Search"], {
                            placeholder: "Søk i kandidatene",
                            label: "Kandidatsøk",
                            hideLabel: true,
                            variant: "secondary",
                            size: "small",
                            value: fritekstSøk,
                            onChange: (val)=>setFritekstSøk(val)
                        }, void 0, false, {
                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteFilter/KandidatlisteFilterrad.tsx",
                            lineNumber: 16,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteFilter/KandidatlisteFilterrad.tsx",
                        lineNumber: 15,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$filter$2f$FilterKomponent$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        tittel: "Hendelse",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$HendelseTypeFilter$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteFilter/KandidatlisteFilterrad.tsx",
                            lineNumber: 28,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteFilter/KandidatlisteFilterrad.tsx",
                        lineNumber: 27,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$filter$2f$FilterKomponent$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        tittel: "Intern status",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$InternStatusFilter$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteFilter/KandidatlisteFilterrad.tsx",
                            lineNumber: 31,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteFilter/KandidatlisteFilterrad.tsx",
                        lineNumber: 30,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$switch$2f$Switch$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Switch$3e$__["Switch"], {
                        value: visSlettede,
                        checked: visSlettede === 'true',
                        onChange: ()=>setVisSlettede(visSlettede === 'true' ? 'false' : 'true'),
                        children: "Vis slettede"
                    }, void 0, false, {
                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteFilter/KandidatlisteFilterrad.tsx",
                        lineNumber: 33,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "ml-auto",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$filter$2f$AlleFilterKomponent$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$HendelseTypeFilter$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteFilter/KandidatlisteFilterrad.tsx",
                                    lineNumber: 45,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$InternStatusFilter$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteFilter/KandidatlisteFilterrad.tsx",
                                    lineNumber: 46,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteFilter/KandidatlisteFilterrad.tsx",
                            lineNumber: 44,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteFilter/KandidatlisteFilterrad.tsx",
                        lineNumber: 43,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteFilter/KandidatlisteFilterrad.tsx",
                lineNumber: 14,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteChips$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteFilter/KandidatlisteFilterrad.tsx",
                lineNumber: 50,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteFilter/KandidatlisteFilterrad.tsx",
        lineNumber: 13,
        columnNumber: 5
    }, this);
}
_s(KandidatlisteFilterrad, "sz6r4+uDV/yolGeZ2qBclX8Cxz8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useKandidatlisteFilterContext"]
    ];
});
_c = KandidatlisteFilterrad;
var _c;
__turbopack_context__.k.register(_c, "KandidatlisteFilterrad");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteFilter/useFiltrerteKandidater.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteFilter/KandidatlisteFilterContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatlisteContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/KandidatlisteContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/KandidatHendelseTag.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
;
const useFiltrerteKandidater = ()=>{
    _s();
    const { kandidater, usynligeKandidater } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatlisteContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useKandidatlisteContext"])();
    const { fritekstSøk, sortering, internStatus, visSlettede, hendelseFilter } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useKandidatlisteFilterContext"])();
    const filtrerteKandidater = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useFiltrerteKandidater.useMemo[filtrerteKandidater]": ()=>{
            if (!kandidater) return null;
            const nyKandidatliste = [
                ...kandidater
            ];
            const nyUsynligListe = usynligeKandidater ? [
                ...usynligeKandidater
            ] : [];
            switch(sortering){
                case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatlisteSortering"].NAVN_ASC:
                case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatlisteSortering"].NAVN_DESC:
                    nyKandidatliste.sort({
                        "useFiltrerteKandidater.useMemo[filtrerteKandidater]": (a, b)=>{
                            const sammenligning = a.etternavn.localeCompare(b.etternavn, 'nb');
                            return sortering === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatlisteSortering"].NAVN_ASC ? sammenligning : -sammenligning;
                        }
                    }["useFiltrerteKandidater.useMemo[filtrerteKandidater]"]);
                    nyUsynligListe.sort({
                        "useFiltrerteKandidater.useMemo[filtrerteKandidater]": (a, b)=>{
                            const sammenligning = a.etternavn.localeCompare(b.etternavn, 'nb');
                            return sortering === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatlisteSortering"].NAVN_ASC ? sammenligning : -sammenligning;
                        }
                    }["useFiltrerteKandidater.useMemo[filtrerteKandidater]"]);
                    break;
                case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatlisteSortering"].LAGT_TIL_ASC:
                case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatlisteSortering"].LAGT_TIL_DESC:
                    nyKandidatliste.sort({
                        "useFiltrerteKandidater.useMemo[filtrerteKandidater]": (a, b)=>{
                            const datoA = new Date(a.lagtTilTidspunkt).getTime();
                            const datoB = new Date(b.lagtTilTidspunkt).getTime();
                            const sammenligning = datoA - datoB;
                            return sortering === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatlisteSortering"].LAGT_TIL_ASC ? sammenligning : -sammenligning;
                        }
                    }["useFiltrerteKandidater.useMemo[filtrerteKandidater]"]);
                    nyUsynligListe.sort({
                        "useFiltrerteKandidater.useMemo[filtrerteKandidater]": (a, b)=>{
                            const sammenligning = a.lagtTilAvNavn.localeCompare(b.lagtTilAvNavn, 'nb');
                            return sortering === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatlisteSortering"].LAGT_TIL_ASC ? sammenligning : -sammenligning;
                        }
                    }["useFiltrerteKandidater.useMemo[filtrerteKandidater]"]);
                    break;
                case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatlisteSortering"].HENDELSE_ASC:
                case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatlisteSortering"].HENDELSE_DESC:
                    nyKandidatliste.sort({
                        "useFiltrerteKandidater.useMemo[filtrerteKandidater]": (a, b)=>{
                            const aDato = a.kandidatHendelser.sisteHendelse?.dato?.getTime() || 0;
                            const bDato = b.kandidatHendelser.sisteHendelse?.dato?.getTime() || 0;
                            const datoSammenligning = bDato - aDato;
                            return sortering === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatlisteSortering"].HENDELSE_ASC ? datoSammenligning : -datoSammenligning;
                        }
                    }["useFiltrerteKandidater.useMemo[filtrerteKandidater]"]);
                    nyUsynligListe.sort({
                        "useFiltrerteKandidater.useMemo[filtrerteKandidater]": (a, b)=>{
                            const sammenligning = a.utfall.localeCompare(b.utfall, 'nb');
                            return sortering === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatlisteSortering"].HENDELSE_ASC ? sammenligning : -sammenligning;
                        }
                    }["useFiltrerteKandidater.useMemo[filtrerteKandidater]"]);
                    break;
                case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatlisteSortering"].VARSEL_ASC:
                case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatlisteSortering"].VARSEL_DESC:
                    nyKandidatliste.sort({
                        "useFiltrerteKandidater.useMemo[filtrerteKandidater]": (a, b)=>{
                            const aDato = a.kandidatHendelser.sisteSms?.dato?.getTime() || 0;
                            const bDato = b.kandidatHendelser.sisteSms?.dato?.getTime() || 0;
                            const datoSammenligning = bDato - aDato;
                            return sortering === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatlisteSortering"].VARSEL_ASC ? datoSammenligning : -datoSammenligning;
                        }
                    }["useFiltrerteKandidater.useMemo[filtrerteKandidater]"]);
                    break;
                case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatlisteSortering"].INTERN_STATUS_ASC:
                case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatlisteSortering"].INTERN_STATUS_DESC:
                    nyKandidatliste.sort({
                        "useFiltrerteKandidater.useMemo[filtrerteKandidater]": (a, b)=>{
                            const sammenligning = a.status.localeCompare(b.status, 'nb');
                            return sortering === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatlisteSortering"].INTERN_STATUS_ASC ? sammenligning : -sammenligning;
                        }
                    }["useFiltrerteKandidater.useMemo[filtrerteKandidater]"]);
                    break;
            }
            const fritekstKandidater = nyKandidatliste.filter({
                "useFiltrerteKandidater.useMemo[filtrerteKandidater].fritekstKandidater": (kandidat)=>{
                    const fullNavn = `${kandidat.fornavn} ${kandidat.etternavn}`;
                    const fødselsnummer = kandidat.fodselsnr;
                    return fullNavn.toLowerCase().includes(fritekstSøk.toLowerCase()) || fødselsnummer === fritekstSøk;
                }
            }["useFiltrerteKandidater.useMemo[filtrerteKandidater].fritekstKandidater"]).filter({
                "useFiltrerteKandidater.useMemo[filtrerteKandidater].fritekstKandidater": (kandidat)=>{
                    if (internStatus.length === 0) return true;
                    return internStatus.includes(kandidat.status);
                }
            }["useFiltrerteKandidater.useMemo[filtrerteKandidater].fritekstKandidater"]).filter({
                "useFiltrerteKandidater.useMemo[filtrerteKandidater].fritekstKandidater": (kandidat)=>{
                    if (hendelseFilter.length === 0) return true;
                    const filterTyper = hendelseFilter.map({
                        "useFiltrerteKandidater.useMemo[filtrerteKandidater].fritekstKandidater.filterTyper": (filter)=>__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseType"][filter]
                    }["useFiltrerteKandidater.useMemo[filtrerteKandidater].fritekstKandidater.filterTyper"]);
                    return filterTyper.some({
                        "useFiltrerteKandidater.useMemo[filtrerteKandidater].fritekstKandidater": (filter)=>{
                            if (kandidat.kandidatHendelser.sisteHendelse?.type === filter) {
                                return true;
                            }
                            return false;
                        }
                    }["useFiltrerteKandidater.useMemo[filtrerteKandidater].fritekstKandidater"]);
                }
            }["useFiltrerteKandidater.useMemo[filtrerteKandidater].fritekstKandidater"]).filter({
                "useFiltrerteKandidater.useMemo[filtrerteKandidater].fritekstKandidater": (kandidat)=>{
                    if (visSlettede === 'false') {
                        return !kandidat.arkivert;
                    } else {
                        return true;
                    }
                }
            }["useFiltrerteKandidater.useMemo[filtrerteKandidater].fritekstKandidater"]);
            const fritekstUsynlige = nyUsynligListe.filter({
                "useFiltrerteKandidater.useMemo[filtrerteKandidater].fritekstUsynlige": (kandidat)=>{
                    const fullNavn = `${kandidat.fornavn} ${kandidat.etternavn}`;
                    return fullNavn.toLowerCase().includes(fritekstSøk.toLowerCase());
                }
            }["useFiltrerteKandidater.useMemo[filtrerteKandidater].fritekstUsynlige"]);
            return {
                kandidater: fritekstKandidater,
                usynligeKandidater: fritekstUsynlige,
                totaltAntallKandidater: fritekstKandidater.length + (fritekstUsynlige?.length || 0)
            };
        }
    }["useFiltrerteKandidater.useMemo[filtrerteKandidater]"], [
        kandidater,
        usynligeKandidater,
        sortering,
        fritekstSøk,
        internStatus,
        visSlettede,
        hendelseFilter
    ]);
    return filtrerteKandidater;
};
_s(useFiltrerteKandidater, "L/LX89LVXuGYtE/vWxxQ5XYQ3r8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatlisteContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useKandidatlisteContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useKandidatlisteFilterContext"]
    ];
});
const __TURBOPACK__default__export__ = useFiltrerteKandidater;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedArbeidsgiver/ForhåndsvisningAvEpost.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/api-routes.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
const ForhåndsvisningAvEpost = ({ opprettetAvNavn, stillingstittel })=>{
    _s();
    const iframeRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const erstattPlaceholders = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ForhåndsvisningAvEpost.useCallback[erstattPlaceholders]": (iframe)=>{
            if (!iframe) return;
            let iframeDocument = null;
            try {
                // Kaster SecurityError hvis cross-origin
                iframeDocument = iframe.contentDocument || iframe.contentWindow?.document;
                // Ekstra verifikasjon: tilgang til body trigger også ev. SecurityError
                // eslint-disable-next-line @typescript-eslint/no-unused-expressions
                iframeDocument?.body;
            } catch  {
                // Cross-origin: Kan ikke manipulere innhold
                return;
            }
            if (!iframeDocument) return;
            const tittelElement = iframeDocument.getElementById('tittel');
            const stillingstittelElement = iframeDocument.getElementById('stillingstittel');
            const avsenderElement = iframeDocument.getElementById('avsender');
            if (tittelElement) tittelElement.textContent = stillingstittel || 'stilling';
            if (stillingstittelElement) stillingstittelElement.textContent = stillingstittel || 'stilling';
            if (avsenderElement) avsenderElement.textContent = opprettetAvNavn;
        }
    }["ForhåndsvisningAvEpost.useCallback[erstattPlaceholders]"], [
        opprettetAvNavn,
        stillingstittel
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ForhåndsvisningAvEpost.useEffect": ()=>{
            erstattPlaceholders(iframeRef.current);
        }
    }["ForhåndsvisningAvEpost.useEffect"], [
        erstattPlaceholders
    ]);
    const handleFerdigLastet = (iframe)=>{
        iframeRef.current = iframe;
        erstattPlaceholders(iframe);
    };
    const src = `${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ArbeidsgiverNotifikasjonAPI"].internUrl}/template`;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("iframe", {
        ref: iframeRef,
        title: "forhåndsvisning",
        className: "border-border-divider h-[30rem] max-h-full w-full rounded-lg border",
        onLoad: (event)=>handleFerdigLastet(event.currentTarget),
        src: src
    }, void 0, false, {
        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedArbeidsgiver/ForhåndsvisningAvEpost.tsx",
        lineNumber: 60,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(ForhåndsvisningAvEpost, "fRA1qiXy7HdPQENlQJLEcNbKXGU=");
_c = ForhåndsvisningAvEpost;
const __TURBOPACK__default__export__ = ForhåndsvisningAvEpost;
var _c;
__turbopack_context__.k.register(_c, "ForhåndsvisningAvEpost");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedArbeidsgiver/DelMedArbeidsgiver.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$DelMedArbeidsgiver$2f$Forh$e5$ndsvisningAvEpost$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedArbeidsgiver/ForhåndsvisningAvEpost.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$foresporsel$2d$om$2d$deling$2d$av$2d$cv$2f$foresporsler$2f5b2e2e2e$slug$5d2f$useForespurteOmDelingAvCv$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/foresporsel-om-deling-av-cv/foresporsler/[...slug]/useForespurteOmDelingAvCv.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2f$postDelMedArbeidsgiver$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/kandidat/postDelMedArbeidsgiver.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$StillingsContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/StillingsContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatlisteContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/KandidatlisteContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$SWRLaster$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/SWRLaster.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$ApplikasjonContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/providers/ApplikasjonContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$UmamiContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/providers/UmamiContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$umamiEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/util/umamiEvents.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$validerEpost$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/util/validerEpost.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$TasklistSend$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TasklistSendIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/TasklistSend.js [app-client] (ecmascript) <export default as TasklistSendIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Accordion$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/accordion/Accordion.js [app-client] (ecmascript) <export default as Accordion>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/alert/Alert.js [app-client] (ecmascript) <export default as Alert>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyLong$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyLong$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/BodyLong.js [app-client] (ecmascript) <export default as BodyLong>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/modal/Modal.js [app-client] (ecmascript) <export default as Modal>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/table/Table.js [app-client] (ecmascript) <export default as Table>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$ComboboxProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__UNSAFE_Combobox$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/combobox/ComboboxProvider.js [app-client] (ecmascript) <export default as UNSAFE_Combobox>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
const DelMedArbeidsgiver = ({ markerteKandidater })=>{
    _s();
    const { track } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$UmamiContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUmami"])();
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [visModal, setVisModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const { valgtNavKontor } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$ApplikasjonContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useApplikasjonContext"])();
    const { stillingsData } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$StillingsContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStillingsContext"])();
    const { kandidatlisteId, reFetchKandidatliste, kandidatlisteRawData } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatlisteContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useKandidatlisteContext"])();
    const forespurteKandidaterHook = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$foresporsel$2d$om$2d$deling$2d$av$2d$cv$2f$foresporsler$2f5b2e2e2e$slug$5d2f$useForespurteOmDelingAvCv$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useForespurteOmDelingAvCv"])(stillingsData.stilling.uuid);
    const eposter = stillingsData.stilling.contactList?.map((kontakt)=>kontakt.email).filter((email)=>email !== null && email.trim() !== '') || [];
    const [epost, setEpost] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(eposter);
    const onDelMedArbeidsgiver = async (kandidatnummerListe)=>{
        track(__TURBOPACK__imported__module__$5b$project$5d2f$util$2f$umamiEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UmamiEvent"].Stilling.del_kandidat_med_arbeidsgiver, {
            antall: kandidatnummerListe.length
        });
        setLoading(true);
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2f$postDelMedArbeidsgiver$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["postDelMedArbeidsgiver"])({
            kandidatlisteId: kandidatlisteId,
            kandidatnummerListe,
            mailadresser: epost,
            navKontor: valgtNavKontor?.navKontor ?? ''
        }).then(()=>{
            setLoading(false);
            setEpost([]);
            setVisModal(false);
            reFetchKandidatliste();
        });
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                onClick: ()=>setVisModal(true),
                disabled: markerteKandidater.length === 0,
                size: "xsmall",
                variant: "primary",
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$TasklistSend$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TasklistSendIcon$3e$__["TasklistSendIcon"], {
                    title: "Del med arbeidsgiver"
                }, void 0, false, {
                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedArbeidsgiver/DelMedArbeidsgiver.tsx",
                    lineNumber: 78,
                    columnNumber: 15
                }, void 0),
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "hidden lg:inline",
                    children: "Del CV med arbeidsgiver"
                }, void 0, false, {
                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedArbeidsgiver/DelMedArbeidsgiver.tsx",
                    lineNumber: 80,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedArbeidsgiver/DelMedArbeidsgiver.tsx",
                lineNumber: 73,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"], {
                className: "overflow-visible",
                width: 'medium',
                open: visModal,
                onClose: ()=>setVisModal(false),
                "aria-label": "Del kandidater med arbeidsgiver",
                header: {
                    heading: `Del med arbeidsgiver`
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$SWRLaster$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    hooks: [
                        forespurteKandidaterHook
                    ],
                    children: (forespurteKandidater)=>{
                        const harSvartJa = markerteKandidater.filter((kandidat)=>{
                            const forespørselCvForKandidat = (kandidat.aktørid && forespurteKandidater[kandidat.aktørid]) ?? null;
                            const svartJa = forespørselCvForKandidat ? forespørselCvForKandidat?.some((forespurt)=>forespurt.svar?.harSvartJa === true) : null;
                            return svartJa ? kandidat : null;
                        });
                        const alleHarSvartJa = harSvartJa.length === markerteKandidater.length;
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"].Body, {
                                    className: 'overflow-visible',
                                    children: [
                                        !alleHarSvartJa && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__["Alert"], {
                                            variant: "warning",
                                            size: "small",
                                            className: "mb-4",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyLong$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyLong$3e$__["BodyLong"], {
                                                children: [
                                                    harSvartJa.length === 0 ? 'Kandidaten(e) ' : `${markerteKandidater.length - harSvartJa.length} av kandidatene har `,
                                                    "har ikke svart eller svart nei på om CV-en kan deles."
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedArbeidsgiver/DelMedArbeidsgiver.tsx",
                                                lineNumber: 116,
                                                columnNumber: 23
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedArbeidsgiver/DelMedArbeidsgiver.tsx",
                                            lineNumber: 115,
                                            columnNumber: 21
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Accordion$3e$__["Accordion"], {
                                            size: "small",
                                            className: "my-4",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Accordion$3e$__["Accordion"].Item, {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Accordion$3e$__["Accordion"].Header, {
                                                        children: "Vis kandidater"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedArbeidsgiver/DelMedArbeidsgiver.tsx",
                                                        lineNumber: 126,
                                                        columnNumber: 23
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Accordion$3e$__["Accordion"].Content, {
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__["Table"], {
                                                            size: "small",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__["Table"].Header, {
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__["Table"].Row, {
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__["Table"].HeaderCell, {
                                                                                scope: "col",
                                                                                children: "Navn"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedArbeidsgiver/DelMedArbeidsgiver.tsx",
                                                                                lineNumber: 131,
                                                                                columnNumber: 31
                                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__["Table"].HeaderCell, {
                                                                                scope: "col",
                                                                                children: "Fødselsnr."
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedArbeidsgiver/DelMedArbeidsgiver.tsx",
                                                                                lineNumber: 134,
                                                                                columnNumber: 31
                                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__["Table"].HeaderCell, {
                                                                                scope: "col",
                                                                                children: "Kan deles"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedArbeidsgiver/DelMedArbeidsgiver.tsx",
                                                                                lineNumber: 137,
                                                                                columnNumber: 31
                                                                            }, ("TURBOPACK compile-time value", void 0))
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedArbeidsgiver/DelMedArbeidsgiver.tsx",
                                                                        lineNumber: 130,
                                                                        columnNumber: 29
                                                                    }, ("TURBOPACK compile-time value", void 0))
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedArbeidsgiver/DelMedArbeidsgiver.tsx",
                                                                    lineNumber: 129,
                                                                    columnNumber: 27
                                                                }, ("TURBOPACK compile-time value", void 0)),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__["Table"].Body, {
                                                                    children: markerteKandidater?.map(({ fornavn, etternavn, fodselsnr }, i)=>{
                                                                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__["Table"].Row, {
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__["Table"].HeaderCell, {
                                                                                    scope: "row",
                                                                                    children: [
                                                                                        fornavn,
                                                                                        " ",
                                                                                        etternavn
                                                                                    ]
                                                                                }, void 0, true, {
                                                                                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedArbeidsgiver/DelMedArbeidsgiver.tsx",
                                                                                    lineNumber: 147,
                                                                                    columnNumber: 37
                                                                                }, ("TURBOPACK compile-time value", void 0)),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__["Table"].DataCell, {
                                                                                    children: fodselsnr
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedArbeidsgiver/DelMedArbeidsgiver.tsx",
                                                                                    lineNumber: 150,
                                                                                    columnNumber: 37
                                                                                }, ("TURBOPACK compile-time value", void 0)),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__["Table"].DataCell, {
                                                                                    children: fodselsnr && harSvartJa.some((kandidat)=>kandidat.fodselsnr === fodselsnr) ? 'Ja' : 'Nei'
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedArbeidsgiver/DelMedArbeidsgiver.tsx",
                                                                                    lineNumber: 151,
                                                                                    columnNumber: 37
                                                                                }, ("TURBOPACK compile-time value", void 0))
                                                                            ]
                                                                        }, i, true, {
                                                                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedArbeidsgiver/DelMedArbeidsgiver.tsx",
                                                                            lineNumber: 146,
                                                                            columnNumber: 35
                                                                        }, ("TURBOPACK compile-time value", void 0));
                                                                    })
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedArbeidsgiver/DelMedArbeidsgiver.tsx",
                                                                    lineNumber: 142,
                                                                    columnNumber: 27
                                                                }, ("TURBOPACK compile-time value", void 0))
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedArbeidsgiver/DelMedArbeidsgiver.tsx",
                                                            lineNumber: 128,
                                                            columnNumber: 25
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedArbeidsgiver/DelMedArbeidsgiver.tsx",
                                                        lineNumber: 127,
                                                        columnNumber: 23
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedArbeidsgiver/DelMedArbeidsgiver.tsx",
                                                lineNumber: 125,
                                                columnNumber: 21
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedArbeidsgiver/DelMedArbeidsgiver.tsx",
                                            lineNumber: 124,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyLong$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyLong$3e$__["BodyLong"], {
                                            children: "Send en e-post med kandidater med arbeidsgiveren."
                                        }, void 0, false, {
                                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedArbeidsgiver/DelMedArbeidsgiver.tsx",
                                            lineNumber: 169,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$combobox$2f$ComboboxProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__UNSAFE_Combobox$3e$__["UNSAFE_Combobox"], {
                                            className: "my-4",
                                            allowNewValues: true,
                                            label: "E-post til arbeidsgiver",
                                            options: eposter,
                                            // isListOpen={false}
                                            // toggleListButton={false}
                                            selectedOptions: epost,
                                            shouldAutocomplete: false,
                                            isMultiSelect: true,
                                            onToggleSelected: (val, selected)=>{
                                                if (selected) {
                                                    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$validerEpost$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validerEpost"])(val).erGodkjent) {
                                                        setEpost([
                                                            ...epost,
                                                            val
                                                        ]);
                                                    }
                                                } else {
                                                    setEpost(epost.filter((e)=>e !== val));
                                                }
                                            }
                                        }, void 0, false, {
                                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedArbeidsgiver/DelMedArbeidsgiver.tsx",
                                            lineNumber: 173,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Accordion$3e$__["Accordion"], {
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Accordion$3e$__["Accordion"].Item, {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Accordion$3e$__["Accordion"].Header, {
                                                        children: "Forhåndsvis e-posten"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedArbeidsgiver/DelMedArbeidsgiver.tsx",
                                                        lineNumber: 196,
                                                        columnNumber: 23
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Accordion$3e$__["Accordion"].Content, {
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$DelMedArbeidsgiver$2f$Forh$e5$ndsvisningAvEpost$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                            stillingstittel: stillingsData.stilling.title,
                                                            opprettetAvNavn: kandidatlisteRawData.opprettetAv.navn
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedArbeidsgiver/DelMedArbeidsgiver.tsx",
                                                            lineNumber: 198,
                                                            columnNumber: 25
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedArbeidsgiver/DelMedArbeidsgiver.tsx",
                                                        lineNumber: 197,
                                                        columnNumber: 23
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedArbeidsgiver/DelMedArbeidsgiver.tsx",
                                                lineNumber: 195,
                                                columnNumber: 21
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedArbeidsgiver/DelMedArbeidsgiver.tsx",
                                            lineNumber: 194,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedArbeidsgiver/DelMedArbeidsgiver.tsx",
                                    lineNumber: 113,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"].Footer, {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                            variant: "secondary",
                                            onClick: ()=>setVisModal(false),
                                            children: "Avbryt"
                                        }, void 0, false, {
                                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedArbeidsgiver/DelMedArbeidsgiver.tsx",
                                            lineNumber: 209,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                            loading: loading,
                                            disabled: harSvartJa.length === 0 || epost.length === 0,
                                            variant: "primary",
                                            onClick: ()=>onDelMedArbeidsgiver(harSvartJa.map((kandidat)=>kandidat.kandidatnr).filter((id)=>id !== null)),
                                            children: "Del kandidatene"
                                        }, void 0, false, {
                                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedArbeidsgiver/DelMedArbeidsgiver.tsx",
                                            lineNumber: 215,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedArbeidsgiver/DelMedArbeidsgiver.tsx",
                                    lineNumber: 208,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true);
                    }
                }, void 0, false, {
                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedArbeidsgiver/DelMedArbeidsgiver.tsx",
                    lineNumber: 92,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedArbeidsgiver/DelMedArbeidsgiver.tsx",
                lineNumber: 82,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true);
};
_s(DelMedArbeidsgiver, "byuhTMDU1Z/4LKXAbIeZvD2Ia5k=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$UmamiContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUmami"],
        __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$ApplikasjonContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useApplikasjonContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$StillingsContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStillingsContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatlisteContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useKandidatlisteContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$foresporsel$2d$om$2d$deling$2d$av$2d$cv$2f$foresporsler$2f5b2e2e2e$slug$5d2f$useForespurteOmDelingAvCv$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useForespurteOmDelingAvCv"]
    ];
});
_c = DelMedArbeidsgiver;
const __TURBOPACK__default__export__ = DelMedArbeidsgiver;
var _c;
__turbopack_context__.k.register(_c, "DelMedArbeidsgiver");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedKandidat/VelgSvarfrist.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Svarfrist",
    ()=>Svarfrist,
    "default",
    ()=>__TURBOPACK__default__export__,
    "lagFristFraSvarfrist",
    ()=>lagFristFraSvarfrist
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/BodyShort.js [app-client] (ecmascript) <export default as BodyShort>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$date$2f$datepicker$2f$DatePicker$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DatePicker$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/date/datepicker/DatePicker.js [app-client] (ecmascript) <export default as DatePicker>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$Label$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Label$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/Label.js [app-client] (ecmascript) <export default as Label>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$radio$2f$Radio$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Radio$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/radio/Radio.js [app-client] (ecmascript) <export default as Radio>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$radio$2f$RadioGroup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__RadioGroup$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/radio/RadioGroup.js [app-client] (ecmascript) <export default as RadioGroup>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$date$2f$datepicker$2f$hooks$2f$useDatepicker$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/date/datepicker/hooks/useDatepicker.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$addDays$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/addDays.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$addMonths$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/addMonths.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/format.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$nb$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/locale/nb.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
var Svarfrist = /*#__PURE__*/ function(Svarfrist) {
    Svarfrist["ToDager"] = "TO_DAGER";
    Svarfrist["TreDager"] = "TRE_DAGER";
    Svarfrist["SyvDager"] = "SYV_DAGER";
    Svarfrist["Egenvalgt"] = "EGENVALGT";
    return Svarfrist;
}({});
const svarfristLabels = {
    ["TO_DAGER"]: '2 dager',
    ["TRE_DAGER"]: '3 dager',
    ["SYV_DAGER"]: '7 dager',
    ["EGENVALGT"]: 'Egenvalgt'
};
const VelgSvarfrist = ({ tittel, setValgtSvarfrist })=>{
    _s();
    const [svarFrist, setSvarFrist] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(undefined);
    const [valgtRadiobutton, setValgtRadiobutton] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const { datepickerProps, inputProps } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$date$2f$datepicker$2f$hooks$2f$useDatepicker$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDatepicker"])({
        fromDate: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$addDays$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addDays"])(new Date(), 2),
        toDate: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$addMonths$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addMonths"])(new Date(), 1),
        onDateChange: {
            "VelgSvarfrist.useDatepicker": (date)=>setSvarFrist(date)
        }["VelgSvarfrist.useDatepicker"],
        defaultSelected: svarFrist,
        // onValidate: onEgenvalgValidation,
        inputFormat: 'dd.MM.yyyy',
        allowTwoDigitYear: false
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "VelgSvarfrist.useEffect": ()=>{
            if (svarFrist) {
                setValgtSvarfrist(svarFrist);
            }
        }
    }["VelgSvarfrist.useEffect"], [
        svarFrist,
        setValgtSvarfrist
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: 'my-4',
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$radio$2f$RadioGroup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__RadioGroup$3e$__["RadioGroup"], {
                legend: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$Label$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Label$3e$__["Label"], {
                            as: "span",
                            children: tittel || 'Frist for svar'
                        }, void 0, false, {
                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedKandidat/VelgSvarfrist.tsx",
                            lineNumber: 63,
                            columnNumber: 13
                        }, void 0),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__["BodyShort"], {
                            as: "span",
                            children: " (må fylles ut)"
                        }, void 0, false, {
                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedKandidat/VelgSvarfrist.tsx",
                            lineNumber: 64,
                            columnNumber: 13
                        }, void 0)
                    ]
                }, void 0, true),
                description: "Kandidatene kan ikke svare etter denne fristen",
                defaultValue: null,
                children: Object.values(Svarfrist).map((value)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$radio$2f$Radio$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Radio$3e$__["Radio"], {
                        name: "svarfrist",
                        value: value,
                        onChange: (e)=>{
                            const valg = e.target.value;
                            setValgtRadiobutton(valg);
                            {
                                if (valg === "EGENVALGT") {
                                    setSvarFrist(undefined);
                                } else {
                                    setSvarFrist(lagFristFraSvarfrist(valg));
                                }
                            }
                        },
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            id: `svarfrist-label_${value}`,
                            children: `${svarfristLabels[value]} ${lagBeskrivelseAvSvarfrist(value)}`
                        }, void 0, false, {
                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedKandidat/VelgSvarfrist.tsx",
                            lineNumber: 87,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, value, false, {
                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedKandidat/VelgSvarfrist.tsx",
                        lineNumber: 71,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)))
            }, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedKandidat/VelgSvarfrist.tsx",
                lineNumber: 60,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$date$2f$datepicker$2f$DatePicker$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DatePicker$3e$__["DatePicker"], {
                ...datepickerProps,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$date$2f$datepicker$2f$DatePicker$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DatePicker$3e$__["DatePicker"].Input, {
                    ...inputProps,
                    // error={egenvalgtFristFeilmelding}
                    label: "Velg frist for svar (frist ut valgt dato)",
                    placeholder: "dd.mm.yyyy",
                    disabled: valgtRadiobutton !== "EGENVALGT"
                }, void 0, false, {
                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedKandidat/VelgSvarfrist.tsx",
                    lineNumber: 95,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedKandidat/VelgSvarfrist.tsx",
                lineNumber: 94,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedKandidat/VelgSvarfrist.tsx",
        lineNumber: 59,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(VelgSvarfrist, "1v1Fk1JZsBX9ohNR2Ni6D3jKwFk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$date$2f$datepicker$2f$hooks$2f$useDatepicker$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDatepicker"]
    ];
});
_c = VelgSvarfrist;
const lagBeskrivelseAvSvarfrist = (svarfrist)=>{
    let dato = new Date();
    if (svarfrist === "TO_DAGER") {
        dato = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$addDays$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addDays"])(dato, 2);
    } else if (svarfrist === "TRE_DAGER") {
        dato = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$addDays$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addDays"])(dato, 3);
    } else if (svarfrist === "SYV_DAGER") {
        dato = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$addDays$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addDays"])(dato, 7);
    } else {
        return '';
    }
    return `(frist ut ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(dato, 'EEEE d. MMMM', {
        locale: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$nb$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["nb"]
    })})`;
};
const lagFristFraSvarfrist = (svarfrist)=>{
    switch(svarfrist){
        case "TO_DAGER":
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$addDays$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addDays"])(new Date(), 2);
        case "TRE_DAGER":
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$addDays$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addDays"])(new Date(), 3);
        case "SYV_DAGER":
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$addDays$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addDays"])(new Date(), 7);
    }
};
const __TURBOPACK__default__export__ = VelgSvarfrist;
var _c;
__turbopack_context__.k.register(_c, "VelgSvarfrist");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/hendelseUtil.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CVAlleredeForespurtDeling",
    ()=>CVAlleredeForespurtDeling,
    "CVKandidaterSvartJa",
    ()=>CVKandidaterSvartJa,
    "CVKandidaterSvartNei_IkkeSpurtPåNytt",
    ()=>CVKandidaterSvartNei_IkkeSpurtPåNytt,
    "CVkandidaterMedUtløptFrist_IkkeSpurtPåNytt",
    ()=>CVkandidaterMedUtløptFrist_IkkeSpurtPåNytt
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/KandidatHendelseTag.tsx [app-client] (ecmascript)");
;
const CVKandidaterSvartJa = (kandidater)=>{
    return kandidater.filter((k)=>{
        const cvHendelser = k.kandidatHendelser.cvHendelser;
        if (!cvHendelser || cvHendelser.length === 0) {
            return false;
        }
        if (cvHendelser.some((hendelse)=>hendelse.type === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseType"].Deling_av_CV_JA)) {
            return true;
        }
        return false;
    });
};
_c = CVKandidaterSvartJa;
const CVKandidaterSvartNei_IkkeSpurtPåNytt = (kandidater)=>{
    return kandidater.filter((k)=>{
        const cvHendelser = k.kandidatHendelser.cvHendelser;
        if (!cvHendelser || cvHendelser.length === 0) {
            return false;
        }
        const neiHendelser = cvHendelser.filter((hendelse)=>hendelse.type === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseType"].Deling_av_CV_NEI);
        if (neiHendelser.length === 0) {
            return false;
        }
        const sisteNeiHendelse = neiHendelser[0];
        const tidspunktNei = new Date(sisteNeiHendelse.dato || '');
        const senereSpurtHendelseFinnes = cvHendelser.some((hendelse)=>{
            if (hendelse.type === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseType"].Spurt_om_å_dele_CV || hendelse.type === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseType"].Deling_av_CV_JA || hendelse.type === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseType"].Spurt_om_å_dele_CV_IKKE_DIGITAL) {
                const tidspunktSpurt = new Date(hendelse.dato || '');
                return tidspunktSpurt > tidspunktNei;
            }
            return false;
        });
        return !senereSpurtHendelseFinnes;
    });
};
_c1 = CVKandidaterSvartNei_IkkeSpurtPåNytt;
const CVkandidaterMedUtløptFrist_IkkeSpurtPåNytt = (kandidater)=>kandidater.filter((k)=>{
        const cvHendelser = k.kandidatHendelser.cvHendelser;
        if (!cvHendelser || cvHendelser.length === 0) {
            return false;
        }
        const fristUtløptHendelse = cvHendelser?.filter((h)=>h.type === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseType"].Frist_for_deling_av_cv_utløpt);
        if (fristUtløptHendelse.length === 0) {
            return false;
        }
        const sisteNeiHendelse = fristUtløptHendelse[0];
        const tidspunktNei = new Date(sisteNeiHendelse.dato || '');
        const senereSpurtHendelseFinnes = cvHendelser.some((hendelse)=>{
            if (hendelse.type === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseType"].Spurt_om_å_dele_CV || hendelse.type === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseType"].Spurt_om_å_dele_CV_IKKE_DIGITAL) {
                const tidspunktSpurt = new Date(hendelse.dato || '');
                return tidspunktSpurt > tidspunktNei;
            }
            return false;
        });
        return !senereSpurtHendelseFinnes;
    });
_c2 = CVkandidaterMedUtløptFrist_IkkeSpurtPåNytt;
const CVAlleredeForespurtDeling = (kandidater)=>kandidater.filter((k)=>{
        const cvHendelser = k.kandidatHendelser.cvHendelser;
        if (!cvHendelser || cvHendelser.length === 0) {
            return false;
        }
        const harDelingsHendelse = cvHendelser.some((hendelse)=>{
            if (hendelse.type === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseType"].Spurt_om_å_dele_CV || hendelse.type === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$KandidatHendelseTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatHendelseType"].Spurt_om_å_dele_CV_IKKE_DIGITAL) {
                const svarfrist = hendelse.raw && 'svarfrist' in hendelse.raw ? new Date(hendelse.raw.svarfrist || '') : null;
                return svarfrist && svarfrist > new Date();
            }
            return false;
        });
        return harDelingsHendelse;
    });
_c3 = CVAlleredeForespurtDeling;
var _c, _c1, _c2, _c3;
__turbopack_context__.k.register(_c, "CVKandidaterSvartJa");
__turbopack_context__.k.register(_c1, "CVKandidaterSvartNei_IkkeSpurtPåNytt");
__turbopack_context__.k.register(_c2, "CVkandidaterMedUtløptFrist_IkkeSpurtPåNytt");
__turbopack_context__.k.register(_c3, "CVAlleredeForespurtDeling");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedKandidat/DelMedKandidatModal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$DelMedKandidat$2f$VelgSvarfrist$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedKandidat/VelgSvarfrist.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$foresporsel$2d$om$2d$deling$2d$av$2d$cv$2f$foresporsler$2f5b2e2e2e$slug$5d2f$useForespurteOmDelingAvCv$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/foresporsel-om-deling-av-cv/foresporsler/[...slug]/useForespurteOmDelingAvCv.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$foresporsel$2d$om$2d$deling$2d$av$2d$cv$2f$foresporsler$2f$foresp$f8$rselOmDelingAvCv$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/foresporsel-om-deling-av-cv/foresporsler/forespørselOmDelingAvCv.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$StillingsContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/StillingsContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatlisteContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/KandidatlisteContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$hendelseUtil$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/hendelseUtil.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$ApplikasjonContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/providers/ApplikasjonContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$UmamiContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/providers/UmamiContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$rekbisError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/util/rekbisError.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$umamiEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/util/umamiEvents.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$Tasklist$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TasklistIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/Tasklist.js [app-client] (ecmascript) <export default as TasklistIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Accordion$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/accordion/Accordion.js [app-client] (ecmascript) <export default as Accordion>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/alert/Alert.js [app-client] (ecmascript) <export default as Alert>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyLong$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyLong$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/BodyLong.js [app-client] (ecmascript) <export default as BodyLong>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/BodyShort.js [app-client] (ecmascript) <export default as BodyShort>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/modal/Modal.js [app-client] (ecmascript) <export default as Modal>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/table/Table.js [app-client] (ecmascript) <export default as Table>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$endOfDay$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/endOfDay.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/format.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const DelMedKandidatModal = ({ markerteKandidater, fjernAllMarkering })=>{
    _s();
    const { track } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$UmamiContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUmami"])();
    const { stillingsId } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$StillingsContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStillingsContext"])();
    const [modalErÅpen, setModalErÅpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [svarfrist, setSvarfrist] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(undefined);
    const { valgtNavKontor, visVarsel } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$ApplikasjonContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useApplikasjonContext"])();
    const { reFetchKandidatliste } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatlisteContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useKandidatlisteContext"])();
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const forespurteKandidaterHook = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$foresporsel$2d$om$2d$deling$2d$av$2d$cv$2f$foresporsler$2f5b2e2e2e$slug$5d2f$useForespurteOmDelingAvCv$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useForespurteOmDelingAvCv"])(stillingsId);
    const kandidaterSvartNei = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$hendelseUtil$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CVKandidaterSvartNei_IkkeSpurtPåNytt"])(markerteKandidater);
    const kandidatFristUtløpt = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$hendelseUtil$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CVkandidaterMedUtløptFrist_IkkeSpurtPåNytt"])(markerteKandidater);
    const kandidaterVenterPåSvar = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$hendelseUtil$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CVAlleredeForespurtDeling"])(markerteKandidater);
    const harSvartJa = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelser$2f$hendelseUtil$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CVKandidaterSvartJa"])(markerteKandidater);
    const delCVpåNytt = [
        ...kandidaterSvartNei,
        ...kandidatFristUtløpt
    ].filter((kandidat)=>!harSvartJa.some((k)=>k.aktørid === kandidat.aktørid));
    const delFørsteGang = markerteKandidater.filter((kandidat)=>!harSvartJa.some((k)=>k.aktørid === kandidat.aktørid) && !kandidaterSvartNei.some((k)=>k.aktørid === kandidat.aktørid) && !kandidatFristUtløpt.some((k)=>k.aktørid === kandidat.aktørid) && !kandidaterVenterPåSvar.some((k)=>k.aktørid === kandidat.aktørid));
    const sendForespørsel = async ()=>{
        const vanlgiDeling = delFørsteGang.map((kandidat)=>kandidat.aktørid).filter((id)=>id !== null);
        const delingPåNytt = delCVpåNytt.filter((kandidat)=>kandidat.aktørid);
        if (svarfrist) {
            setLoading(true);
            try {
                if (vanlgiDeling.length > 0) {
                    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$foresporsel$2d$om$2d$deling$2d$av$2d$cv$2f$foresporsler$2f$foresp$f8$rselOmDelingAvCv$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sendForespørselOmDelingAvCv"])({
                        stillingsId: stillingsId,
                        svarfrist: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$endOfDay$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["endOfDay"])(svarfrist), "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"),
                        aktorIder: vanlgiDeling,
                        navKontor: valgtNavKontor?.navKontor ?? ''
                    });
                    track(__TURBOPACK__imported__module__$5b$project$5d2f$util$2f$umamiEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UmamiEvent"].Stilling.del_stilling_med_kandidat, {
                        antall: vanlgiDeling.length
                    });
                }
                if (delingPåNytt.length > 0) {
                    const nyeForespørslerPromises = delingPåNytt.map((kandidat)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$foresporsel$2d$om$2d$deling$2d$av$2d$cv$2f$foresporsler$2f$foresp$f8$rselOmDelingAvCv$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sendNyForespørselOmDelingAvCv"])(kandidat.aktørid, {
                            stillingsId: stillingsId,
                            svarfrist: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$endOfDay$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["endOfDay"])(svarfrist), "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"),
                            navKontor: valgtNavKontor?.navKontor ?? ''
                        }));
                    track(__TURBOPACK__imported__module__$5b$project$5d2f$util$2f$umamiEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UmamiEvent"].Stilling.del_stilling_med_kandidat_påNytt, {
                        antall: delingPåNytt.length
                    });
                    await Promise.all(nyeForespørslerPromises);
                }
                visVarsel({
                    tekst: 'Stillingen er delt med kandidatene',
                    type: 'info'
                });
            } catch (error) {
                new __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$rekbisError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RekbisError"]({
                    message: 'Feil ved deling av CV for kandidater',
                    error
                });
                visVarsel({
                    tekst: 'Det oppstod en feil ved deling av stilling til alle markerte kandidater',
                    type: 'error'
                });
            } finally{
                fjernAllMarkering();
                setModalErÅpen(false);
                setLoading(false);
                setTimeout(()=>{
                    forespurteKandidaterHook.mutate();
                    reFetchKandidatliste();
                }, 5000); // 5000 milliseconds = 5 seconds
            }
        }
    };
    const tabellStatus = (aktørId)=>{
        if (aktørId === null) {
            return 'Kan ikke spørre';
        }
        switch(true){
            case harSvartJa.some((k)=>k.aktørid === aktørId):
                return 'Har allerede svart ja';
            case kandidaterVenterPåSvar.some((k)=>k.aktørid === aktørId):
                return 'Venter på svar';
            case kandidaterSvartNei.some((k)=>k.aktørid === aktørId):
                return 'Har tidligere svart nei';
            case kandidatFristUtløpt.some((k)=>k.aktørid === aktørId):
                return 'Frist utløpt';
            default:
                return 'Ikke spurt';
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                disabled: markerteKandidater.length === 0,
                onClick: ()=>setModalErÅpen(true),
                size: "xsmall",
                variant: "primary",
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$Tasklist$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TasklistIcon$3e$__["TasklistIcon"], {
                    title: "Del med jobbsøker"
                }, void 0, false, {
                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedKandidat/DelMedKandidatModal.tsx",
                    lineNumber: 167,
                    columnNumber: 15
                }, void 0),
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "hidden lg:inline",
                    children: "Spør om å dele CV"
                }, void 0, false, {
                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedKandidat/DelMedKandidatModal.tsx",
                    lineNumber: 169,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedKandidat/DelMedKandidatModal.tsx",
                lineNumber: 162,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"], {
                open: modalErÅpen,
                "aria-label": "Del stillingen med de markerte jobbsøkere",
                onClose: ()=>setModalErÅpen(false),
                header: {
                    heading: `Del med ${markerteKandidater.length} ${markerteKandidater.length === 1 ? 'jobbsøker ' : 'jobbsøkere'} i aktivitetsplanen`
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"].Body, {
                        children: [
                            kandidaterVenterPåSvar.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__["Alert"], {
                                variant: "info",
                                size: "small",
                                className: "mb-1",
                                children: [
                                    kandidaterVenterPåSvar.length,
                                    ' ',
                                    kandidaterVenterPåSvar.length === 1 ? 'jobbsøker ' : 'jobbsøkere',
                                    "har ikke svart på forespørselen."
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedKandidat/DelMedKandidatModal.tsx",
                                lineNumber: 183,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            kandidaterSvartNei.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__["Alert"], {
                                variant: "error",
                                size: "small",
                                className: "mb-1",
                                children: [
                                    kandidaterSvartNei.length,
                                    ' ',
                                    kandidaterSvartNei.length === 1 ? 'jobbsøker ' : 'jobbsøkere',
                                    "har tidliger svart nei til å dele CV-en."
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedKandidat/DelMedKandidatModal.tsx",
                                lineNumber: 192,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            kandidatFristUtløpt.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__["Alert"], {
                                variant: "warning",
                                size: "small",
                                className: "mb-1",
                                children: [
                                    kandidatFristUtløpt.length,
                                    ' ',
                                    kandidatFristUtløpt.length === 1 ? 'jobbsøker ' : 'jobbsøkere',
                                    "har tidligere fått spørsmål, men ikke svart innen fristen."
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedKandidat/DelMedKandidatModal.tsx",
                                lineNumber: 199,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            harSvartJa.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__["Alert"], {
                                variant: "success",
                                size: "small",
                                className: "mb-1",
                                children: [
                                    harSvartJa.length,
                                    ' ',
                                    harSvartJa.length === 1 ? 'jobbsøker ' : 'jobbsøkere',
                                    "har allerede svart ja."
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedKandidat/DelMedKandidatModal.tsx",
                                lineNumber: 206,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Accordion$3e$__["Accordion"], {
                                size: "small",
                                className: "my-4",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Accordion$3e$__["Accordion"].Item, {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Accordion$3e$__["Accordion"].Header, {
                                            children: "Vis jobbsøkere"
                                        }, void 0, false, {
                                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedKandidat/DelMedKandidatModal.tsx",
                                            lineNumber: 214,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Accordion$3e$__["Accordion"].Content, {
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__["Table"], {
                                                size: "small",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__["Table"].Header, {
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__["Table"].Row, {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__["Table"].HeaderCell, {
                                                                    scope: "col",
                                                                    children: "Navn"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedKandidat/DelMedKandidatModal.tsx",
                                                                    lineNumber: 219,
                                                                    columnNumber: 23
                                                                }, ("TURBOPACK compile-time value", void 0)),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__["Table"].HeaderCell, {
                                                                    scope: "col",
                                                                    children: "Fødselsnr."
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedKandidat/DelMedKandidatModal.tsx",
                                                                    lineNumber: 220,
                                                                    columnNumber: 23
                                                                }, ("TURBOPACK compile-time value", void 0)),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__["Table"].HeaderCell, {
                                                                    scope: "col",
                                                                    children: "Status"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedKandidat/DelMedKandidatModal.tsx",
                                                                    lineNumber: 223,
                                                                    columnNumber: 23
                                                                }, ("TURBOPACK compile-time value", void 0))
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedKandidat/DelMedKandidatModal.tsx",
                                                            lineNumber: 218,
                                                            columnNumber: 21
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedKandidat/DelMedKandidatModal.tsx",
                                                        lineNumber: 217,
                                                        columnNumber: 19
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__["Table"].Body, {
                                                        children: markerteKandidater?.map(({ fornavn, etternavn, fodselsnr, aktørid }, i)=>{
                                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__["Table"].Row, {
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__["Table"].HeaderCell, {
                                                                        scope: "row",
                                                                        children: [
                                                                            fornavn,
                                                                            " ",
                                                                            etternavn
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedKandidat/DelMedKandidatModal.tsx",
                                                                        lineNumber: 231,
                                                                        columnNumber: 29
                                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__["Table"].DataCell, {
                                                                        children: fodselsnr
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedKandidat/DelMedKandidatModal.tsx",
                                                                        lineNumber: 234,
                                                                        columnNumber: 29
                                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Table$3e$__["Table"].DataCell, {
                                                                        children: tabellStatus(aktørid)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedKandidat/DelMedKandidatModal.tsx",
                                                                        lineNumber: 235,
                                                                        columnNumber: 29
                                                                    }, ("TURBOPACK compile-time value", void 0))
                                                                ]
                                                            }, i, true, {
                                                                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedKandidat/DelMedKandidatModal.tsx",
                                                                lineNumber: 230,
                                                                columnNumber: 27
                                                            }, ("TURBOPACK compile-time value", void 0));
                                                        })
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedKandidat/DelMedKandidatModal.tsx",
                                                        lineNumber: 226,
                                                        columnNumber: 19
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedKandidat/DelMedKandidatModal.tsx",
                                                lineNumber: 216,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedKandidat/DelMedKandidatModal.tsx",
                                            lineNumber: 215,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedKandidat/DelMedKandidatModal.tsx",
                                    lineNumber: 213,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedKandidat/DelMedKandidatModal.tsx",
                                lineNumber: 212,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__["BodyShort"], {
                                className: "my-8",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: [
                                        delFørsteGang.length > 0 && `Deler for første gang stillingen med ${delFørsteGang.length} ${delFørsteGang.length === 1 ? 'jobbsøker' : 'jobbsøkere'}.`,
                                        delCVpåNytt.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedKandidat/DelMedKandidatModal.tsx",
                                                    lineNumber: 256,
                                                    columnNumber: 19
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                `Spør om deling på nytt for ${delCVpåNytt.length} ${delCVpåNytt.length === 1 ? 'jobbsøker' : 'jobbsøkere'}.`
                                            ]
                                        }, void 0, true)
                                    ]
                                }, void 0, true)
                            }, void 0, false, {
                                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedKandidat/DelMedKandidatModal.tsx",
                                lineNumber: 248,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyLong$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyLong$3e$__["BodyLong"], {
                                className: "my-8",
                                children: `Det opprettes et stillingskort i Aktivitetsplanen. Jobbsøkere
                  vil bli varslet på SMS, og kan svare "ja" eller "nei" til at
                  CV-en skal bli delt med arbeidsgiver. Du vil se svaret i
                  kandidatlisten.`
                            }, void 0, false, {
                                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedKandidat/DelMedKandidatModal.tsx",
                                lineNumber: 264,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$DelMedKandidat$2f$VelgSvarfrist$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                setValgtSvarfrist: setSvarfrist
                            }, void 0, false, {
                                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedKandidat/DelMedKandidatModal.tsx",
                                lineNumber: 271,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Alert$3e$__["Alert"], {
                                variant: "info",
                                className: 'mt-8',
                                children: [
                                    "Stillingsoppdraget vil bli delt med jobbsøker.",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedKandidat/DelMedKandidatModal.tsx",
                                        lineNumber: 274,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    " Det er viktig at annonseteksten er informativ og lett å forstå."
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedKandidat/DelMedKandidatModal.tsx",
                                lineNumber: 272,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedKandidat/DelMedKandidatModal.tsx",
                        lineNumber: 181,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"].Footer, {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                disabled: !svarfrist || markerteKandidater.length === 0,
                                onClick: sendForespørsel,
                                variant: "primary",
                                loading: loading,
                                children: "Del stilling"
                            }, void 0, false, {
                                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedKandidat/DelMedKandidatModal.tsx",
                                lineNumber: 279,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                disabled: loading,
                                variant: "secondary",
                                onClick: ()=>setModalErÅpen(false),
                                children: "Avbryt"
                            }, void 0, false, {
                                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedKandidat/DelMedKandidatModal.tsx",
                                lineNumber: 287,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedKandidat/DelMedKandidatModal.tsx",
                        lineNumber: 278,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedKandidat/DelMedKandidatModal.tsx",
                lineNumber: 171,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true);
};
_s(DelMedKandidatModal, "Qo2meDy0FtMG/GtYtopNVeq30Uw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$UmamiContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUmami"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$StillingsContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStillingsContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$ApplikasjonContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useApplikasjonContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatlisteContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useKandidatlisteContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$foresporsel$2d$om$2d$deling$2d$av$2d$cv$2f$foresporsler$2f5b2e2e2e$slug$5d2f$useForespurteOmDelingAvCv$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useForespurteOmDelingAvCv"]
    ];
});
_c = DelMedKandidatModal;
const __TURBOPACK__default__export__ = DelMedKandidatModal;
var _c;
__turbopack_context__.k.register(_c, "DelMedKandidatModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteHandlingsRad.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$DelMedArbeidsgiver$2f$DelMedArbeidsgiver$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedArbeidsgiver/DelMedArbeidsgiver.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$DelMedKandidat$2f$DelMedKandidatModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/DelMedKandidat/DelMedKandidatModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$useFiltrerteKandidater$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteFilter/useFiltrerteKandidater.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$SendSMS$2f$SendSmsModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$StillingsContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/StillingsContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatlisteContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/KandidatlisteContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$SendSMS$2f$SendSmsKnapp$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/SendSMS/SendSmsKnapp.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$checkbox$2f$Checkbox$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Checkbox$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/form/checkbox/Checkbox.js [app-client] (ecmascript) <export default as Checkbox>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
const KandidatlisteHandlingsRad = ()=>{
    _s();
    const { kandidater, lukketKandidatliste, markerteKandidater, setMarkerteKandidater } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatlisteContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useKandidatlisteContext"])();
    const { omStilling: { erJobbmesse } } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$StillingsContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStillingsContext"])();
    // filtrerteKandidater
    const filtrerteKandidater = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$useFiltrerteKandidater$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    const [visSendSmsModal, setVisSendSmsModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-row flex-wrap items-baseline gap-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$form$2f$checkbox$2f$Checkbox$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Checkbox$3e$__["Checkbox"], {
                className: "ml-5",
                disabled: lukketKandidatliste,
                checked: markerteKandidater && markerteKandidater.length === kandidater.length,
                indeterminate: markerteKandidater && markerteKandidater.length > 0 && markerteKandidater.length !== kandidater.length,
                onChange: ()=>{
                    if (markerteKandidater.length) {
                        setMarkerteKandidater([]);
                    } else {
                        if (filtrerteKandidater?.kandidater) {
                            setMarkerteKandidater(filtrerteKandidater.kandidater.filter((k)=>k.fodselsnr !== null));
                        }
                    }
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    children: markerteKandidater.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: [
                            " ",
                            markerteKandidater.length,
                            " valgt"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteHandlingsRad.tsx",
                        lineNumber: 57,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteHandlingsRad.tsx",
                    lineNumber: 55,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteHandlingsRad.tsx",
                lineNumber: 30,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            !lukketKandidatliste && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    !erJobbmesse && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$DelMedKandidat$2f$DelMedKandidatModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    markerteKandidater: markerteKandidater,
                                    fjernAllMarkering: ()=>setMarkerteKandidater([])
                                }, void 0, false, {
                                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteHandlingsRad.tsx",
                                    lineNumber: 66,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteHandlingsRad.tsx",
                                lineNumber: 65,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$DelMedArbeidsgiver$2f$DelMedArbeidsgiver$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    markerteKandidater: markerteKandidater
                                }, void 0, false, {
                                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteHandlingsRad.tsx",
                                    lineNumber: 72,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteHandlingsRad.tsx",
                                lineNumber: 71,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$SendSMS$2f$SendSmsKnapp$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            markerteKandidater: markerteKandidater,
                            knappVariant: 'tertiary',
                            setVisSendSmsModal: setVisSendSmsModal
                        }, void 0, false, {
                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteHandlingsRad.tsx",
                            lineNumber: 77,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteHandlingsRad.tsx",
                        lineNumber: 76,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    visSendSmsModal && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$SendSMS$2f$SendSmsModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        markerteKandidater: markerteKandidater,
                        fjernAllMarkering: ()=>setMarkerteKandidater([]),
                        setVisSendSmsModal: ()=>setVisSendSmsModal(false)
                    }, void 0, false, {
                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteHandlingsRad.tsx",
                        lineNumber: 84,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true)
        ]
    }, void 0, true, {
        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteHandlingsRad.tsx",
        lineNumber: 29,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(KandidatlisteHandlingsRad, "U9iNwGlBZvdxnfZAqNTF+2SPync=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatlisteContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useKandidatlisteContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$StillingsContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStillingsContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$useFiltrerteKandidater$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
    ];
});
_c = KandidatlisteHandlingsRad;
const __TURBOPACK__default__export__ = KandidatlisteHandlingsRad;
var _c;
__turbopack_context__.k.register(_c, "KandidatlisteHandlingsRad");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/[stillingsId]/kandidatliste/FiltrertKandidatListeVisning.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "KANDIDATLISTE_COLUMN_LAYOUT",
    ()=>KANDIDATLISTE_COLUMN_LAYOUT,
    "default",
    ()=>FiltrertKandidatListeVisning
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$Kandidatkort$2f$KandidatlisteKort$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/Kandidatkort/KandidatlisteKort.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteFilter/KandidatlisteFilterContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterrad$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteFilter/KandidatlisteFilterrad.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$useFiltrerteKandidater$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteFilter/useFiltrerteKandidater.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteHandlingsRad$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteHandlingsRad.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$SideScroll$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/SideScroll.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$KandidatNavigeringContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/providers/KandidatNavigeringContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$SortDown$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__SortDownIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/SortDown.js [app-client] (ecmascript) <export default as SortDownIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$SortUp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__SortUpIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/SortUp.js [app-client] (ecmascript) <export default as SortUpIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
const KANDIDATLISTE_COLUMN_LAYOUT = 'grid-cols-1 md:grid-cols-[minmax(10rem,30%)_minmax(6rem,20%)_minmax(10rem,20%)_minmax(5rem,10%)_minmax(10rem,12%)_minmax(1rem,2%)]';
function FiltrertKandidatListeVisning({ kunVisning }) {
    _s();
    const filtrerteKandidater = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$useFiltrerteKandidater$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    const { setSortering, sortering } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useKandidatlisteFilterContext"])();
    const { setKandidatNavigering } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$KandidatNavigeringContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useKandidatNavigeringContext"])();
    const headerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const sortIcon = (asc, desc)=>{
        if (asc) {
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$SortDown$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__SortDownIcon$3e$__["SortDownIcon"], {}, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/FiltrertKandidatListeVisning.tsx",
                lineNumber: 33,
                columnNumber: 14
            }, this);
        }
        if (desc) {
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$SortUp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__SortUpIcon$3e$__["SortUpIcon"], {}, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/FiltrertKandidatListeVisning.tsx",
                lineNumber: 36,
                columnNumber: 14
            }, this);
        }
        return null;
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "FiltrertKandidatListeVisning.useEffect": ()=>{
            if (filtrerteKandidater?.kandidater) {
                setKandidatNavigering(filtrerteKandidater.kandidater.map({
                    "FiltrertKandidatListeVisning.useEffect": (kandidat)=>kandidat.kandidatnr
                }["FiltrertKandidatListeVisning.useEffect"]));
            } else {
                setKandidatNavigering([]);
            }
        }
    }["FiltrertKandidatListeVisning.useEffect"], [
        setKandidatNavigering,
        filtrerteKandidater?.kandidater
    ]);
    const knappStyling = 'p-0';
    const tableHeader = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `grid ${KANDIDATLISTE_COLUMN_LAYOUT} gap-x-3 px-4`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-start",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                    iconPosition: "right",
                    icon: sortIcon(sortering === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatlisteSortering"].NAVN_ASC, sortering === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatlisteSortering"].NAVN_DESC),
                    className: knappStyling,
                    variant: "tertiary",
                    size: "small",
                    onClick: ()=>{
                        if (sortering === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatlisteSortering"].NAVN_ASC) setSortering(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatlisteSortering"].NAVN_DESC);
                        else setSortering(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatlisteSortering"].NAVN_ASC);
                    },
                    children: "Navn"
                }, void 0, false, {
                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/FiltrertKandidatListeVisning.tsx",
                    lineNumber: 56,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/FiltrertKandidatListeVisning.tsx",
                lineNumber: 55,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-start",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                    iconPosition: "right",
                    icon: sortIcon(sortering === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatlisteSortering"].LAGT_TIL_ASC, sortering === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatlisteSortering"].LAGT_TIL_DESC),
                    className: knappStyling,
                    variant: "tertiary",
                    size: "small",
                    onClick: ()=>{
                        if (sortering === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatlisteSortering"].LAGT_TIL_ASC) setSortering(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatlisteSortering"].LAGT_TIL_DESC);
                        else setSortering(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatlisteSortering"].LAGT_TIL_ASC);
                    },
                    children: "Lagt til"
                }, void 0, false, {
                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/FiltrertKandidatListeVisning.tsx",
                    lineNumber: 75,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/FiltrertKandidatListeVisning.tsx",
                lineNumber: 74,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-start",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                    iconPosition: "right",
                    icon: sortIcon(sortering === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatlisteSortering"].HENDELSE_ASC, sortering === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatlisteSortering"].HENDELSE_DESC),
                    className: knappStyling,
                    variant: "tertiary",
                    size: "small",
                    onClick: ()=>{
                        if (sortering === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatlisteSortering"].HENDELSE_ASC) setSortering(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatlisteSortering"].HENDELSE_DESC);
                        else setSortering(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatlisteSortering"].HENDELSE_ASC);
                    },
                    children: "Siste hendelse"
                }, void 0, false, {
                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/FiltrertKandidatListeVisning.tsx",
                    lineNumber: 94,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/FiltrertKandidatListeVisning.tsx",
                lineNumber: 93,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-start",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                    iconPosition: "right",
                    icon: sortIcon(sortering === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatlisteSortering"].VARSEL_ASC, sortering === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatlisteSortering"].VARSEL_DESC),
                    className: knappStyling,
                    variant: "tertiary",
                    size: "small",
                    onClick: ()=>{
                        if (sortering === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatlisteSortering"].VARSEL_ASC) setSortering(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatlisteSortering"].VARSEL_DESC);
                        else setSortering(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatlisteSortering"].VARSEL_ASC);
                    },
                    children: "Varsler"
                }, void 0, false, {
                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/FiltrertKandidatListeVisning.tsx",
                    lineNumber: 113,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/FiltrertKandidatListeVisning.tsx",
                lineNumber: 112,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-start",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                    iconPosition: "right",
                    icon: sortIcon(sortering === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatlisteSortering"].INTERN_STATUS_ASC, sortering === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatlisteSortering"].INTERN_STATUS_DESC),
                    className: knappStyling,
                    variant: "tertiary",
                    size: "small",
                    onClick: ()=>{
                        if (sortering === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatlisteSortering"].INTERN_STATUS_ASC) setSortering(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatlisteSortering"].INTERN_STATUS_DESC);
                        else setSortering(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatlisteSortering"].INTERN_STATUS_ASC);
                    },
                    children: "Intern status"
                }, void 0, false, {
                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/FiltrertKandidatListeVisning.tsx",
                    lineNumber: 132,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/FiltrertKandidatListeVisning.tsx",
                lineNumber: 131,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/FiltrertKandidatListeVisning.tsx",
        lineNumber: 54,
        columnNumber: 5
    }, this);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: [
            !kunVisning && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ref: headerRef,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterrad$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/FiltrertKandidatListeVisning.tsx",
                        lineNumber: 157,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteHandlingsRad$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/FiltrertKandidatListeVisning.tsx",
                        lineNumber: 158,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/FiltrertKandidatListeVisning.tsx",
                lineNumber: 156,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$SideScroll$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                enableHorizontalScroll: true,
                lagreScrollNøkkel: `kandidater-${filtrerteKandidater?.kandidater?.length}`,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    children: [
                        tableHeader,
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "grid grid-cols-1 gap-1 p-1",
                            children: [
                                filtrerteKandidater?.usynligeKandidater?.map((kandidat, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$Kandidatkort$2f$KandidatlisteKort$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        usynligKandidat: kandidat,
                                        kunVisning: kunVisning
                                    }, index, false, {
                                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/FiltrertKandidatListeVisning.tsx",
                                        lineNumber: 169,
                                        columnNumber: 15
                                    }, this)),
                                filtrerteKandidater?.kandidater?.map((kandidat)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$Kandidatkort$2f$KandidatlisteKort$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        kandidat: kandidat,
                                        kunVisning: kunVisning
                                    }, kandidat.kandidatnr, false, {
                                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/FiltrertKandidatListeVisning.tsx",
                                        lineNumber: 176,
                                        columnNumber: 15
                                    }, this))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/FiltrertKandidatListeVisning.tsx",
                            lineNumber: 167,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/FiltrertKandidatListeVisning.tsx",
                    lineNumber: 165,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/FiltrertKandidatListeVisning.tsx",
                lineNumber: 161,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/FiltrertKandidatListeVisning.tsx",
        lineNumber: 154,
        columnNumber: 5
    }, this);
}
_s(FiltrertKandidatListeVisning, "VuetZGZLePCXzR65uqMGj8RSqQ0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$useFiltrerteKandidater$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useKandidatlisteFilterContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$KandidatNavigeringContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useKandidatNavigeringContext"]
    ];
});
_c = FiltrertKandidatListeVisning;
var _c;
__turbopack_context__.k.register(_c, "FiltrertKandidatListeVisning");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/[stillingsId]/kandidatliste/KandidatlisteWrapper.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatlisteContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/KandidatlisteContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatlisteFilter/KandidatlisteFilterContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$foresporsel$2d$om$2d$deling$2d$av$2d$cv$2f$foresporsler$2f5b2e2e2e$slug$5d2f$useForespurteOmDelingAvCv$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/foresporsel-om-deling-av-cv/foresporsler/[...slug]/useForespurteOmDelingAvCv.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2f$useKandidatlisteForEier$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/kandidat/useKandidatlisteForEier.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidatvarsel$2f$kandidatvarsel$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/kandidatvarsel/kandidatvarsel.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stilling$2f$overta$2d$eierskap$2f$overtaEierskap$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/stilling/overta-eierskap/overtaEierskap.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$StillingsContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/StillingsContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$SWRLaster$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/SWRLaster.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$ApplikasjonContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/providers/ApplikasjonContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/button/Button.js [app-client] (ecmascript) <export default as Button>");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
const KandidatlisteWrapper = ({ children })=>{
    _s();
    const { brukerData, valgtNavKontor } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$ApplikasjonContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useApplikasjonContext"])();
    const { stillingsData, erEier } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$StillingsContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStillingsContext"])();
    const forespurteKandidaterHook = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$foresporsel$2d$om$2d$deling$2d$av$2d$cv$2f$foresporsler$2f5b2e2e2e$slug$5d2f$useForespurteOmDelingAvCv$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useForespurteOmDelingAvCv"])(stillingsData.stilling.uuid);
    const beskjederHook = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidatvarsel$2f$kandidatvarsel$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSmserForStilling"])(stillingsData.stilling.uuid);
    const kandidatlisteHook = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2f$useKandidatlisteForEier$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useKandidatlisteForEier"])(stillingsData, erEier);
    const onOvertaStilling = async ()=>{
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stilling$2f$overta$2d$eierskap$2f$overtaEierskap$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["overtaEierskap"])({
            stillingsid: stillingsData.stilling.uuid,
            eierNavident: brukerData.ident,
            eierNavn: brukerData.navn,
            eierNavKontorEnhetId: valgtNavKontor?.navKontor
        });
        window.location.reload();
    };
    const reFetchKandidatliste = ()=>{
        kandidatlisteHook.mutate();
        forespurteKandidaterHook.mutate();
        beskjederHook.mutate();
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$SWRLaster$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        hooks: [
            kandidatlisteHook,
            forespurteKandidaterHook,
            beskjederHook
        ],
        egenFeilmelding: ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    "Feil ved henting av kandidater",
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/KandidatlisteWrapper.tsx",
                        lineNumber: 51,
                        columnNumber: 11
                    }, void 0),
                    "Du får ikke vise kandidater hvis du ikke er eier, du kan prøve å ta eierskap på nytt",
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                        onClick: onOvertaStilling,
                        variant: "secondary",
                        size: "small",
                        className: "my-2 h-5 w-full",
                        children: "Ta eierskap"
                    }, void 0, false, {
                        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/KandidatlisteWrapper.tsx",
                        lineNumber: 54,
                        columnNumber: 11
                    }, void 0)
                ]
            }, void 0, true, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/KandidatlisteWrapper.tsx",
                lineNumber: 49,
                columnNumber: 9
            }, void 0),
        children: (kandidatliste, forespurteKandidater, beskjeder)=>{
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatlisteFilter$2f$KandidatlisteFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatlisteFilterContextProvider"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatlisteContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatlisteContextProvider"], {
                    kandidatliste: kandidatliste,
                    forespurteKandidater: forespurteKandidater,
                    beskjeder: beskjeder,
                    reFetchKandidatliste: reFetchKandidatliste,
                    children: children
                }, void 0, false, {
                    fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/KandidatlisteWrapper.tsx",
                    lineNumber: 68,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/KandidatlisteWrapper.tsx",
                lineNumber: 67,
                columnNumber: 11
            }, ("TURBOPACK compile-time value", void 0));
        }
    }, void 0, false, {
        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/KandidatlisteWrapper.tsx",
        lineNumber: 46,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(KandidatlisteWrapper, "NrMRG47g/QCqJVxXgrS6zFcrVpM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$ApplikasjonContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useApplikasjonContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$StillingsContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStillingsContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$foresporsel$2d$om$2d$deling$2d$av$2d$cv$2f$foresporsler$2f5b2e2e2e$slug$5d2f$useForespurteOmDelingAvCv$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useForespurteOmDelingAvCv"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidatvarsel$2f$kandidatvarsel$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSmserForStilling"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2f$useKandidatlisteForEier$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useKandidatlisteForEier"]
    ];
});
_c = KandidatlisteWrapper;
const __TURBOPACK__default__export__ = KandidatlisteWrapper;
var _c;
__turbopack_context__.k.register(_c, "KandidatlisteWrapper");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/[stillingsId]/kandidatliste/_ui/FjernDelingMedArbeidsgiver.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2f$slettCvFraArbeidsgiver$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/kandidat/slettCvFraArbeidsgiver.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatlisteContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/KandidatlisteContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$MinusCircle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MinusCircleIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/MinusCircle.js [app-client] (ecmascript) <export default as MinusCircleIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
const FjernDelingMedArbeidsgiver = ({ kandidatnummer, navKontor })=>{
    _s();
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const { reFetchKandidatliste, kandidatlisteId } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatlisteContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useKandidatlisteContext"])();
    const slettCv = async ()=>{
        setLoading(true);
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2f$slettCvFraArbeidsgiver$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["slettCvFraArbeidsgiversKandidatliste"])(kandidatlisteId, kandidatnummer, navKontor).finally(()=>{
            setLoading(false);
            reFetchKandidatliste();
        });
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
        loading: loading,
        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$MinusCircle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MinusCircleIcon$3e$__["MinusCircleIcon"], {}, void 0, false, {
            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/FjernDelingMedArbeidsgiver.tsx",
            lineNumber: 33,
            columnNumber: 13
        }, void 0),
        variant: "tertiary",
        size: "small",
        className: "self-center",
        onClick: slettCv,
        children: "Fjern CV fra arbeidsgiver"
    }, void 0, false, {
        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/FjernDelingMedArbeidsgiver.tsx",
        lineNumber: 31,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(FjernDelingMedArbeidsgiver, "3B8GzhUCgu7X+/AqEYMERoX6y5Y=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatlisteContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useKandidatlisteContext"]
    ];
});
_c = FjernDelingMedArbeidsgiver;
const __TURBOPACK__default__export__ = FjernDelingMedArbeidsgiver;
var _c;
__turbopack_context__.k.register(_c, "FjernDelingMedArbeidsgiver");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/KandidatHendelser.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelseTagVisning$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelseTagVisning.tsx [app-client] (ecmascript)");
;
;
const KandidatHendelser = ({ kandidatHendelser })=>{
    // Flatten kandidatHendelser
    const flatKandidatHendelser = [
        // kandidatHendelser.opprettet,
        ...kandidatHendelser.cvHendelser ?? [],
        ...kandidatHendelser.utfallsendringer ?? [],
        ...kandidatHendelser.varsler ?? []
    ].filter((hendelse)=>hendelse !== undefined);
    const sortedKandidatHendelser = flatKandidatHendelser.sort((h1, h2)=>(h2.dato?.getTime() || 0) - (h1.dato?.getTime() || 0));
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col gap-4",
        children: sortedKandidatHendelser.map((hendelse, index)=>{
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$_ui$2f$KandidatHendelseTagVisning$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                kandidatHendelse: hendelse
            }, index, false, {
                fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/KandidatHendelser.tsx",
                lineNumber: 52,
                columnNumber: 11
            }, ("TURBOPACK compile-time value", void 0));
        })
    }, void 0, false, {
        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/_ui/KandidatHendelser/KandidatHendelser.tsx",
        lineNumber: 49,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = KandidatHendelser;
const __TURBOPACK__default__export__ = KandidatHendelser;
var _c;
__turbopack_context__.k.register(_c, "KandidatHendelser");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stilling/[stillingsId]/kandidatliste/KandidatlisteKandidatView.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$kandidat$2f5b$kandidatNr$5d2f$jobbs$f8$ker$2d$visning$2f$VisJobbs$f8$ker$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/kandidat/[kandidatNr]/jobbsøker-visning/VisJobbsøker.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatlisteWrapper$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/KandidatlisteWrapper.tsx [app-client] (ecmascript)");
'use client';
;
;
;
const KandidatlisteKandidatView = ({ kandidatId })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatlisteWrapper$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$kandidat$2f5b$kandidatNr$5d2f$jobbs$f8$ker$2d$visning$2f$VisJobbs$f8$ker$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            kandidatId: kandidatId
        }, void 0, false, {
            fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/KandidatlisteKandidatView.tsx",
            lineNumber: 15,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/app/stilling/[stillingsId]/kandidatliste/KandidatlisteKandidatView.tsx",
        lineNumber: 14,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = KandidatlisteKandidatView;
const __TURBOPACK__default__export__ = KandidatlisteKandidatView;
var _c;
__turbopack_context__.k.register(_c, "KandidatlisteKandidatView");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=app_stilling_%5BstillingsId%5D_kandidatliste_2447fa1b._.js.map