(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/tag/Tag.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Tag",
    ()=>Tag,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/BodyShort.js [app-client] (ecmascript) <export default as BodyShort>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
const Tag = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = (_a, ref)=>{
    var { children, className, variant = "outline", size = "medium", icon, "data-color": color } = _a, rest = __rest(_a, [
        "children",
        "className",
        "variant",
        "size",
        "icon",
        "data-color"
    ]);
    const filledVariant = (variant === null || variant === void 0 ? void 0 : variant.endsWith("-filled")) && "strong";
    const moderateVariant = (variant === null || variant === void 0 ? void 0 : variant.endsWith("-moderate")) && "moderate";
    const updatedVariant = variant === "moderate" || variant === "strong" || variant === "outline";
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__["BodyShort"], Object.assign({
        "data-color": color !== null && color !== void 0 ? color : variantToColor(variant),
        "data-variant": updatedVariant ? variant : filledVariant || moderateVariant || "outline"
    }, rest, {
        ref: ref,
        as: "span",
        size: size === "medium" ? "medium" : "small",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-tag", className, `aksel-tag--${size}`)
    }), icon && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("span", {
        className: "aksel-tag__icon--left"
    }, icon), children);
});
_c1 = Tag;
function variantToColor(variant) {
    switch(variant){
        case "warning":
        case "warning-filled":
        case "warning-moderate":
            return "warning";
        case "error":
        case "error-filled":
        case "error-moderate":
            return "danger";
        case "info":
        case "info-filled":
        case "info-moderate":
        case "alt3":
        case "alt3-filled":
        case "alt3-moderate":
            return "info";
        case "success":
        case "success-filled":
        case "success-moderate":
            return "success";
        case "neutral":
        case "neutral-filled":
        case "neutral-moderate":
            return "neutral";
        case "alt1":
        case "alt1-filled":
        case "alt1-moderate":
            return "meta-purple";
        case "alt2":
        case "alt2-filled":
        case "alt2-moderate":
            return "meta-lime";
        default:
            return "neutral";
    }
}
const __TURBOPACK__default__export__ = Tag;
var _c, _c1;
__turbopack_context__.k.register(_c, "Tag$forwardRef");
__turbopack_context__.k.register(_c1, "Tag");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=Tag.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/tag/Tag.js [app-client] (ecmascript) <export default as Tag>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Tag",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tag$2f$Tag$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tag$2f$Tag$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/tag/Tag.js [app-client] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/chips/Removable.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RemovableChips",
    ()=>RemovableChips,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$XMark$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XMarkIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/XMark.js [app-client] (ecmascript) <export default as XMarkIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$composeEventHandlers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/composeEventHandlers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$i18n$2f$i18n$2e$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/i18n/i18n.hooks.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
;
;
const RemovableChips = /*#__PURE__*/ _s((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = _s((_a, ref)=>{
    _s();
    var { children, variant, onDelete, className, onClick, type = "button", "data-color": color } = _a, rest = __rest(_a, [
        "children",
        "variant",
        "onDelete",
        "className",
        "onClick",
        "type",
        "data-color"
    ]);
    const translate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$i18n$2f$i18n$2e$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useI18n"])("Chips");
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("button", Object.assign({
        "data-color": color !== null && color !== void 0 ? color : variantToColor(variant)
    }, rest, {
        ref: ref,
        type: type,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-chips__chip aksel-chips__removable aksel-chips--icon-right", className),
        "aria-label": `${children} ${translate("Removable.labelSuffix")}`,
        onClick: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$composeEventHandlers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["composeEventHandlers"])(onClick, onDelete)
    }), /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("span", {
        className: "aksel-chips__chip-text"
    }, children), /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("span", {
        className: "aksel-chips__removable-icon"
    }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$XMark$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XMarkIcon$3e$__["XMarkIcon"], {
        "aria-hidden": true
    })));
}, "KV87nYrn2zW6QxQP1Zrr/rEPoM0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$i18n$2f$i18n$2e$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useI18n"]
    ];
})), "KV87nYrn2zW6QxQP1Zrr/rEPoM0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$i18n$2f$i18n$2e$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useI18n"]
    ];
});
_c1 = RemovableChips;
function variantToColor(variant) {
    switch(variant){
        case "action":
            return "accent";
        case "neutral":
            return "neutral";
        default:
            return undefined;
    }
}
const __TURBOPACK__default__export__ = RemovableChips;
var _c, _c1;
__turbopack_context__.k.register(_c, "RemovableChips$forwardRef");
__turbopack_context__.k.register(_c1, "RemovableChips");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=Removable.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/chips/Toggle.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ToggleChips",
    ()=>ToggleChips,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
const ToggleChips = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = (_a, ref)=>{
    var { className, children, selected, variant, checkmark = true, as: Component = "button", "data-color": color } = _a, rest = __rest(_a, [
        "className",
        "children",
        "selected",
        "variant",
        "checkmark",
        "as",
        "data-color"
    ]);
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(Component, Object.assign({
        "data-color": color !== null && color !== void 0 ? color : variantToColor(variant)
    }, rest, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-chips__chip aksel-chips__toggle", className, {
            "aksel-chips__toggle--with-checkmark": checkmark
        }),
        "aria-pressed": selected,
        "data-pressed": selected
    }), checkmark && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("svg", {
        "aria-hidden": true,
        className: "aksel-chips__toggle-icon",
        width: "1.25em",
        height: "1.25em",
        viewBox: "0 0 20 20",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        focusable: false,
        role: "img"
    }, selected ? /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("path", {
        fillRule: "evenodd",
        clipRule: "evenodd",
        d: "M10 18.125C14.4873 18.125 18.125 14.4873 18.125 10C18.125 5.51269 14.4873 1.875 10 1.875C5.51269 1.875 1.875 5.51269 1.875 10C1.875 14.4873 5.51269 18.125 10 18.125ZM14.128 7.72904C14.3695 7.44357 14.3339 7.01635 14.0485 6.7748C13.763 6.53326 13.3358 6.56886 13.0942 6.85432L8.60428 12.1606L6.41627 9.97263C6.15185 9.70822 5.72315 9.70822 5.45873 9.97263C5.19431 10.2371 5.19431 10.6658 5.45873 10.9302L8.16706 13.6385C8.30095 13.7724 8.48479 13.8441 8.67397 13.8362C8.86316 13.8284 9.0404 13.7416 9.16271 13.5971L14.128 7.72904Z",
        fill: "currentColor"
    }) : /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("path", {
        fillRule: "evenodd",
        clipRule: "evenodd",
        d: "M10 3.125C6.20304 3.125 3.125 6.20304 3.125 10C3.125 13.797 6.20304 16.875 10 16.875C13.797 16.875 16.875 13.797 16.875 10C16.875 6.20304 13.797 3.125 10 3.125ZM1.875 10C1.875 5.51269 5.51269 1.875 10 1.875C14.4873 1.875 18.125 5.51269 18.125 10C18.125 14.4873 14.4873 18.125 10 18.125C5.51269 18.125 1.875 14.4873 1.875 10Z",
        /* After removing old fallbacks, change to currentColor */ fill: "var(--ax-text-default)"
    })), /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("span", {
        className: "aksel-chips__chip-text"
    }, children));
});
_c1 = ToggleChips;
function variantToColor(variant) {
    switch(variant){
        case "action":
            return "accent";
        case "neutral":
            return "neutral";
        default:
            return undefined;
    }
}
const __TURBOPACK__default__export__ = ToggleChips;
var _c, _c1;
__turbopack_context__.k.register(_c, "ToggleChips$forwardRef");
__turbopack_context__.k.register(_c1, "ToggleChips");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=Toggle.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/chips/Chips.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Chips",
    ()=>Chips,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$chips$2f$Removable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/chips/Removable.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$chips$2f$Toggle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/chips/Toggle.js [app-client] (ecmascript)");
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
;
const Chips = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = (_a, ref)=>{
    var { className, size = "medium", children } = _a, rest = __rest(_a, [
        "className",
        "size",
        "children"
    ]);
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("ul", Object.assign({}, rest, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-chips", className, `aksel-chips--${size}`, {
            "aksel-body-short aksel-body-short--small": size === "medium",
            "aksel-detail aksel-detail--small": size === "small"
        })
    }), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Children.map(children, (chip, index)=>{
        return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("li", {
            key: (chip === null || chip === void 0 ? void 0 : chip.toString()) || index
        }, chip);
    }));
});
_c1 = Chips;
Chips.Toggle = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$chips$2f$Toggle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
Chips.Removable = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$chips$2f$Removable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
const __TURBOPACK__default__export__ = Chips;
var _c, _c1;
__turbopack_context__.k.register(_c, "Chips$forwardRef");
__turbopack_context__.k.register(_c1, "Chips");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=Chips.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/chips/Chips.js [app-client] (ecmascript) <export default as Chips>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Chips",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$chips$2f$Chips$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$chips$2f$Chips$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/chips/Chips.js [app-client] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/tooltip/Tooltip.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Tooltip",
    ()=>Tooltip,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$dom$40$1$2e$7$2e$4$2f$node_modules$2f40$floating$2d$ui$2f$dom$2f$dist$2f$floating$2d$ui$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@floating-ui+dom@1.7.4/node_modules/@floating-ui/dom/dist/floating-ui.dom.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$react$2d$dom$40$2$2e$1$2e$6_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$floating$2d$ui$2f$react$2d$dom$2f$dist$2f$floating$2d$ui$2e$react$2d$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@floating-ui+react-dom@2.1.6_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@floating-ui/react-dom/dist/floating-ui.react-dom.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$react$40$0$2e$27$2e$8_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@floating-ui+react@0.27.8_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@floating-ui/react/dist/floating-ui.react.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$Modal$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/modal/Modal.context.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$portal$2f$Portal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Portal$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/portal/Portal.js [app-client] (ecmascript) <export default as Portal>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$slot$2f$Slot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/slot/Slot.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$Detail$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Detail$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/Detail.js [app-client] (ecmascript) <export default as Detail>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/useId.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useControllableState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/useControllableState.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useMergeRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/useMergeRefs.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
;
;
;
;
;
;
;
const Tooltip = /*#__PURE__*/ _s((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = _s((_a, ref)=>{
    _s();
    var { children, className, arrow: _arrow = true, placement: _placement = "top", open, defaultOpen = false, onOpenChange, offset: _offset, content, delay = 150, id, keys, maxChar = 80, describesChild = false } = _a, rest = __rest(_a, [
        "children",
        "className",
        "arrow",
        "placement",
        "open",
        "defaultOpen",
        "onOpenChange",
        "offset",
        "content",
        "delay",
        "id",
        "keys",
        "maxChar",
        "describesChild"
    ]);
    const [_open, _setOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useControllableState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useControllableState"])({
        defaultValue: defaultOpen,
        value: open,
        onChange: onOpenChange
    });
    const arrowRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const modalContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$Modal$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useModalContext"])(false);
    const rootElement = modalContext ? modalContext.modalRef.current : undefined;
    const { x, y, strategy, context, placement, middlewareData: { arrow: { x: arrowX, y: arrowY } = {}, hide: { referenceHidden } = {} }, refs } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$react$40$0$2e$27$2e$8_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useFloating"])({
        placement: _placement,
        open: _open,
        onOpenChange: {
            "Tooltip.useFloating": (newState)=>_setOpen(newState)
        }["Tooltip.useFloating"],
        middleware: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$react$2d$dom$40$2$2e$1$2e$6_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$floating$2d$ui$2f$react$2d$dom$2f$dist$2f$floating$2d$ui$2e$react$2d$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["offset"])(_offset !== null && _offset !== void 0 ? _offset : _arrow ? 8 : 4),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$react$2d$dom$40$2$2e$1$2e$6_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$floating$2d$ui$2f$react$2d$dom$2f$dist$2f$floating$2d$ui$2e$react$2d$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["shift"])(),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$react$2d$dom$40$2$2e$1$2e$6_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$floating$2d$ui$2f$react$2d$dom$2f$dist$2f$floating$2d$ui$2e$react$2d$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["flip"])({
                padding: 5,
                fallbackPlacements: [
                    "bottom",
                    "top"
                ]
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$react$2d$dom$40$2$2e$1$2e$6_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$floating$2d$ui$2f$react$2d$dom$2f$dist$2f$floating$2d$ui$2e$react$2d$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["arrow"])({
                element: arrowRef,
                padding: 5
            })
        ],
        whileElementsMounted: modalContext ? ({
            "Tooltip.useFloating": (reference, floating, update)=>// Reduces jumping in Chrome when used in a Modal and it's the first focusable element.
                // Can be removed when autofocus starts working on <dialog> in Chrome. See also Modal.tsx
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$dom$40$1$2e$7$2e$4$2f$node_modules$2f40$floating$2d$ui$2f$dom$2f$dist$2f$floating$2d$ui$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["autoUpdate"])(reference, floating, update, {
                    animationFrame: true
                })
        })["Tooltip.useFloating"] : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$dom$40$1$2e$7$2e$4$2f$node_modules$2f40$floating$2d$ui$2f$dom$2f$dist$2f$floating$2d$ui$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["autoUpdate"],
        strategy: modalContext ? "fixed" : undefined
    });
    const { getReferenceProps, getFloatingProps } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$react$40$0$2e$27$2e$8_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useInteractions"])([
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$react$40$0$2e$27$2e$8_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useHover"])(context, {
            handleClose: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$react$40$0$2e$27$2e$8_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["safePolygon"])(),
            restMs: delay
        }),
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$react$40$0$2e$27$2e$8_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useFocus"])(context),
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$react$40$0$2e$27$2e$8_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useDismiss"])(context)
    ]);
    const ariaId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])(id);
    const mergedRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useMergeRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMergeRefs"])(ref, refs.setFloating);
    if (!children || (children === null || children === void 0 ? void 0 : children.type) === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Fragment || children === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Fragment) {
        console.error("<Tooltip> children needs to be a single ReactElement and not: <React.Fragment/> | <></>");
        return null;
    }
    if ((content === null || content === void 0 ? void 0 : content.length) > maxChar) {
        _open && console.warn(`Because of strict accessibility concers we encourage all Tooltips to have less than 80 characters. Can be overwritten with the maxChar-prop\n\nLength:${content.length}\nTooltip-content: ${content}`);
    }
    const labelProps = describesChild ? _open ? {
        "aria-describedby": ariaId
    } : {
        title: content
    } : {
        "aria-label": content
    };
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Fragment, null, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$slot$2f$Slot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Slot"], Object.assign({
        ref: refs.setReference
    }, getReferenceProps(), labelProps, {
        "aria-keyshortcuts": keys ? keys.join("+") : undefined
    }), children), _open && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$portal$2f$Portal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Portal$3e$__["Portal"], {
        rootElement: rootElement
    }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", Object.assign({}, getFloatingProps(Object.assign(Object.assign({}, rest), {
        ref: mergedRef,
        style: {
            position: strategy,
            top: y !== null && y !== void 0 ? y : 0,
            left: x !== null && x !== void 0 ? x : 0,
            visibility: referenceHidden ? "hidden" : "visible"
        },
        role: "tooltip",
        id: ariaId,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-tooltip", "aksel-detail aksel-detail--small", className)
    })), {
        "data-side": placement,
        "data-state": "open"
    }), content, keys && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("span", {
        className: "aksel-tooltip__keys",
        "aria-hidden": true
    }, keys.map((key)=>/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$Detail$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Detail$3e$__["Detail"], {
            as: "kbd",
            key: key,
            className: "aksel-tooltip__key"
        }, key))), _arrow && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", {
        ref: (node)=>{
            arrowRef.current = node;
        },
        className: "aksel-tooltip__arrow",
        style: {
            left: arrowX != null ? `${arrowX}px` : "",
            top: arrowY != null ? `${arrowY}px` : "",
            right: "",
            bottom: "",
            [({
                top: "bottom",
                right: "left",
                bottom: "top",
                left: "right"
            })[placement]]: "-3.5px"
        }
    }))));
}, "JMrNXaFnSGKcE5TzzwglW2dZokQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useControllableState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useControllableState"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$Modal$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useModalContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$react$40$0$2e$27$2e$8_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useFloating"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$react$40$0$2e$27$2e$8_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useInteractions"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useMergeRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMergeRefs"]
    ];
})), "JMrNXaFnSGKcE5TzzwglW2dZokQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useControllableState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useControllableState"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$Modal$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useModalContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$react$40$0$2e$27$2e$8_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useFloating"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$react$40$0$2e$27$2e$8_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useInteractions"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useMergeRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMergeRefs"]
    ];
});
_c1 = Tooltip;
const __TURBOPACK__default__export__ = Tooltip;
var _c, _c1;
__turbopack_context__.k.register(_c, "Tooltip$forwardRef");
__turbopack_context__.k.register(_c1, "Tooltip");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=Tooltip.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/tooltip/Tooltip.js [app-client] (ecmascript) <export default as Tooltip>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Tooltip",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/tooltip/Tooltip.js [app-client] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/skeleton/Skeleton.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Skeleton",
    ()=>Skeleton,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
const Skeleton = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = (_a, ref)=>{
    var { className, children, height, width, style, variant = "text", as: As = "div" } = _a, rest = __rest(_a, [
        "className",
        "children",
        "height",
        "width",
        "style",
        "variant",
        "as"
    ]);
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(As, Object.assign({}, rest, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-skeleton", className, `aksel-skeleton--${variant}`, {
            "aksel-skeleton--has-children": Boolean(children),
            "aksel-skeleton--no-height": !height,
            "aksel-skeleton--no-width": !width,
            "aksel-skeleton--inline": As === "span"
        }),
        style: Object.assign(Object.assign({}, style), {
            width,
            height
        }),
        "aria-hidden": true
    }), children);
});
_c1 = Skeleton;
const __TURBOPACK__default__export__ = Skeleton;
var _c, _c1;
__turbopack_context__.k.register(_c, "Skeleton$forwardRef");
__turbopack_context__.k.register(_c1, "Skeleton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=Skeleton.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/skeleton/Skeleton.js [app-client] (ecmascript) <export default as Skeleton>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Skeleton",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/skeleton/Skeleton.js [app-client] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/alert/info-card/content/InfoCardContent.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "InfoCardContent",
    ()=>InfoCardContent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$base$2d$alert$2f$namespace$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__BaseAlert$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/alert/base-alert/namespace.js [app-client] (ecmascript) <export * as BaseAlert>");
;
/**
 * @see 🏷️ {@link InfoCardContentProps}
 * @example
 * ```jsx
 *  <InfoCard>
 *    <InfoCard.Header>
 *      <InfoCard.Title>Info title</InfoCard.Title>
 *    </InfoCard.Header>
 *
 *    <InfoCard.Content>Content</InfoCard.Content>
 *  </InfoCard>
 * ```
 */ const InfoCardContent = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$base$2d$alert$2f$namespace$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__BaseAlert$3e$__["BaseAlert"].Content;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=InfoCardContent.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/alert/info-card/header/InfoCardHeader.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "InfoCardHeader",
    ()=>InfoCardHeader
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$base$2d$alert$2f$namespace$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__BaseAlert$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/alert/base-alert/namespace.js [app-client] (ecmascript) <export * as BaseAlert>");
;
/**
 * @see 🏷️ {@link InfoCardHeaderProps}
 * @example
 * ```jsx
 *  <InfoCard>
 *    <InfoCard.Header icon={<InformationSquareIcon aria-hidden />}>
 *      <InfoCard.Title>Info title</InfoCard.Title>
 *    </InfoCard.Header>
 *  </InfoCard>
 * ```
 */ const InfoCardHeader = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$base$2d$alert$2f$namespace$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__BaseAlert$3e$__["BaseAlert"].Header;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=InfoCardHeader.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/alert/info-card/title/InfoCardTitle.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "InfoCardTitle",
    ()=>InfoCardTitle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$base$2d$alert$2f$namespace$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__BaseAlert$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/alert/base-alert/namespace.js [app-client] (ecmascript) <export * as BaseAlert>");
;
/**
 * Title component for InfoCard. Remember to use correct heading-level with the `as` prop.
 * @see 🏷️ {@link InfoCardTitleProps}
 * @example
 * ```jsx
 *  <InfoCard>
 *    <InfoCard.Header>
 *      <InfoCard.Title as="h2">Info title</InfoCard.Title>
 *    </InfoCard.Header>
 *  </InfoCard>
 * ```
 */ const InfoCardTitle = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$base$2d$alert$2f$namespace$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__BaseAlert$3e$__["BaseAlert"].Title;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=InfoCardTitle.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/alert/info-card/root/InfoCardRoot.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "InfoCard",
    ()=>InfoCard,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$base$2d$alert$2f$namespace$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__BaseAlert$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/alert/base-alert/namespace.js [app-client] (ecmascript) <export * as BaseAlert>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$info$2d$card$2f$content$2f$InfoCardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/alert/info-card/content/InfoCardContent.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$info$2d$card$2f$header$2f$InfoCardHeader$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/alert/info-card/header/InfoCardHeader.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$info$2d$card$2f$title$2f$InfoCardTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/alert/info-card/title/InfoCardTitle.js [app-client] (ecmascript)");
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
;
;
const InfoCard = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = (_a, forwardedRef)=>{
    var { "data-color": dataColor = "info", as = "div" } = _a, restProps = __rest(_a, [
        "data-color",
        "as"
    ]);
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$base$2d$alert$2f$namespace$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__BaseAlert$3e$__["BaseAlert"].Root, Object.assign({
        ref: forwardedRef,
        "data-color": dataColor
    }, restProps, {
        type: "moderate",
        global: false,
        as: as
    }));
});
_c1 = InfoCard;
InfoCard.Header = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$info$2d$card$2f$header$2f$InfoCardHeader$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InfoCardHeader"];
InfoCard.Title = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$info$2d$card$2f$title$2f$InfoCardTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InfoCardTitle"];
InfoCard.Content = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$info$2d$card$2f$content$2f$InfoCardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InfoCardContent"];
const __TURBOPACK__default__export__ = InfoCard;
;
var _c, _c1;
__turbopack_context__.k.register(_c, "InfoCard$forwardRef");
__turbopack_context__.k.register(_c1, "InfoCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=InfoCardRoot.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/alert/local-alert/close-button/LocalAlertCloseButton.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LocalAlertCloseButton",
    ()=>LocalAlertCloseButton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$base$2d$alert$2f$namespace$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__BaseAlert$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/alert/base-alert/namespace.js [app-client] (ecmascript) <export * as BaseAlert>");
;
/**
 * @see 🏷️ {@link LocalAlertCloseButtonProps}
 * @example
 * ```jsx
 *  <LocalAlert>
 *    <LocalAlert.Header>
 *      <LocalAlert.Title>Info title</LocalAlert.Title>
 *     <LocalAlert.CloseButton onClick={() => alert("Closed!")} />
 *    </LocalAlert.Header>
 *  </LocalAlert>
 * ```
 */ const LocalAlertCloseButton = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$base$2d$alert$2f$namespace$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__BaseAlert$3e$__["BaseAlert"].CloseButton;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=LocalAlertCloseButton.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/alert/local-alert/content/LocalAlertContent.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LocalAlertContent",
    ()=>LocalAlertContent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$base$2d$alert$2f$namespace$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__BaseAlert$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/alert/base-alert/namespace.js [app-client] (ecmascript) <export * as BaseAlert>");
;
/**
 * @see 🏷️ {@link LocalAlertContentProps}
 * @example
 * ```jsx
 *  <LocalAlert>
 *    <LocalAlert.Header>
 *      <LocalAlert.Title>Info title</LocalAlert.Title>
 *    </LocalAlert.Header>
 *
 *    <LocalAlert.Content>Content</LocalAlert.Content>
 *  </LocalAlert>
 * ```
 */ const LocalAlertContent = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$base$2d$alert$2f$namespace$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__BaseAlert$3e$__["BaseAlert"].Content;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=LocalAlertContent.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/alert/local-alert/header/LocalAlertHeader.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LocalAlertHeader",
    ()=>LocalAlertHeader
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$base$2d$alert$2f$namespace$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__BaseAlert$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/alert/base-alert/namespace.js [app-client] (ecmascript) <export * as BaseAlert>");
;
;
/**
 * @see 🏷️ {@link LocalAlertHeaderProps}
 * @example
 * ```jsx
 *  <LocalAlert>
 *    <LocalAlert.Header>
 *      <LocalAlert.Title>Info title</LocalAlert.Title>
 *    </LocalAlert.Header>
 *  </LocalAlert>
 * ```
 */ const LocalAlertHeader = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = (props, forwardedRef)=>{
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$base$2d$alert$2f$namespace$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__BaseAlert$3e$__["BaseAlert"].Header, Object.assign({
        ref: forwardedRef
    }, props));
});
_c1 = LocalAlertHeader;
;
var _c, _c1;
__turbopack_context__.k.register(_c, "LocalAlertHeader$forwardRef");
__turbopack_context__.k.register(_c1, "LocalAlertHeader");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=LocalAlertHeader.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/alert/local-alert/title/LocalAlertTitle.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LocalAlertTitle",
    ()=>LocalAlertTitle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$base$2d$alert$2f$namespace$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__BaseAlert$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/alert/base-alert/namespace.js [app-client] (ecmascript) <export * as BaseAlert>");
;
/**
 * Title component for LocalAlert. Remember to use correct heading-level with the `as` prop.
 * @see 🏷️ {@link LocalAlertTitleProps}
 * @example
 * ```jsx
 *  <LocalAlert>
 *    <LocalAlert.Header>
 *      <LocalAlert.Title as="h2">Info title</LocalAlert.Title>
 *    </LocalAlert.Header>
 *  </LocalAlert>
 * ```
 */ const LocalAlertTitle = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$base$2d$alert$2f$namespace$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__BaseAlert$3e$__["BaseAlert"].Title;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=LocalAlertTitle.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/alert/local-alert/root/LocalAlertRoot.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LocalAlert",
    ()=>LocalAlert,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$base$2d$alert$2f$namespace$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__BaseAlert$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/alert/base-alert/namespace.js [app-client] (ecmascript) <export * as BaseAlert>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$local$2d$alert$2f$close$2d$button$2f$LocalAlertCloseButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/alert/local-alert/close-button/LocalAlertCloseButton.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$local$2d$alert$2f$content$2f$LocalAlertContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/alert/local-alert/content/LocalAlertContent.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$local$2d$alert$2f$header$2f$LocalAlertHeader$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/alert/local-alert/header/LocalAlertHeader.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$local$2d$alert$2f$title$2f$LocalAlertTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/alert/local-alert/title/LocalAlertTitle.js [app-client] (ecmascript)");
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
;
;
;
const LocalAlert = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = (_a, forwardedRef)=>{
    var { status } = _a, restProps = __rest(_a, [
        "status"
    ]);
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$base$2d$alert$2f$namespace$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__BaseAlert$3e$__["BaseAlert"].Root, Object.assign({
        ref: forwardedRef,
        role: "alert"
    }, restProps, {
        type: "strong",
        global: false,
        status: status
    }));
});
_c1 = LocalAlert;
LocalAlert.Header = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$local$2d$alert$2f$header$2f$LocalAlertHeader$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LocalAlertHeader"];
LocalAlert.Title = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$local$2d$alert$2f$title$2f$LocalAlertTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LocalAlertTitle"];
LocalAlert.Content = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$local$2d$alert$2f$content$2f$LocalAlertContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LocalAlertContent"];
LocalAlert.CloseButton = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$alert$2f$local$2d$alert$2f$close$2d$button$2f$LocalAlertCloseButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LocalAlertCloseButton"];
const __TURBOPACK__default__export__ = LocalAlert;
;
var _c, _c1;
__turbopack_context__.k.register(_c, "LocalAlert$forwardRef");
__turbopack_context__.k.register(_c1, "LocalAlert");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=LocalAlertRoot.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/useTransitionStatus.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createTransitionStatusAttribute",
    ()=>createTransitionStatusAttribute,
    "useTransitionStatus",
    ()=>useTransitionStatus
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react-dom/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useClientLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/useClientLayoutEffect.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
/**
 * Transition status state machine for components that animate between an
 * `open` boolean and actual mount/unmount. Keeps the element mounted while
 * exit animations run and introduces an optional stable `idle` phase.
 *
 * Adapted from MUI Base + Floating UI examples:
 *  - Source: https://github.com/mui/base-ui/blob/6fd69008d83561dbe75ff89acf270f0fac3e0049/packages/react/src/utils/useTransitionStatus.ts
 *  - Originally based on https://github.com/floating-ui/floating-ui/blob/7c33a3d0198a9b523d54ae2c37cedb315a309452/packages/react/src/hooks/useTransition.ts
 *
 * States (transitionStatus):
 *  - "entering"  : just entered (initial frame of enter) OR re-entering to reach "idle".
 *  - "idle"      : stable open (only when `enableIdleState === true`).
 *  - "exiting"   : exit animation is running; element still mounted.
 *  - undefined   : closed (unmounted) OR stable open when idle state is disabled.
 *                   When `enableIdleState` is false we clear the label after
 *                   the first frame so styling can rely purely on `mounted`.
 *
 * Distinction:
 *  - `mounted` tells you whether to render DOM.
 *  - `transitionStatus` tells you which phase-specific classes to apply.
 *
 * Frame separation: state changes that must trigger CSS transitions are
 * scheduled with `requestAnimationFrame` so the browser sees distinct style
 * mutations across frames (avoids missed transitions due to batching).
 *
 * @param open              Controls visibility lifecycle.
 * @param enableIdleState   Insert a persistent "idle" phase after entering.
 * @param deferExitingState  Delay entering the exit phase by one frame to allow
 *                          measurement / layout work before applying exit styles.
 */ function useTransitionStatus(open, enableIdleState = false, deferExitingState = false) {
    _s();
    const [mounted, setMounted] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(open);
    const [transitionStatus, setTransitionStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(open && enableIdleState ? "idle" : undefined);
    /* Opening: mount immediately and label as "entering" for the first frame. */ if (open && !mounted) {
        setMounted(true);
        setTransitionStatus("entering");
    }
    /* Closing (no defer): begin exit animation right away. */ if (!open && mounted && transitionStatus !== "exiting" && !deferExitingState) {
        setTransitionStatus("exiting");
    }
    /* Cleanup: after unmount post-exit ensure status returns to undefined. */ if (!open && !mounted && transitionStatus === "exiting") {
        setTransitionStatus(undefined);
    }
    /* Deferred closing: provide one frame to measure / flush layout before exit styles. */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useClientLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useClientLayoutEffect"])({
        "useTransitionStatus.useClientLayoutEffect": ()=>{
            if (!open && mounted && transitionStatus !== "exiting" && deferExitingState) {
                const frame = requestAnimationFrame({
                    "useTransitionStatus.useClientLayoutEffect.frame": ()=>{
                        setTransitionStatus("exiting");
                    }
                }["useTransitionStatus.useClientLayoutEffect.frame"]);
                return ({
                    "useTransitionStatus.useClientLayoutEffect": ()=>{
                        cancelAnimationFrame(frame);
                    }
                })["useTransitionStatus.useClientLayoutEffect"];
            }
            return undefined;
        }
    }["useTransitionStatus.useClientLayoutEffect"], [
        open,
        mounted,
        transitionStatus,
        deferExitingState
    ]);
    /* Enter (no idle): hold "entering" for one frame, then clear label (stable open). */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useClientLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useClientLayoutEffect"])({
        "useTransitionStatus.useClientLayoutEffect": ()=>{
            if (!open || enableIdleState) {
                return undefined;
            }
            const frame = requestAnimationFrame({
                "useTransitionStatus.useClientLayoutEffect.frame": ()=>{
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].flushSync({
                        "useTransitionStatus.useClientLayoutEffect.frame": ()=>{
                            setTransitionStatus(undefined);
                        }
                    }["useTransitionStatus.useClientLayoutEffect.frame"]);
                }
            }["useTransitionStatus.useClientLayoutEffect.frame"]);
            return ({
                "useTransitionStatus.useClientLayoutEffect": ()=>{
                    cancelAnimationFrame(frame);
                }
            })["useTransitionStatus.useClientLayoutEffect"];
        }
    }["useTransitionStatus.useClientLayoutEffect"], [
        enableIdleState,
        open
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useClientLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useClientLayoutEffect"])({
        "useTransitionStatus.useClientLayoutEffect": ()=>{
            if (!open || !enableIdleState) {
                return undefined;
            }
            /*
         * We can enter this state by re-opening before exiting-state was finished
         * (open → close → open in quick succession).
         */ if (open && mounted && transitionStatus !== "idle") {
                setTransitionStatus("entering");
            }
            /**
         * Next frame, after "entering", switch to persistent "idle" state.
         * By delaying to the next frame we ensure any "entering" styles are
         * applied and the transition can run.
         */ const frame = requestAnimationFrame({
                "useTransitionStatus.useClientLayoutEffect.frame": ()=>{
                    setTransitionStatus("idle");
                }
            }["useTransitionStatus.useClientLayoutEffect.frame"]);
            return ({
                "useTransitionStatus.useClientLayoutEffect": ()=>{
                    cancelAnimationFrame(frame);
                }
            })["useTransitionStatus.useClientLayoutEffect"];
        }
    }["useTransitionStatus.useClientLayoutEffect"], [
        enableIdleState,
        open,
        mounted,
        setTransitionStatus,
        transitionStatus
    ]);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useTransitionStatus.useMemo": ()=>({
                mounted,
                setMounted,
                transitionStatus
            })
    }["useTransitionStatus.useMemo"], [
        mounted,
        transitionStatus
    ]);
}
_s(useTransitionStatus, "Xb0zYglCEuqpcYTJo0QVhTcZCD8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useClientLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useClientLayoutEffect"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useClientLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useClientLayoutEffect"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useClientLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useClientLayoutEffect"]
    ];
});
/**
 * Creates a single data attribute with optional suffix
 * (e.g., data-entering-style, data-exiting-style, data-idle-style)
 */ function createTransitionStatusAttribute(value) {
    if (!value) {
        return {};
    }
    return {
        [`data-${value}-style`]: true
    };
}
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=useTransitionStatus.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/focus-guards/FocusGuards.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FocusGuards",
    ()=>FocusGuards
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useMergeRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/useMergeRefs.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
const visuallyHidden = {
    clip: "rect(0 0 0 0)",
    overflow: "hidden",
    whiteSpace: "nowrap",
    position: "fixed",
    top: 0,
    left: 0,
    border: 0,
    padding: 0,
    width: 1,
    height: 1,
    margin: -1
};
function FocusGuards({ children, startRef: forwardedStartRef, endRef: forwardedEndRef }) {
    _s();
    const startRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(null);
    const endRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(null);
    const startRefCombined = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useMergeRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMergeRefs"])(startRef, forwardedStartRef);
    const endRefCombined = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useMergeRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMergeRefs"])(endRef, forwardedEndRef);
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Fragment, null, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("span", {
        ref: startRefCombined,
        // eslint-disable-next-line jsx-a11y/no-noninteractive-tabindex
        tabIndex: 0,
        style: visuallyHidden,
        "data-aksel-focus-guard": ""
    }), children, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("span", {
        ref: endRefCombined,
        // eslint-disable-next-line jsx-a11y/no-noninteractive-tabindex
        tabIndex: 0,
        style: visuallyHidden,
        "data-aksel-focus-guard": ""
    }));
}
_s(FocusGuards, "EcPSwQix4ABlTlolVj0n1uD4XEs=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useMergeRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMergeRefs"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useMergeRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMergeRefs"]
    ];
});
_c = FocusGuards;
;
var _c;
__turbopack_context__.k.register(_c, "FocusGuards");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=FocusGuards.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/detectBrowser.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isIOS",
    ()=>isIOS,
    "isSafari",
    ()=>isSafari,
    "isWebKit",
    ()=>isWebKit
]);
const hasNavigator = typeof navigator !== "undefined";
function getNavigatorData() {
    var _a, _b;
    if (!hasNavigator) {
        return {
            platform: "",
            maxTouchPoints: -1
        };
    }
    const uaData = navigator.userAgentData;
    if (uaData === null || uaData === void 0 ? void 0 : uaData.platform) {
        return {
            platform: uaData.platform,
            maxTouchPoints: navigator.maxTouchPoints
        };
    }
    return {
        platform: (_a = navigator.platform) !== null && _a !== void 0 ? _a : "",
        maxTouchPoints: (_b = navigator.maxTouchPoints) !== null && _b !== void 0 ? _b : -1
    };
}
const nav = getNavigatorData();
const isSafari = hasNavigator && /apple/i.test(navigator.vendor);
const isWebKit = typeof CSS === "undefined" || !CSS.supports ? false : CSS.supports("-webkit-backdrop-filter:none");
const isIOS = nav.platform === "MacIntel" && nav.maxTouchPoints > 1 ? true : /iP(hone|ad|od)|iOS/.test(nav.platform);
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=detectBrowser.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/useScrollLock.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useScrollLock",
    ()=>useScrollLock
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$detectBrowser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/detectBrowser.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$owner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/owner.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useClientLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/useClientLayoutEffect.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useTimeout$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/useTimeout.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
;
let originalHtmlStyles = {};
let originalBodyStyles = {};
let originalHtmlScrollBehavior = "";
function hasInsetScrollbars(referenceElement) {
    if (typeof document === "undefined") {
        return false;
    }
    const doc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$owner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ownerDocument"])(referenceElement);
    const win = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$owner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ownerWindow"])(doc);
    return win.innerWidth - doc.documentElement.clientWidth > 0;
}
function preventScrollBasic(referenceElement) {
    const doc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$owner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ownerDocument"])(referenceElement);
    const html = doc.documentElement;
    const body = doc.body;
    /**
     * If an `overflow` style is present on <html>, we need to lock it, because a lock on <body>
     * won't have any effect.
     * But if <body> has an `overflow` style (like `overflow-x: hidden`), we need to lock it
     * instead, as sticky elements shift otherwise.
     */ const elementToLock = isOverflowElement(html) ? html : body;
    const originalOverflow = elementToLock.style.overflow;
    elementToLock.style.overflow = "hidden";
    return ()=>{
        elementToLock.style.overflow = originalOverflow;
    };
}
function preventScrollStandard(referenceElement) {
    var _a, _b;
    const doc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$owner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ownerDocument"])(referenceElement);
    const html = doc.documentElement;
    const body = doc.body;
    const win = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$owner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ownerWindow"])(html);
    let scrollTop = 0;
    let scrollLeft = 0;
    let resizeRaf = 0;
    /* Pinch-zoom in Safari causes a shift. Just don't lock scroll if there's any pinch-zoom. */ if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$detectBrowser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isWebKit"] && ((_b = (_a = win.visualViewport) === null || _a === void 0 ? void 0 : _a.scale) !== null && _b !== void 0 ? _b : 1) !== 1) {
        return ()=>{};
    }
    /**
     * Locks the scroll by applying styles to Html and Body element.
     * Reads the DOM first, then writes to avoid layout thrashing.
     */ function lockScroll() {
        /* DOM reads: */ var _a;
        const htmlStyles = win.getComputedStyle(html);
        const bodyStyles = win.getComputedStyle(body);
        scrollTop = html.scrollTop;
        scrollLeft = html.scrollLeft;
        originalHtmlStyles = {
            scrollbarGutter: html.style.scrollbarGutter,
            overflowY: html.style.overflowY,
            overflowX: html.style.overflowX
        };
        originalHtmlScrollBehavior = html.style.scrollBehavior;
        originalBodyStyles = {
            position: body.style.position,
            height: body.style.height,
            width: body.style.width,
            boxSizing: body.style.boxSizing,
            overflowY: body.style.overflowY,
            overflowX: body.style.overflowX,
            scrollBehavior: body.style.scrollBehavior
        };
        const isScrollableY = html.scrollHeight > html.clientHeight;
        const isScrollableX = html.scrollWidth > html.clientWidth;
        const hasConstantOverflowY = htmlStyles.overflowY === "scroll" || bodyStyles.overflowY === "scroll";
        const hasConstantOverflowX = htmlStyles.overflowX === "scroll" || bodyStyles.overflowX === "scroll";
        /* Values can be negative in Firefox */ const scrollbarWidth = Math.max(0, win.innerWidth - html.clientWidth);
        const scrollbarHeight = Math.max(0, win.innerHeight - html.clientHeight);
        /*
         * Avoid shift due to <body> margin. NB: This does cause elements to be clipped
         * with whitespace.
         */ const marginY = parseFloat(bodyStyles.marginTop) + parseFloat(bodyStyles.marginBottom);
        const marginX = parseFloat(bodyStyles.marginLeft) + parseFloat(bodyStyles.marginRight);
        /**
         * Check support for stable scrollbar gutter to avoid layout shift when scrollbars appear/disappear.
         */ const supportsStableScrollbarGutter = typeof CSS !== "undefined" && ((_a = CSS.supports) === null || _a === void 0 ? void 0 : _a.call(CSS, "scrollbar-gutter", "stable"));
        /*
         * DOM writes:
         * Do not read the DOM past this point!
         */ Object.assign(html.style, {
            scrollbarGutter: "stable",
            overflowY: !supportsStableScrollbarGutter && (isScrollableY || hasConstantOverflowY) ? "scroll" : "hidden",
            overflowX: !supportsStableScrollbarGutter && (isScrollableX || hasConstantOverflowX) ? "scroll" : "hidden"
        });
        Object.assign(body.style, {
            /*
             * Keeps existing positioned children in place (e.g. fixed headers).
             */ position: "relative",
            /**
             *  Limits height to the viewport minus margins/scrollbar compensation to stop vertical overflow from reappearing.
             */ height: marginY || scrollbarHeight ? `calc(100dvh - ${marginY + scrollbarHeight}px)` : "100dvh",
            /**
             * Mirrors height-logic for width.
             */ width: marginX || scrollbarWidth ? `calc(100vw - ${marginX + scrollbarWidth}px)` : "100vw",
            /**
             * Ensures the adjusted dimensions include padding/border, matching the measured values.
             */ boxSizing: "border-box",
            /**
             * Blocks scrollable overflow.
             */ overflow: "hidden",
            /**
             * Removes smooth-scrolling so immediate position restores occur without animation.
             */ scrollBehavior: "unset"
        });
        body.scrollTop = scrollTop;
        body.scrollLeft = scrollLeft;
        html.setAttribute("data-aksel-scroll-locked", "");
        html.style.scrollBehavior = "unset";
    }
    /**
     * Restores the original scroll position and styles to Html and Body element.
     */ function cleanup() {
        Object.assign(html.style, originalHtmlStyles);
        Object.assign(body.style, originalBodyStyles);
        html.scrollTop = scrollTop;
        html.scrollLeft = scrollLeft;
        html.removeAttribute("data-aksel-scroll-locked");
        html.style.scrollBehavior = originalHtmlScrollBehavior;
    }
    /**
     * On resize, restore original styles, then re-apply scroll lock next frame.
     */ function handleResize() {
        cleanup();
        if (resizeRaf) {
            cancelAnimationFrame(resizeRaf);
        }
        /**
         * Wait until next frame to re-apply scroll lock ensuring layout has settled after resize.
         */ resizeRaf = requestAnimationFrame(lockScroll);
    }
    lockScroll();
    win.addEventListener("resize", handleResize);
    return ()=>{
        if (resizeRaf) {
            cancelAnimationFrame(resizeRaf);
        }
        cleanup();
        win.removeEventListener("resize", handleResize);
    };
}
class ScrollLocker {
    constructor(){
        this.lockCount = 0;
        this.restore = null;
        this.timeoutLock = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useTimeout$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timeout"].create();
        this.timeoutUnlock = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useTimeout$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timeout"].create();
        /**
         * Releases a lock
         * - If last lock, unlock document-scroll.
         * - If not last lock, do nothing.
         */ this.release = ()=>{
            this.lockCount -= 1;
            if (this.lockCount === 0 && this.restore) {
                this.timeoutUnlock.start(0, this.unlock);
            }
        };
        this.unlock = ()=>{
            var _a;
            if (this.lockCount === 0 && this.restore) {
                (_a = this.restore) === null || _a === void 0 ? void 0 : _a.call(this);
                this.restore = null;
            }
        };
    }
    /**
     * Aquires a new lock
     * - If first lock, lock document-scroll.
     * - If not first lock, do nothing.
     */ acquire(referenceElement) {
        this.lockCount += 1;
        if (this.lockCount === 1 && this.restore === null) {
            /*
             * Delay locking to avoid layout thrashing when multiple locks/unlocks are requested in quick succession.
             */ this.timeoutLock.start(0, ()=>this.lock(referenceElement));
        }
        return this.release;
    }
    lock(referenceElement) {
        if (this.lockCount === 0 || this.restore !== null) {
            return;
        }
        const doc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$owner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ownerDocument"])(referenceElement);
        const html = doc.documentElement;
        const htmlOverflowY = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$owner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ownerWindow"])(html).getComputedStyle(html).overflowY;
        /* If the site author already hid overflow on <html>, respect it and bail out. */ if (htmlOverflowY === "hidden" || htmlOverflowY === "clip") {
            this.restore = ()=>{};
            return;
        }
        const shouldUseBasicLock = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$detectBrowser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isIOS"] || !hasInsetScrollbars(referenceElement);
        /**
         * On iOS, the standard scroll locking method does not work properly if the navbar is collapsed.
         * The following must be researched extensively before activating standard scroll locking on iOS:
         * - Textboxes must scroll into view when focused, and not cause a glitchy scroll animation.
         * - The navbar must not force itself into view and cause layout shift.
         * - Scroll containers must not flicker upon closing a popup when it has an exit animation.
         */ this.restore = shouldUseBasicLock ? preventScrollBasic(referenceElement) : preventScrollStandard(referenceElement);
    }
}
const SCROLL_LOCKER = new ScrollLocker();
/**
 * Locks the scroll of the document when enabled.
 * @param enabled - Whether to enable the scroll lock.
 */ function useScrollLock(params) {
    _s();
    const { enabled = true, mounted, open, referenceElement = null } = params;
    /**
     * When closing elements with "sloppy clicks" (clicks that start inside the element and ends outside),
     * animating out on WebKit browsers (mounted + not open) can cause the whole page to be selected.
     * To prevent this, we temporarily disable user-select on body while the element is animating out.
     * This bug might be fixed in newer WebKit versions.
     *
     * @see https://github.com/mui/base-ui/issues/1135
     */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useClientLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useClientLayoutEffect"])({
        "useScrollLock.useClientLayoutEffect": ()=>{
            if (enabled && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$detectBrowser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isWebKit"] && mounted && !open) {
                const doc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$owner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ownerDocument"])(referenceElement);
                const originalUserSelect = doc.body.style.userSelect;
                const originalWebkitUserSelect = doc.body.style.webkitUserSelect;
                doc.body.style.userSelect = "none";
                doc.body.style.webkitUserSelect = "none";
                return ({
                    "useScrollLock.useClientLayoutEffect": ()=>{
                        doc.body.style.userSelect = originalUserSelect;
                        doc.body.style.webkitUserSelect = originalWebkitUserSelect;
                    }
                })["useScrollLock.useClientLayoutEffect"];
            }
            return undefined;
        }
    }["useScrollLock.useClientLayoutEffect"], [
        enabled,
        mounted,
        open,
        referenceElement
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useClientLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useClientLayoutEffect"])({
        "useScrollLock.useClientLayoutEffect": ()=>{
            if (!enabled) {
                return undefined;
            }
            return SCROLL_LOCKER.acquire(referenceElement);
        }
    }["useScrollLock.useClientLayoutEffect"], [
        enabled,
        referenceElement
    ]);
}
_s(useScrollLock, "Ck/Ck7WAcBCztBu544VKFas1Akc=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useClientLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useClientLayoutEffect"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useClientLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useClientLayoutEffect"]
    ];
});
const invalidOverflowDisplayValues = new Set([
    "inline",
    "contents"
]);
function isOverflowElement(element) {
    const { overflow, overflowX, overflowY, display } = getComputedStyle(element);
    return /auto|scroll|overlay|hidden|clip/.test(overflow + overflowY + overflowX) && !invalidOverflowDisplayValues.has(display);
}
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=useScrollLock.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/i18n/locales/en.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$en$2d$GB$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/locale/en-GB.js [app-client] (ecmascript)");
;
const __TURBOPACK__default__export__ = {
    global: {
        dateLocale: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$en$2d$GB$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["enGB"],
        showMore: "Show more",
        showLess: "Show less",
        readOnly: "Read-only",
        close: "Close",
        error: "Error",
        info: "Information",
        success: "Success",
        warning: "Warning",
        announcement: "Announcement"
    },
    Chips: {
        Removable: {
            labelSuffix: "delete"
        }
    },
    Combobox: {
        addOption: "Add",
        noMatches: "No search hits",
        loading: "Searching…",
        maxSelected: "{selected} of max {limit} are selected."
    },
    CopyButton: {
        title: "Copy",
        activeText: "Copied!"
    },
    DatePicker: {
        chooseDate: "Choose date",
        chooseDates: "Choose dates",
        chooseDateRange: "Choose start and end date",
        chooseMonth: "Choose month",
        week: "Week",
        weekNumber: "Week {week}",
        selectWeekNumber: "Select week {week}",
        month: "Month",
        goToNextMonth: "Go to next month",
        goToPreviousMonth: "Go to previous month",
        year: "Year",
        goToNextYear: "Go to next year",
        goToPreviousYear: "Go to previous year",
        openDatePicker: "Open date picker",
        openMonthPicker: "Open month picker",
        closeDatePicker: "Close date picker",
        closeMonthPicker: "Close month picker"
    },
    ErrorSummary: {
        heading: "You must correct the following errors before you can continue:"
    },
    FileUpload: {
        dropzone: {
            button: "Choose file",
            buttonMultiple: "Choose files",
            dragAndDrop: "Drag and drop file here",
            dragAndDropMultiple: "Drag and drop files here",
            drop: "Drop",
            or: "or",
            disabled: "File upload disabled",
            disabledFilelimit: "You cannot upload more files"
        },
        item: {
            retryButtonTitle: "Try uploading the file again",
            deleteButtonTitle: "Delete file",
            uploading: "Uploading…",
            downloading: "Downloading…"
        }
    },
    FormProgress: {
        step: "Step {activeStep} of {totalSteps}",
        showAllSteps: "Show all steps",
        hideAllSteps: "Hide all steps"
    },
    FormSummary: {
        editAnswer: "Edit answer"
    },
    GuidePanel: {
        illustrationLabel: "Illustration of advisor"
    },
    HelpText: {
        title: "More information"
    },
    Loader: {
        title: "Waiting…"
    },
    Pagination: {
        previous: "Previous",
        next: "Next"
    },
    Process: {
        active: "Active"
    },
    ProgressBar: {
        progress: "{current} of {max}",
        progressUnknown: "Progress is unknown, estimated time is {seconds} seconds."
    },
    Search: {
        clear: "Clear field",
        search: "Search"
    },
    Textarea: {
        maxLength: "Text area with a {maxLength} character limit.",
        charsTooMany: "{chars} characters too many",
        charsLeft: "{chars} characters left"
    },
    Timeline: {
        dateFormat: "yyyy-MM-dd",
        dayFormat: "d MMM",
        monthFormat: "MMM yyyy",
        yearFormat: "yyyy",
        Row: {
            noPeriods: "No periods",
            period: "{start} to {end}"
        },
        Period: {
            success: "Success",
            warning: "Warning",
            danger: "Danger",
            info: "Info",
            neutral: "Neutral",
            period: "{status} from {start} to {end}"
        },
        Pin: {
            pin: "Pin: {date}"
        },
        Zoom: {
            zoom: "Zoom timeline {start} to {end}",
            reset: "Reset zoom"
        }
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=en.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/i18n/locales/nn.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$nn$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@4.1.0/node_modules/date-fns/locale/nn.js [app-client] (ecmascript)");
;
const __TURBOPACK__default__export__ = {
    global: {
        dateLocale: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$4$2e$1$2e$0$2f$node_modules$2f$date$2d$fns$2f$locale$2f$nn$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["nn"],
        showMore: "Vis meir",
        showLess: "Vis mindre",
        readOnly: "Skrivebeskytta",
        close: "Lukk",
        error: "Feil",
        info: "Informasjon",
        success: "Suksess",
        warning: "Åtvaring",
        announcement: "Kunngjering"
    },
    Chips: {
        Removable: {
            labelSuffix: "slett"
        }
    },
    Combobox: {
        addOption: "Legg til",
        noMatches: "Ingen søketreff",
        loading: "Søker…",
        maxSelected: "{selected} av maks {limit} er valt."
    },
    CopyButton: {
        title: "Kopier",
        activeText: "Kopiert!"
    },
    DatePicker: {
        chooseDate: "Vel dato",
        chooseDates: "Vel datoar",
        chooseDateRange: "Vel start- og sluttdato",
        chooseMonth: "Vel månad",
        week: "Veke",
        weekNumber: "Veke {week}",
        selectWeekNumber: "Vel veke {week}",
        month: "Månad",
        goToNextMonth: "Gå til neste månad",
        goToPreviousMonth: "Gå til førre månad",
        year: "År",
        goToNextYear: "Gå til neste år",
        goToPreviousYear: "Gå til førre år",
        openDatePicker: "Opne datoveljar",
        openMonthPicker: "Opne månadsveljar",
        closeDatePicker: "Lukk datoveljar",
        closeMonthPicker: "Lukk månadsveljar"
    },
    ErrorSummary: {
        heading: "Du må rette desse feila før du kan halde fram:"
    },
    FileUpload: {
        dropzone: {
            button: "Vel fil",
            buttonMultiple: "Vel filer",
            dragAndDrop: "Dra og slepp fila her",
            dragAndDropMultiple: "Dra og slepp filer her",
            drop: "Slepp",
            or: "eller",
            disabled: "Filopplasting er deaktivert",
            disabledFilelimit: "Du kan ikkje laste opp fleire filer"
        },
        item: {
            retryButtonTitle: "Prøv å laste opp fila på nytt",
            deleteButtonTitle: "Slett fila",
            uploading: "Lastar opp…",
            downloading: "Lastar ned…"
        }
    },
    FormProgress: {
        step: "Steg {activeStep} av {totalSteps}",
        showAllSteps: "Vis alle steg",
        hideAllSteps: "Skjul alle steg"
    },
    FormSummary: {
        editAnswer: "Endre svar"
    },
    GuidePanel: {
        illustrationLabel: "Illustrasjon av rettleiar"
    },
    HelpText: {
        title: "Meir informasjon"
    },
    Loader: {
        title: "Ventar…"
    },
    Pagination: {
        previous: "Førre",
        next: "Neste"
    },
    Process: {
        active: "Aktiv"
    },
    ProgressBar: {
        progress: "{current} av {max}",
        progressUnknown: "Framdrift kan ikkje bereknast, antatt tid er {seconds} sekund."
    },
    Search: {
        clear: "Tøm feltet",
        search: "Søk"
    },
    Textarea: {
        maxLength: "Tekstområde med plass til {maxLength} teikn.",
        charsTooMany: "{chars} teikn for mykje",
        charsLeft: "{chars} teikn igjen"
    },
    Timeline: {
        dateFormat: "dd.MM.yyyy",
        dayFormat: "dd.MM",
        monthFormat: "MMM yy",
        yearFormat: "yyyy",
        Row: {
            noPeriods: "Ingen periodar",
            period: "{start} til {end}"
        },
        Period: {
            success: "Suksess",
            warning: "Åtvaring",
            danger: "Fare",
            info: "Info",
            neutral: "Nøytral",
            period: "{status} frå {start} til {end}"
        },
        Pin: {
            pin: "Pin: {date}"
        },
        Zoom: {
            zoom: "Zoom tidslina {start} til {end}",
            reset: "Tilbakestill tidsperspektiv"
        }
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=nn.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/useMedia.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "noMatchMedia",
    ()=>noMatchMedia,
    "useMedia",
    ()=>useMedia
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
const noMatchMedia = ("TURBOPACK compile-time value", "object") !== "undefined" && window.matchMedia === undefined;
const useMedia = (media, fallback)=>{
    _s();
    const [matches, setMatches] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(fallback);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useMedia.useEffect": ()=>{
            if (noMatchMedia) {
                return;
            }
            const mediaQueryList = window.matchMedia(media);
            setMatches(mediaQueryList.matches);
            const listener = {
                "useMedia.useEffect.listener": (evt)=>{
                    setMatches(evt.matches);
                }
            }["useMedia.useEffect.listener"];
            mediaQueryList.addEventListener("change", listener);
            return ({
                "useMedia.useEffect": ()=>{
                    mediaQueryList.removeEventListener("change", listener);
                }
            })["useMedia.useEffect"];
        }
    }["useMedia.useEffect"], [
        media
    ]);
    return matches;
}; //# sourceMappingURL=useMedia.js.map
_s(useMedia, "LR7J7Dky/UQTJzU9S34lnSVr6WQ=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/link-anchor/LinkAnchor.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LinkAnchor",
    ()=>LinkAnchor,
    "LinkAnchorArrow",
    ()=>LinkAnchorArrow,
    "LinkAnchorOverlay",
    ()=>LinkAnchorOverlay
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$ArrowRight$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRightIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/ArrowRight.js [app-client] (ecmascript) <export default as ArrowRightIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$slot$2f$Slot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/slot/Slot.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$composeEventHandlers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/composeEventHandlers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$create$2d$strict$2d$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/create-strict-context.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useMergeRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/useMergeRefs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$owner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/owner.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
;
;
;
;
;
const { Provider: LinkAnchorContextProvider, useContext: useLinkAnchorContext } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$create$2d$strict$2d$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createStrictContext"])({
    name: "LinkAnchorOverlayContext"
});
const LinkAnchorOverlay = /*#__PURE__*/ _s((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = _s((_a, forwardedRef)=>{
    _s();
    var { children, asChild, className, onClick } = _a, restProps = __rest(_a, [
        "children",
        "asChild",
        "className",
        "onClick"
    ]);
    const anchorRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const Component = asChild ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$slot$2f$Slot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Slot"] : "div";
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(LinkAnchorContextProvider, {
        anchorRef: anchorRef
    }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(Component, Object.assign({
        ref: forwardedRef
    }, restProps, {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-link-anchor__overlay", className),
        onClick: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$composeEventHandlers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["composeEventHandlers"])(onClick, (e)=>{
            var _a;
            if (e.target === anchorRef.current || isTextSelected(anchorRef.current)) {
                return;
            }
            const event = new MouseEvent("click", {
                bubbles: true,
                cancelable: true,
                view: window,
                ctrlKey: e.ctrlKey,
                shiftKey: e.shiftKey,
                altKey: e.altKey,
                metaKey: e.metaKey,
                button: e.button,
                screenX: e.screenX,
                screenY: e.screenY,
                clientX: e.clientX,
                clientY: e.clientY
            });
            (_a = anchorRef.current) === null || _a === void 0 ? void 0 : _a.dispatchEvent(event);
        })
    }), children));
}, "8MmVO+p7Pr8AFI+ZrSDSjihV77c=")), "8MmVO+p7Pr8AFI+ZrSDSjihV77c=");
_c1 = LinkAnchorOverlay;
const LinkAnchor = /*#__PURE__*/ _s1((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c2 = _s1((_a, forwardedRef)=>{
    _s1();
    var { children, asChild, className } = _a, restProps = __rest(_a, [
        "children",
        "asChild",
        "className"
    ]);
    const context = useLinkAnchorContext(false);
    const mergedRefs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useMergeRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMergeRefs"])(forwardedRef, context === null || context === void 0 ? void 0 : context.anchorRef);
    const Component = asChild ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$slot$2f$Slot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Slot"] : "a";
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(Component, Object.assign({
        ref: mergedRefs
    }, restProps, {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-link-anchor", className)
    }), children);
}, "+cYF+Opcz/3PsjfuRB0c6e/0gII=", false, function() {
    return [
        useLinkAnchorContext,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useMergeRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMergeRefs"]
    ];
})), "+cYF+Opcz/3PsjfuRB0c6e/0gII=", false, function() {
    return [
        useLinkAnchorContext,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useMergeRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMergeRefs"]
    ];
});
_c3 = LinkAnchor;
const LinkAnchorArrow = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c4 = (_a, forwardedRef)=>{
    var { className } = _a, restProps = __rest(_a, [
        "className"
    ]);
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$ArrowRight$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRightIcon$3e$__["ArrowRightIcon"], Object.assign({
        ref: forwardedRef,
        "aria-hidden": true,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-link-anchor__arrow", className)
    }, restProps));
});
_c5 = LinkAnchorArrow;
/* -------------------------- LinkAnchor Utilities -------------------------- */ function isTextSelected(refElement) {
    var _a, _b;
    return !!((_b = (_a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$owner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ownerWindow"])(refElement)) === null || _a === void 0 ? void 0 : _a.getSelection()) === null || _b === void 0 ? void 0 : _b.toString());
}
;
var _c, _c1, _c2, _c3, _c4, _c5;
__turbopack_context__.k.register(_c, "LinkAnchorOverlay$forwardRef");
__turbopack_context__.k.register(_c1, "LinkAnchorOverlay");
__turbopack_context__.k.register(_c2, "LinkAnchor$forwardRef");
__turbopack_context__.k.register(_c3, "LinkAnchor");
__turbopack_context__.k.register(_c4, "LinkAnchorArrow$forwardRef");
__turbopack_context__.k.register(_c5, "LinkAnchorArrow");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=LinkAnchor.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/debounce.js [app-client] (ecmascript) <export default as debounce>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "debounce",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$debounce$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$debounce$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/debounce.js [app-client] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/usePrevious.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "usePrevious",
    ()=>usePrevious
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
const usePrevious = (value)=>{
    _s();
    const ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(value);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "usePrevious.useEffect": ()=>{
            ref.current = value;
        }
    }["usePrevious.useEffect"], [
        value
    ]);
    return ref.current;
}; //# sourceMappingURL=usePrevious.js.map
_s(usePrevious, "8uVE59eA/r6b92xF80p7sH8rXLk=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/dialog/body/DialogBody.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DialogBody",
    ()=>DialogBody
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
/**
 * @see 🏷️ {@link DialogBodyProps}
 * @example
 * ```jsx
 *  <Dialog>
 *    <Dialog.Popup>
 *      <Dialog.Body>
 *        Dialog body content
 *      </Dialog.Body>
 *    </Dialog.Popup>
 *  </Dialog>
 * ```
 */ const DialogBody = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = (_a, forwardedRef)=>{
    var { className, children } = _a, restProps = __rest(_a, [
        "className",
        "children"
    ]);
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", Object.assign({}, restProps, {
        ref: forwardedRef,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-dialog__body", className)
    }), children);
});
_c1 = DialogBody;
;
var _c, _c1;
__turbopack_context__.k.register(_c, "DialogBody$forwardRef");
__turbopack_context__.k.register(_c1, "DialogBody");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=DialogBody.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/dialog/root/DialogRoot.context.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DialogContextProvider",
    ()=>DialogContextProvider,
    "useDialogContext",
    ()=>useDialogContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$create$2d$strict$2d$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/create-strict-context.js [app-client] (ecmascript)");
;
const { Provider: DialogContextProvider, useContext: useDialogContext } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$create$2d$strict$2d$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createStrictContext"])({
    name: "DialogContext",
    errorMessage: "useDialogContext must be used within Dialog"
});
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=DialogRoot.context.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/dialog/close-trigger/DialogCloseTrigger.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DialogCloseTrigger",
    ()=>DialogCloseTrigger
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$slot$2f$Slot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/slot/Slot.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$composeEventHandlers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/composeEventHandlers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$root$2f$DialogRoot$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/dialog/root/DialogRoot.context.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
;
/**
 * @see 🏷️ {@link DialogCloseTriggerProps}
 * @example
 * ```jsx
 *  <Dialog>
 *    <Dialog.Popup>
 *      <Dialog.CloseTrigger>
 *        <Button>Close dialog</Button>
 *      </Dialog.CloseTrigger>
 *    </Dialog.Popup>
 *  </Dialog>
 * ```
 */ const DialogCloseTrigger = /*#__PURE__*/ _s((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = _s((_a, forwardedRef)=>{
    _s();
    var { children, onClick } = _a, restProps = __rest(_a, [
        "children",
        "onClick"
    ]);
    const { open, setOpen } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$root$2f$DialogRoot$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDialogContext"])();
    const handleClick = (event)=>{
        if (open) {
            setOpen(false, event.nativeEvent);
        }
    };
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$slot$2f$Slot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Slot"], Object.assign({
        type: "button"
    }, restProps, {
        ref: forwardedRef,
        onClick: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$composeEventHandlers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["composeEventHandlers"])(onClick, handleClick)
    }), children);
}, "l2AM9gZexltHagtO651+jr64LoI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$root$2f$DialogRoot$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDialogContext"]
    ];
})), "l2AM9gZexltHagtO651+jr64LoI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$root$2f$DialogRoot$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDialogContext"]
    ];
});
_c1 = DialogCloseTrigger;
;
var _c, _c1;
__turbopack_context__.k.register(_c, "DialogCloseTrigger$forwardRef");
__turbopack_context__.k.register(_c1, "DialogCloseTrigger");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=DialogCloseTrigger.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/dialog/description/DialogDescription.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DialogDescription",
    ()=>DialogDescription
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/BodyShort.js [app-client] (ecmascript) <export default as BodyShort>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$root$2f$DialogRoot$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/dialog/root/DialogRoot.context.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
;
/**
 * @see 🏷️ {@link DialogDescriptionProps}
 * @example
 * ```jsx
 *  <Dialog>
 *    <Dialog.Popup>
 *      <Dialog.Header>
 *        <Dialog.Title>Dialog title</Dialog.Title>
 *        <Dialog.Description>Dialog description</Dialog.Description>
 *      </Dialog.Header>
 *    </Dialog.Popup>
 *  </Dialog>
 * ```
 */ const DialogDescription = /*#__PURE__*/ _s((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = _s((_a, forwardedRef)=>{
    _s();
    var { className, children } = _a, restProps = __rest(_a, [
        "className",
        "children"
    ]);
    const { size } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$root$2f$DialogRoot$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDialogContext"])();
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__["BodyShort"], Object.assign({}, restProps, {
        ref: forwardedRef,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-dialog__description", className),
        size: size,
        "data-color": "neutral",
        textColor: "subtle"
    }), children);
}, "U2UcMxDWqBw+pF5VTy9TwWdDpwE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$root$2f$DialogRoot$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDialogContext"]
    ];
})), "U2UcMxDWqBw+pF5VTy9TwWdDpwE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$root$2f$DialogRoot$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDialogContext"]
    ];
});
_c1 = DialogDescription;
;
var _c, _c1;
__turbopack_context__.k.register(_c, "DialogDescription$forwardRef");
__turbopack_context__.k.register(_c1, "DialogDescription");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=DialogDescription.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/dialog/footer/DialogFooter.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DialogFooter",
    ()=>DialogFooter
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
/**
 * @see 🏷️ {@link DialogFooterProps}
 * @example
 * ```jsx
 *  <Dialog>
 *    <Dialog.Popup>
 *      <Dialog.Footer>
 *        <Dialog.CloseTrigger>
 *          <Button>Close dialog</Button>
 *        </Dialog.CloseTrigger>
 *      </Dialog.Footer>
 *    </Dialog.Popup>
 *  </Dialog>
 * ```
 */ const DialogFooter = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = (_a, forwardedRef)=>{
    var { className, children } = _a, restProps = __rest(_a, [
        "className",
        "children"
    ]);
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", Object.assign({}, restProps, {
        ref: forwardedRef,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-dialog__footer", className)
    }), children);
});
_c1 = DialogFooter;
;
var _c, _c1;
__turbopack_context__.k.register(_c, "DialogFooter$forwardRef");
__turbopack_context__.k.register(_c1, "DialogFooter");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=DialogFooter.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/dialog/header/DialogHeader.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DialogHeader",
    ()=>DialogHeader
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$XMark$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XMarkIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/XMark.js [app-client] (ecmascript) <export default as XMarkIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$i18n$2f$i18n$2e$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/i18n/i18n.hooks.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$close$2d$trigger$2f$DialogCloseTrigger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/dialog/close-trigger/DialogCloseTrigger.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
;
;
;
/**
 * @see 🏷️ {@link DialogHeaderProps}
 * @example
 * ```jsx
 *  <Dialog>
 *    <Dialog.Popup>
 *      <Dialog.Header>
 *        <Dialog.Title>Dialog title</Dialog.Title>
 *      </Dialog.Header>
 *    </Dialog.Popup>
 *  </Dialog>
 * ```
 */ const DialogHeader = /*#__PURE__*/ _s((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = _s((_a, forwardedRef)=>{
    _s();
    var { className, children, withClosebutton = true } = _a, restProps = __rest(_a, [
        "className",
        "children",
        "withClosebutton"
    ]);
    const translate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$i18n$2f$i18n$2e$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useI18n"])("global");
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", Object.assign({}, restProps, {
        ref: forwardedRef,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-dialog__header", className)
    }), withClosebutton && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$close$2d$trigger$2f$DialogCloseTrigger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogCloseTrigger"], null, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
        type: "button",
        className: "aksel-dialog__close-button",
        size: "small",
        variant: "tertiary-neutral",
        icon: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$XMark$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XMarkIcon$3e$__["XMarkIcon"], {
            title: translate("close")
        })
    })), children);
}, "KV87nYrn2zW6QxQP1Zrr/rEPoM0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$i18n$2f$i18n$2e$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useI18n"]
    ];
})), "KV87nYrn2zW6QxQP1Zrr/rEPoM0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$i18n$2f$i18n$2e$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useI18n"]
    ];
});
_c1 = DialogHeader;
;
var _c, _c1;
__turbopack_context__.k.register(_c, "DialogHeader$forwardRef");
__turbopack_context__.k.register(_c1, "DialogHeader");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=DialogHeader.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/dialog/backdrop/DialogBackdropInternal.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DialogBackdropInternal",
    ()=>DialogBackdropInternal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useTransitionStatus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/useTransitionStatus.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$root$2f$DialogRoot$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/dialog/root/DialogRoot.context.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
;
const DialogBackdropInternal = /*#__PURE__*/ _s((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = _s((_a, forwardedRef)=>{
    _s();
    var { className } = _a, restProps = __rest(_a, [
        "className"
    ]);
    const { transitionStatus } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$root$2f$DialogRoot$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDialogContext"])();
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", Object.assign({}, restProps, {
        ref: forwardedRef,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-dialog__backdrop", className)
    }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useTransitionStatus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createTransitionStatusAttribute"])(transitionStatus)));
}, "7PSd2iuZ3xQ/PWDTMYju/CXVenM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$root$2f$DialogRoot$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDialogContext"]
    ];
})), "7PSd2iuZ3xQ/PWDTMYju/CXVenM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$root$2f$DialogRoot$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDialogContext"]
    ];
});
_c1 = DialogBackdropInternal;
;
var _c, _c1;
__turbopack_context__.k.register(_c, "DialogBackdropInternal$forwardRef");
__turbopack_context__.k.register(_c1, "DialogBackdropInternal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=DialogBackdropInternal.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/dialog/popup/DialogPopupInternal.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DialogPopupInternal",
    ()=>DialogPopupInternal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$layout$2f$box$2f$Box$2e$darkside$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BoxNew$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/layout/box/Box.darkside.js [app-client] (ecmascript) <export default as BoxNew>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$overlays$2f$dismissablelayer$2f$DismissableLayer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/overlays/dismissablelayer/DismissableLayer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$focus$2d$boundary$2f$FocusBoundary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/focus-boundary/FocusBoundary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$focus$2d$guards$2f$FocusGuards$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/focus-guards/FocusGuards.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useMergeRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/useMergeRefs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useOpenChangeAnimationComplete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/useOpenChangeAnimationComplete.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useScrollLock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/useScrollLock.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useTransitionStatus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/useTransitionStatus.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$root$2f$DialogRoot$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/dialog/root/DialogRoot.context.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
;
;
;
;
;
;
;
;
const DialogPopupInternal = /*#__PURE__*/ _s((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = _s((_a, forwardedRef)=>{
    _s();
    var { className, modal, closeOnOutsideClick = true, initialFocusTo, returnFocusTo, position = "center", width = "medium", height, id, style, "aria-labelledby": ariaLabelledbyProp, withBackdrop, role = "dialog" } = _a, restProps = __rest(_a, [
        "className",
        "modal",
        "closeOnOutsideClick",
        "initialFocusTo",
        "returnFocusTo",
        "position",
        "width",
        "height",
        "id",
        "style",
        "aria-labelledby",
        "withBackdrop",
        "role"
    ]);
    const { mounted, popupRef, setPopupElement, triggerElement, setOpen, open, transitionStatus, popupElement, nestedOpenDialogCount: nestedOpenDialogCountProp, nested, size, titleId, popupId, onOpenChangeComplete, setMounted } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$root$2f$DialogRoot$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDialogContext"])();
    const mergedRefs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useMergeRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMergeRefs"])(forwardedRef, popupRef, setPopupElement);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useScrollLock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useScrollLock"])({
        enabled: open && modal === true,
        mounted,
        open,
        referenceElement: popupElement
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useOpenChangeAnimationComplete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOpenChangeAnimationComplete"])({
        open,
        ref: popupRef,
        onComplete () {
            if (open) {
                onOpenChangeComplete === null || onOpenChangeComplete === void 0 ? void 0 : onOpenChangeComplete(true);
            } else {
                setMounted(false);
                onOpenChangeComplete === null || onOpenChangeComplete === void 0 ? void 0 : onOpenChangeComplete(false);
            }
        }
    });
    const resolvedInitialFocus = initialFocusTo !== null && initialFocusTo !== void 0 ? initialFocusTo : popupRef;
    const resolvedReturnFocus = ()=>{
        if (returnFocusTo) {
            return typeof returnFocusTo === "function" ? returnFocusTo() : returnFocusTo.current;
        }
        if (isFocusable(triggerElement)) {
            return triggerElement;
        }
        return true;
    };
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$focus$2d$guards$2f$FocusGuards$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FocusGuards"], null, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$focus$2d$boundary$2f$FocusBoundary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FocusBoundary"], {
        loop: true,
        trapped: open,
        initialFocus: resolvedInitialFocus,
        returnFocus: resolvedReturnFocus,
        modal: true
    }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$overlays$2f$dismissablelayer$2f$DismissableLayer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DismissableLayer"], {
        asChild: true,
        safeZone: {
            anchor: triggerElement
        },
        onDismiss: (event)=>{
            open && setOpen(false, event);
        },
        disableOutsidePointerEvents: modal === true || withBackdrop,
        onInteractOutside: (event)=>{
            /**
                     * Since trigger might be set up to close the dialog on click,
                     * we need to prevent dismissing when clicking the trigger to avoid double close events (potentially re-triggering open)
                     */ const target = event.target;
            const targetIsTrigger = triggerElement === null || triggerElement === void 0 ? void 0 : triggerElement.contains(target);
            if (targetIsTrigger) {
                event.preventDefault();
            }
        },
        /**
                 * Only close dialog on pointerUp pointerEvents
                 */ onPointerDownOutside: (event)=>{
            event.preventDefault();
        },
        onFocusOutside: (event)=>{
            /**
                     * Focus-events are tricky when dealing with portals and nested dialogs.
                     * If multiple dialogs are open, initial auto-focus might cause
                     * onFocusOutside to trigger on the parent dialog when focusing the child dialog.
                     */ event.preventDefault();
        },
        enablePointerUpOutside: true,
        onPointerUpOutside: (event)=>{
            !closeOnOutsideClick && event.preventDefault();
        }
    }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$layout$2f$box$2f$Box$2e$darkside$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BoxNew$3e$__["BoxNew"], Object.assign({
        "aria-labelledby": ariaLabelledbyProp !== null && ariaLabelledbyProp !== void 0 ? ariaLabelledbyProp : titleId,
        id: id !== null && id !== void 0 ? id : popupId
    }, restProps, {
        ref: mergedRefs,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-dialog__popup", className),
        role: role,
        "aria-modal": "true"
    }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useTransitionStatus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createTransitionStatusAttribute"])(transitionStatus), {
        "data-position": position,
        "data-size": size,
        width: translateWidth(width, position),
        height: translateHeight(height, position),
        style: Object.assign(Object.assign({}, style), {
            "--__axc-nested-level": nestedOpenDialogCountProp
        }),
        "data-nested-dialog-open": !!nestedOpenDialogCountProp,
        "data-nested": !!nested
    })))));
}, "zzfdSTvC/6ka/q64Cpu8RWYm4EE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$root$2f$DialogRoot$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDialogContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useMergeRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMergeRefs"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useScrollLock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useScrollLock"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useOpenChangeAnimationComplete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOpenChangeAnimationComplete"]
    ];
})), "zzfdSTvC/6ka/q64Cpu8RWYm4EE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$root$2f$DialogRoot$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDialogContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useMergeRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMergeRefs"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useScrollLock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useScrollLock"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useOpenChangeAnimationComplete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOpenChangeAnimationComplete"]
    ];
});
_c1 = DialogPopupInternal;
function translateWidth(width, position) {
    if (position === "fullscreen") {
        return undefined;
    }
    switch(width){
        case "small":
            return "480px";
        case "medium":
            return "640px";
        case "large":
            return "800px";
        default:
            return width;
    }
}
function translateHeight(height, position) {
    if (position === "fullscreen" || position === "left" || position === "right") {
        return undefined;
    }
    return height;
}
function isFocusable(element) {
    if (!element || !element.isConnected) {
        return false;
    }
    /**
     * Baselined in 2024
     * @see https://caniuse.com/?search=checkvisibility
     */ if (typeof element.checkVisibility === "function") {
        return element.checkVisibility();
    }
    return getComputedStyle(element).display !== "none";
}
;
var _c, _c1;
__turbopack_context__.k.register(_c, "DialogPopupInternal$forwardRef");
__turbopack_context__.k.register(_c1, "DialogPopupInternal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=DialogPopupInternal.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/dialog/popup/DialogPopup.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DialogPopup",
    ()=>DialogPopup
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$Modal$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/modal/Modal.context.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$portal$2f$Portal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Portal$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/portal/Portal.js [app-client] (ecmascript) <export default as Portal>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$backdrop$2f$DialogBackdropInternal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/dialog/backdrop/DialogBackdropInternal.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$root$2f$DialogRoot$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/dialog/root/DialogRoot.context.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$popup$2f$DialogPopupInternal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/dialog/popup/DialogPopupInternal.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
;
;
;
/**
 * @see 🏷️ {@link DialogPopupProps}
 * @example
 * ```jsx
 *  <Dialog>
 *    <Dialog.Popup>
 *      ...
 *    </Dialog.Popup>
 *  </Dialog>
 * ```
 */ const DialogPopup = /*#__PURE__*/ _s((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = _s((_a, forwardedRef)=>{
    _s();
    var { modal = true, withBackdrop = modal === true, rootElement: rootElementProp, position } = _a, restProps = __rest(_a, [
        "modal",
        "withBackdrop",
        "rootElement",
        "position"
    ]);
    const { mounted, nested } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$root$2f$DialogRoot$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDialogContext"])();
    const modalContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$Modal$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useModalContext"])(false);
    const rootElement = modalContext ? modalContext.modalRef.current : rootElementProp;
    if (!mounted) {
        return null;
    }
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$portal$2f$Portal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Portal$3e$__["Portal"], {
        rootElement: rootElement
    }, withBackdrop && position !== "fullscreen" && !nested && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$backdrop$2f$DialogBackdropInternal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogBackdropInternal"], null), /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$popup$2f$DialogPopupInternal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogPopupInternal"], Object.assign({
        ref: forwardedRef
    }, restProps, {
        position: position,
        withBackdrop: withBackdrop && position !== "fullscreen",
        modal: modal
    })));
}, "Pvzlcz9ymfTtxaRJxWkd+9XB/JE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$root$2f$DialogRoot$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDialogContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$Modal$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useModalContext"]
    ];
})), "Pvzlcz9ymfTtxaRJxWkd+9XB/JE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$root$2f$DialogRoot$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDialogContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$Modal$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useModalContext"]
    ];
});
_c1 = DialogPopup;
;
var _c, _c1;
__turbopack_context__.k.register(_c, "DialogPopup$forwardRef");
__turbopack_context__.k.register(_c1, "DialogPopup");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=DialogPopup.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/dialog/title/DialogTitle.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DialogTitle",
    ()=>DialogTitle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$Heading$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Heading$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/Heading.js [app-client] (ecmascript) <export default as Heading>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useClientLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/useClientLayoutEffect.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/useId.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$root$2f$DialogRoot$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/dialog/root/DialogRoot.context.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
;
;
/**
 * @see 🏷️ {@link DialogTitleProps}
 * @example
 * ```jsx
 *  <Dialog>
 *    <Dialog.Popup>
 *      <Dialog.Header>
 *        <Dialog.Title>Dialog title</Dialog.Title>
 *      </Dialog.Header>
 *    </Dialog.Popup>
 *  </Dialog>
 * ```
 */ const DialogTitle = /*#__PURE__*/ _s((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = _s((_a, forwardedRef)=>{
    _s();
    var { className, children, id } = _a, restProps = __rest(_a, [
        "className",
        "children",
        "id"
    ]);
    const { size, setTitleId } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$root$2f$DialogRoot$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDialogContext"])();
    const titleId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])(id);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useClientLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useClientLayoutEffect"])({
        "DialogTitle.useClientLayoutEffect": ()=>{
            setTitleId(titleId);
            return ({
                "DialogTitle.useClientLayoutEffect": ()=>{
                    setTitleId(undefined);
                }
            })["DialogTitle.useClientLayoutEffect"];
        }
    }["DialogTitle.useClientLayoutEffect"], [
        titleId,
        setTitleId
    ]);
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$Heading$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Heading$3e$__["Heading"], Object.assign({}, restProps, {
        id: titleId,
        ref: forwardedRef,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-dialog__title", className),
        size: size,
        level: "1"
    }), children);
}, "qzwxuj84l8ROQj2V6MX0iMRN4pg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$root$2f$DialogRoot$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDialogContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useClientLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useClientLayoutEffect"]
    ];
})), "qzwxuj84l8ROQj2V6MX0iMRN4pg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$root$2f$DialogRoot$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDialogContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useClientLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useClientLayoutEffect"]
    ];
});
_c1 = DialogTitle;
;
var _c, _c1;
__turbopack_context__.k.register(_c, "DialogTitle$forwardRef");
__turbopack_context__.k.register(_c1, "DialogTitle");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=DialogTitle.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/dialog/trigger/DialogTrigger.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DialogTrigger",
    ()=>DialogTrigger
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$slot$2f$Slot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/slot/Slot.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$composeEventHandlers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/composeEventHandlers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useMergeRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/useMergeRefs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$root$2f$DialogRoot$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/dialog/root/DialogRoot.context.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
;
;
/**
 * @see 🏷️ {@link DialogTriggerProps}
 * @example
 * ```jsx
 *  <Dialog>
 *    <Dialog.Trigger>
 *      <Button>Open dialog</Button>
 *    </Dialog.Trigger>
 *  </Dialog>
 * ```
 */ const DialogTrigger = /*#__PURE__*/ _s((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = _s((_a, forwardedRef)=>{
    _s();
    var { children, onClick } = _a, restProps = __rest(_a, [
        "children",
        "onClick"
    ]);
    const { open, setOpen, setTriggerElement, popupId } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$root$2f$DialogRoot$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDialogContext"])();
    const mergedRefs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useMergeRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMergeRefs"])(forwardedRef, setTriggerElement);
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$slot$2f$Slot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Slot"], Object.assign({
        type: "button"
    }, restProps, {
        ref: mergedRefs,
        onClick: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$composeEventHandlers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["composeEventHandlers"])(onClick, (event)=>setOpen(!open, event.nativeEvent)),
        "aria-haspopup": "dialog",
        "aria-controls": open ? popupId : undefined
    }), children);
}, "FTIwh4XgeOqBXYpnHDJ47zfWAG8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$root$2f$DialogRoot$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDialogContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useMergeRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMergeRefs"]
    ];
})), "FTIwh4XgeOqBXYpnHDJ47zfWAG8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$root$2f$DialogRoot$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDialogContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useMergeRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMergeRefs"]
    ];
});
_c1 = DialogTrigger;
;
var _c, _c1;
__turbopack_context__.k.register(_c, "DialogTrigger$forwardRef");
__turbopack_context__.k.register(_c1, "DialogTrigger");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=DialogTrigger.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/dialog/root/DialogRoot.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Dialog",
    ()=>Dialog,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/useId.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useControllableState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/useControllableState.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useEventCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/useEventCallback.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useTransitionStatus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/useTransitionStatus.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$body$2f$DialogBody$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/dialog/body/DialogBody.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$close$2d$trigger$2f$DialogCloseTrigger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/dialog/close-trigger/DialogCloseTrigger.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$description$2f$DialogDescription$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/dialog/description/DialogDescription.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$footer$2f$DialogFooter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/dialog/footer/DialogFooter.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$header$2f$DialogHeader$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/dialog/header/DialogHeader.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$popup$2f$DialogPopup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/dialog/popup/DialogPopup.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$title$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/dialog/title/DialogTitle.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$trigger$2f$DialogTrigger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/dialog/trigger/DialogTrigger.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$root$2f$DialogRoot$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/dialog/root/DialogRoot.context.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const Dialog = (props)=>{
    _s();
    var _a;
    const { children, defaultOpen = false, open: openParam, onOpenChange, onOpenChangeComplete, size = "medium" } = props;
    const [open, setOpenStateInternal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useControllableState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useControllableState"])({
        defaultValue: defaultOpen,
        value: openParam
    });
    const { mounted, setMounted, transitionStatus } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useTransitionStatus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTransitionStatus"])(open);
    const popupRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [triggerElement, setTriggerElement] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [popupElement, setPopupElement] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const defaultId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])();
    const [titleId, setTitleId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])();
    const [ownNestedOpenDialogs, setOwnNestedOpenDialogs] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const nestedDialogOpened = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Dialog.useCallback[nestedDialogOpened]": (nestedCount)=>{
            setOwnNestedOpenDialogs(nestedCount + 1);
        }
    }["Dialog.useCallback[nestedDialogOpened]"], []);
    const nestedDialogClosed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Dialog.useCallback[nestedDialogClosed]": ()=>{
            setOwnNestedOpenDialogs(0);
        }
    }["Dialog.useCallback[nestedDialogClosed]"], []);
    const parentContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$root$2f$DialogRoot$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDialogContext"])(false);
    /**
     * Notify parent dialog about nested dialogs opening/closing.
     * This allows us to better hide/obscure parent dialogs when nested dialogs are opened.
     *
     * This pattern is not good for deep nesting since the context updates will cause cascading renders
     * but should work fine for 1-2 levels of nesting which is the most common use case here.
     */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Dialog.useEffect": ()=>{
            if (open && parentContext) {
                parentContext.nestedDialogOpened(ownNestedOpenDialogs);
                return ({
                    "Dialog.useEffect": ()=>parentContext.nestedDialogClosed()
                })["Dialog.useEffect"];
            }
        }
    }["Dialog.useEffect"], [
        open,
        parentContext,
        ownNestedOpenDialogs
    ]);
    /**
     * Passing the original event to onOpenChange to allow preventing the state change
     */ const setOpen = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useEventCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEventCallback"])({
        "Dialog.useEventCallback[setOpen]": (nextOpen, originalEvent)=>{
            onOpenChange === null || onOpenChange === void 0 ? void 0 : onOpenChange(nextOpen, originalEvent);
            if (originalEvent === null || originalEvent === void 0 ? void 0 : originalEvent.defaultPrevented) {
                return;
            }
            setOpenStateInternal(nextOpen);
        }
    }["Dialog.useEventCallback[setOpen]"]);
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$root$2f$DialogRoot$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogContextProvider"], {
        open: open,
        setOpen: setOpen,
        mounted: mounted,
        transitionStatus: transitionStatus,
        popupRef: popupRef,
        setPopupElement: setPopupElement,
        popupElement: popupElement,
        popupId: (_a = popupElement === null || popupElement === void 0 ? void 0 : popupElement.id) !== null && _a !== void 0 ? _a : defaultId,
        setTriggerElement: setTriggerElement,
        triggerElement: triggerElement,
        nested: !!parentContext,
        nestedDialogOpened: nestedDialogOpened,
        nestedDialogClosed: nestedDialogClosed,
        nestedOpenDialogCount: ownNestedOpenDialogs,
        size: size,
        titleId: titleId,
        setTitleId: setTitleId,
        onOpenChangeComplete: onOpenChangeComplete,
        setMounted: setMounted
    }, children);
};
_s(Dialog, "K30TUP6Zn/+2sUuWml9uRAeRp3A=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useControllableState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useControllableState"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useTransitionStatus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTransitionStatus"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$root$2f$DialogRoot$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDialogContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useEventCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEventCallback"]
    ];
});
_c = Dialog;
Dialog.Trigger = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$trigger$2f$DialogTrigger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogTrigger"];
Dialog.CloseTrigger = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$close$2d$trigger$2f$DialogCloseTrigger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogCloseTrigger"];
Dialog.Header = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$header$2f$DialogHeader$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogHeader"];
Dialog.Title = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$title$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogTitle"];
Dialog.Description = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$description$2f$DialogDescription$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogDescription"];
Dialog.Body = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$body$2f$DialogBody$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogBody"];
Dialog.Footer = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$footer$2f$DialogFooter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogFooter"];
Dialog.Popup = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$popup$2f$DialogPopup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogPopup"];
const __TURBOPACK__default__export__ = Dialog;
var _c;
__turbopack_context__.k.register(_c, "Dialog");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=DialogRoot.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/dialog/root/DialogRoot.js [app-client] (ecmascript) <export default as Dialog>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Dialog",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$root$2f$DialogRoot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$dialog$2f$root$2f$DialogRoot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/dialog/root/DialogRoot.js [app-client] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/layout/box/Box.darkside.js [app-client] (ecmascript) <export default as BoxNew>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BoxNew",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$layout$2f$box$2f$Box$2e$darkside$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$layout$2f$box$2f$Box$2e$darkside$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/layout/box/Box.darkside.js [app-client] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/layout/stack/Stack.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Stack",
    ()=>Stack,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$slot$2f$Slot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/slot/Slot.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$omit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/omit.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$layout$2f$base$2f$BasePrimitive$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/layout/base/BasePrimitive.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$layout$2f$utilities$2f$css$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/layout/utilities/css.js [app-client] (ecmascript)");
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
;
;
;
const Stack = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = (_a, ref)=>{
    var { children, className, as: Component = "div", align, justify, wrap = true, gap, style: _style, direction = "row", asChild } = _a, rest = __rest(_a, [
        "children",
        "className",
        "as",
        "align",
        "justify",
        "wrap",
        "gap",
        "style",
        "direction",
        "asChild"
    ]);
    const style = Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({}, _style), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$layout$2f$utilities$2f$css$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getResponsiveProps"])(`stack`, "gap", "space", gap)), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$layout$2f$utilities$2f$css$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getResponsiveValue"])(`stack`, "direction", direction)), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$layout$2f$utilities$2f$css$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getResponsiveValue"])(`stack`, "align", align)), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$layout$2f$utilities$2f$css$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getResponsiveValue"])(`stack`, "justify", justify));
    const Comp = asChild ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$slot$2f$Slot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Slot"] : Component;
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$layout$2f$base$2f$BasePrimitive$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], Object.assign({}, rest), /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(Comp, Object.assign({}, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$omit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["omit"])(rest, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$layout$2f$base$2f$BasePrimitive$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PRIMITIVE_PROPS"]), {
        ref: ref,
        style: style,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-stack", className, {
            "aksel-vstack": direction === "column",
            "aksel-hstack": direction === "row",
            "aksel-stack-gap": gap,
            "aksel-stack-align": align,
            "aksel-stack-justify": justify,
            "aksel-stack-direction": direction,
            "aksel-stack-wrap": wrap
        })
    }), children));
});
_c1 = Stack;
const __TURBOPACK__default__export__ = Stack;
var _c, _c1;
__turbopack_context__.k.register(_c, "Stack$forwardRef");
__turbopack_context__.k.register(_c1, "Stack");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=Stack.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/layout/stack/HStack.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HStack",
    ()=>HStack,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$layout$2f$stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/layout/stack/Stack.js [app-client] (ecmascript)");
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
const HStack = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = (_a, ref)=>{
    var { as = "div" } = _a, rest = __rest(_a, [
        "as"
    ]);
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$layout$2f$stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Stack"], Object.assign({
        as: as
    }, rest, {
        ref: ref,
        direction: "row"
    }));
});
_c1 = HStack;
const __TURBOPACK__default__export__ = HStack;
var _c, _c1;
__turbopack_context__.k.register(_c, "HStack$forwardRef");
__turbopack_context__.k.register(_c1, "HStack");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=HStack.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/layout/stack/HStack.js [app-client] (ecmascript) <export default as HStack>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HStack",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$layout$2f$stack$2f$HStack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$layout$2f$stack$2f$HStack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/layout/stack/HStack.js [app-client] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/layout/stack/VStack.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "VStack",
    ()=>VStack,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$layout$2f$stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/layout/stack/Stack.js [app-client] (ecmascript)");
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
const VStack = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = (_a, ref)=>{
    var { as = "div" } = _a, rest = __rest(_a, [
        "as"
    ]);
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$layout$2f$stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Stack"], Object.assign({
        as: as
    }, rest, {
        ref: ref,
        direction: "column",
        wrap: false
    }));
});
_c1 = VStack;
const __TURBOPACK__default__export__ = VStack;
var _c, _c1;
__turbopack_context__.k.register(_c, "VStack$forwardRef");
__turbopack_context__.k.register(_c1, "VStack");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=VStack.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/layout/stack/VStack.js [app-client] (ecmascript) <export default as VStack>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "VStack",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$layout$2f$stack$2f$VStack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$layout$2f$stack$2f$VStack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/layout/stack/VStack.js [app-client] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/layout/responsive/Responsive.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Hide",
    ()=>Hide,
    "Show",
    ()=>Show
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$slot$2f$Slot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/slot/Slot.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
const Responsive = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])((_a, ref)=>{
    var { as: Component = "div", className, above, below, variant, asChild } = _a, rest = __rest(_a, [
        "as",
        "className",
        "above",
        "below",
        "variant",
        "asChild"
    ]);
    const aboveProp = variant === "show" ? above : below;
    const belowProp = variant === "show" ? below : above;
    const Comp = asChild ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$slot$2f$Slot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Slot"] : Component;
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(Comp, Object.assign({}, rest, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-responsive", className, {
            [`aksel-responsive__above--${aboveProp}`]: aboveProp,
            [`aksel-responsive__below--${belowProp}`]: belowProp
        })
    }));
});
_c = Responsive;
const Hide = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c1 = (props, ref)=>/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(Responsive, Object.assign({}, props, {
        ref: ref,
        variant: "hide"
    })));
_c2 = Hide;
const Show = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c3 = (props, ref)=>/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(Responsive, Object.assign({}, props, {
        ref: ref,
        variant: "show"
    }))); //# sourceMappingURL=Responsive.js.map
_c4 = Show;
var _c, _c1, _c2, _c3, _c4;
__turbopack_context__.k.register(_c, "Responsive");
__turbopack_context__.k.register(_c1, "Hide$forwardRef");
__turbopack_context__.k.register(_c2, "Hide");
__turbopack_context__.k.register(_c3, "Show$forwardRef");
__turbopack_context__.k.register(_c4, "Show");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/modal/ModalBody.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
const ModalBody = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = (_a, ref)=>{
    var { className } = _a, rest = __rest(_a, [
        "className"
    ]);
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", Object.assign({}, rest, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-modal__body", className)
    }));
});
_c1 = ModalBody;
const __TURBOPACK__default__export__ = ModalBody;
var _c, _c1;
__turbopack_context__.k.register(_c, "ModalBody$forwardRef");
__turbopack_context__.k.register(_c1, "ModalBody");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=ModalBody.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/modal/ModalFooter.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
const ModalFooter = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = (_a, ref)=>{
    var { className } = _a, rest = __rest(_a, [
        "className"
    ]);
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", Object.assign({}, rest, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-modal__footer", className)
    }));
});
_c1 = ModalFooter;
const __TURBOPACK__default__export__ = ModalFooter;
var _c, _c1;
__turbopack_context__.k.register(_c, "ModalFooter$forwardRef");
__turbopack_context__.k.register(_c1, "ModalFooter");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=ModalFooter.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/modal/ModalHeader.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$XMark$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XMarkIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/XMark.js [app-client] (ecmascript) <export default as XMarkIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$i18n$2f$i18n$2e$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/i18n/i18n.hooks.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$Modal$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/modal/Modal.context.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
;
;
;
const ModalHeader = /*#__PURE__*/ _s((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = _s((_a, ref)=>{
    _s();
    var { children, className, closeButton = true } = _a, rest = __rest(_a, [
        "children",
        "className",
        "closeButton"
    ]);
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$Modal$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useModalContext"])();
    const translate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$i18n$2f$i18n$2e$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useI18n"])("global");
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", Object.assign({}, rest, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-modal__header", className)
    }), context.closeHandler && closeButton && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
        type: "button",
        className: "aksel-modal__button",
        size: "small",
        variant: "tertiary-neutral",
        onKeyDown: (event)=>{
            /* Prevents autofocus used in combination with holding down keys from closing modal */ if ([
                "Enter",
                " "
            ].includes(event.key) && event.repeat) {
                event.preventDefault();
            }
        },
        onClick: context.closeHandler,
        icon: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$XMark$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XMarkIcon$3e$__["XMarkIcon"], {
            title: translate("close")
        })
    }), children);
}, "u6UD91DHCnkV/sYxAH8TImkYbI0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$Modal$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useModalContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$i18n$2f$i18n$2e$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useI18n"]
    ];
})), "u6UD91DHCnkV/sYxAH8TImkYbI0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$Modal$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useModalContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$i18n$2f$i18n$2e$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useI18n"]
    ];
});
_c1 = ModalHeader;
const __TURBOPACK__default__export__ = ModalHeader;
var _c, _c1;
__turbopack_context__.k.register(_c, "ModalHeader$forwardRef");
__turbopack_context__.k.register(_c1, "ModalHeader");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=ModalHeader.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/modal/ModalUtils.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "coordsAreInside",
    ()=>coordsAreInside,
    "getCloseHandler",
    ()=>getCloseHandler,
    "useIsModalOpen",
    ()=>useIsModalOpen
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
const coordsAreInside = ({ clientX, clientY }, { left, top, right, bottom })=>{
    if (clientX < left || clientY < top) return false;
    if (clientX > right || clientY > bottom) return false;
    return true;
};
function getCloseHandler(modalRef, header, onBeforeClose) {
    if (header && header.closeButton === false) return undefined;
    if (onBeforeClose) {
        return ()=>{
            var _a;
            return onBeforeClose() !== false && ((_a = modalRef.current) === null || _a === void 0 ? void 0 : _a.close());
        };
    }
    return ()=>{
        var _a;
        return (_a = modalRef.current) === null || _a === void 0 ? void 0 : _a.close();
    };
}
function useIsModalOpen(modalRef) {
    _s();
    const [isOpen, setIsOpen] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useIsModalOpen.useEffect": ()=>{
            if (!modalRef) {
                return;
            }
            setIsOpen(modalRef.open);
            const observer = new MutationObserver({
                "useIsModalOpen.useEffect": ()=>{
                    setIsOpen(modalRef.open);
                }
            }["useIsModalOpen.useEffect"]);
            observer.observe(modalRef, {
                attributes: true,
                attributeFilter: [
                    "open"
                ]
            });
            return ({
                "useIsModalOpen.useEffect": ()=>{
                    observer.disconnect();
                }
            })["useIsModalOpen.useEffect"];
        }
    }["useIsModalOpen.useEffect"], [
        modalRef
    ]);
    return isOpen;
}
_s(useIsModalOpen, "vl0Rt3/A8evyRPW1OQ1AhRk4UhU=");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=ModalUtils.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/modal/dialog-polyfill.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/* eslint-disable no-var, object-shorthand */ // eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-nocheck
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "needPolyfill",
    ()=>needPolyfill
]);
const needPolyfill = ("TURBOPACK compile-time value", "object") !== "undefined" && (window.HTMLDialogElement === undefined || navigator.userAgent.includes("jsdom"));
// Copyright (c) 2013 The Chromium Authors. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met:
//
//    * Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
//    * Redistributions in binary form must reproduce the above
// copyright notice, this list of conditions and the following disclaimer
// in the documentation and/or other materials provided with the
// distribution.
//    * Neither the name of Google Inc. nor the names of its
// contributors may be used to endorse or promote products derived from
// this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
/**
 * Dispatches the passed event to both an "on<type>" handler as well as via the
 * normal dispatch operation. Does not bubble.
 *
 * @param {!EventTarget} target
 * @param {!Event} event
 * @return {boolean}
 */ function safeDispatchEvent(target, event) {
    var check = "on" + event.type.toLowerCase();
    if (typeof target[check] === "function") {
        target[check](event);
    }
    return target.dispatchEvent(event);
}
/**
 * Finds the nearest <dialog> from the passed element.
 *
 * @param {Element} el to search from
 * @return {HTMLDialogElement} dialog found
 */ function findNearestDialog(el) {
    while(el){
        if (el.localName === "dialog") {
            return /** @type {HTMLDialogElement} */ el;
        }
        if (el.parentElement) {
            el = el.parentElement;
        } else if (el.parentNode) {
            el = el.parentNode.host;
        } else {
            el = null;
        }
    }
    return null;
}
/**
 * Blur the specified element, as long as it's not the HTML body element.
 * This works around an IE9/10 bug - blurring the body causes Windows to
 * blur the whole application.
 *
 * @param {Element} el to blur
 */ function safeBlur(el) {
    // Find the actual focused element when the active element is inside a shadow root
    while(el && el.shadowRoot && el.shadowRoot.activeElement){
        el = el.shadowRoot.activeElement;
    }
    if (el && el.blur && el !== document.body) {
        el.blur();
    }
}
/**
 * @param {!NodeList} nodeList to search
 * @param {Node} node to find
 * @return {boolean} whether node is inside nodeList
 */ function inNodeList(nodeList, node) {
    for(var i = 0; i < nodeList.length; ++i){
        if (nodeList[i] === node) {
            return true;
        }
    }
    return false;
}
/**
 * @param {HTMLFormElement} el to check
 * @return {boolean} whether this form has method="dialog"
 */ function isFormMethodDialog(el) {
    if (!el || !el.hasAttribute("method")) {
        return false;
    }
    return el.getAttribute("method").toLowerCase() === "dialog";
}
/**
 * @param {!DocumentFragment|!Element} hostElement
 * @return {?Element}
 */ function findFocusableElementWithin(hostElement) {
    // Note that this is 'any focusable area'. This list is probably not exhaustive, but the
    // alternative involves stepping through and trying to focus everything.
    var opts = [
        "button",
        "input",
        "keygen",
        "select",
        "textarea"
    ];
    var query = opts.map(function(el) {
        return el + ":not([disabled])";
    });
    // TODO(samthor): tabindex values that are not numeric are not focusable.
    query.push('[tabindex]:not([disabled]):not([tabindex=""])'); // tabindex != "", not disabled
    var target = hostElement.querySelector(query.join(", "));
    if (!target && "attachShadow" in Element.prototype) {
        // If we haven't found a focusable target, see if the host element contains an element
        // which has a shadowRoot.
        // Recursively search for the first focusable item in shadow roots.
        var elems = hostElement.querySelectorAll("*");
        for(var i = 0; i < elems.length; i++){
            if (elems[i].tagName && elems[i].shadowRoot) {
                target = findFocusableElementWithin(elems[i].shadowRoot);
                if (target) {
                    break;
                }
            }
        }
    }
    return target;
}
/**
 * Determines if an element is attached to the DOM.
 * @param {Element} element to check
 * @return {boolean} whether the element is in DOM
 */ function isConnected(element) {
    return element.isConnected || document.body.contains(element);
}
/**
 * @param {!Event} event
 * @return {?Element}
 */ function findFormSubmitter(event) {
    if (event.submitter) {
        return event.submitter;
    }
    var form = event.target;
    if (!(form instanceof HTMLFormElement)) {
        return null;
    }
    var submitter = dialogPolyfill.formSubmitter;
    if (!submitter) {
        var target = event.target;
        var root = "getRootNode" in target && target.getRootNode() || document;
        submitter = root.activeElement;
    }
    if (!submitter || submitter.form !== form) {
        return null;
    }
    return submitter;
}
/**
 * @param {!Event} event
 */ function maybeHandleSubmit(event) {
    if (event.defaultPrevented) {
        return;
    }
    var form = /** @type {!HTMLFormElement} */ event.target;
    // We'd have a value if we clicked on an imagemap.
    var value = dialogPolyfill.imagemapUseValue;
    var submitter = findFormSubmitter(event);
    if (value === null && submitter) {
        value = submitter.value;
    }
    // There should always be a dialog as this handler is added specifically on them, but check just
    // in case.
    var dialog = findNearestDialog(form);
    if (!dialog) {
        return;
    }
    // Prefer formmethod on the button.
    var formmethod = submitter && submitter.getAttribute("formmethod") || form.getAttribute("method");
    if (formmethod !== "dialog") {
        return;
    }
    event.preventDefault();
    if (value != null) {
        // nb. we explicitly check against null/undefined
        dialog.close(value);
    } else {
        dialog.close();
    }
}
/**
 * @param {!HTMLDialogElement} dialog to upgrade
 * @constructor
 */ function dialogPolyfillInfo(dialog) {
    this.dialog_ = dialog;
    this.replacedStyleTop_ = false;
    this.openAsModal_ = false;
    // Set a11y role. Browsers that support dialog implicitly know this already.
    if (!dialog.hasAttribute("role")) {
        dialog.setAttribute("role", "dialog");
    }
    dialog.show = this.show.bind(this);
    dialog.showModal = this.showModal.bind(this);
    dialog.close = this.close.bind(this);
    dialog.addEventListener("submit", maybeHandleSubmit, false);
    if (!("returnValue" in dialog)) {
        dialog.returnValue = "";
    }
    if ("MutationObserver" in window) {
        var mo = new MutationObserver(this.maybeHideModal.bind(this));
        mo.observe(dialog, {
            attributes: true,
            attributeFilter: [
                "open"
            ]
        });
    } else {
        // IE10 and below support. Note that DOMNodeRemoved etc fire _before_ removal. They also
        // seem to fire even if the element was removed as part of a parent removal. Use the removed
        // events to force downgrade (useful if removed/immediately added).
        var removed = false;
        var cb = (function() {
            removed ? this.downgradeModal() : this.maybeHideModal();
            removed = false;
        }).bind(this);
        var timeout;
        var delayModel = function(ev) {
            if (ev.target !== dialog) {
                return;
            } // not for a child element
            var cand = "DOMNodeRemoved";
            removed |= ev.type.substr(0, cand.length) === cand;
            window.clearTimeout(timeout);
            timeout = window.setTimeout(cb, 0);
        };
        [
            "DOMAttrModified",
            "DOMNodeRemoved",
            "DOMNodeRemovedFromDocument"
        ].forEach(function(name) {
            dialog.addEventListener(name, delayModel);
        });
    }
    // Note that the DOM is observed inside DialogManager while any dialog
    // is being displayed as a modal, to catch modal removal from the DOM.
    Object.defineProperty(dialog, "open", {
        set: this.setOpen.bind(this),
        get: dialog.hasAttribute.bind(dialog, "open")
    });
    this.backdrop_ = document.createElement("div");
    this.backdrop_.className = "backdrop";
    this.backdrop_.addEventListener("mouseup", this.backdropMouseEvent_.bind(this));
    this.backdrop_.addEventListener("mousedown", this.backdropMouseEvent_.bind(this));
    this.backdrop_.addEventListener("click", this.backdropMouseEvent_.bind(this));
}
dialogPolyfillInfo.prototype = /** @type {HTMLDialogElement.prototype} */ {
    get dialog () {
        return this.dialog_;
    },
    /**
     * Maybe remove this dialog from the modal top layer. This is called when
     * a modal dialog may no longer be tenable, e.g., when the dialog is no
     * longer open or is no longer part of the DOM.
     */ maybeHideModal: function() {
        if (this.dialog_.hasAttribute("open") && isConnected(this.dialog_)) {
            return;
        }
        this.downgradeModal();
    },
    /**
     * Remove this dialog from the modal top layer, leaving it as a non-modal.
     */ downgradeModal: function() {
        if (!this.openAsModal_) {
            return;
        }
        this.openAsModal_ = false;
        this.dialog_.style.zIndex = "";
        // This won't match the native <dialog> exactly because if the user set top on a centered
        // polyfill dialog, that top gets thrown away when the dialog is closed. Not sure it's
        // possible to polyfill this perfectly.
        if (this.replacedStyleTop_) {
            this.dialog_.style.top = "";
            this.replacedStyleTop_ = false;
        }
        // Clear the backdrop and remove from the manager.
        this.backdrop_.parentNode && this.backdrop_.parentNode.removeChild(this.backdrop_);
        dialogPolyfill.dm.removeDialog(this);
    },
    /**
     * @param {boolean} value whether to open or close this dialog
     */ setOpen: function(value) {
        if (value) {
            this.dialog_.hasAttribute("open") || this.dialog_.setAttribute("open", "");
        } else {
            this.dialog_.removeAttribute("open");
            this.maybeHideModal(); // nb. redundant with MutationObserver
        }
    },
    /**
     * Handles mouse events ('mouseup', 'mousedown', 'click') on the fake .backdrop element, redirecting them as if
     * they were on the dialog itself.
     *
     * @param {!Event} e to redirect
     */ backdropMouseEvent_: function(e) {
        if (!this.dialog_.hasAttribute("tabindex")) {
            // Clicking on the backdrop should move the implicit cursor, even if dialog cannot be
            // focused. Create a fake thing to focus on. If the backdrop was _before_ the dialog, this
            // would not be needed - clicks would move the implicit cursor there.
            var fake = document.createElement("div");
            this.dialog_.insertBefore(fake, this.dialog_.firstChild);
            fake.tabIndex = -1;
            fake.focus();
            this.dialog_.removeChild(fake);
        } else {
            this.dialog_.focus();
        }
        var redirectedEvent = document.createEvent("MouseEvents");
        redirectedEvent.initMouseEvent(e.type, e.bubbles, e.cancelable, window, e.detail, e.screenX, e.screenY, e.clientX, e.clientY, e.ctrlKey, e.altKey, e.shiftKey, e.metaKey, e.button, e.relatedTarget);
        this.dialog_.dispatchEvent(redirectedEvent);
        e.stopPropagation();
    },
    /**
     * Focuses on the first focusable element within the dialog. This will always blur the current
     * focus, even if nothing within the dialog is found.
     */ focus_: function() {
        // Find element with `autofocus` attribute, or fall back to the first form/tabindex control.
        var target = this.dialog_.querySelector("[autofocus]:not([disabled])");
        if (!target && this.dialog_.tabIndex >= 0) {
            target = this.dialog_;
        }
        if (!target) {
            target = findFocusableElementWithin(this.dialog_);
        }
        safeBlur(document.activeElement);
        target && target.focus();
    },
    /**
     * Sets the zIndex for the backdrop and dialog.
     *
     * @param {number} dialogZ
     * @param {number} backdropZ
     */ updateZIndex: function(dialogZ, backdropZ) {
        if (dialogZ < backdropZ) {
            throw new Error("dialogZ should never be < backdropZ");
        }
        this.dialog_.style.zIndex = dialogZ;
        this.backdrop_.style.zIndex = backdropZ;
    },
    /**
     * Shows the dialog. If the dialog is already open, this does nothing.
     */ show: function() {
        if (!this.dialog_.open) {
            this.setOpen(true);
            this.focus_();
        }
    },
    /**
     * Show this dialog modally.
     */ showModal: function() {
        if (this.dialog_.hasAttribute("open")) {
            throw new Error("Failed to execute 'showModal' on dialog: The element is already open, and therefore cannot be opened modally.");
        }
        if (!isConnected(this.dialog_)) {
            throw new Error("Failed to execute 'showModal' on dialog: The element is not in a Document.");
        }
        if (!dialogPolyfill.dm.pushDialog(this)) {
            throw new Error("Failed to execute 'showModal' on dialog: There are too many open modal dialogs.");
        }
        this.setOpen(true);
        this.openAsModal_ = true;
        // Optionally center vertically, relative to the current viewport.
        if (dialogPolyfill.needsCentering(this.dialog_)) {
            dialogPolyfill.reposition(this.dialog_);
            this.replacedStyleTop_ = true;
        } else {
            this.replacedStyleTop_ = false;
        }
        // Insert backdrop.
        this.dialog_.parentNode.insertBefore(this.backdrop_, this.dialog_.nextSibling);
        // Focus on whatever inside the dialog.
        this.focus_();
    },
    /**
     * Closes this HTMLDialogElement. This is optional vs clearing the open
     * attribute, however this fires a 'close' event.
     *
     * @param {string=} opt_returnValue to use as the returnValue
     */ close: function(opt_returnValue) {
        if (!this.dialog_.hasAttribute("open")) {
            throw new Error("Failed to execute 'close' on dialog: The element does not have an 'open' attribute, and therefore cannot be closed.");
        }
        this.setOpen(false);
        // Leave returnValue untouched in case it was set directly on the element
        if (opt_returnValue !== undefined) {
            this.dialog_.returnValue = opt_returnValue;
        }
        // Triggering "close" event for any attached listeners on the <dialog>.
        var closeEvent = new window.CustomEvent("close", {
            bubbles: false,
            cancelable: false
        });
        safeDispatchEvent(this.dialog_, closeEvent);
    }
};
var dialogPolyfill = {};
dialogPolyfill.reposition = function(element) {
    var scrollTop = document.body.scrollTop || document.documentElement.scrollTop;
    var topValue = scrollTop + (window.innerHeight - element.offsetHeight) / 2;
    element.style.top = Math.max(scrollTop, topValue) + "px";
};
dialogPolyfill.isInlinePositionSetByStylesheet = function(element) {
    for(var i = 0; i < document.styleSheets.length; ++i){
        var styleSheet = document.styleSheets[i];
        var cssRules = null;
        // Some browsers throw on cssRules.
        try {
            cssRules = styleSheet.cssRules;
        } catch (_a) {
        /* empty */ }
        if (!cssRules) {
            continue;
        }
        for(var j = 0; j < cssRules.length; ++j){
            var rule = cssRules[j];
            var selectedNodes = null;
            // Ignore errors on invalid selector texts.
            try {
                selectedNodes = document.querySelectorAll(rule.selectorText);
            } catch (_b) {
            /* empty */ }
            if (!selectedNodes || !inNodeList(selectedNodes, element)) {
                continue;
            }
            var cssTop = rule.style.getPropertyValue("top");
            var cssBottom = rule.style.getPropertyValue("bottom");
            if (cssTop && cssTop !== "auto" || cssBottom && cssBottom !== "auto") {
                return true;
            }
        }
    }
    return false;
};
dialogPolyfill.needsCentering = function(dialog) {
    var computedStyle = window.getComputedStyle(dialog);
    if (computedStyle.position !== "absolute") {
        return false;
    }
    // We must determine whether the top/bottom specified value is non-auto.  In
    // WebKit/Blink, checking computedStyle.top == 'auto' is sufficient, but
    // Firefox returns the used value. So we do this crazy thing instead: check
    // the inline style and then go through CSS rules.
    if (dialog.style.top !== "auto" && dialog.style.top !== "" || dialog.style.bottom !== "auto" && dialog.style.bottom !== "") {
        return false;
    }
    return !dialogPolyfill.isInlinePositionSetByStylesheet(dialog);
};
/**
 * @param {!Element} element to force upgrade
 */ dialogPolyfill.forceRegisterDialog = function(element) {
    if (element.showModal) {
        console.warn("This browser already supports <dialog>, the polyfill " + "may not work correctly", element);
    }
    if (element.localName !== "dialog") {
        throw new Error("Failed to register dialog: The element is not a dialog.");
    }
    new dialogPolyfillInfo(/** @type {!HTMLDialogElement} */ element);
};
/**
 * @param {!Element} element to upgrade, if necessary
 */ dialogPolyfill.registerDialog = function(element) {
    if (!element.showModal) {
        dialogPolyfill.forceRegisterDialog(element);
    }
};
/**
 * @constructor
 */ dialogPolyfill.DialogManager = function() {
    /** @type {!dialogPolyfillInfo[]} */ this.pendingDialogStack = [];
    var checkDOM = this.checkDOM_.bind(this);
    // The overlay is used to simulate how a modal dialog blocks the document.
    // The blocking dialog is positioned on top of the overlay, and the rest of
    // the dialogs on the pending dialog stack are positioned below it. In the
    // actual implementation, the modal dialog stacking is controlled by the
    // top layer, where z-index has no effect.
    this.overlay = document.createElement("div");
    this.overlay.className = "_dialog_overlay";
    this.overlay.addEventListener("click", (function(e) {
        this.forwardTab_ = undefined;
        e.stopPropagation();
        checkDOM([]); // sanity-check DOM
    }).bind(this));
    this.handleKey_ = this.handleKey_.bind(this);
    this.handleFocus_ = this.handleFocus_.bind(this);
    this.zIndexLow_ = 100000;
    this.zIndexHigh_ = 100000 + 150;
    this.forwardTab_ = undefined;
    if ("MutationObserver" in window) {
        this.mo_ = new MutationObserver(function(records) {
            var removed = [];
            records.forEach(function(rec) {
                for(var i = 0, c; c = rec.removedNodes[i]; ++i){
                    if (!(c instanceof Element)) {
                        continue;
                    }
                    if (c.localName === "dialog") {
                        removed.push(c);
                    }
                    removed = removed.concat(c.querySelectorAll("dialog"));
                }
            });
            removed.length && checkDOM(removed);
        });
    }
};
/**
 * Called on the first modal dialog being shown. Adds the overlay and related
 * handlers.
 */ dialogPolyfill.DialogManager.prototype.blockDocument = function() {
    document.documentElement.addEventListener("focus", this.handleFocus_, true);
    document.addEventListener("keydown", this.handleKey_);
    this.mo_ && this.mo_.observe(document, {
        childList: true,
        subtree: true
    });
};
/**
 * Called on the first modal dialog being removed, i.e., when no more modal
 * dialogs are visible.
 */ dialogPolyfill.DialogManager.prototype.unblockDocument = function() {
    document.documentElement.removeEventListener("focus", this.handleFocus_, true);
    document.removeEventListener("keydown", this.handleKey_);
    this.mo_ && this.mo_.disconnect();
};
/**
 * Updates the stacking of all known dialogs.
 */ dialogPolyfill.DialogManager.prototype.updateStacking = function() {
    var zIndex = this.zIndexHigh_;
    for(var i = 0, dpi; dpi = this.pendingDialogStack[i]; ++i){
        dpi.updateZIndex(--zIndex, --zIndex);
        if (i === 0) {
            this.overlay.style.zIndex = --zIndex;
        }
    }
    // Make the overlay a sibling of the dialog itself.
    var last = this.pendingDialogStack[0];
    if (last) {
        var p = last.dialog.parentNode || document.body;
        p.appendChild(this.overlay);
    } else if (this.overlay.parentNode) {
        this.overlay.parentNode.removeChild(this.overlay);
    }
};
/**
 * @param {Element} candidate to check if contained or is the top-most modal dialog
 * @return {boolean} whether candidate is contained in top dialog
 */ dialogPolyfill.DialogManager.prototype.containedByTopDialog_ = function(candidate) {
    while(candidate = findNearestDialog(candidate)){
        for(var i = 0, dpi; dpi = this.pendingDialogStack[i]; ++i){
            if (dpi.dialog === candidate) {
                return i === 0; // only valid if top-most
            }
        }
        candidate = candidate.parentElement;
    }
    return false;
};
dialogPolyfill.DialogManager.prototype.handleFocus_ = function(event) {
    var target = event.composedPath ? event.composedPath()[0] : event.target;
    if (this.containedByTopDialog_(target)) {
        return;
    }
    if (document.activeElement === document.documentElement) {
        return;
    }
    event.preventDefault();
    event.stopPropagation();
    safeBlur(/** @type {Element} */ target);
    if (this.forwardTab_ === undefined) {
        return;
    } // move focus only from a tab key
    var dpi = this.pendingDialogStack[0];
    var dialog = dpi.dialog;
    var position = dialog.compareDocumentPosition(target);
    if (position & Node.DOCUMENT_POSITION_PRECEDING) {
        if (this.forwardTab_) {
            // forward
            dpi.focus_();
        } else if (target !== document.documentElement) {
            // backwards if we're not already focused on <html>
            document.documentElement.focus();
        }
    } else {
    // TODO: Focus after the dialog, is ignored.
    }
    return false;
};
dialogPolyfill.DialogManager.prototype.handleKey_ = function(event) {
    this.forwardTab_ = undefined;
    if (event.keyCode === 27) {
        event.preventDefault();
        event.stopPropagation();
        var cancelEvent = new window.CustomEvent("cancel", {
            bubbles: false,
            cancelable: true
        });
        var dpi = this.pendingDialogStack[0];
        if (dpi && safeDispatchEvent(dpi.dialog, cancelEvent)) {
            dpi.dialog.close();
        }
    } else if (event.keyCode === 9) {
        this.forwardTab_ = !event.shiftKey;
    }
};
/**
 * Finds and downgrades any known modal dialogs that are no longer displayed. Dialogs that are
 * removed and immediately readded don't stay modal, they become normal.
 *
 * @param {!HTMLDialogElement[]} removed that have definitely been removed
 */ dialogPolyfill.DialogManager.prototype.checkDOM_ = function(removed) {
    // This operates on a clone because it may cause it to change. Each change also calls
    // updateStacking, which only actually needs to happen once. But who removes many modal dialogs
    // at a time?!
    var clone = this.pendingDialogStack.slice();
    clone.forEach(function(dpi) {
        if (removed.indexOf(dpi.dialog) !== -1) {
            dpi.downgradeModal();
        } else {
            dpi.maybeHideModal();
        }
    });
};
/**
 * @param {!dialogPolyfillInfo} dpi
 * @return {boolean} whether the dialog was allowed
 */ dialogPolyfill.DialogManager.prototype.pushDialog = function(dpi) {
    var allowed = (this.zIndexHigh_ - this.zIndexLow_) / 2 - 1;
    if (this.pendingDialogStack.length >= allowed) {
        return false;
    }
    if (this.pendingDialogStack.unshift(dpi) === 1) {
        this.blockDocument();
    }
    this.updateStacking();
    return true;
};
/**
 * @param {!dialogPolyfillInfo} dpi
 */ dialogPolyfill.DialogManager.prototype.removeDialog = function(dpi) {
    var index = this.pendingDialogStack.indexOf(dpi);
    if (index === -1) {
        return;
    }
    this.pendingDialogStack.splice(index, 1);
    if (this.pendingDialogStack.length === 0) {
        this.unblockDocument();
    }
    this.updateStacking();
};
if (needPolyfill) {
    dialogPolyfill.dm = new dialogPolyfill.DialogManager();
    dialogPolyfill.formSubmitter = null;
    dialogPolyfill.imagemapUseValue = null;
}
/**
 * Installs global handlers, such as click listers and native method overrides. These are needed
 * even if a no dialog is registered, as they deal with <form method="dialog">.
 */ if (needPolyfill) {
    /**
     * If HTMLFormElement translates method="DIALOG" into 'get', then replace the descriptor with
     * one that returns the correct value.
     */ var testForm = document.createElement("form");
    testForm.setAttribute("method", "dialog");
    if (testForm.method !== "dialog") {
        var methodDescriptor = Object.getOwnPropertyDescriptor(HTMLFormElement.prototype, "method");
        if (methodDescriptor) {
            // nb. Some older iOS and older PhantomJS fail to return the descriptor. Don't do anything
            // and don't bother to update the element.
            var realGet = methodDescriptor.get;
            methodDescriptor.get = function() {
                if (isFormMethodDialog(this)) {
                    return "dialog";
                }
                return realGet.call(this);
            };
            var realSet = methodDescriptor.set;
            /** @this {HTMLElement} */ methodDescriptor.set = function(v) {
                if (typeof v === "string" && v.toLowerCase() === "dialog") {
                    return this.setAttribute("method", v);
                }
                return realSet.call(this, v);
            };
            Object.defineProperty(HTMLFormElement.prototype, "method", methodDescriptor);
        }
    }
    /**
     * Global 'click' handler, to capture the <input type="submit"> or <button> element which has
     * submitted a <form method="dialog">. Needed as Safari and others don't report this inside
     * document.activeElement.
     */ document.addEventListener("click", function(ev) {
        dialogPolyfill.formSubmitter = null;
        dialogPolyfill.imagemapUseValue = null;
        if (ev.defaultPrevented) {
            return;
        } // e.g. a submit which prevents default submission
        var target = /** @type {Element} */ ev.target;
        if ("composedPath" in ev) {
            var path = ev.composedPath();
            target = path.shift() || target;
        }
        if (!target || !isFormMethodDialog(target.form)) {
            return;
        }
        var valid = target.type === "submit" && [
            "button",
            "input"
        ].indexOf(target.localName) > -1;
        if (!valid) {
            if (!(target.localName === "input" && target.type === "image")) {
                return;
            }
            // this is a <input type="image">, which can submit forms
            dialogPolyfill.imagemapUseValue = ev.offsetX + "," + ev.offsetY;
        }
        var dialog = findNearestDialog(target);
        if (!dialog) {
            return;
        }
        dialogPolyfill.formSubmitter = target;
    }, false);
    /**
     * Global 'submit' handler. This handles submits of `method="dialog"` which are invalid, i.e.,
     * outside a dialog. They get prevented.
     */ document.addEventListener("submit", function(ev) {
        var form = ev.target;
        var dialog = findNearestDialog(form);
        if (dialog) {
            return; // ignore, handle there
        }
        var submitter = findFormSubmitter(ev);
        var formmethod = submitter && submitter.getAttribute("formmethod") || form.getAttribute("method");
        if (formmethod === "dialog") {
            ev.preventDefault();
        }
    });
    /**
     * Replace the native HTMLFormElement.submit() method, as it won't fire the
     * submit event and give us a chance to respond.
     */ var nativeFormSubmit = HTMLFormElement.prototype.submit;
    var replacementFormSubmit = function() {
        if (!isFormMethodDialog(this)) {
            return nativeFormSubmit.call(this);
        }
        var dialog = findNearestDialog(this);
        dialog && dialog.close();
    };
    HTMLFormElement.prototype.submit = replacementFormSubmit;
}
const __TURBOPACK__default__export__ = dialogPolyfill;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=dialog-polyfill.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/modal/Modal.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Modal",
    ()=>Modal,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$react$40$0$2e$27$2e$8_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@floating-ui+react@0.27.8_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@floating-ui/react/dist/floating-ui.react.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react-dom/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$date$2f$Date$2e$Input$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/date/Date.Input.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$provider$2f$Provider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/provider/Provider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$Detail$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Detail$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/Detail.js [app-client] (ecmascript) <export default as Detail>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$Heading$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Heading$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/Heading.js [app-client] (ecmascript) <export default as Heading>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$composeEventHandlers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/composeEventHandlers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/useId.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useMergeRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/useMergeRefs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useScrollLock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/useScrollLock.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$Modal$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/modal/Modal.context.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$ModalBody$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/modal/ModalBody.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$ModalFooter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/modal/ModalFooter.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$ModalHeader$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/modal/ModalHeader.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$ModalUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/modal/ModalUtils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$dialog$2d$polyfill$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/modal/dialog-polyfill.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const polyfillClassName = "aksel-modal--polyfilled";
const Modal = /*#__PURE__*/ _s((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = _s((_a, ref)=>{
    _s();
    var _b, _c;
    var { header, children, open, onBeforeClose, onCancel, closeOnBackdropClick, width, placement, portal, className, "aria-labelledby": ariaLabelledby, style, onClick, onMouseDown } = _a, rest = __rest(_a, [
        "header",
        "children",
        "open",
        "onBeforeClose",
        "onCancel",
        "closeOnBackdropClick",
        "width",
        "placement",
        "portal",
        "className",
        "aria-labelledby",
        "style",
        "onClick",
        "onMouseDown"
    ]);
    const modalRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const mergedRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useMergeRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMergeRefs"])(modalRef, ref);
    const ariaLabelId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])();
    const rootElement = (_b = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$provider$2f$Provider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProvider"])()) === null || _b === void 0 ? void 0 : _b.rootElement;
    const portalNode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$react$40$0$2e$27$2e$8_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useFloatingPortalNode"])({
        root: rootElement
    });
    const dateContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$date$2f$Date$2e$Input$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDateInputContext"])(false);
    const isNested = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$Modal$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useModalContext"])(false) !== undefined;
    const isModalOpen = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$ModalUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsModalOpen"])(modalRef.current);
    if (isNested && !dateContext) {
        console.error("Modals should not be nested");
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Modal.useEffect": ()=>{
            // If using portal, modalRef.current will not be set before portalNode is set.
            // If not using portal, modalRef.current is available first.
            // We check both to avoid activating polyfill twice when not using portal.
            if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$dialog$2d$polyfill$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["needPolyfill"] && modalRef.current && portalNode) {
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$dialog$2d$polyfill$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].registerDialog(modalRef.current);
                // Force-add the "polyfilled" class in case of SSR (needPolyfill will always be false on the server)
                modalRef.current.classList.add(polyfillClassName);
            }
            // We set autofocus on the dialog element to prevent the default behavior where first focusable element gets focus when modal is opened.
            // This is mainly to fix an edge case where having a Tooltip as the first focusable element would make it activate when you open the modal.
            // We have to use JS because it doesn't work to set it with a prop (React bug?)
            // Currently doesn't seem to work in Chrome. See also Tooltip.tsx
            if (modalRef.current && portalNode) modalRef.current.autofocus = true;
        }
    }["Modal.useEffect"], [
        portalNode
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Modal.useEffect": ()=>{
            // We need to have this in a useEffect so that the content renders before the modal is displayed,
            // and in case `open` is true initially.
            // We need to check both modalRef.current and portalNode to make sure the polyfill has been activated.
            if (modalRef.current && portalNode && open !== undefined) {
                if (open && !modalRef.current.open) {
                    modalRef.current.showModal();
                } else if (!open && modalRef.current.open) {
                    modalRef.current.close();
                }
            }
        }
    }["Modal.useEffect"], [
        portalNode,
        open
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useScrollLock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useScrollLock"])({
        enabled: isModalOpen,
        mounted: isModalOpen,
        open: isModalOpen,
        referenceElement: modalRef.current
    });
    const isWidthPreset = typeof width === "string" && [
        "small",
        "medium"
    ].includes(width);
    const mergedClassName = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-modal", className, {
        [polyfillClassName]: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$dialog$2d$polyfill$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["needPolyfill"],
        "aksel-modal--autowidth": !width,
        [`aksel-modal--${width}`]: isWidthPreset,
        "aksel-modal--top": placement === "top" && !__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$dialog$2d$polyfill$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["needPolyfill"]
    });
    const mergedStyle = Object.assign(Object.assign({}, style), !isWidthPreset ? {
        width
    } : {});
    const mouseClickStart = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])({
        clientX: 0,
        clientY: 0
    });
    const handleModalMouseDown = (event)=>{
        mouseClickStart.current = event;
    };
    const shouldHandleModalClick = closeOnBackdropClick && !__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$dialog$2d$polyfill$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["needPolyfill"];
    /**
     * `closeOnBackdropClick` has issues on polyfill when nesting modals (DatePicker)
     */ const handleModalClick = (endEvent)=>{
        if (endEvent.target !== modalRef.current) {
            return;
        }
        const modalRect = modalRef.current.getBoundingClientRect();
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$ModalUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["coordsAreInside"])(mouseClickStart.current, modalRect) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$ModalUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["coordsAreInside"])(endEvent, modalRect)) {
            return;
        }
        if (onBeforeClose !== undefined && onBeforeClose() === false) {
            return;
        }
        modalRef.current.close();
    };
    /**
     * onCancel fires when you press `Esc`
     */ const handleModalCancel = (event)=>{
        onBeforeClose && onBeforeClose() === false && event.preventDefault();
    };
    const mergedAriaLabelledBy = !ariaLabelledby && !rest["aria-label"] && header ? ariaLabelId : ariaLabelledby;
    const component = // eslint-disable-next-line jsx-a11y/no-noninteractive-element-interactions
    /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("dialog", Object.assign({}, rest, {
        ref: mergedRef,
        className: mergedClassName,
        style: mergedStyle,
        onCancel: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$composeEventHandlers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["composeEventHandlers"])(onCancel, handleModalCancel),
        onClick: shouldHandleModalClick ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$composeEventHandlers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["composeEventHandlers"])(onClick, handleModalClick) : onClick,
        onMouseDown: shouldHandleModalClick ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$composeEventHandlers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["composeEventHandlers"])(onMouseDown, handleModalMouseDown) : onMouseDown,
        "aria-labelledby": mergedAriaLabelledBy,
        onKeyDown: (e)=>{
            /**
             * Stops propagation of Escape key to prevent closing parent modals/dialogs
             */ if (e.key === "Escape") {
                e.stopPropagation();
            }
        }
    }), /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$Modal$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ModalContextProvider"], {
        closeHandler: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$ModalUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCloseHandler"])(modalRef, header, onBeforeClose),
        modalRef: modalRef
    }, header && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$ModalHeader$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], null, header.label && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$Detail$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Detail$3e$__["Detail"], {
        className: "aksel-modal__label"
    }, header.label), /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$Heading$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Heading$3e$__["Heading"], {
        size: (_c = header.size) !== null && _c !== void 0 ? _c : "medium",
        level: "1",
        id: ariaLabelId
    }, header.icon && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("span", {
        className: "aksel-modal__header-icon"
    }, header.icon), header.heading)), children));
    if (portal) {
        if (portalNode) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPortal"])(component, portalNode);
        return null;
    }
    return component;
}, "OBnb4kNaIiWES+uFUeYB6MAIfyw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useMergeRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMergeRefs"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$provider$2f$Provider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProvider"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$react$40$0$2e$27$2e$8_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useFloatingPortalNode"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$date$2f$Date$2e$Input$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDateInputContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$Modal$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useModalContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$ModalUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsModalOpen"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useScrollLock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useScrollLock"]
    ];
})), "OBnb4kNaIiWES+uFUeYB6MAIfyw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useMergeRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMergeRefs"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$provider$2f$Provider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProvider"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$react$40$0$2e$27$2e$8_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useFloatingPortalNode"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$date$2f$Date$2e$Input$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDateInputContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$Modal$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useModalContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$ModalUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsModalOpen"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useScrollLock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useScrollLock"]
    ];
});
_c1 = Modal;
Modal.Header = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$ModalHeader$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
Modal.Body = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$ModalBody$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
Modal.Footer = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$ModalFooter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
const __TURBOPACK__default__export__ = Modal;
var _c, _c1;
__turbopack_context__.k.register(_c, "Modal$forwardRef");
__turbopack_context__.k.register(_c1, "Modal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=Modal.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/modal/Modal.js [app-client] (ecmascript) <export default as Modal>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Modal",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$modal$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/modal/Modal.js [app-client] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/link-card/LinkCard.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LinkCard",
    ()=>LinkCard,
    "LinkCardAnchor",
    ()=>LinkCardAnchor,
    "LinkCardDescription",
    ()=>LinkCardDescription,
    "LinkCardFooter",
    ()=>LinkCardFooter,
    "LinkCardIcon",
    ()=>LinkCardIcon,
    "LinkCardImage",
    ()=>LinkCardImage,
    "LinkCardTitle",
    ()=>LinkCardTitle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyLong$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyLong$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/BodyLong.js [app-client] (ecmascript) <export default as BodyLong>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$Heading$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Heading$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/Heading.js [app-client] (ecmascript) <export default as Heading>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$create$2d$strict$2d$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/create-strict-context.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$link$2d$anchor$2f$LinkAnchor$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/link-anchor/LinkAnchor.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
;
;
const { Provider: LinkCardContextProvider, useContext: useLinkCardContext } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$create$2d$strict$2d$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createStrictContext"])({
    name: "LinkCardContextProvider"
});
const LinkCard = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = (_a, forwardedRef)=>{
    var { children, className, arrow = true, arrowPosition = "baseline", size = "medium" } = _a, restProps = __rest(_a, [
        "children",
        "className",
        "arrow",
        "arrowPosition",
        "size"
    ]);
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(LinkCardContextProvider, {
        size: size
    }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$link$2d$anchor$2f$LinkAnchor$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LinkAnchorOverlay"], {
        asChild: true
    }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyLong$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyLong$3e$__["BodyLong"], Object.assign({
        as: "div",
        size: size,
        ref: forwardedRef,
        "data-color": "neutral",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-link-card", className, `aksel-link-card--${size}`),
        "data-align-arrow": arrowPosition
    }, restProps), children, arrow && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$link$2d$anchor$2f$LinkAnchor$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LinkAnchorArrow"], {
        fontSize: size === "medium" ? "1.75rem" : "1.5rem",
        className: "aksel-link-card__arrow"
    }))));
});
_c1 = LinkCard;
const LinkCardTitle = /*#__PURE__*/ _s((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c2 = _s((_a, forwardedRef)=>{
    _s();
    var { children, as = "span", className } = _a, restProps = __rest(_a, [
        "children",
        "as",
        "className"
    ]);
    const context = useLinkCardContext();
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$Heading$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Heading$3e$__["Heading"], Object.assign({
        ref: forwardedRef,
        as: as,
        size: context.size === "medium" ? "small" : "xsmall",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-link-card__title", className)
    }, restProps), children);
}, "hbqdcASJziozUduQwKbnmUd8qvA=", false, function() {
    return [
        useLinkCardContext
    ];
})), "hbqdcASJziozUduQwKbnmUd8qvA=", false, function() {
    return [
        useLinkCardContext
    ];
});
_c3 = LinkCardTitle;
const LinkCardAnchor = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$link$2d$anchor$2f$LinkAnchor$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LinkAnchor"];
const LinkCardDescription = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c4 = (_a, forwardedRef)=>{
    var { children, className } = _a, restProps = __rest(_a, [
        "children",
        "className"
    ]);
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", Object.assign({
        ref: forwardedRef,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-link-card__description", className)
    }, restProps), children);
});
_c5 = LinkCardDescription;
const LinkCardFooter = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c6 = (_a, forwardedRef)=>{
    var { children, className } = _a, restProps = __rest(_a, [
        "children",
        "className"
    ]);
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", Object.assign({
        ref: forwardedRef,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-link-card__footer", className)
    }, restProps), children);
});
_c7 = LinkCardFooter;
const LinkCardIcon = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c8 = (_a, forwardedRef)=>{
    var { children, className } = _a, restProps = __rest(_a, [
        "children",
        "className"
    ]);
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", Object.assign({
        ref: forwardedRef,
        "aria-hidden": true,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-link-card__icon", className)
    }, restProps), children);
});
_c9 = LinkCardIcon;
const LinkCardImage = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c10 = (_a, forwardedRef)=>{
    var { children, className, aspectRatio, style } = _a, restProps = __rest(_a, [
        "children",
        "className",
        "aspectRatio",
        "style"
    ]);
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", Object.assign({
        ref: forwardedRef,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-link-card__image-container", className),
        style: Object.assign(Object.assign({}, style), {
            aspectRatio
        })
    }, restProps), children);
});
_c11 = LinkCardImage;
LinkCard.Title = LinkCardTitle;
LinkCard.Anchor = LinkCardAnchor;
LinkCard.Description = LinkCardDescription;
LinkCard.Footer = LinkCardFooter;
LinkCard.Icon = LinkCardIcon;
LinkCard.Image = LinkCardImage; //# sourceMappingURL=LinkCard.js.map
var _c, _c1, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11;
__turbopack_context__.k.register(_c, "LinkCard$forwardRef");
__turbopack_context__.k.register(_c1, "LinkCard");
__turbopack_context__.k.register(_c2, "LinkCardTitle$forwardRef");
__turbopack_context__.k.register(_c3, "LinkCardTitle");
__turbopack_context__.k.register(_c4, "LinkCardDescription$forwardRef");
__turbopack_context__.k.register(_c5, "LinkCardDescription");
__turbopack_context__.k.register(_c6, "LinkCardFooter$forwardRef");
__turbopack_context__.k.register(_c7, "LinkCardFooter");
__turbopack_context__.k.register(_c8, "LinkCardIcon$forwardRef");
__turbopack_context__.k.register(_c9, "LinkCardIcon");
__turbopack_context__.k.register(_c10, "LinkCardImage$forwardRef");
__turbopack_context__.k.register(_c11, "LinkCardImage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/read-more/ReadMore.js [app-client] (ecmascript) <export default as ReadMore>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ReadMore",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$read$2d$more$2f$ReadMore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$read$2d$more$2f$ReadMore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/read-more/ReadMore.js [app-client] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/tabs/Tabs.context.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TabsDescendantsProvider",
    ()=>TabsDescendantsProvider,
    "TabsProvider",
    ()=>TabsProvider,
    "useTabsContext",
    ()=>useTabsContext,
    "useTabsDescendant",
    ()=>useTabsDescendant,
    "useTabsDescendants",
    ()=>useTabsDescendants,
    "useTabsDescendantsContext",
    ()=>useTabsDescendantsContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$create$2d$strict$2d$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/create-strict-context.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$descendants$2f$useDescendant$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/descendants/useDescendant.js [app-client] (ecmascript)");
;
;
const [TabsDescendantsProvider, useTabsDescendantsContext, useTabsDescendants, useTabsDescendant] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$descendants$2f$useDescendant$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createDescendantContext"])();
const { Provider: TabsProvider, useContext: useTabsContext } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$create$2d$strict$2d$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createStrictContext"])({
    name: "TabsContext",
    errorMessage: "Tabs.List, Tabs.Tag and Tabs.Panel needs to be wrapped within <Tabs>"
}); //# sourceMappingURL=Tabs.context.js.map
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/tabs/parts/tab/useTab.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useTab",
    ()=>useTab
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$composeEventHandlers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/composeEventHandlers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useMergeRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/useMergeRefs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$Tabs$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/tabs/Tabs.context.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
function useTab({ value, disabled = false, onFocus: _onFocus, onClick }, ref) {
    _s();
    const { id, setSelectedValue, selectionFollowsFocus, focusedValue, setFocusedValue, selectedValue, makeTabId, makeTabPanelId } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$Tabs$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTabsContext"])();
    const { register } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$Tabs$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTabsDescendant"])({
        disabled,
        value
    });
    const isSelected = value === selectedValue;
    const onFocus = ()=>{
        setFocusedValue(value);
        selectionFollowsFocus && setSelectedValue(value);
    };
    const refs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useMergeRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMergeRefs"])(register, ref);
    return {
        ref: refs,
        isSelected,
        isFocused: focusedValue === value,
        id: makeTabId(id, value),
        controlsId: makeTabPanelId(id, value),
        onClick: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$composeEventHandlers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["composeEventHandlers"])(onClick, ()=>setSelectedValue(value)),
        onFocus: disabled ? undefined : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$composeEventHandlers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["composeEventHandlers"])(_onFocus, onFocus)
    };
} //# sourceMappingURL=useTab.js.map
_s(useTab, "dsJS5HO+FWHZ8Th1XxYOc+SoC5Y=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$Tabs$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTabsContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$Tabs$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTabsDescendant"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useMergeRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMergeRefs"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/tabs/parts/tab/Tab.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Tab",
    ()=>Tab,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/BodyShort.js [app-client] (ecmascript) <export default as BodyShort>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$Tabs$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/tabs/Tabs.context.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$parts$2f$tab$2f$useTab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/tabs/parts/tab/useTab.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
;
;
const Tab = /*#__PURE__*/ _s((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = _s((_a, ref)=>{
    _s();
    var _b, _c;
    var { className, as: Component = "button", label, icon, value, onClick, onFocus, disabled, id } = _a, rest = __rest(_a, [
        "className",
        "as",
        "label",
        "icon",
        "value",
        "onClick",
        "onFocus",
        "disabled",
        "id"
    ]);
    const tabCtx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$parts$2f$tab$2f$useTab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTab"])({
        value,
        onClick,
        onFocus,
        disabled
    }, ref);
    const ctx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$Tabs$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTabsContext"])();
    if (!label && !icon) {
        console.error("<Tabs.Tab/> needs label and/or icon");
        return null;
    }
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(Component, Object.assign({
        ref: tabCtx.ref
    }, rest, {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-tabs__tab", `aksel-tabs__tab--${(_b = ctx === null || ctx === void 0 ? void 0 : ctx.size) !== null && _b !== void 0 ? _b : "medium"}`, `aksel-tabs__tab-icon--${ctx === null || ctx === void 0 ? void 0 : ctx.iconPosition}`, className, {
            "aksel-tabs__tab--icon-only": icon && !label,
            "aksel-tabs__tab--fill": ctx.fill
        }),
        role: "tab",
        type: "button",
        "aria-selected": tabCtx.isSelected,
        "data-state": tabCtx.isSelected ? "active" : "inactive",
        tabIndex: tabCtx.isFocused ? 0 : -1,
        "aria-controls": (_c = rest["aria-controls"]) !== null && _c !== void 0 ? _c : tabCtx.controlsId,
        id: id !== null && id !== void 0 ? id : tabCtx.id,
        onFocus: tabCtx.onFocus,
        onClick: tabCtx.onClick
    }), /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__["BodyShort"], {
        as: "span",
        className: "aksel-tabs__tab-inner",
        size: ctx === null || ctx === void 0 ? void 0 : ctx.size
    }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("span", {
        "aria-hidden": !!label
    }, icon), /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("span", null, label)));
}, "kK1Jv7rWrpnDjeulNpv7/8e06qA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$parts$2f$tab$2f$useTab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTab"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$Tabs$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTabsContext"]
    ];
})), "kK1Jv7rWrpnDjeulNpv7/8e06qA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$parts$2f$tab$2f$useTab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTab"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$Tabs$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTabsContext"]
    ];
});
_c1 = Tab;
const __TURBOPACK__default__export__ = Tab;
var _c, _c1;
__turbopack_context__.k.register(_c, "Tab$forwardRef");
__turbopack_context__.k.register(_c1, "Tab");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=Tab.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/tabs/parts/tablist/ScrollButtons.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$ChevronLeft$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeftIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/ChevronLeft.js [app-client] (ecmascript) <export default as ChevronLeftIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$ChevronRight$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRightIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/ChevronRight.js [app-client] (ecmascript) <export default as ChevronRightIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
;
;
;
function ScrollButton({ hidden, onClick, dir }) {
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-tabs__scroll-button", {
            "aksel-tabs__scroll-button--hidden": hidden
        }),
        onClick: onClick,
        "aria-hidden": true
    }, dir === "left" ? /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$ChevronLeft$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeftIcon$3e$__["ChevronLeftIcon"], null) : /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$ChevronRight$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRightIcon$3e$__["ChevronRightIcon"], null));
}
_c = ScrollButton;
const __TURBOPACK__default__export__ = ScrollButton;
var _c;
__turbopack_context__.k.register(_c, "ScrollButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=ScrollButtons.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/tabs/parts/tablist/useScrollButtons.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useScrollButtons",
    ()=>useScrollButtons
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$debounce$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__debounce$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/debounce.js [app-client] (ecmascript) <export default as debounce>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$owner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/owner.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
function useScrollButtons(listRef) {
    _s();
    const [displayScroll, setDisplayScroll] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        start: false,
        end: false
    });
    const updateScrollButtonState = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useScrollButtons.useMemo[updateScrollButtonState]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$debounce$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__debounce$3e$__["debounce"])({
                "useScrollButtons.useMemo[updateScrollButtonState]": ()=>{
                    if (!(listRef === null || listRef === void 0 ? void 0 : listRef.current)) return;
                    const { scrollWidth, clientWidth } = listRef.current;
                    const scrollLeft = listRef.current.scrollLeft;
                    // use 1 for the potential rounding error with browser zooms.
                    const showStartScroll = scrollLeft > 1;
                    const showEndScroll = scrollLeft < scrollWidth - clientWidth - 1;
                    setDisplayScroll({
                        "useScrollButtons.useMemo[updateScrollButtonState]": (oldDisplayScroll)=>showStartScroll === oldDisplayScroll.start && showEndScroll === oldDisplayScroll.end ? oldDisplayScroll : {
                                start: showStartScroll,
                                end: showEndScroll
                            }
                    }["useScrollButtons.useMemo[updateScrollButtonState]"]);
                }
            }["useScrollButtons.useMemo[updateScrollButtonState]"])
    }["useScrollButtons.useMemo[updateScrollButtonState]"], [
        listRef
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useScrollButtons.useEffect": ()=>{
            const handleResize = {
                "useScrollButtons.useEffect.handleResize": ()=>updateScrollButtonState()
            }["useScrollButtons.useEffect.handleResize"];
            const ownerDoc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$owner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ownerDocument"])(listRef.current);
            ownerDoc.addEventListener("resize", handleResize);
            let resizeObserver;
            if (typeof ResizeObserver !== "undefined" && listRef.current) {
                resizeObserver = new ResizeObserver(handleResize);
                resizeObserver.observe(listRef.current);
            }
            return ({
                "useScrollButtons.useEffect": ()=>{
                    ownerDoc.removeEventListener("resize", handleResize);
                    resizeObserver === null || resizeObserver === void 0 ? void 0 : resizeObserver.disconnect();
                    updateScrollButtonState.clear();
                }
            })["useScrollButtons.useEffect"];
        }
    }["useScrollButtons.useEffect"], [
        listRef,
        updateScrollButtonState
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useScrollButtons.useEffect": ()=>{
            updateScrollButtonState();
        }
    }["useScrollButtons.useEffect"]);
    return {
        update: updateScrollButtonState,
        start: displayScroll.start,
        end: displayScroll.end,
        show: displayScroll.end || displayScroll.start,
        scrollLeft: ()=>{
            if (listRef.current) {
                listRef.current.scrollLeft -= 100;
            }
        },
        scrollRight: ()=>{
            if (listRef.current) {
                listRef.current.scrollLeft += 100;
            }
        }
    };
} //# sourceMappingURL=useScrollButtons.js.map
_s(useScrollButtons, "y4AawkIkDTgrzqctwnqHQxdxa8c=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/tabs/parts/tablist/useTabList.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useTabList",
    ()=>useTabList
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$Tabs$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/tabs/Tabs.context.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
function useTabList() {
    _s();
    const { focusedValue, loop, selectedValue, setFocusedValue } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$Tabs$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTabsContext"])();
    const descendants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$Tabs$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTabsDescendantsContext"])();
    /**
     * Implements rowing-tabindex for horizontal tabs
     */ const onKeyDown = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useTabList.useCallback[onKeyDown]": (event)=>{
            /**
         * Tabs.Tab is registered with its prop 'value'.
         * We can then use it to find the current focuses descendant
         */ const idx = descendants.values().findIndex({
                "useTabList.useCallback[onKeyDown].idx": (x)=>x.value === focusedValue
            }["useTabList.useCallback[onKeyDown].idx"]);
            const nextTab = {
                "useTabList.useCallback[onKeyDown].nextTab": ()=>{
                    var _a;
                    const next = descendants.nextEnabled(idx, loop);
                    (_a = next === null || next === void 0 ? void 0 : next.node) === null || _a === void 0 ? void 0 : _a.focus();
                }
            }["useTabList.useCallback[onKeyDown].nextTab"];
            const prevTab = {
                "useTabList.useCallback[onKeyDown].prevTab": ()=>{
                    var _a;
                    const prev = descendants.prevEnabled(idx, loop);
                    (_a = prev === null || prev === void 0 ? void 0 : prev.node) === null || _a === void 0 ? void 0 : _a.focus();
                }
            }["useTabList.useCallback[onKeyDown].prevTab"];
            const firstTab = {
                "useTabList.useCallback[onKeyDown].firstTab": ()=>{
                    var _a;
                    const first = descendants.firstEnabled();
                    (_a = first === null || first === void 0 ? void 0 : first.node) === null || _a === void 0 ? void 0 : _a.focus();
                }
            }["useTabList.useCallback[onKeyDown].firstTab"];
            const lastTab = {
                "useTabList.useCallback[onKeyDown].lastTab": ()=>{
                    var _a;
                    const last = descendants.lastEnabled();
                    (_a = last === null || last === void 0 ? void 0 : last.node) === null || _a === void 0 ? void 0 : _a.focus();
                }
            }["useTabList.useCallback[onKeyDown].lastTab"];
            const keyMap = {
                ArrowLeft: prevTab,
                ArrowRight: nextTab,
                Home: firstTab,
                End: lastTab
            };
            const hasModifiers = event.shiftKey || event.ctrlKey || event.altKey || event.metaKey;
            const action = keyMap[event.key];
            if (action && !hasModifiers) {
                event.preventDefault();
                action(event);
            } else if (event.key === "Tab") {
                /**
             * Imperative focus during keydown is risky so we prevent React's batching updates
             * to avoid potential bugs. See: https://github.com/facebook/react/issues/20332
             */ selectedValue && setTimeout({
                    "useTabList.useCallback[onKeyDown]": ()=>setFocusedValue(selectedValue)
                }["useTabList.useCallback[onKeyDown]"]);
            }
        }
    }["useTabList.useCallback[onKeyDown]"], [
        descendants,
        focusedValue,
        loop,
        selectedValue,
        setFocusedValue
    ]);
    return {
        onKeyDown
    };
} //# sourceMappingURL=useTabList.js.map
_s(useTabList, "cEc8QZDc6B4/bDLnON7nEdBaHe0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$Tabs$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTabsContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$Tabs$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTabsDescendantsContext"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/tabs/parts/tablist/TabList.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TabList",
    ()=>TabList,
    "default",
    ()=>__TURBOPACK__default__export__
]);
/* eslint-disable jsx-a11y/interactive-supports-focus */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$composeEventHandlers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/composeEventHandlers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useMergeRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/useMergeRefs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$parts$2f$tablist$2f$ScrollButtons$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/tabs/parts/tablist/ScrollButtons.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$parts$2f$tablist$2f$useScrollButtons$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/tabs/parts/tablist/useScrollButtons.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$parts$2f$tablist$2f$useTabList$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/tabs/parts/tablist/useTabList.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
;
;
;
;
const TabList = /*#__PURE__*/ _s((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = _s((_a, ref)=>{
    _s();
    var { className, onKeyDown } = _a, rest = __rest(_a, [
        "className",
        "onKeyDown"
    ]);
    const { onKeyDown: _onKeyDown } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$parts$2f$tablist$2f$useTabList$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTabList"])();
    const listRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const mergedRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useMergeRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMergeRefs"])(listRef, ref);
    const scrollCtx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$parts$2f$tablist$2f$useScrollButtons$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useScrollButtons"])(listRef);
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", {
        className: "aksel-tabs__tablist-wrapper"
    }, scrollCtx.show && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$parts$2f$tablist$2f$ScrollButtons$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        dir: "left",
        hidden: !scrollCtx.start,
        onClick: scrollCtx.scrollLeft
    }), /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", Object.assign({
        ref: mergedRef
    }, rest, {
        onScroll: scrollCtx.update,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-tabs__tablist", className),
        role: "tablist",
        "aria-orientation": "horizontal",
        onKeyDown: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$composeEventHandlers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["composeEventHandlers"])(onKeyDown, _onKeyDown)
    })), scrollCtx.show && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$parts$2f$tablist$2f$ScrollButtons$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        dir: "right",
        hidden: !scrollCtx.end,
        onClick: scrollCtx.scrollRight
    }));
}, "bfpAFVW+XJJlmh+zQKizDGHqoX8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$parts$2f$tablist$2f$useTabList$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTabList"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useMergeRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMergeRefs"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$parts$2f$tablist$2f$useScrollButtons$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useScrollButtons"]
    ];
})), "bfpAFVW+XJJlmh+zQKizDGHqoX8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$parts$2f$tablist$2f$useTabList$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTabList"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useMergeRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMergeRefs"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$parts$2f$tablist$2f$useScrollButtons$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useScrollButtons"]
    ];
});
_c1 = TabList;
const __TURBOPACK__default__export__ = TabList;
var _c, _c1;
__turbopack_context__.k.register(_c, "TabList$forwardRef");
__turbopack_context__.k.register(_c1, "TabList");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=TabList.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/tabs/parts/tabpanel/useTabPanel.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useTabPanel",
    ()=>useTabPanel
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$Tabs$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/tabs/Tabs.context.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
function useTabPanel({ value }) {
    _s();
    const { id, selectedValue, makeTabId, makeTabPanelId } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$Tabs$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTabsContext"])();
    return {
        labelledbyId: makeTabId(id, value),
        hidden: selectedValue !== value,
        id: makeTabPanelId(id, value)
    };
} //# sourceMappingURL=useTabPanel.js.map
_s(useTabPanel, "CDadJ7LXFO7Gc2a8QudOVwur3fY=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$Tabs$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTabsContext"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/tabs/parts/tabpanel/TabPanel.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$parts$2f$tabpanel$2f$useTabPanel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/tabs/parts/tabpanel/useTabPanel.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
const TabPanel = /*#__PURE__*/ _s((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = _s((_a, ref)=>{
    _s();
    var _b;
    var { className, value, children, lazy = true, id } = _a, rest = __rest(_a, [
        "className",
        "value",
        "children",
        "lazy",
        "id"
    ]);
    const ctx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$parts$2f$tabpanel$2f$useTabPanel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTabPanel"])({
        value
    });
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", Object.assign({
        ref: ref
    }, rest, {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-tabs__tabpanel", className),
        role: "tabpanel",
        tabIndex: 0,
        "aria-labelledby": (_b = rest["aria-labelledby"]) !== null && _b !== void 0 ? _b : ctx.labelledbyId,
        id: id !== null && id !== void 0 ? id : ctx.id,
        hidden: ctx.hidden,
        "data-state": !ctx.hidden ? "active" : "inactive"
    }), lazy && ctx.hidden ? null : children);
}, "hbalZzH6PSPq2SM8+G2QalEHJTs=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$parts$2f$tabpanel$2f$useTabPanel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTabPanel"]
    ];
})), "hbalZzH6PSPq2SM8+G2QalEHJTs=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$parts$2f$tabpanel$2f$useTabPanel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTabPanel"]
    ];
});
_c1 = TabPanel;
const __TURBOPACK__default__export__ = TabPanel;
var _c, _c1;
__turbopack_context__.k.register(_c, "TabPanel$forwardRef");
__turbopack_context__.k.register(_c1, "TabPanel");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=TabPanel.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/tabs/useTabs.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useTabs",
    ()=>useTabs
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/useId.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useControllableState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/useControllableState.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
function useTabs({ onChange, value, defaultValue = "", id }) {
    _s();
    const [focusedValue, setFocusedValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(defaultValue);
    const [selectedValue, setSelectedValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useControllableState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useControllableState"])({
        defaultValue,
        value,
        onChange
    });
    /**
     * Sync focused `value` with controlled `selectedValue`
     */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useTabs.useEffect": ()=>{
            if (value != null) {
                setFocusedValue(value);
            }
        }
    }["useTabs.useEffect"], [
        value
    ]);
    /**
     * Scope ids for better tracking
     */ const uuid = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])();
    return {
        id: `tabs-${id !== null && id !== void 0 ? id : uuid}`,
        selectedValue,
        setSelectedValue,
        focusedValue,
        setFocusedValue,
        makeTabId,
        makeTabPanelId
    };
}
_s(useTabs, "wYuLgDO4pEDTFRQ7toNlbLL61/c=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useControllableState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useControllableState"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"]
    ];
});
function makeTabId(id, value) {
    return `${id}--tab-${value}`;
}
function makeTabPanelId(id, value) {
    return `${id}--tabpanel-${value}`;
} //# sourceMappingURL=useTabs.js.map
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/tabs/Tabs.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Tabs",
    ()=>Tabs,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$Tabs$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/tabs/Tabs.context.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$parts$2f$tab$2f$Tab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/tabs/parts/tab/Tab.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$parts$2f$tablist$2f$TabList$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/tabs/parts/tablist/TabList.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$parts$2f$tabpanel$2f$TabPanel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/tabs/parts/tabpanel/TabPanel.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$useTabs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/tabs/useTabs.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
;
;
;
;
const Tabs = /*#__PURE__*/ _s((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = _s((_a, ref)=>{
    _s();
    var { className, children, size = "medium", defaultValue = "", value, onChange, id, selectionFollowsFocus = false, loop = true, iconPosition = "left", fill = false } = _a, rest = __rest(_a, [
        "className",
        "children",
        "size",
        "defaultValue",
        "value",
        "onChange",
        "id",
        "selectionFollowsFocus",
        "loop",
        "iconPosition",
        "fill"
    ]);
    const descendants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$Tabs$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTabsDescendants"])();
    const tabsContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$useTabs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTabs"])({
        defaultValue,
        value,
        onChange,
        id
    });
    /**
     * TabsProvider handles memoization of context values, so we can safely skip it here.
     */ const context = Object.assign(Object.assign({}, tabsContext), {
        selectionFollowsFocus,
        loop,
        size,
        iconPosition,
        fill
    });
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$Tabs$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TabsDescendantsProvider"], {
        value: descendants
    }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$Tabs$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TabsProvider"], Object.assign({}, context), /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", Object.assign({
        ref: ref
    }, rest, {
        id: id,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-tabs", className, `aksel-tabs--${size}`)
    }), children)));
}, "OJ2PjBbnodbbtvSxbR+O0uqoqMo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$Tabs$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTabsDescendants"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$useTabs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTabs"]
    ];
})), "OJ2PjBbnodbbtvSxbR+O0uqoqMo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$Tabs$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTabsDescendants"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$useTabs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTabs"]
    ];
});
_c1 = Tabs;
Tabs.Tab = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$parts$2f$tab$2f$Tab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
Tabs.List = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$parts$2f$tablist$2f$TabList$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
Tabs.Panel = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$parts$2f$tabpanel$2f$TabPanel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
const __TURBOPACK__default__export__ = Tabs;
var _c, _c1;
__turbopack_context__.k.register(_c, "Tabs$forwardRef");
__turbopack_context__.k.register(_c1, "Tabs");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=Tabs.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/tabs/Tabs.js [app-client] (ecmascript) <export default as Tabs>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Tabs",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$Tabs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$tabs$2f$Tabs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/tabs/Tabs.js [app-client] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/list/List.context.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ListContext",
    ()=>ListContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
const ListContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])({
    listType: "ul",
    size: "medium"
}); //# sourceMappingURL=List.context.js.map
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/list/List.Item.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ListItem",
    ()=>ListItem,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyLong$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyLong$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/BodyLong.js [app-client] (ecmascript) <export default as BodyLong>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$list$2f$List$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/list/List.context.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
;
const ListItem = /*#__PURE__*/ _s((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = _s((_a, ref)=>{
    _s();
    var { className, children, title, icon } = _a, rest = __rest(_a, [
        "className",
        "children",
        "title",
        "icon"
    ]);
    const { listType, size } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$list$2f$List$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ListContext"]);
    if (listType === "ol" && icon) {
        console.warn("<List />: Icon prop is not supported for ordered lists. Please remove the icon prop.");
    }
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("li", Object.assign({}, rest, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-list__item", className)
    }), listType === "ul" && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-list__item-marker", {
            "aksel-list__item-marker--icon": icon,
            "aksel-list__item-marker--bullet": !icon
        })
    }, icon ? icon : /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("svg", {
        viewBox: "0 0 6 6",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        "aria-hidden": true,
        focusable: false,
        role: "img"
    }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("rect", {
        width: "6",
        height: "6",
        rx: "3",
        fill: "currentColor"
    }))), /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", null, title && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyLong$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyLong$3e$__["BodyLong"], {
        as: "p",
        size: size,
        weight: "semibold"
    }, title), children));
}, "+tW7xV7Mtwncy2VeOqFGw4ZeUNc=")), "+tW7xV7Mtwncy2VeOqFGw4ZeUNc=");
_c1 = ListItem;
ListItem.displayName = "List.Item";
const __TURBOPACK__default__export__ = ListItem;
var _c, _c1;
__turbopack_context__.k.register(_c, "ListItem$forwardRef");
__turbopack_context__.k.register(_c1, "ListItem");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=List.Item.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/list/List.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "List",
    ()=>List,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyLong$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyLong$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/BodyLong.js [app-client] (ecmascript) <export default as BodyLong>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$list$2f$List$2e$Item$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/list/List.Item.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$list$2f$List$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/list/List.context.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
;
;
const List = /*#__PURE__*/ _s((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = _s((_a, ref)=>{
    _s();
    var { children, className, as: ListTag = "ul", size, "aria-label": _ariaLabel, "aria-labelledby": _ariaLabelledBy } = _a, rest = __rest(_a, [
        "children",
        "className",
        "as",
        "size",
        "aria-label",
        "aria-labelledby"
    ]);
    const { size: contextSize } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$list$2f$List$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ListContext"]);
    const listSize = size !== null && size !== void 0 ? size : contextSize;
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$list$2f$List$2e$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ListContext"].Provider, {
        value: {
            listType: ListTag,
            size: listSize
        }
    }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyLong$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyLong$3e$__["BodyLong"], Object.assign({
        as: "div"
    }, rest, {
        size: listSize,
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-list", `aksel-list--${listSize}`, className)
    }), /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(ListTag, {
        role: "list",
        "aria-label": _ariaLabel,
        "aria-labelledby": _ariaLabelledBy
    }, children)));
}, "wcYt8femnSeE9+7Pzl/4R4EMSb0=")), "wcYt8femnSeE9+7Pzl/4R4EMSb0=");
_c1 = List;
List.Item = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$list$2f$List$2e$Item$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ListItem"];
const __TURBOPACK__default__export__ = List;
var _c, _c1;
__turbopack_context__.k.register(_c, "List$forwardRef");
__turbopack_context__.k.register(_c1, "List");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=List.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/list/List.js [app-client] (ecmascript) <export default as List>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "List",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$list$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$list$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/list/List.js [app-client] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/accordion/AccordionContext.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AccordionContext",
    ()=>AccordionContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
const AccordionContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])({
    size: "medium",
    openItems: [],
    mounted: false
}); //# sourceMappingURL=AccordionContext.js.map
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/accordion/AccordionItem.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AccordionItemContext",
    ()=>AccordionItemContext,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$omit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/omit.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useControllableState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/useControllableState.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$accordion$2f$AccordionContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/accordion/AccordionContext.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
;
;
const AccordionItemContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(null);
const AccordionItem = /*#__PURE__*/ _s((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = _s((_a, ref)=>{
    _s();
    var { children, className, open, defaultOpen = false, onOpenChange } = _a, rest = __rest(_a, [
        "children",
        "className",
        "open",
        "defaultOpen",
        "onOpenChange"
    ]);
    const [_open, _setOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useControllableState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useControllableState"])({
        defaultValue: defaultOpen,
        value: open,
        onChange: onOpenChange
    });
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$accordion$2f$AccordionContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AccordionContext"]);
    const shouldAnimate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(!(Boolean(open) || defaultOpen));
    const handleOpen = ()=>{
        _setOpen((x)=>!x);
        shouldAnimate.current = true;
    };
    if (!(context === null || context === void 0 ? void 0 : context.mounted)) {
        console.error("<Accordion.Item> has to be used within an <Accordion>");
    }
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", Object.assign({
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-accordion__item", className, {
            "aksel-accordion__item--open": _open,
            "aksel-accordion__item--no-animation": !shouldAnimate.current
        }),
        "data-expanded": _open,
        ref: ref
    }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$omit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["omit"])(rest, [
        "onClick"
    ])), /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(AccordionItemContext.Provider, {
        value: {
            open: _open,
            toggleOpen: handleOpen
        }
    }, children));
}, "MOBze6QFYESuYEljzB2207nYeTI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useControllableState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useControllableState"]
    ];
})), "MOBze6QFYESuYEljzB2207nYeTI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useControllableState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useControllableState"]
    ];
});
_c1 = AccordionItem;
const __TURBOPACK__default__export__ = AccordionItem;
var _c, _c1;
__turbopack_context__.k.register(_c, "AccordionItem$forwardRef");
__turbopack_context__.k.register(_c1, "AccordionItem");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=AccordionItem.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/accordion/AccordionContent.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$theme$2f$Theme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/theme/Theme.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyLong$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyLong$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/BodyLong.js [app-client] (ecmascript) <export default as BodyLong>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$accordion$2f$AccordionItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/accordion/AccordionItem.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
;
;
const AccordionContent = /*#__PURE__*/ _s((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = _s((_a, ref)=>{
    _s();
    var { children, className } = _a, rest = __rest(_a, [
        "children",
        "className"
    ]);
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$accordion$2f$AccordionItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AccordionItemContext"]);
    const themeContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$theme$2f$Theme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useThemeInternal"])();
    if (context === null) {
        console.error("<Accordion.Content> has to be used within an <Accordion.Item>");
        return null;
    }
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyLong$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyLong$3e$__["BodyLong"], Object.assign({}, rest, {
        as: "div",
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-accordion__content", {
            "aksel-accordion__content--closed": !context.open
        }, className)
    }), /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", {
        className: "aksel-accordion__content-inner",
        "data-color": themeContext.color
    }, children));
}, "wCDiuZyQ1o9IQ434sb48oWNZ7ws=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$theme$2f$Theme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useThemeInternal"]
    ];
})), "wCDiuZyQ1o9IQ434sb48oWNZ7ws=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$theme$2f$Theme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useThemeInternal"]
    ];
});
_c1 = AccordionContent;
const __TURBOPACK__default__export__ = AccordionContent;
var _c, _c1;
__turbopack_context__.k.register(_c, "AccordionContent$forwardRef");
__turbopack_context__.k.register(_c1, "AccordionContent");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=AccordionContent.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/accordion/AccordionHeader.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$ChevronDown$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDownIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/ChevronDown.js [app-client] (ecmascript) <export default as ChevronDownIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$Heading$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Heading$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/Heading.js [app-client] (ecmascript) <export default as Heading>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$composeEventHandlers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/composeEventHandlers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$accordion$2f$AccordionContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/accordion/AccordionContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$accordion$2f$AccordionItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/accordion/AccordionItem.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
;
;
;
;
const AccordionHeader = /*#__PURE__*/ _s((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = _s((_a, ref)=>{
    _s();
    var { children, className, onClick } = _a, rest = __rest(_a, [
        "children",
        "className",
        "onClick"
    ]);
    const itemContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$accordion$2f$AccordionItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AccordionItemContext"]);
    const accordionContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$accordion$2f$AccordionContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AccordionContext"]);
    if (itemContext === null) {
        console.error("<Accordion.Header> has to be used within an <Accordion.Item>, which in turn must be within an <Accordion>");
        return null;
    }
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("button", Object.assign({
        ref: ref,
        "data-color": (accordionContext === null || accordionContext === void 0 ? void 0 : accordionContext.variant) === "neutral" ? "neutral" : undefined
    }, rest, {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-accordion__header", className),
        onClick: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$composeEventHandlers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["composeEventHandlers"])(onClick, itemContext.toggleOpen),
        "aria-expanded": itemContext.open,
        type: "button"
    }), /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("span", {
        className: "aksel-accordion__icon-wrapper"
    }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$ChevronDown$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDownIcon$3e$__["ChevronDownIcon"], {
        className: "aksel-accordion__header-chevron",
        "aria-hidden": true
    })), /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$Heading$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Heading$3e$__["Heading"], {
        size: (accordionContext === null || accordionContext === void 0 ? void 0 : accordionContext.size) === "large" ? "small" : "xsmall",
        as: "span"
    }, children));
}, "x/jZNT/b6WL9pv5yKgjHOOu24z0=")), "x/jZNT/b6WL9pv5yKgjHOOu24z0=");
_c1 = AccordionHeader;
const __TURBOPACK__default__export__ = AccordionHeader;
var _c, _c1;
__turbopack_context__.k.register(_c, "AccordionHeader$forwardRef");
__turbopack_context__.k.register(_c1, "AccordionHeader");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=AccordionHeader.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/accordion/Accordion.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Accordion",
    ()=>Accordion,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$omit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/omit.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$accordion$2f$AccordionContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/accordion/AccordionContent.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$accordion$2f$AccordionContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/accordion/AccordionContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$accordion$2f$AccordionHeader$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/accordion/AccordionHeader.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$accordion$2f$AccordionItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/accordion/AccordionItem.js [app-client] (ecmascript)");
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
;
;
;
;
const Accordion = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = (_a, ref)=>{
    var { className, variant = "default", size = "medium", indent = true } = _a, rest = __rest(_a, [
        "className",
        "variant",
        "size",
        "indent"
    ]);
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$accordion$2f$AccordionContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AccordionContext"].Provider, {
        value: {
            size,
            mounted: true,
            variant
        }
    }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", Object.assign({}, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$omit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["omit"])(rest, [
        "headingSize"
    ]), {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-accordion", className, `aksel-accordion--${size}`, {
            "aksel-accordion--indent": indent
        }),
        ref: ref
    })));
});
_c1 = Accordion;
Accordion.Header = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$accordion$2f$AccordionHeader$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
Accordion.Content = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$accordion$2f$AccordionContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
Accordion.Item = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$accordion$2f$AccordionItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
const __TURBOPACK__default__export__ = Accordion;
var _c, _c1;
__turbopack_context__.k.register(_c, "Accordion$forwardRef");
__turbopack_context__.k.register(_c1, "Accordion");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=Accordion.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/accordion/Accordion.js [app-client] (ecmascript) <export default as Accordion>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Accordion",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$accordion$2f$Accordion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/accordion/Accordion.js [app-client] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/table/Body.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Body",
    ()=>Body,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
const Body = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = (_a, ref)=>{
    var { className } = _a, rest = __rest(_a, [
        "className"
    ]);
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("tbody", Object.assign({}, rest, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-table__body", className)
    }));
});
_c1 = Body;
const __TURBOPACK__default__export__ = Body;
var _c, _c1;
__turbopack_context__.k.register(_c, "Body$forwardRef");
__turbopack_context__.k.register(_c1, "Body");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=Body.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/table/HeaderCell.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HeaderCell",
    ()=>HeaderCell,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
const HeaderCell = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = (_a, ref)=>{
    var { className, children, align, textSize } = _a, rest = __rest(_a, [
        "className",
        "children",
        "align",
        "textSize"
    ]);
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("th", Object.assign({
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-table__header-cell", "aksel-label", className, {
            [`aksel-table__header-cell--align-${align}`]: align,
            "aksel-label--small": textSize === "small"
        })
    }, rest), children);
});
_c1 = HeaderCell;
const __TURBOPACK__default__export__ = HeaderCell;
var _c, _c1;
__turbopack_context__.k.register(_c, "HeaderCell$forwardRef");
__turbopack_context__.k.register(_c1, "HeaderCell");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=HeaderCell.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/table/context.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TableContext",
    ()=>TableContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
const TableContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(null); //# sourceMappingURL=context.js.map
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/table/ColumnHeader.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ColumnHeader",
    ()=>ColumnHeader,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$ArrowsUpDown$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowsUpDownIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/ArrowsUpDown.js [app-client] (ecmascript) <export default as ArrowsUpDownIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$SortDown$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__SortDownIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/SortDown.js [app-client] (ecmascript) <export default as SortDownIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$SortUp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__SortUpIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/SortUp.js [app-client] (ecmascript) <export default as SortUpIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$HeaderCell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/table/HeaderCell.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/table/context.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
;
const ColumnHeader = /*#__PURE__*/ _s((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = _s((_a, ref)=>{
    _s();
    var _b, _c, _d, _e;
    var { children, sortable = false, sortKey } = _a, rest = __rest(_a, [
        "children",
        "sortable",
        "sortKey"
    ]);
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableContext"]);
    if (sortable && !sortKey) {
        console.warn("ColumnHeader with `sortable=true` must have a sortKey.");
    }
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$HeaderCell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], Object.assign({
        scope: "col",
        ref: ref,
        "aria-sort": sortable ? ((_b = context === null || context === void 0 ? void 0 : context.sort) === null || _b === void 0 ? void 0 : _b.orderBy) === sortKey ? (_c = context === null || context === void 0 ? void 0 : context.sort) === null || _c === void 0 ? void 0 : _c.direction : "none" : undefined
    }, rest), sortable ? /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("button", {
        type: "button",
        className: "aksel-table__sort-button",
        onClick: sortable && sortKey ? ()=>{
            var _a;
            return (_a = context === null || context === void 0 ? void 0 : context.onSortChange) === null || _a === void 0 ? void 0 : _a.call(context, sortKey);
        } : undefined
    }, children, ((_d = context === null || context === void 0 ? void 0 : context.sort) === null || _d === void 0 ? void 0 : _d.orderBy) === sortKey ? ((_e = context === null || context === void 0 ? void 0 : context.sort) === null || _e === void 0 ? void 0 : _e.direction) === "descending" ? /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$SortDown$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__SortDownIcon$3e$__["SortDownIcon"], {
        "aria-hidden": true
    }) : /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$SortUp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__SortUpIcon$3e$__["SortUpIcon"], {
        "aria-hidden": true
    }) : /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$ArrowsUpDown$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowsUpDownIcon$3e$__["ArrowsUpDownIcon"], {
        "aria-hidden": true
    })) : children);
}, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=")), "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
_c1 = ColumnHeader;
const __TURBOPACK__default__export__ = ColumnHeader;
var _c, _c1;
__turbopack_context__.k.register(_c, "ColumnHeader$forwardRef");
__turbopack_context__.k.register(_c1, "ColumnHeader");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=ColumnHeader.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/table/DataCell.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DataCell",
    ()=>DataCell,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/BodyShort.js [app-client] (ecmascript) <export default as BodyShort>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
const DataCell = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = (_a, ref)=>{
    var { className, children = "", align, textSize } = _a, rest = __rest(_a, [
        "className",
        "children",
        "align",
        "textSize"
    ]);
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__["BodyShort"], Object.assign({
        as: "td",
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-table__data-cell", className, {
            [`aksel-table__data-cell--align-${align}`]: align
        }),
        size: textSize
    }, rest), children);
});
_c1 = DataCell;
const __TURBOPACK__default__export__ = DataCell;
var _c, _c1;
__turbopack_context__.k.register(_c, "DataCell$forwardRef");
__turbopack_context__.k.register(_c1, "DataCell");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=DataCell.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/table/AnimateHeight.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
/* https://github.com/Stanko/react-animate-height/blob/v3/src/index.tsx */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useTimeout$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/useTimeout.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
// ------------------ Helpers
const prefersReducedMotion = (globalThis === null || globalThis === void 0 ? void 0 : globalThis.matchMedia) ? globalThis.matchMedia("(prefers-reduced-motion: reduce)").matches : false;
function isNumber(n) {
    const number = parseFloat(n);
    return !Number.isNaN(number) && Number.isFinite(number);
}
function isPercentage(height) {
    // Percentage height
    return typeof height === "string" && height[height.length - 1] === "%" && isNumber(height.substring(0, height.length - 1));
}
function hideContent(element, height) {
    // Check for element?.style is added cause this would fail in tests (react-test-renderer)
    // Read more here: https://github.com/Stanko/react-animate-height/issues/17
    if (height === 0 && (element === null || element === void 0 ? void 0 : element.style)) {
        element.style.display = "none";
    }
}
function showContent(element, height) {
    // Check for element?.style is added cause this would fail in tests (react-test-renderer)
    // Read more here: https://github.com/Stanko/react-animate-height/issues/17
    if (height === 0 && (element === null || element === void 0 ? void 0 : element.style)) {
        element.style.display = "";
    }
}
const AnimateHeight = (_a)=>{
    _s();
    var { children, className, innerClassName, duration: userDuration = 250, easing = "ease", height } = _a, props = __rest(_a, [
        "children",
        "className",
        "innerClassName",
        "duration",
        "easing",
        "height"
    ]);
    // ------------------ Initialization
    const prevHeight = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(height);
    const contentElement = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const animationClassTimeout = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useTimeout$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTimeout"])();
    const animationTimeout = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useTimeout$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTimeout"])();
    const initialHeight = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(height);
    const initialOverflow = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])("visible");
    const duration = prefersReducedMotion ? 0 : userDuration;
    if (typeof initialHeight.current === "number") {
        // Reset negative height to 0
        if (typeof height !== "string") {
            initialHeight.current = height < 0 ? 0 : height;
        }
        initialOverflow.current = "hidden";
    } else if (isPercentage(initialHeight.current)) {
        // If value is string "0%" make sure we convert it to number 0
        initialHeight.current = height === "0%" ? 0 : height;
        initialOverflow.current = "hidden";
    }
    const [currentHeight, setCurrentHeight] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialHeight.current);
    const [overflow, setOverflow] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialOverflow.current);
    const [useTransitions, setUseTransitions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AnimateHeight.useEffect": ()=>{
            // Hide content if height is 0 (to prevent tabbing into it)
            hideContent(contentElement.current, initialHeight.current);
        }
    }["AnimateHeight.useEffect"], []);
    // ------------------ Height update
    // biome-ignore lint/correctness/useExhaustiveDependencies: This should be explicitly run only on height change
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AnimateHeight.useEffect": ()=>{
            if (height !== prevHeight.current && contentElement.current) {
                showContent(contentElement.current, prevHeight.current);
                // Cache content height
                contentElement.current.style.overflow = "hidden";
                const contentHeight = contentElement.current.offsetHeight;
                contentElement.current.style.overflow = "";
                // set total animation time
                const totalDuration = duration;
                let newHeight;
                let timeoutHeight;
                let timeoutOverflow = "hidden";
                let timeoutUseTransitions;
                const isCurrentHeightAuto = prevHeight.current === "auto";
                if (typeof height === "number") {
                    // Reset negative height to 0
                    newHeight = height < 0 ? 0 : height;
                    timeoutHeight = newHeight;
                } else if (isPercentage(height)) {
                    // If value is string "0%" make sure we convert it to number 0
                    newHeight = height === "0%" ? 0 : height;
                    timeoutHeight = newHeight;
                } else {
                    // If not, animate to content height
                    // and then reset to auto
                    newHeight = contentHeight; // TODO solve contentHeight = 0
                    timeoutHeight = "auto";
                    timeoutOverflow = undefined;
                }
                if (isCurrentHeightAuto) {
                    // This is the height to be animated to
                    timeoutHeight = newHeight;
                    // If previous height was 'auto'
                    // set starting height explicitly to be able to use transition
                    newHeight = contentHeight;
                }
                // Set starting height and animating classes
                // When animating from 'auto' we first need to set fixed height
                // that change should be animated
                setCurrentHeight(newHeight);
                setOverflow("hidden");
                setUseTransitions(!isCurrentHeightAuto);
                if (isCurrentHeightAuto) {
                    // When animating from 'auto' we use a short timeout to start animation
                    // after setting fixed height above
                    timeoutUseTransitions = true;
                    // Short timeout to allow rendering of the initial animation state first
                    animationTimeout.start(50, {
                        "AnimateHeight.useEffect": ()=>{
                            setCurrentHeight(timeoutHeight);
                            setOverflow(timeoutOverflow);
                            setUseTransitions(timeoutUseTransitions);
                        }
                    }["AnimateHeight.useEffect"]);
                    // Set static classes and remove transitions when animation ends
                    animationClassTimeout.start(totalDuration, {
                        "AnimateHeight.useEffect": ()=>{
                            setUseTransitions(false);
                            // ANIMATION ENDS
                            // Hide content if height is 0 (to prevent tabbing into it)
                            hideContent(contentElement.current, timeoutHeight);
                        }
                    }["AnimateHeight.useEffect"]);
                } else {
                    // Set end height, classes and remove transitions when animation is complete
                    animationTimeout.start(totalDuration, {
                        "AnimateHeight.useEffect": ()=>{
                            setCurrentHeight(timeoutHeight);
                            setOverflow(timeoutOverflow);
                            setUseTransitions(false);
                            // ANIMATION ENDS
                            // If height is auto, don't hide the content
                            // (case when element is empty, therefore height is 0)
                            if (height !== "auto") {
                                // Hide content if height is 0 (to prevent tabbing into it)
                                hideContent(contentElement.current, newHeight); // TODO solve newHeight = 0
                            }
                        }
                    }["AnimateHeight.useEffect"]);
                }
            }
            prevHeight.current = height;
            /* We need to manually clear here since we cant guarantee the `.start()` getting called after `height` changes */ return ({
                "AnimateHeight.useEffect": ()=>{
                    animationTimeout.clear();
                    animationClassTimeout.clear();
                }
            })["AnimateHeight.useEffect"];
        // This should be explicitly run only on height change
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["AnimateHeight.useEffect"], [
        height
    ]);
    // ------------------ Render
    const componentStyle = {
        height: currentHeight,
        overflow
    };
    if (useTransitions) {
        componentStyle.transition = `height ${duration}ms ${easing} 0ms`;
        // Add webkit vendor prefix still used by opera, blackberry...
        componentStyle.WebkitTransition = componentStyle.transition;
    }
    // Check if user passed aria-hidden prop
    const hasAriaHiddenProp = typeof props["aria-hidden"] !== "undefined";
    const ariaHidden = hasAriaHiddenProp ? props["aria-hidden"] : height === 0;
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", Object.assign({}, props, {
        className: className,
        style: componentStyle
    }), /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", {
        "aria-hidden": ariaHidden,
        className: innerClassName,
        ref: contentElement
    }, children));
};
_s(AnimateHeight, "RlcMwKLfAe6cnZE7frfKM7/N/YY=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useTimeout$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTimeout"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useTimeout$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTimeout"]
    ];
});
_c = AnimateHeight;
const __TURBOPACK__default__export__ = AnimateHeight;
var _c;
__turbopack_context__.k.register(_c, "AnimateHeight");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=AnimateHeight.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/table/Table.utils.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isElementInteractiveTarget",
    ()=>isElementInteractiveTarget
]);
const INTERACTIVE_TAGS = new Set([
    "BUTTON",
    "A",
    "INPUT",
    "SELECT",
    "TEXTAREA",
    "DETAILS",
    "SUMMARY",
    "LABEL"
]);
const INTERACTIVE_ROLES = new Set([
    "button",
    "link",
    "checkbox",
    "radio",
    "switch",
    "menuitem",
    "option",
    "tab",
    "textbox",
    "combobox",
    "spinbutton",
    "slider"
]);
/**
 * Walks up from the event target until TR/TH (row / header) or root.
 * Returns true if any ancestor is inherently interactive, explicitly focusable,
 * or has an interactive ARIA role.
 * Used to decide whether a row click should be treated as a row selection
 * or ignored because the user interacted with an embedded control.
 */ function isElementInteractiveTarget(element) {
    for(let node = element; node && node.nodeName !== "TR" && node.nodeName !== "TH"; node = node.parentElement){
        const tag = node.nodeName;
        /* Native interactive tag */ if (INTERACTIVE_TAGS.has(tag)) {
            return true;
        }
        /* Explicit interactive role */ const role = node.getAttribute("role");
        if (role && INTERACTIVE_ROLES.has(role)) {
            return true;
        }
        /* Focusable via tabindex (exclude -1) */ if (node.hasAttribute("tabindex")) {
            const ti = node.getAttribute("tabindex");
            if (ti !== "-1") {
                return true;
            }
        }
    }
    return false;
}
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=Table.utils.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/table/Row.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Row",
    ()=>Row,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$composeEventHandlers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/composeEventHandlers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/table/Table.utils.js [app-client] (ecmascript)");
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
;
const Row = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = (_a, ref)=>{
    var { className, selected = false, shadeOnHover = true, onClick, onRowClick } = _a, rest = __rest(_a, [
        "className",
        "selected",
        "shadeOnHover",
        "onClick",
        "onRowClick"
    ]);
    const handleRowClick = (event)=>{
        if (!onRowClick) {
            return;
        }
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isElementInteractiveTarget"])(event.target)) {
            return;
        }
        onRowClick(event);
    };
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("tr", Object.assign({}, rest, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-table__row", className, {
            "aksel-table__row--selected": selected,
            "aksel-table__row--shade-on-hover": shadeOnHover
        }),
        onClick: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$composeEventHandlers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["composeEventHandlers"])(onClick, handleRowClick),
        "data-interactive": !!onRowClick
    }));
});
_c1 = Row;
const __TURBOPACK__default__export__ = Row;
var _c, _c1;
__turbopack_context__.k.register(_c, "Row$forwardRef");
__turbopack_context__.k.register(_c1, "Row");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=Row.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/table/ExpandableRow.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ExpandableRow",
    ()=>ExpandableRow,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$ChevronDown$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDownIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/ChevronDown.js [app-client] (ecmascript) <export default as ChevronDownIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$composeEventHandlers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/composeEventHandlers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/useId.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useControllableState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/useControllableState.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$i18n$2f$i18n$2e$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/i18n/i18n.hooks.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$AnimateHeight$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/table/AnimateHeight.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$DataCell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/table/DataCell.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Row$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/table/Row.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/table/Table.utils.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
;
;
;
;
;
;
;
;
const ExpandableRow = /*#__PURE__*/ _s((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = _s((_a, ref)=>{
    _s();
    var { className, children, content, togglePlacement = "left", defaultOpen = false, open, onOpenChange, expansionDisabled = false, expandOnRowClick = false, colSpan = 999, contentGutter, onClick } = _a, rest = __rest(_a, [
        "className",
        "children",
        "content",
        "togglePlacement",
        "defaultOpen",
        "open",
        "onOpenChange",
        "expansionDisabled",
        "expandOnRowClick",
        "colSpan",
        "contentGutter",
        "onClick"
    ]);
    const [_open, _setOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useControllableState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useControllableState"])({
        defaultValue: defaultOpen,
        value: open,
        onChange: onOpenChange
    });
    const translate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$i18n$2f$i18n$2e$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useI18n"])("global");
    const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])();
    const expansionHandler = (event)=>{
        _setOpen((oldOpen)=>!oldOpen);
        event.stopPropagation();
    };
    const handleRowClick = (event)=>{
        expandOnRowClick && !expansionDisabled && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isElementInteractiveTarget"])(event.target) && expansionHandler(event);
    };
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Fragment, null, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Row$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], Object.assign({}, rest, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-table__expandable-row", className, {
            "aksel-table__expandable-row--open": _open,
            "aksel-table__expandable-row--expansion-disabled": expansionDisabled,
            "aksel-table__expandable-row--clickable": expandOnRowClick
        }),
        onClick: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$composeEventHandlers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["composeEventHandlers"])(onClick, handleRowClick)
    }), togglePlacement === "right" && children, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$DataCell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-table__toggle-expand-cell", {
            "aksel-table__toggle-expand-cell--open": _open
        }),
        onClick: !expansionDisabled ? expansionHandler : ()=>null
    }, !expansionDisabled && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("button", {
        className: "aksel-table__toggle-expand-button",
        type: "button",
        "aria-controls": id,
        "aria-expanded": _open,
        onClick: expansionHandler
    }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$ChevronDown$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDownIcon$3e$__["ChevronDownIcon"], {
        className: "aksel-table__expandable-icon",
        title: _open ? translate("showLess") : translate("showMore")
    }))), togglePlacement === "left" && children), /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("tr", {
        "data-state": _open ? "open" : "closed",
        className: "aksel-table__expanded-row",
        "aria-hidden": !_open,
        id: id
    }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("td", {
        colSpan: colSpan,
        className: "aksel-table__expanded-row-cell"
    }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$AnimateHeight$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        className: "aksel-table__expanded-row-collapse",
        innerClassName: `aksel-table__expanded-row-content aksel-table__expanded-row-content--gutter-${contentGutter !== null && contentGutter !== void 0 ? contentGutter : togglePlacement}`,
        height: _open ? "auto" : 0,
        duration: 150,
        easing: "cubic-bezier(0.39,0.57,0.56,1)"
    }, content))));
}, "89lPVBhkZwkN+tMFIcilD6aehrg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useControllableState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useControllableState"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$i18n$2f$i18n$2e$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useI18n"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"]
    ];
})), "89lPVBhkZwkN+tMFIcilD6aehrg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useControllableState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useControllableState"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$i18n$2f$i18n$2e$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useI18n"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"]
    ];
});
_c1 = ExpandableRow;
const __TURBOPACK__default__export__ = ExpandableRow;
var _c, _c1;
__turbopack_context__.k.register(_c, "ExpandableRow$forwardRef");
__turbopack_context__.k.register(_c1, "ExpandableRow");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=ExpandableRow.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/table/Header.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Header",
    ()=>Header,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
const Header = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = (_a, ref)=>{
    var { className } = _a, rest = __rest(_a, [
        "className"
    ]);
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("thead", Object.assign({}, rest, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-table__header", className)
    }));
});
_c1 = Header;
const __TURBOPACK__default__export__ = Header;
var _c, _c1;
__turbopack_context__.k.register(_c, "Header$forwardRef");
__turbopack_context__.k.register(_c1, "Header");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=Header.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/table/Table.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Table",
    ()=>Table,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Body$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/table/Body.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$ColumnHeader$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/table/ColumnHeader.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$DataCell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/table/DataCell.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$ExpandableRow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/table/ExpandableRow.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Header$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/table/Header.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$HeaderCell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/table/HeaderCell.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Row$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/table/Row.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/table/context.js [app-client] (ecmascript)");
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
;
;
;
;
;
;
;
const Table = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = (_a, ref)=>{
    var { className, zebraStripes = false, size = "medium", onSortChange, sort, stickyHeader = false } = _a, rest = __rest(_a, [
        "className",
        "zebraStripes",
        "size",
        "onSortChange",
        "sort",
        "stickyHeader"
    ]);
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableContext"].Provider, {
        value: {
            onSortChange,
            sort
        }
    }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("table", Object.assign({}, rest, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-table", `aksel-table--${size}`, className, {
            "aksel-table--zebra-stripes": zebraStripes,
            "aksel-table--sticky-header": stickyHeader
        })
    })));
});
_c1 = Table;
Table.Header = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Header$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
Table.Body = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Body$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
Table.Row = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Row$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
Table.ColumnHeader = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$ColumnHeader$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
Table.HeaderCell = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$HeaderCell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
Table.DataCell = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$DataCell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
Table.ExpandableRow = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$ExpandableRow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
const __TURBOPACK__default__export__ = Table;
var _c, _c1;
__turbopack_context__.k.register(_c, "Table$forwardRef");
__turbopack_context__.k.register(_c1, "Table");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=Table.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/table/Table.js [app-client] (ecmascript) <export default as Table>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Table",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/table/Table.js [app-client] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/pagination/PaginationItem.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Item",
    ()=>Item,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
const Item = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = (_a, ref)=>{
    var { children, as: Component = "button", selected = false, className, page, "data-color": color } = _a, rest = __rest(_a, [
        "children",
        "as",
        "selected",
        "className",
        "page",
        "data-color"
    ]);
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], Object.assign({
        as: Component,
        variant: "tertiary",
        "data-color": color,
        "aria-current": selected,
        "data-pressed": selected,
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-pagination__item", className, {
            "aksel-pagination__item--selected": selected
        }),
        "data-page": page,
        /* TODO: Breaking change to remove since it's in use by some applications. Add to future major version. */ page: page
    }, Component === "button" && {
        type: "button"
    }, rest), children);
});
_c1 = Item;
const __TURBOPACK__default__export__ = Item;
var _c, _c1;
__turbopack_context__.k.register(_c, "Item$forwardRef");
__turbopack_context__.k.register(_c1, "Item");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=PaginationItem.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/pagination/Pagination.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Pagination",
    ()=>Pagination,
    "default",
    ()=>__TURBOPACK__default__export__,
    "getSteps",
    ()=>getSteps
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$ChevronLeft$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeftIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/ChevronLeft.js [app-client] (ecmascript) <export default as ChevronLeftIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$ChevronRight$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRightIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+aksel-icons@8.0.1/node_modules/@navikt/aksel-icons/dist/react/esm/ChevronRight.js [app-client] (ecmascript) <export default as ChevronRightIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/BodyShort.js [app-client] (ecmascript) <export default as BodyShort>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$Heading$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Heading$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/typography/Heading.js [app-client] (ecmascript) <export default as Heading>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/hooks/useId.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/className.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$i18n$2f$i18n$2e$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/util/i18n/i18n.hooks.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$pagination$2f$PaginationItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/pagination/PaginationItem.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
;
;
;
;
const getSteps = ({ page, count, boundaryCount = 1, siblingCount = 1 })=>{
    var _a, _b;
    const range = (start, end)=>Array.from({
            length: end - start + 1
        }, (_, i)=>start + i);
    if (count <= (boundaryCount + siblingCount) * 2 + 3) return range(1, count);
    const startPages = range(1, boundaryCount);
    const endPages = range(count - boundaryCount + 1, count);
    const siblingsStart = Math.max(Math.min(page - siblingCount, count - boundaryCount - siblingCount * 2 - 1), boundaryCount + 2);
    const siblingsEnd = siblingsStart + siblingCount * 2;
    return [
        ...startPages,
        siblingsStart - ((_a = startPages[startPages.length - 1]) !== null && _a !== void 0 ? _a : 0) === 2 ? siblingsStart - 1 : "ellipsis",
        ...range(siblingsStart, siblingsEnd),
        ((_b = endPages[0]) !== null && _b !== void 0 ? _b : count + 1) - siblingsEnd === 2 ? siblingsEnd + 1 : "ellipsis",
        ...endPages
    ];
};
const Pagination = /*#__PURE__*/ _s((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = _s((_a, ref)=>{
    _s();
    var { page, onPageChange, count, boundaryCount = 1, siblingCount = 1, className, size = "medium", prevNextTexts = false, srHeading, "aria-labelledby": ariaLabelledBy, renderItem: Item = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$pagination$2f$PaginationItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], "data-color": color = "neutral" } = _a, rest = __rest(_a, [
        "page",
        "onPageChange",
        "count",
        "boundaryCount",
        "siblingCount",
        "className",
        "size",
        "prevNextTexts",
        "srHeading",
        "aria-labelledby",
        "renderItem",
        "data-color"
    ]);
    const headingId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])();
    const translate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$i18n$2f$i18n$2e$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useI18n"])("Pagination");
    if (page < 1) {
        console.error("page cannot be less than 1");
        return null;
    }
    if (count < 1) {
        console.error("count cannot be less than 1");
        return null;
    }
    if (boundaryCount < 0) {
        console.error("boundaryCount cannot be less than 0");
        return null;
    }
    if (siblingCount < 0) {
        console.error("siblingCount cannot be less than 0");
        return null;
    }
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("nav", Object.assign({
        ref: ref
    }, rest, {
        "data-color": color,
        "aria-labelledby": srHeading ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])(headingId, ariaLabelledBy) : ariaLabelledBy,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])("aksel-pagination", `aksel-pagination--${size}`, className)
    }), srHeading && /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$Heading$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Heading$3e$__["Heading"], {
        size: "xsmall",
        visuallyHidden: true,
        as: srHeading.tag,
        id: headingId
    }, srHeading.text), /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("ul", {
        className: "aksel-pagination__list"
    }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("li", null, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(Item, {
        "data-color": color,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])({
            "aksel-pagination--invisible": page === 1
        }),
        disabled: page === 1,
        onClick: ()=>onPageChange === null || onPageChange === void 0 ? void 0 : onPageChange(page - 1),
        page: page - 1,
        size: size,
        icon: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$ChevronLeft$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeftIcon$3e$__["ChevronLeftIcon"], Object.assign({}, prevNextTexts ? {
            "aria-hidden": true
        } : {
            title: translate("previous")
        }))
    }, prevNextTexts && translate("previous"))), getSteps({
        page,
        count,
        siblingCount,
        boundaryCount
    }).map((step, i)=>{
        const n = Number(step);
        return Number.isNaN(n) ? /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("li", {
            className: "aksel-pagination__ellipsis",
            key: `${step}${i}`
        }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$typography$2f$BodyShort$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BodyShort$3e$__["BodyShort"], {
            size: size === "xsmall" ? "small" : size,
            as: "span"
        }, "...")) : /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("li", {
            key: step
        }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(Item, {
            "data-color": color,
            /* Remember to update RenderItemProps if you make changes to props sent into Item */ onClick: ()=>onPageChange === null || onPageChange === void 0 ? void 0 : onPageChange(n),
            selected: page === n,
            page: n,
            size: size
        }, n));
    }), /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("li", null, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(Item, {
        "data-color": color,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$className$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])({
            "aksel-pagination--invisible": page === count
        }),
        disabled: page === count,
        onClick: ()=>onPageChange === null || onPageChange === void 0 ? void 0 : onPageChange(page + 1),
        page: page + 1,
        size: size,
        icon: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$aksel$2d$icons$40$8$2e$0$2e$1$2f$node_modules$2f40$navikt$2f$aksel$2d$icons$2f$dist$2f$react$2f$esm$2f$ChevronRight$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRightIcon$3e$__["ChevronRightIcon"], Object.assign({}, prevNextTexts ? {
            "aria-hidden": true
        } : {
            title: translate("next")
        })),
        iconPosition: "right"
    }, prevNextTexts && translate("next")))));
}, "PUPhiwHirPfcsB/BOUEfKDqHwHU=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$i18n$2f$i18n$2e$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useI18n"]
    ];
})), "PUPhiwHirPfcsB/BOUEfKDqHwHU=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$hooks$2f$useId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$util$2f$i18n$2f$i18n$2e$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useI18n"]
    ];
});
_c1 = Pagination;
Pagination.Item = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$pagination$2f$PaginationItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
const __TURBOPACK__default__export__ = Pagination;
var _c, _c1;
__turbopack_context__.k.register(_c, "Pagination$forwardRef");
__turbopack_context__.k.register(_c1, "Pagination");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=Pagination.js.map
}),
"[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/pagination/Pagination.js [app-client] (ecmascript) <export default as Pagination>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Pagination",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$pagination$2f$Pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$navikt$2b$ds$2d$react$40$8$2e$0$2e$1_$40$types$2b$react$40$19$2e$2$2e$9_react$2d$dom$40$19$2e$2$2e$1_react$40$19$2e$2$2e$1_$5f$react$40$19$2e$2$2e$1$2f$node_modules$2f40$navikt$2f$ds$2d$react$2f$esm$2f$pagination$2f$Pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@navikt+ds-react@8.0.1_@types+react@19.2.9_react-dom@19.2.1_react@19.2.1__react@19.2.1/node_modules/@navikt/ds-react/esm/pagination/Pagination.js [app-client] (ecmascript)");
}),
]);

//# sourceMappingURL=4722a_%40navikt_ds-react_esm_0bd29425._.js.map