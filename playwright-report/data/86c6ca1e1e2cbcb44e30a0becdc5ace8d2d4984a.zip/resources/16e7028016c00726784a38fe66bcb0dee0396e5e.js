(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/app/api/stilling/standardsok/useBrukersStandardsøk.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "brukerStandardSøkEndepunkt",
    ()=>brukerStandardSøkEndepunkt,
    "brukerStandardSøkMSWHandler",
    ()=>brukerStandardSøkMSWHandler,
    "useUseBrukerStandardSøk",
    ()=>useUseBrukerStandardSøk
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/api-routes.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRGet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/useSWRGet.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/http.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/HttpResponse.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zod@4.0.17/node_modules/zod/v4/classic/external.js [app-client] (ecmascript) <export * as z>");
var _s = __turbopack_context__.k.signature();
;
;
;
;
const brukerStandardSøkEndepunkt = `${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StillingAPI"].internUrl}/standardsok`;
const BrukerStandardSøkSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    søk: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    navIdent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    tidspunkt: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string()
});
const useUseBrukerStandardSøk = ()=>{
    _s();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRGet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSWRGet"])(brukerStandardSøkEndepunkt, BrukerStandardSøkSchema, {
        fetchOptions: {
            skjulFeilmelding: true
        },
        revalidateOnFocus: false,
        revalidateOnReconnect: false,
        refreshInterval: 0,
        dedupingInterval: 0,
        shouldRetryOnError: false
    });
};
_s(useUseBrukerStandardSøk, "K4Y6k2WDwBHXduaV5Y5moFGSmko=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRGet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSWRGet"]
    ];
});
const brukerStandardSøkMSWHandler = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].get(brukerStandardSøkEndepunkt, ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json({
        søk: 'brukStandardsok=true&publisert=intern&statuser=publisert%2Cutl%C3%B8pt%2Cstoppet&fylker=33&kommuner=3301',
        navIdent: 'Z993141',
        tidspunkt: '2025-01-22T21:35:39.691808'
    }));
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/stillings-sok/elastic-search/elasticSearchQueryBuilder.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ElasticSearchQueryBuilder",
    ()=>ElasticSearchQueryBuilder,
    "maksAntallTreffPerSøk",
    ()=>maksAntallTreffPerSøk,
    "regnUtFørsteTreffFra",
    ()=>regnUtFørsteTreffFra
]);
const maksAntallTreffPerSøk = 20;
const regnUtFørsteTreffFra = (side, antallTreffPerSide)=>side * antallTreffPerSide - antallTreffPerSide;
class ElasticSearchQueryBuilder {
    filterClauses = [];
    mustClauses = [];
    shouldClauses = [];
    mustNotClauses = [];
    sorting = [];
    aggregations = {};
    postFilterClause = null;
    minimumShouldMatch;
    addFilter(clauseOrField, value) {
        if (typeof clauseOrField === 'string' && value !== undefined) {
            // Når kalt med felt-navn og verdi
            this.filterClauses.push({
                term: {
                    [clauseOrField]: value
                }
            });
        } else {
            // Når kalt med eksisterende clause objekt
            const clause = clauseOrField;
            if (Array.isArray(clause)) {
                this.filterClauses.push(...clause);
            } else if (clause) {
                this.filterClauses.push(clause);
            }
        }
        return this;
    }
    addMust(clauseOrField, value) {
        if (typeof clauseOrField === 'string' && value !== undefined) {
            // Når kalt med felt-navn og verdi
            this.mustClauses.push({
                term: {
                    [clauseOrField]: value
                }
            });
        } else {
            // Når kalt med eksisterende clause objekt
            const clause = clauseOrField;
            if (Array.isArray(clause)) {
                this.mustClauses.push(...clause);
            } else if (clause) {
                this.mustClauses.push(clause);
            }
        }
        return this;
    }
    addShould(clauseOrField, value) {
        if (typeof clauseOrField === 'string' && value !== undefined) {
            // Når kalt med felt-navn og verdi
            this.shouldClauses.push({
                term: {
                    [clauseOrField]: value
                }
            });
        } else {
            // Når kalt med eksisterende clause objekt
            const clause = clauseOrField;
            if (Array.isArray(clause)) {
                this.shouldClauses.push(...clause);
            } else if (clause) {
                this.shouldClauses.push(clause);
            }
        }
        return this;
    }
    addMustNot(clauseOrField, value) {
        if (typeof clauseOrField === 'string' && value !== undefined) {
            // Når kalt med felt-navn og verdi
            this.mustNotClauses.push({
                term: {
                    [clauseOrField]: value
                }
            });
        } else {
            // Når kalt med eksisterende clause objekt
            const clause = clauseOrField;
            if (Array.isArray(clause)) {
                this.mustNotClauses.push(...clause);
            } else if (clause) {
                this.mustNotClauses.push(clause);
            }
        }
        return this;
    }
    /**
   * Legger til exists-clause som filter (MÅ ha feltet)
   */ addExists(field) {
        this.filterClauses.push({
            exists: {
                field: field
            }
        });
        return this;
    }
    /**
   * Legger til range-clause som filter
   */ addRange(field, rangeConditions) {
        this.filterClauses.push({
            range: {
                [field]: rangeConditions
            }
        });
        return this;
    }
    /**
   * Legger til en kompleks bool-query som filter
   */ addBoolFilter(boolQuery) {
        this.filterClauses.push({
            bool: boolQuery
        });
        return this;
    }
    /**
   * Setter minimum_should_match for should-clauses
   */ setMinimumShouldMatch(minimumShouldMatch) {
        this.minimumShouldMatch = minimumShouldMatch;
        return this;
    }
    /**
   * Legger til simple_query_string som should-clause
   */ addSimpleQueryString(query, fields, defaultOperator = 'and') {
        if (query && query.length > 0) {
            this.shouldClauses.push({
                simple_query_string: {
                    query: query,
                    fields: fields,
                    default_operator: defaultOperator
                }
            });
        }
        return this;
    }
    /**
   * Legger til fritekst-søk med prosessert søkestreng
   * Tar imot en allerede prosessert søkestreng og bygger simple_query_string direkte
   */ addFritekstSøk(fritekst, felt) {
        if (!fritekst || fritekst.length < 1) return this;
        const feltManSkalSøkeI = [];
        if (felt === 'tekstfelter') {
            feltManSkalSøkeI.push('stilling.adtext_no^0.5', 'stilling.uuid', 'stilling.tittel', 'stilling.employer.name', 'stilling.properties.jobtitle', 'stilling.properties.arbeidsplassenoccupation', 'stilling.properties.keywords');
        } else {
            feltManSkalSøkeI.push('stilling.adtext_no^0.5', 'stilling.uuid', 'stilling.tittel', 'stilling.annonsenr', 'stilling.employer.name', 'stilling.employer.orgnr', 'stilling.properties.jobtitle', 'stilling.properties.arbeidsplassenoccupation', 'stilling.properties.keywords');
        }
        this.shouldClauses.push({
            simple_query_string: {
                query: fritekst,
                fields: feltManSkalSøkeI,
                default_operator: 'and'
            }
        });
        return this;
    }
    /**
   * Setter sorteringsalternativer
   */ setSorting(sort) {
        this.sorting = sort;
        return this;
    }
    /**
   * Setter aggregering
   */ setAggregations(aggs) {
        this.aggregations = aggs;
        return this;
    }
    /**
   * Setter post_filter (påvirker bare treff, ikke aggregasjoner)
   */ setPostFilter(clause) {
        this.postFilterClause = clause;
        return this;
    }
    /**
   * Bygger standard aggregering som alltid skal være med
   * Inkluderer fritekst-søk i should-delen hvis det finnes fritekst
   * Matcher den fungerende implementasjonen fra stillingssøkElasticSearchQuery
   */ buildStandardAggregation(navIdent, kontorEnhetId, fritekstSøkestreng, opts) {
        // Hent hele bool-strukturen for bruk i aggregeringer
        const allFilters = this.buildFilters();
        // Fjern portefølje-filtre (skal ikke tas med i tab-aggregatene siden hver tab definerer porteføljen selv)
        const portfolioFields = new Set([
            'stilling.administration.navIdent',
            'stillingsinfo.eierNavident',
            'stillingsinfo.eierNavKontorEnhetId'
        ]);
        // Rekursiv pruning av alle clauses som refererer til portefølje-felt
        const pruneClause = (clause)=>{
            if (!clause) return clause;
            // Enkel term
            if (clause.term && typeof clause.term === 'object') {
                const fieldName = Object.keys(clause.term)[0];
                if (portfolioFields.has(fieldName)) return null; // fjern
                return clause; // behold
            }
            // Fjern exists stillingsinfo (INTERN-spesifikt) fra "globale" filtre, vi bygger dette eksplisitt per fane
            if (clause.exists && clause.exists.field === 'stillingsinfo') {
                return null;
            }
            // Bool-struktur
            if (clause.bool && typeof clause.bool === 'object') {
                const b = clause.bool;
                const keys = [
                    'filter',
                    'must',
                    'should',
                    'must_not'
                ];
                const newBool = {};
                // Identifiser publiserings-bool (must inneholder DONE + publishedByAdmin + range published) og must_not REJECTED/DELETED
                const isPubliseringsBool = ()=>{
                    if (!Array.isArray(b.must)) return false;
                    const hasDone = b.must.some((m)=>m.term && m.term['stilling.administration.status'] === 'DONE');
                    const hasPublishedByAdmin = b.must.some((m)=>m.exists && m.exists.field === 'stilling.publishedByAdmin');
                    const hasRange = b.must.some((m)=>m.range && m.range['stilling.published']);
                    const hasRejectedDeleted = Array.isArray(b.must_not) && b.must_not.some((mn)=>mn.term && (mn.term['stilling.status'] === 'REJECTED' || mn.term['stilling.status'] === 'DELETED'));
                    return hasDone && hasPublishedByAdmin && hasRange && hasRejectedDeleted;
                };
                if (isPubliseringsBool()) {
                    return null; // fjern for å sikre konsistent portefølje-agnostisk basis
                }
                keys.forEach((k)=>{
                    if (Array.isArray(b[k])) {
                        const pruned = b[k].map((c)=>pruneClause(c)).filter((c)=>!!c);
                        if (pruned.length > 0) newBool[k] = pruned;
                    }
                });
                // Behold minimum_should_match kun hvis should fortsatt finnes
                if (b.minimum_should_match && newBool.should) {
                    newBool.minimum_should_match = b.minimum_should_match;
                }
                // Hvis bool ble tom -> fjern hele
                if (Object.keys(newBool).length === 0) return null;
                return {
                    bool: newBool
                };
            }
            // Andre clause-typer (range, exists, simple_query_string etc.) beholdes
            return clause;
        };
        const pruneTopLevelArrays = (filtersObj)=>{
            if (!filtersObj || Object.keys(filtersObj).length === 0) return filtersObj;
            const cleaned = {};
            [
                'filter',
                'must',
                'should',
                'must_not'
            ].forEach((k)=>{
                if (Array.isArray(filtersObj[k])) {
                    const pruned = filtersObj[k].map((c)=>pruneClause(c)).filter((c)=>!!c);
                    if (pruned.length > 0) cleaned[k] = pruned;
                }
            });
            if (filtersObj.minimum_should_match && cleaned.should) {
                cleaned.minimum_should_match = filtersObj.minimum_should_match;
            }
            return cleaned;
        };
        const allFiltersWithoutPortfolio = opts?.includePortfolioInCounts ? allFilters // ta med portefølje-feltene i counts
         : pruneTopLevelArrays(allFilters); // gammel oppførsel
        // removeGeografiNested fjernet: område skal nå reflektere valgt område direkte
        // Fjern status-termer for status-aggregeringen slik at hver status viser total antall uavhengig av valg av andre statuser
        const removeStatusTerms = (filtersObj)=>{
            if (!filtersObj || Object.keys(filtersObj).length === 0) return filtersObj;
            const cleaned = {};
            // Hjelper: identifiser publiserings-kriterier (uten REJECTED/DELETED) slik de kan dukke opp fra statusQuery (STOPPED/UTLØPT)
            const erPubliseringsMustSet = (mustArray)=>{
                if (!Array.isArray(mustArray)) return false;
                // Krav: inneholder alle tre: administration.status DONE, exists publishedByAdmin, range published <= now/d
                let hasDone = false;
                let hasExists = false;
                let hasRange = false;
                for (const m of mustArray){
                    if (m?.term && m.term['stilling.administration.status'] === 'DONE') hasDone = true;
                    else if (m?.exists?.field === 'stilling.publishedByAdmin') hasExists = true;
                    else if (m?.range && m.range['stilling.published']) hasRange = true;
                    else return false; // Inneholder annet -> ikke rent publiseringssett
                }
                return hasDone && hasExists && hasRange && mustArray.length === 3;
            };
            [
                'filter',
                'must',
                'should',
                'must_not'
            ].forEach((k)=>{
                if (Array.isArray(filtersObj[k])) {
                    const pruned = filtersObj[k].map((c)=>{
                        if (c && c.term && c.term['stilling.status']) {
                            return null; // fjern direkte status-term
                        }
                        if (c && c.terms && c.terms['stilling.status']) {
                            return null; // fjern terms-variant
                        }
                        if (c && c.bool) {
                            const inner = removeStatusTerms(c.bool);
                            // Hvis det kun gjenstår et must-array med publiseringskriterier, fjern hele bool'en for å hindre inkonsistente status-tall
                            if (inner && Object.keys(inner).length === 1 && inner.must && erPubliseringsMustSet(inner.must)) {
                                return null;
                            }
                            return Object.keys(inner).length === 0 ? null : {
                                bool: inner
                            };
                        }
                        return c;
                    }).filter((c)=>!!c);
                    if (pruned.length > 0) cleaned[k] = pruned;
                }
            });
            if (filtersObj.minimum_should_match && cleaned.should) {
                cleaned.minimum_should_match = filtersObj.minimum_should_match;
            }
            return cleaned;
        };
        const allFiltersWithoutStatus = removeStatusTerms(allFiltersWithoutPortfolio);
        // Hvis status er valgt legges dette til kun i geografi-aggregasjonen (område skal ta høyde for valgt status)
        // Status-valg legges i post_filter for treff, men aggregeringer ignorerer post_filter.
        // Vi gjenbruker post_filter-clausen dersom den filtrerer på stilling.status for å få korrekte område-tall.
        const statusPostFilterClause = this.postFilterClause && typeof this.postFilterClause === 'object' && JSON.stringify(this.postFilterClause).includes('"stilling.status"') ? this.postFilterClause : null;
        return {
            globalAggregering: {
                global: {},
                aggs: {
                    // Visningsstatus-facet (Alle visningsstatuser fra VisningsStatus enum)
                    visningsstatus: {
                        // Beholder andre filtre (uten status) i container-filteret
                        filter: {
                            bool: {
                                filter: [
                                    ...allFiltersWithoutStatus && Object.keys(allFiltersWithoutStatus).length > 0 ? [
                                        {
                                            bool: allFiltersWithoutStatus
                                        }
                                    ] : []
                                ]
                            }
                        },
                        aggs: {
                            // Eksplicit definisjon av buckets som speiler visStillingsDataInfo logikken
                            koder: {
                                filters: {
                                    filters: {
                                        'Ikke publisert': {
                                            bool: {
                                                must: [
                                                    {
                                                        term: {
                                                            'stilling.status': 'INACTIVE'
                                                        }
                                                    }
                                                ],
                                                must_not: [
                                                    {
                                                        exists: {
                                                            field: 'stilling.publishedByAdmin'
                                                        }
                                                    },
                                                    {
                                                        term: {
                                                            'stilling.status': 'REJECTED'
                                                        }
                                                    },
                                                    {
                                                        term: {
                                                            'stilling.status': 'DELETED'
                                                        }
                                                    }
                                                ]
                                            }
                                        },
                                        'Åpen for søkere': {
                                            bool: {
                                                must: [
                                                    {
                                                        term: {
                                                            'stilling.status': 'ACTIVE'
                                                        }
                                                    },
                                                    {
                                                        term: {
                                                            'stilling.administration.status': 'DONE'
                                                        }
                                                    },
                                                    {
                                                        exists: {
                                                            field: 'stilling.publishedByAdmin'
                                                        }
                                                    },
                                                    {
                                                        range: {
                                                            'stilling.published': {
                                                                lte: 'now/d'
                                                            }
                                                        }
                                                    }
                                                ],
                                                must_not: [
                                                    {
                                                        term: {
                                                            'stilling.status': 'REJECTED'
                                                        }
                                                    },
                                                    {
                                                        term: {
                                                            'stilling.status': 'DELETED'
                                                        }
                                                    }
                                                ]
                                            }
                                        },
                                        'Stengt for søkere': {
                                            bool: {
                                                must: [
                                                    {
                                                        term: {
                                                            'stilling.status': 'INACTIVE'
                                                        }
                                                    },
                                                    {
                                                        exists: {
                                                            field: 'stilling.publishedByAdmin'
                                                        }
                                                    },
                                                    {
                                                        range: {
                                                            'stilling.published': {
                                                                lte: 'now/d'
                                                            }
                                                        }
                                                    }
                                                ],
                                                must_not: [
                                                    {
                                                        range: {
                                                            'stilling.expires': {
                                                                lt: 'now/d'
                                                            }
                                                        }
                                                    },
                                                    {
                                                        term: {
                                                            'stilling.status': 'REJECTED'
                                                        }
                                                    },
                                                    {
                                                        term: {
                                                            'stilling.status': 'DELETED'
                                                        }
                                                    }
                                                ]
                                            }
                                        },
                                        'Utløpt - Stengt for søkere': {
                                            bool: {
                                                must: [
                                                    {
                                                        term: {
                                                            'stilling.status': 'INACTIVE'
                                                        }
                                                    },
                                                    {
                                                        range: {
                                                            'stilling.expires': {
                                                                lt: 'now/d'
                                                            }
                                                        }
                                                    },
                                                    {
                                                        exists: {
                                                            field: 'stilling.publishedByAdmin'
                                                        }
                                                    },
                                                    {
                                                        range: {
                                                            'stilling.published': {
                                                                lte: 'now/d'
                                                            }
                                                        }
                                                    }
                                                ],
                                                must_not: [
                                                    {
                                                        term: {
                                                            'stilling.status': 'REJECTED'
                                                        }
                                                    },
                                                    {
                                                        term: {
                                                            'stilling.status': 'DELETED'
                                                        }
                                                    }
                                                ]
                                            }
                                        },
                                        Fullført: {
                                            bool: {
                                                must: [
                                                    {
                                                        term: {
                                                            'stilling.status': 'STOPPED'
                                                        }
                                                    },
                                                    {
                                                        term: {
                                                            'stilling.administration.status': 'DONE'
                                                        }
                                                    },
                                                    {
                                                        exists: {
                                                            field: 'stilling.publishedByAdmin'
                                                        }
                                                    },
                                                    {
                                                        range: {
                                                            'stilling.published': {
                                                                lte: 'now/d'
                                                            }
                                                        }
                                                    }
                                                ],
                                                must_not: [
                                                    {
                                                        term: {
                                                            'stilling.status': 'REJECTED'
                                                        }
                                                    },
                                                    {
                                                        term: {
                                                            'stilling.status': 'DELETED'
                                                        }
                                                    }
                                                ]
                                            }
                                        },
                                        Avbrutt: {
                                            bool: {
                                                must: [
                                                    {
                                                        term: {
                                                            'stilling.status': 'DELETED'
                                                        }
                                                    }
                                                ]
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    },
                    // Kategori-facet (Stilling / Jobbmesse)
                    kategori: {
                        filters: {
                            filters: {
                                stilling: {
                                    bool: {
                                        filter: [
                                            ...allFiltersWithoutPortfolio && Object.keys(allFiltersWithoutPortfolio).length > 0 ? [
                                                {
                                                    bool: allFiltersWithoutPortfolio
                                                }
                                            ] : [],
                                            {
                                                bool: {
                                                    must_not: [
                                                        {
                                                            term: {
                                                                'stillingsinfo.stillingskategori': 'JOBBMESSE'
                                                            }
                                                        },
                                                        {
                                                            term: {
                                                                'stillingsinfo.stillingskategori': 'ARBEIDSTRENING'
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                },
                                jobbmesse: {
                                    bool: {
                                        filter: [
                                            ...allFiltersWithoutPortfolio && Object.keys(allFiltersWithoutPortfolio).length > 0 ? [
                                                {
                                                    bool: allFiltersWithoutPortfolio
                                                }
                                            ] : [],
                                            {
                                                term: {
                                                    'stillingsinfo.stillingskategori': 'JOBBMESSE'
                                                }
                                            }
                                        ]
                                    }
                                }
                            }
                        }
                    },
                    // Rå buckets for alle stillingskategorier (inkl. FORMIDLING, ARBEIDSTRENING, JOBBMESSE, osv.) – respekterer valgte filtre
                    stillingskategori: {
                        filter: {
                            bool: {
                                filter: [
                                    ...allFiltersWithoutPortfolio && Object.keys(allFiltersWithoutPortfolio).length > 0 ? [
                                        {
                                            bool: allFiltersWithoutPortfolio
                                        }
                                    ] : []
                                ]
                            }
                        },
                        aggs: {
                            koder: {
                                terms: {
                                    field: 'stillingsinfo.stillingskategori',
                                    size: 20,
                                    order: {
                                        _key: 'asc'
                                    }
                                }
                            }
                        }
                    },
                    // Geografi-facets (fylker og kommuner) – teller per område gitt andre filtre (IGNORERER valgt område)
                    geografi: {
                        filter: {
                            bool: {
                                filter: [
                                    // Endret: område skal nå reflektere valgt område også, så vi bruker fullstendig filter-sett
                                    ...allFiltersWithoutPortfolio && Object.keys(allFiltersWithoutPortfolio).length > 0 ? [
                                        {
                                            bool: allFiltersWithoutPortfolio
                                        }
                                    ] : [],
                                    // Inkluder valgt status hvis satt (status legges ellers kun i post_filter)
                                    ...statusPostFilterClause ? [
                                        statusPostFilterClause
                                    ] : []
                                ]
                            }
                        },
                        aggs: {
                            nested_geografi: {
                                nested: {
                                    path: 'stilling.locations'
                                },
                                aggs: {
                                    fylker: {
                                        terms: {
                                            field: 'stilling.locations.countyCode',
                                            size: 50,
                                            order: {
                                                _key: 'asc'
                                            }
                                        },
                                        aggs: {
                                            // Unik telling av stillinger (parent docs) som har minst én location i dette fylket
                                            stillinger: {
                                                reverse_nested: {},
                                                aggs: {
                                                    unique_count: {
                                                        cardinality: {
                                                            field: 'stilling.uuid'
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    },
                                    kommuner: {
                                        terms: {
                                            field: 'stilling.locations.municipalCode',
                                            size: 200,
                                            order: {
                                                _key: 'asc'
                                            }
                                        }
                                    },
                                    // Ekstra agg: dokumenter uten fylkeskode (countyCode mangler eller tom streng) grupperes på county.keyword
                                    // slik at vi kan legge disse til korrekt fylke-count (eks: AGDER uten kode skal inn under 42)
                                    utenCountyCode: {
                                        filter: {
                                            bool: {
                                                should: [
                                                    {
                                                        bool: {
                                                            must_not: [
                                                                {
                                                                    exists: {
                                                                        field: 'stilling.locations.countyCode'
                                                                    }
                                                                }
                                                            ]
                                                        }
                                                    },
                                                    {
                                                        term: {
                                                            'stilling.locations.countyCode': ''
                                                        }
                                                    }
                                                ],
                                                minimum_should_match: 1
                                            }
                                        },
                                        aggs: {
                                            fylker: {
                                                terms: {
                                                    field: 'stilling.locations.county.keyword',
                                                    size: 20,
                                                    order: {
                                                        _key: 'asc'
                                                    }
                                                },
                                                aggs: {
                                                    // Parent-docs for missing countyCode (brukes for å unngå dobbelttelling hvis samme stilling også har kode)
                                                    stillinger: {
                                                        reverse_nested: {},
                                                        aggs: {
                                                            unique_count: {
                                                                cardinality: {
                                                                    field: 'stilling.uuid'
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        };
    }
    /**
   * Setter standard aggregering som alltid skal være med
   * Inkluderer fritekst-søk hvis det finnes
   */ setStandardAggregation(navIdent, kontorEnhetId, fritekst, opts) {
        const fritekstSøkestreng = fritekst && fritekst.length > 0 ? fritekst.join(' ') : undefined;
        const standardAggs = this.buildStandardAggregation(navIdent, kontorEnhetId, fritekstSøkestreng, opts);
        // Kombiner med eksisterende aggregeringer
        this.aggregations = {
            ...this.aggregations,
            ...standardAggs
        };
        return this;
    }
    /**
   * Bygger filter-delen av query (brukes når det er filter-kriterier)
   */ buildFilters() {
        const filters = {};
        if (this.filterClauses.length > 0) {
            filters.filter = this.filterClauses;
        }
        if (this.mustClauses.length > 0) {
            filters.must = this.mustClauses;
        }
        if (this.shouldClauses.length > 0) {
            filters.should = this.shouldClauses;
            // Bruk eksplisitt satt minimum_should_match hvis den finnes
            if (this.minimumShouldMatch !== undefined) {
                filters.minimum_should_match = this.minimumShouldMatch;
            } else if (this.mustClauses.length === 0 && this.filterClauses.length === 0) {
                // Hvis vi har should-clauses, krever vi at minst én matcher (kun hvis ingen must/filter)
                filters.minimum_should_match = 1;
            }
        }
        if (this.mustNotClauses.length > 0) {
            filters.must_not = this.mustNotClauses;
        }
        return filters;
    }
    /**
   * Bygger den endelige Elasticsearch query
   */ build(size = maksAntallTreffPerSøk, from = 0) {
        const filters = this.buildFilters();
        const query = {
            size,
            from,
            track_total_hits: true
        };
        // Hvis vi har noen filter/must/should/must_not clauses
        if (Object.keys(filters).length > 0) {
            query.query = {
                bool: filters
            };
        } else {
            // Hvis ingen spesifikke filtre, match alle dokumenter
            query.query = {
                match_all: {}
            };
        }
        // Legg til sortering hvis spesifisert
        if (this.sorting && this.sorting.length > 0) {
            // Hvis det bare er ett sorteringselement, bruk det direkte
            // Hvis det er flere, bruk array
            query.sort = this.sorting.length === 1 ? this.sorting[0] : this.sorting;
        }
        // Legg til aggregering hvis spesifisert
        if (Object.keys(this.aggregations).length > 0) {
            query.aggs = this.aggregations;
        }
        if (this.postFilterClause) {
            query.post_filter = this.postFilterClause;
        }
        return query;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/stillings-sok/byggKombinertQuery.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "byggKombinertQuery",
    ()=>byggKombinertQuery
]);
'use client';
function byggKombinertQuery(treff, aggs) {
    const treffClone = {
        ...treff || {}
    };
    const aggsNode = aggs?.aggs || aggs?.aggregations || {};
    const merged = {
        ...treffClone,
        aggs: aggsNode
    };
    if (merged.track_total_hits === undefined) merged.track_total_hits = true;
    return merged;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/stillings-sok/mocks/mockStillingssøk.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "mockEtterregistreringssøk",
    ()=>mockEtterregistreringssøk,
    "mockStillingssøk",
    ()=>mockStillingssøk
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@faker-js+faker@9.9.0/node_modules/@faker-js/faker/dist/chunk-RHFAIXC4.js [app-client] (ecmascript) <export b as faker>");
;
const createMockHit = (props)=>({
        _index: 'stilling_5',
        _type: '_doc',
        _id: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].string.uuid(),
        _score: null,
        _source: {
            stilling: {
                uuid: props.id ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].string.uuid(),
                annonsenr: `R${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].number.int({
                    min: 1000,
                    max: 9999
                })}`,
                status: props.status || 'ACTIVE',
                privacy: props.privacy || 'INTERNAL_NOT_SHOWN',
                published: props.published || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].date.past().toISOString(),
                publishedByAdmin: props.publishedByAdmin !== undefined ? props.publishedByAdmin : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].date.future().toISOString(),
                expires: props.expires || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].date.future().toISOString(),
                created: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].date.recent().toISOString(),
                updated: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].date.recent().toISOString(),
                employer: {
                    name: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].company.name(),
                    publicName: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].company.name(),
                    orgnr: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].number.int({
                        min: 100000000,
                        max: 999999999
                    }).toString(),
                    parentOrgnr: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].number.int({
                        min: 100000000,
                        max: 999999999
                    }).toString(),
                    orgform: 'BEDR'
                },
                categories: [],
                source: props.source || 'DIR',
                medium: props.source || 'DIR',
                businessName: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].company.name(),
                locations: [
                    {
                        address: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].location.streetAddress(),
                        postalCode: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].location.zipCode(),
                        city: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].location.city(),
                        county: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].location.county(),
                        // countyCode: '1337',
                        municipal: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].location.state(),
                        municipalCode: '1337',
                        latitue: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].location.latitude(),
                        longitude: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].location.longitude(),
                        country: 'NORGE'
                    }
                ],
                reference: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].string.uuid(),
                administration: {
                    status: props.adStatus || 'DONE',
                    remarks: [],
                    comments: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].lorem.sentence(),
                    reportee: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].person.fullName(),
                    navIdent: props.eier || `Z${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].number.int({
                        min: 100000,
                        max: 999999
                    })}`
                },
                properties: {
                    extent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].helpers.arrayElement([
                        'Heltid',
                        'Deltid'
                    ]),
                    workhours: [
                        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].helpers.arrayElement([
                            'Dagtid',
                            'Kveld',
                            'Natt'
                        ])
                    ],
                    workday: [
                        'Ukedager'
                    ],
                    applicationdue: 'Snarest',
                    jobtitle: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].person.jobTitle(),
                    positioncount: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].number.int({
                        min: 1,
                        max: 10
                    }),
                    engagementtype: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].helpers.arrayElement([
                        'Fast',
                        'Midlertidig',
                        'Vikariat'
                    ]),
                    classification_styrk08_score: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].number.float({
                        min: 0,
                        max: 1
                    }),
                    adtext: `<p>${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].lorem.paragraphs(3)}</p>`,
                    classification_styrk08_code: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].number.int({
                        min: 1000,
                        max: 9999
                    }),
                    searchtags: [
                        {
                            label: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].person.jobType(),
                            score: 0
                        },
                        {
                            label: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].person.jobType(),
                            score: 0
                        }
                    ],
                    classification_esco_code: `http://data.europa.eu/esco/isco/c${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].number.int({
                        min: 1000,
                        max: 9999
                    })}`,
                    classification_input_source: 'jobtitle',
                    sector: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].helpers.arrayElement([
                        'Privat',
                        'Offentlig'
                    ])
                },
                contacts: [
                    {
                        name: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].person.fullName(),
                        role: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].person.jobTitle(),
                        title: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].person.jobType(),
                        email: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].internet.email(),
                        phone: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].phone.number()
                    }
                ],
                tittel: props.tittel ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].person.jobTitle()
            },
            stillingsinfo: {
                eierNavident: null,
                eierNavn: null,
                notat: null,
                stillingsid: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].string.uuid(),
                stillingsinfoid: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].string.uuid(),
                stillingskategori: props.erJobbmesse ? 'JOBBMESSE' : props.erFormidling ? 'FORMIDLING' : 'STILLING'
            }
        },
        sort: [
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].number.int({
                min: 1000000000000,
                max: 9999999999999
            })
        ]
    });
__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__faker$3e$__["faker"].seed(1337);
// Felles datoer – konsistent med stillingMock.ts
const now = new Date();
const fremtidigDato = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000).toISOString();
const forbiDato = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000).toISOString();
// ──────────────────────────────────────────────────────────
// 6 konsistente tilstander (matcher stillingMock.ts-IDer)
// ──────────────────────────────────────────────────────────
const publisertStilling = createMockHit({
    id: 'publisertStilling',
    eier: 'TestIdent',
    tittel: 'Publisert stilling (intern)',
    status: 'ACTIVE',
    adStatus: 'DONE',
    expires: fremtidigDato
});
const publisertEksternStilling = createMockHit({
    id: 'publisertEksternStilling',
    eier: 'TestIdent',
    tittel: 'Publisert stilling (arbeidsplassen.no)',
    status: 'ACTIVE',
    adStatus: 'DONE',
    privacy: 'SHOW_ALL',
    expires: fremtidigDato
});
const utløptStilling = createMockHit({
    id: 'utloptStilling',
    eier: 'TestIdent',
    tittel: 'Utløpt stilling',
    status: 'INACTIVE',
    adStatus: 'DONE',
    expires: forbiDato
});
const stengtForSøkereStilling = createMockHit({
    id: 'stengtStilling',
    eier: 'TestIdent',
    tittel: 'Stengt for søkere',
    status: 'INACTIVE',
    adStatus: 'PENDING',
    expires: fremtidigDato
});
const slettetStilling = createMockHit({
    id: 'slettetStilling',
    eier: 'TestIdent',
    tittel: 'Slettet stilling',
    status: 'DELETED',
    adStatus: 'DONE'
});
const fullførtStilling = createMockHit({
    id: 'fullfortStilling',
    eier: 'TestIdent',
    tittel: 'Fullført stilling',
    status: 'STOPPED',
    adStatus: 'DONE'
});
// ──────────────────────────────────────────────────────────
// StillingsBanner-spesifikke hits
// ──────────────────────────────────────────────────────────
const bannerForlengOppdrag = createMockHit({
    id: 'bannerForlengOppdrag',
    eier: 'TestIdent',
    tittel: 'Stillingsbanner (Forleng oppdrag)',
    status: 'INACTIVE',
    adStatus: 'DONE',
    expires: forbiDato
});
const bannerÅpneSøkeforslag = createMockHit({
    id: 'bannerApneSokeforslag',
    eier: 'TestIdent',
    tittel: 'Stillingsbanner (Åpne søkeforslag)',
    status: 'INACTIVE',
    adStatus: 'PENDING',
    expires: fremtidigDato
});
// ──────────────────────────────────────────────────────────
// Fullført-banner states
// ──────────────────────────────────────────────────────────
const fullførtBesattLåst = createMockHit({
    id: 'fullfortBesattLast',
    eier: 'TestIdent',
    tittel: 'Fullført banner (Besatt + Låst)',
    status: 'STOPPED',
    adStatus: 'DONE'
});
const fullførtIkkeBesattIkkeLåst = createMockHit({
    id: 'fullfortIkkeBesattIkkeLast',
    eier: 'TestIdent',
    tittel: 'Fullført banner (Ikke besatt + Ikke låst)',
    status: 'STOPPED',
    adStatus: 'DONE'
});
const fullførtIkkeBesattLåst = createMockHit({
    id: 'fullfortIkkeBesattLast',
    eier: 'TestIdent',
    tittel: 'Fullført banner (Ikke besatt + Låst)',
    status: 'STOPPED',
    adStatus: 'DONE'
});
// ──────────────────────────────────────────────────────────
// Utkast (draft)
// ──────────────────────────────────────────────────────────
const utkastStilling = createMockHit({
    id: 'utkastStilling',
    eier: 'TestIdent',
    tittel: 'Utkast stilling',
    status: 'INACTIVE',
    adStatus: 'PENDING',
    publishedByAdmin: null
});
// ──────────────────────────────────────────────────────────
// Legacy-hits for bakoverkompatibilitet
// ──────────────────────────────────────────────────────────
const minStilling = createMockHit({
    eier: 'TestIdent',
    id: 'minStilling',
    status: 'ACTIVE',
    adStatus: 'DONE',
    expires: fremtidigDato
});
const minStillingEkstern = createMockHit({
    eier: 'TestIdent',
    privacy: 'SHOW_ALL',
    source: 'minEksternStilling',
    id: 'minEksternStilling',
    status: 'ACTIVE',
    adStatus: 'DONE',
    expires: fremtidigDato
});
const eksternStilling = createMockHit({
    privacy: 'SHOW_ALL',
    source: 'eksternStilling',
    id: 'eksternStilling',
    status: 'ACTIVE',
    adStatus: 'DONE',
    expires: fremtidigDato
});
// ──────────────────────────────────────────────────────────
// Etterregistreringer (formidlinger) – vises under /etterregistrering
// ──────────────────────────────────────────────────────────
const etterregistrering = createMockHit({
    id: 'etterregistrering',
    eier: 'TestIdent',
    tittel: 'Etterregistrering Formidling',
    status: 'STOPPED',
    adStatus: 'DONE',
    erFormidling: true
});
const etterregistreringÅpen = createMockHit({
    id: 'etterregistreringApen',
    eier: 'TestIdent',
    tittel: 'Etterregistrering Formidling Åpen',
    status: 'ACTIVE',
    adStatus: 'DONE',
    erFormidling: true
});
// ──────────────────────────────────────────────────────────
// Jobbmesse
// ──────────────────────────────────────────────────────────
const jobbmesse = createMockHit({
    id: 'jobbmesse',
    eier: 'TestIdent',
    tittel: 'NAV Jobbmesse Lillestrøm',
    status: 'ACTIVE',
    adStatus: 'DONE',
    expires: fremtidigDato,
    erJobbmesse: true
});
// ──────────────────────────────────────────────────────────
// Øvrige stillinger fra stillingMock (aksesseres via direkte URL)
// ──────────────────────────────────────────────────────────
const nyStilling = createMockHit({
    id: 'nyStilling',
    eier: 'TestIdent',
    tittel: 'Stilling uten valgt jobbtittel',
    status: 'INACTIVE',
    adStatus: 'PENDING',
    publishedByAdmin: null
});
const internStilling = createMockHit({
    id: 'internStilling',
    tittel: 'Intern stilling',
    status: 'ACTIVE',
    adStatus: 'DONE',
    expires: fremtidigDato
});
const minFormidling = createMockHit({
    id: 'minFormidling',
    eier: 'TestIdent',
    tittel: 'Min formidling',
    erFormidling: true
});
const ikkePublisertStilling = createMockHit({
    id: 'ikkePublisertStilling',
    tittel: 'Stilling uten valgt jobbtittel',
    status: 'INACTIVE',
    adStatus: 'PENDING',
    publishedByAdmin: null
});
// Stillinger – vises under /stilling
const stillingHits = [
    publisertStilling,
    publisertEksternStilling,
    utløptStilling,
    stengtForSøkereStilling,
    slettetStilling,
    fullførtStilling,
    bannerForlengOppdrag,
    bannerÅpneSøkeforslag,
    fullførtBesattLåst,
    fullførtIkkeBesattIkkeLåst,
    fullførtIkkeBesattLåst,
    utkastStilling,
    minStilling,
    minStillingEkstern,
    eksternStilling,
    jobbmesse,
    nyStilling,
    internStilling,
    ikkePublisertStilling
];
// Etterregistreringer – vises under /etterregistrering
const etterregistreringHits = [
    etterregistrering,
    etterregistreringÅpen,
    minFormidling
];
const lagMockSøkeresultat = (hits)=>({
        took: 35,
        timed_out: false,
        _shards: {
            total: 3,
            successful: 3,
            skipped: 0,
            failed: 0
        },
        hits: {
            total: {
                value: hits.length,
                relation: 'eq'
            },
            max_score: null,
            hits: hits
        },
        aggregations: {
            globalAggregering: {
                doc_count: hits.length,
                felter: {
                    buckets: {
                        annonsenummer: {
                            doc_count: 1
                        },
                        annonsetekst: {
                            doc_count: 0
                        },
                        arbeidsgiver: {
                            doc_count: 0
                        },
                        tittel: {
                            doc_count: 0
                        }
                    }
                }
            }
        }
    });
const mockStillingssøk = lagMockSøkeresultat(stillingHits);
const mockEtterregistreringssøk = lagMockSøkeresultat(etterregistreringHits);
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/stillings-sok/elastic-search/queries/fritekst-query.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "fritekstQuery",
    ()=>fritekstQuery
]);
const fritekstQuery = (params, esBuilder)=>{
    const fritekst = params.filter.fritekst;
    const inneholderVerdierMedBareTall = fritekst.some((verdi)=>/^R?\d+$/.test(verdi));
    const ordSomSkalFiltreresUt = [
        'innen',
        'på',
        'av',
        'og',
        'for',
        'med',
        'som',
        'mv.',
        'o.l.'
    ];
    const fritekstSøkestreng = fritekst.map((fritekstStreng)=>{
        const ord = fritekstStreng.split(' ').filter((it)=>it.length > 1 && !ordSomSkalFiltreresUt.includes(it.toLowerCase()));
        return `(+${ord.map((ord)=>ord.trim()).join(' +')})`;
    }).join(' | ');
    let felt;
    if (!inneholderVerdierMedBareTall) {
        felt = 'tekstfelter';
    }
    // Bruk den prosesserte fritekstSøkestreng med addFritekstSøk
    if (fritekstSøkestreng && fritekstSøkestreng.length > 0) {
        esBuilder.addFritekstSøk(fritekstSøkestreng, felt).setMinimumShouldMatch(fritekst.length ? '1' : '0');
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/pam-geografi/typehead/lokasjoner/lokasjoner.mock.json (json)", ((__turbopack_context__) => {

__turbopack_context__.v(JSON.parse("[{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AGDER\",\"fylkesnummer\":\"42\",\"kommune\":null,\"kommunenummer\":null,\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"AGDER\",\"type\":\"FYLKE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AKERSHUS\",\"fylkesnummer\":\"32\",\"kommune\":null,\"kommunenummer\":null,\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"AKERSHUS\",\"type\":\"FYLKE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"NORDLAND\",\"fylkesnummer\":\"18\",\"kommune\":\"ALSTAHAUG\",\"kommunenummer\":\"1820\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ALSTAHAUG\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"FINNMARK\",\"fylkesnummer\":\"56\",\"kommune\":\"ALTA\",\"kommunenummer\":\"5601\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ALTA\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"ALVDAL\",\"kommunenummer\":\"3428\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ALVDAL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTLAND\",\"fylkesnummer\":\"46\",\"kommune\":\"ALVER\",\"kommunenummer\":\"4631\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ALVER\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"NORDLAND\",\"fylkesnummer\":\"18\",\"kommune\":\"ANDØY\",\"kommunenummer\":\"1871\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ANDØY\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"ØSTFOLD\",\"fylkesnummer\":\"31\",\"kommune\":\"AREMARK\",\"kommunenummer\":\"3124\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"AREMARK\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AGDER\",\"fylkesnummer\":\"42\",\"kommune\":\"ARENDAL\",\"kommunenummer\":\"4203\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ARENDAL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AKERSHUS\",\"fylkesnummer\":\"32\",\"kommune\":\"ASKER\",\"kommunenummer\":\"3203\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ASKER\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTLAND\",\"fylkesnummer\":\"46\",\"kommune\":\"ASKVOLL\",\"kommunenummer\":\"4645\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ASKVOLL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTLAND\",\"fylkesnummer\":\"46\",\"kommune\":\"ASKØY\",\"kommunenummer\":\"4627\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ASKØY\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"MØRE OG ROMSDAL\",\"fylkesnummer\":\"15\",\"kommune\":\"AUKRA\",\"kommunenummer\":\"1547\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"AUKRA\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"MØRE OG ROMSDAL\",\"fylkesnummer\":\"15\",\"kommune\":\"AURE\",\"kommunenummer\":\"1576\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"AURE\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTLAND\",\"fylkesnummer\":\"46\",\"kommune\":\"AURLAND\",\"kommunenummer\":\"4641\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"AURLAND\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AKERSHUS\",\"fylkesnummer\":\"32\",\"kommune\":\"AURSKOG-HØLAND\",\"kommunenummer\":\"3226\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"AURSKOG-HØLAND\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTLAND\",\"fylkesnummer\":\"46\",\"kommune\":\"AUSTEVOLL\",\"kommunenummer\":\"4625\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"AUSTEVOLL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTLAND\",\"fylkesnummer\":\"46\",\"kommune\":\"AUSTRHEIM\",\"kommunenummer\":\"4632\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"AUSTRHEIM\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"MØRE OG ROMSDAL\",\"fylkesnummer\":\"15\",\"kommune\":\"AVERØY\",\"kommunenummer\":\"1554\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"AVERØY\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TROMS\",\"fylkesnummer\":\"55\",\"kommune\":\"BALSFJORD\",\"kommunenummer\":\"5532\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"BALSFJORD\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TELEMARK\",\"fylkesnummer\":\"40\",\"kommune\":\"BAMBLE\",\"kommunenummer\":\"4012\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"BAMBLE\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TROMS\",\"fylkesnummer\":\"55\",\"kommune\":\"BARDU\",\"kommunenummer\":\"5520\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"BARDU\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"NORDLAND\",\"fylkesnummer\":\"18\",\"kommune\":\"BEIARN\",\"kommunenummer\":\"1839\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"BEIARN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTLAND\",\"fylkesnummer\":\"46\",\"kommune\":\"BERGEN\",\"kommunenummer\":\"4601\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"BERGEN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"FINNMARK\",\"fylkesnummer\":\"56\",\"kommune\":\"BERLEVÅG\",\"kommunenummer\":\"5630\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"BERLEVÅG\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"NORDLAND\",\"fylkesnummer\":\"18\",\"kommune\":\"BINDAL\",\"kommunenummer\":\"1811\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"BINDAL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AGDER\",\"fylkesnummer\":\"42\",\"kommune\":\"BIRKENES\",\"kommunenummer\":\"4216\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"BIRKENES\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"ROGALAND\",\"fylkesnummer\":\"11\",\"kommune\":\"BJERKREIM\",\"kommunenummer\":\"1114\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"BJERKREIM\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTLAND\",\"fylkesnummer\":\"46\",\"kommune\":\"BJØRNAFJORDEN\",\"kommunenummer\":\"4624\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"BJØRNAFJORDEN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"NORDLAND\",\"fylkesnummer\":\"18\",\"kommune\":\"BODØ\",\"kommunenummer\":\"1804\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"BODØ\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"ROGALAND\",\"fylkesnummer\":\"11\",\"kommune\":\"BOKN\",\"kommunenummer\":\"1145\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"BOKN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTLAND\",\"fylkesnummer\":\"46\",\"kommune\":\"BREMANGER\",\"kommunenummer\":\"4648\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"BREMANGER\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"NORDLAND\",\"fylkesnummer\":\"18\",\"kommune\":\"BRØNNØY\",\"kommunenummer\":\"1813\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"BRØNNØY\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"BUSKERUD\",\"fylkesnummer\":\"33\",\"kommune\":null,\"kommunenummer\":null,\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"BUSKERUD\",\"type\":\"FYLKE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AGDER\",\"fylkesnummer\":\"42\",\"kommune\":\"BYGLAND\",\"kommunenummer\":\"4220\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"BYGLAND\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AGDER\",\"fylkesnummer\":\"42\",\"kommune\":\"BYKLE\",\"kommunenummer\":\"4222\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"BYKLE\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AKERSHUS\",\"fylkesnummer\":\"32\",\"kommune\":\"BÆRUM\",\"kommunenummer\":\"3201\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"BÆRUM\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"NORDLAND\",\"fylkesnummer\":\"18\",\"kommune\":\"BØ (NORDLAND)\",\"kommunenummer\":\"1867\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"BØ (NORDLAND)\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTLAND\",\"fylkesnummer\":\"46\",\"kommune\":\"BØMLO\",\"kommunenummer\":\"4613\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"BØMLO\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"FINNMARK\",\"fylkesnummer\":\"56\",\"kommune\":\"BÅTSFJORD\",\"kommunenummer\":\"5632\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"BÅTSFJORD\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"FINNMARK\",\"fylkesnummer\":\"56\",\"kommune\":\"DEATNU TANA\",\"kommunenummer\":\"5628\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"DEATNU TANA\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"DOVRE\",\"kommunenummer\":\"3431\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"DOVRE\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"BUSKERUD\",\"fylkesnummer\":\"33\",\"kommune\":\"DRAMMEN\",\"kommunenummer\":\"3301\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"DRAMMEN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TELEMARK\",\"fylkesnummer\":\"40\",\"kommune\":\"DRANGEDAL\",\"kommunenummer\":\"4016\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"DRANGEDAL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TROMS\",\"fylkesnummer\":\"55\",\"kommune\":\"DYRØY\",\"kommunenummer\":\"5528\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"DYRØY\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"NORDLAND\",\"fylkesnummer\":\"18\",\"kommune\":\"DØNNA\",\"kommunenummer\":\"1827\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"DØNNA\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTLAND\",\"fylkesnummer\":\"46\",\"kommune\":\"EIDFJORD\",\"kommunenummer\":\"4619\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"EIDFJORD\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"EIDSKOG\",\"kommunenummer\":\"3416\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"EIDSKOG\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AKERSHUS\",\"fylkesnummer\":\"32\",\"kommune\":\"EIDSVOLL\",\"kommunenummer\":\"3240\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"EIDSVOLL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"ROGALAND\",\"fylkesnummer\":\"11\",\"kommune\":\"EIGERSUND\",\"kommunenummer\":\"1101\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"EIGERSUND\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"ELVERUM\",\"kommunenummer\":\"3420\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ELVERUM\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AKERSHUS\",\"fylkesnummer\":\"32\",\"kommune\":\"ENEBAKK\",\"kommunenummer\":\"3220\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ENEBAKK\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"ENGERDAL\",\"kommunenummer\":\"3425\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ENGERDAL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTLAND\",\"fylkesnummer\":\"46\",\"kommune\":\"ETNE\",\"kommunenummer\":\"4611\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ETNE\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"ETNEDAL\",\"kommunenummer\":\"3450\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ETNEDAL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"NORDLAND\",\"fylkesnummer\":\"18\",\"kommune\":\"EVENES\",\"kommunenummer\":\"1853\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"EVENES\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AGDER\",\"fylkesnummer\":\"42\",\"kommune\":\"EVJE OG HORNNES\",\"kommunenummer\":\"4219\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"EVJE OG HORNNES\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AGDER\",\"fylkesnummer\":\"42\",\"kommune\":\"FARSUND\",\"kommunenummer\":\"4206\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"FARSUND\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"NORDLAND\",\"fylkesnummer\":\"18\",\"kommune\":\"FAUSKE\",\"kommunenummer\":\"1841\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"FAUSKE\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTLAND\",\"fylkesnummer\":\"46\",\"kommune\":\"FEDJE\",\"kommunenummer\":\"4633\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"FEDJE\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"FINNMARK\",\"fylkesnummer\":\"56\",\"kommune\":null,\"kommunenummer\":null,\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"FINNMARK\",\"type\":\"FYLKE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTLAND\",\"fylkesnummer\":\"46\",\"kommune\":\"FITJAR\",\"kommunenummer\":\"4615\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"FITJAR\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTLAND\",\"fylkesnummer\":\"46\",\"kommune\":\"FJALER\",\"kommunenummer\":\"4646\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"FJALER\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"MØRE OG ROMSDAL\",\"fylkesnummer\":\"15\",\"kommune\":\"FJORD\",\"kommunenummer\":\"1578\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"FJORD\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"NORDLAND\",\"fylkesnummer\":\"18\",\"kommune\":\"FLAKSTAD\",\"kommunenummer\":\"1859\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"FLAKSTAD\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TRØNDELAG\",\"fylkesnummer\":\"50\",\"kommune\":\"FLATANGER\",\"kommunenummer\":\"5049\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"FLATANGER\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AGDER\",\"fylkesnummer\":\"42\",\"kommune\":\"FLEKKEFJORD\",\"kommunenummer\":\"4207\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"FLEKKEFJORD\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"BUSKERUD\",\"fylkesnummer\":\"33\",\"kommune\":\"FLESBERG\",\"kommunenummer\":\"3334\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"FLESBERG\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"BUSKERUD\",\"fylkesnummer\":\"33\",\"kommune\":\"FLÅ\",\"kommunenummer\":\"3320\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"FLÅ\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"FOLLDAL\",\"kommunenummer\":\"3429\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"FOLLDAL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"ØSTFOLD\",\"fylkesnummer\":\"31\",\"kommune\":\"FREDRIKSTAD\",\"kommunenummer\":\"3107\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"FREDRIKSTAD\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AKERSHUS\",\"fylkesnummer\":\"32\",\"kommune\":\"FROGN\",\"kommunenummer\":\"3214\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"FROGN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AGDER\",\"fylkesnummer\":\"42\",\"kommune\":\"FROLAND\",\"kommunenummer\":\"4214\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"FROLAND\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TRØNDELAG\",\"fylkesnummer\":\"50\",\"kommune\":\"FROSTA\",\"kommunenummer\":\"5036\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"FROSTA\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TRØNDELAG\",\"fylkesnummer\":\"50\",\"kommune\":\"FRØYA\",\"kommunenummer\":\"5014\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"FRØYA\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TELEMARK\",\"fylkesnummer\":\"40\",\"kommune\":\"FYRESDAL\",\"kommunenummer\":\"4032\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"FYRESDAL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTFOLD\",\"fylkesnummer\":\"39\",\"kommune\":\"FÆRDER\",\"kommunenummer\":\"3911\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"FÆRDER\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TROMS\",\"fylkesnummer\":\"55\",\"kommune\":\"GÁIVUOTNA KÅFJORD\",\"kommunenummer\":\"5540\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"GÁIVUOTNA KÅFJORD\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"FINNMARK\",\"fylkesnummer\":\"56\",\"kommune\":\"GAMVIK\",\"kommunenummer\":\"5626\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"GAMVIK\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"GAUSDAL\",\"kommunenummer\":\"3441\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"GAUSDAL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"NORDLAND\",\"fylkesnummer\":\"18\",\"kommune\":\"GILDESKÅL\",\"kommunenummer\":\"1838\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"GILDESKÅL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"MØRE OG ROMSDAL\",\"fylkesnummer\":\"15\",\"kommune\":\"GISKE\",\"kommunenummer\":\"1532\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"GISKE\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"MØRE OG ROMSDAL\",\"fylkesnummer\":\"15\",\"kommune\":\"GJEMNES\",\"kommunenummer\":\"1557\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"GJEMNES\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AKERSHUS\",\"fylkesnummer\":\"32\",\"kommune\":\"GJERDRUM\",\"kommunenummer\":\"3230\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"GJERDRUM\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AGDER\",\"fylkesnummer\":\"42\",\"kommune\":\"GJERSTAD\",\"kommunenummer\":\"4211\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"GJERSTAD\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"ROGALAND\",\"fylkesnummer\":\"11\",\"kommune\":\"GJESDAL\",\"kommunenummer\":\"1122\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"GJESDAL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"GJØVIK\",\"kommunenummer\":\"3407\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"GJØVIK\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTLAND\",\"fylkesnummer\":\"46\",\"kommune\":\"GLOPPEN\",\"kommunenummer\":\"4650\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"GLOPPEN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"BUSKERUD\",\"fylkesnummer\":\"33\",\"kommune\":\"GOL\",\"kommunenummer\":\"3324\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"GOL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"GRAN\",\"kommunenummer\":\"3446\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"GRAN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"NORDLAND\",\"fylkesnummer\":\"18\",\"kommune\":\"GRANE\",\"kommunenummer\":\"1825\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"GRANE\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TROMS\",\"fylkesnummer\":\"55\",\"kommune\":\"GRATANGEN\",\"kommunenummer\":\"5516\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"GRATANGEN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AGDER\",\"fylkesnummer\":\"42\",\"kommune\":\"GRIMSTAD\",\"kommunenummer\":\"4202\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"GRIMSTAD\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TRØNDELAG\",\"fylkesnummer\":\"50\",\"kommune\":\"GRONG\",\"kommunenummer\":\"5045\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"GRONG\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"GRUE\",\"kommunenummer\":\"3417\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"GRUE\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTLAND\",\"fylkesnummer\":\"46\",\"kommune\":\"GULEN\",\"kommunenummer\":\"4635\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"GULEN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"FINNMARK\",\"fylkesnummer\":\"56\",\"kommune\":\"GUOVDAGEAIDNU KAUTOKEINO\",\"kommunenummer\":\"5612\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"GUOVDAGEAIDNU KAUTOKEINO\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"NORDLAND\",\"fylkesnummer\":\"18\",\"kommune\":\"HADSEL\",\"kommunenummer\":\"1866\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"HADSEL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"ØSTFOLD\",\"fylkesnummer\":\"31\",\"kommune\":\"HALDEN\",\"kommunenummer\":\"3101\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"HALDEN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"HAMAR\",\"kommunenummer\":\"3403\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"HAMAR\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"NORDLAND\",\"fylkesnummer\":\"18\",\"kommune\":\"HAMARØY\",\"kommunenummer\":\"1875\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"HAMARØY\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"FINNMARK\",\"fylkesnummer\":\"56\",\"kommune\":\"HAMMERFEST\",\"kommunenummer\":\"5603\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"HAMMERFEST\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"MØRE OG ROMSDAL\",\"fylkesnummer\":\"15\",\"kommune\":\"HARAM\",\"kommunenummer\":\"1580\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"HARAM\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"MØRE OG ROMSDAL\",\"fylkesnummer\":\"15\",\"kommune\":\"HAREID\",\"kommunenummer\":\"1517\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"HAREID\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TROMS\",\"fylkesnummer\":\"55\",\"kommune\":\"HARSTAD\",\"kommunenummer\":\"5503\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"HARSTAD\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"FINNMARK\",\"fylkesnummer\":\"56\",\"kommune\":\"HASVIK\",\"kommunenummer\":\"5616\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"HASVIK\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"NORDLAND\",\"fylkesnummer\":\"18\",\"kommune\":\"HATTFJELLDAL\",\"kommunenummer\":\"1826\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"HATTFJELLDAL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"ROGALAND\",\"fylkesnummer\":\"11\",\"kommune\":\"HAUGESUND\",\"kommunenummer\":\"1106\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"HAUGESUND\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TRØNDELAG\",\"fylkesnummer\":\"50\",\"kommune\":\"HEIM\",\"kommunenummer\":\"5055\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"HEIM\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"NORDLAND\",\"fylkesnummer\":\"18\",\"kommune\":\"HEMNES\",\"kommunenummer\":\"1832\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"HEMNES\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"BUSKERUD\",\"fylkesnummer\":\"33\",\"kommune\":\"HEMSEDAL\",\"kommunenummer\":\"3326\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"HEMSEDAL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"MØRE OG ROMSDAL\",\"fylkesnummer\":\"15\",\"kommune\":\"HERØY (MØRE OG ROMSDAL)\",\"kommunenummer\":\"1515\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"HERØY (MØRE OG ROMSDAL)\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"NORDLAND\",\"fylkesnummer\":\"18\",\"kommune\":\"HERØY (NORDLAND)\",\"kommunenummer\":\"1818\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"HERØY (NORDLAND)\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TRØNDELAG\",\"fylkesnummer\":\"50\",\"kommune\":\"HITRA\",\"kommunenummer\":\"5056\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"HITRA\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TELEMARK\",\"fylkesnummer\":\"40\",\"kommune\":\"HJARTDAL\",\"kommunenummer\":\"4024\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"HJARTDAL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"ROGALAND\",\"fylkesnummer\":\"11\",\"kommune\":\"HJELMELAND\",\"kommunenummer\":\"1133\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"HJELMELAND\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"BUSKERUD\",\"fylkesnummer\":\"33\",\"kommune\":\"HOL\",\"kommunenummer\":\"3330\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"HOL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"BUSKERUD\",\"fylkesnummer\":\"33\",\"kommune\":\"HOLE\",\"kommunenummer\":\"3310\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"HOLE\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTFOLD\",\"fylkesnummer\":\"39\",\"kommune\":\"HOLMESTRAND\",\"kommunenummer\":\"3903\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"HOLMESTRAND\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TRØNDELAG\",\"fylkesnummer\":\"50\",\"kommune\":\"HOLTÅLEN\",\"kommunenummer\":\"5026\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"HOLTÅLEN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTFOLD\",\"fylkesnummer\":\"39\",\"kommune\":\"HORTEN\",\"kommunenummer\":\"3901\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"HORTEN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AKERSHUS\",\"fylkesnummer\":\"32\",\"kommune\":\"HURDAL\",\"kommunenummer\":\"3242\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"HURDAL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"MØRE OG ROMSDAL\",\"fylkesnummer\":\"15\",\"kommune\":\"HUSTADVIKA\",\"kommunenummer\":\"1579\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"HUSTADVIKA\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"ØSTFOLD\",\"fylkesnummer\":\"31\",\"kommune\":\"HVALER\",\"kommunenummer\":\"3110\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"HVALER\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTLAND\",\"fylkesnummer\":\"46\",\"kommune\":\"HYLLESTAD\",\"kommunenummer\":\"4637\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"HYLLESTAD\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AGDER\",\"fylkesnummer\":\"42\",\"kommune\":\"HÆGEBOSTAD\",\"kommunenummer\":\"4226\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"HÆGEBOSTAD\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTLAND\",\"fylkesnummer\":\"46\",\"kommune\":\"HØYANGER\",\"kommunenummer\":\"4638\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"HØYANGER\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TRØNDELAG\",\"fylkesnummer\":\"50\",\"kommune\":\"HØYLANDET\",\"kommunenummer\":\"5046\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"HØYLANDET\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"ROGALAND\",\"fylkesnummer\":\"11\",\"kommune\":\"HÅ\",\"kommunenummer\":\"1119\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"HÅ\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TROMS\",\"fylkesnummer\":\"55\",\"kommune\":\"IBESTAD\",\"kommunenummer\":\"5514\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"IBESTAD\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TRØNDELAG\",\"fylkesnummer\":\"50\",\"kommune\":\"INDERØY\",\"kommunenummer\":\"5053\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"INDERØY\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TRØNDELAG\",\"fylkesnummer\":\"50\",\"kommune\":\"INDRE FOSEN\",\"kommunenummer\":\"5054\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"INDRE FOSEN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"ØSTFOLD\",\"fylkesnummer\":\"31\",\"kommune\":\"INDRE ØSTFOLD\",\"kommunenummer\":\"3118\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"INDRE ØSTFOLD\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":null,\"kommunenummer\":null,\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"INNLANDET\",\"type\":\"FYLKE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AGDER\",\"fylkesnummer\":\"42\",\"kommune\":\"IVELAND\",\"kommunenummer\":\"4218\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"IVELAND\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"JAN MAYEN\",\"fylkesnummer\":\"22\",\"kommune\":null,\"kommunenummer\":null,\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"JAN MAYEN\",\"type\":\"FYLKE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"JAN MAYEN\",\"fylkesnummer\":\"22\",\"kommune\":\"JAN MAYEN\",\"kommunenummer\":\"2211\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"JAN MAYEN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AKERSHUS\",\"fylkesnummer\":\"32\",\"kommune\":\"JEVNAKER\",\"kommunenummer\":\"3236\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"JEVNAKER\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"FINNMARK\",\"fylkesnummer\":\"56\",\"kommune\":\"KARASJOHKA KARASJOK\",\"kommunenummer\":\"5610\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"KARASJOHKA KARASJOK\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TROMS\",\"fylkesnummer\":\"55\",\"kommune\":\"KARLSØY\",\"kommunenummer\":\"5534\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"KARLSØY\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"ROGALAND\",\"fylkesnummer\":\"11\",\"kommune\":\"KARMØY\",\"kommunenummer\":\"1149\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"KARMØY\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTLAND\",\"fylkesnummer\":\"46\",\"kommune\":\"KINN\",\"kommunenummer\":\"4602\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"KINN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"ROGALAND\",\"fylkesnummer\":\"11\",\"kommune\":\"KLEPP\",\"kommunenummer\":\"1120\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"KLEPP\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"BUSKERUD\",\"fylkesnummer\":\"33\",\"kommune\":\"KONGSBERG\",\"kommunenummer\":\"3303\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"KONGSBERG\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"KONGSVINGER\",\"kommunenummer\":\"3401\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"KONGSVINGER\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"KONTINENTALSOKKELEN\",\"fylkesnummer\":\"23\",\"kommune\":null,\"kommunenummer\":null,\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"KONTINENTALSOKKELEN\",\"type\":\"FYLKE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TELEMARK\",\"fylkesnummer\":\"40\",\"kommune\":\"KRAGERØ\",\"kommunenummer\":\"4014\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"KRAGERØ\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AGDER\",\"fylkesnummer\":\"42\",\"kommune\":\"KRISTIANSAND\",\"kommunenummer\":\"4204\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"KRISTIANSAND\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"MØRE OG ROMSDAL\",\"fylkesnummer\":\"15\",\"kommune\":\"KRISTIANSUND\",\"kommunenummer\":\"1505\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"KRISTIANSUND\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"BUSKERUD\",\"fylkesnummer\":\"33\",\"kommune\":\"KRØDSHERAD\",\"kommunenummer\":\"3318\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"KRØDSHERAD\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTLAND\",\"fylkesnummer\":\"46\",\"kommune\":\"KVAM\",\"kommunenummer\":\"4622\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"KVAM\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AGDER\",\"fylkesnummer\":\"42\",\"kommune\":\"KVINESDAL\",\"kommunenummer\":\"4227\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"KVINESDAL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTLAND\",\"fylkesnummer\":\"46\",\"kommune\":\"KVINNHERAD\",\"kommunenummer\":\"4617\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"KVINNHERAD\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TELEMARK\",\"fylkesnummer\":\"40\",\"kommune\":\"KVITESEID\",\"kommunenummer\":\"4028\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"KVITESEID\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"ROGALAND\",\"fylkesnummer\":\"11\",\"kommune\":\"KVITSØY\",\"kommunenummer\":\"1144\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"KVITSØY\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TROMS\",\"fylkesnummer\":\"55\",\"kommune\":\"KVÆFJORD\",\"kommunenummer\":\"5510\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"KVÆFJORD\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TROMS\",\"fylkesnummer\":\"55\",\"kommune\":\"KVÆNANGEN\",\"kommunenummer\":\"5546\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"KVÆNANGEN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTFOLD\",\"fylkesnummer\":\"39\",\"kommune\":\"LARVIK\",\"kommunenummer\":\"3909\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"LARVIK\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TROMS\",\"fylkesnummer\":\"55\",\"kommune\":\"LAVANGEN\",\"kommunenummer\":\"5518\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"LAVANGEN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"FINNMARK\",\"fylkesnummer\":\"56\",\"kommune\":\"LEBESBY\",\"kommunenummer\":\"5624\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"LEBESBY\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"NORDLAND\",\"fylkesnummer\":\"18\",\"kommune\":\"LEIRFJORD\",\"kommunenummer\":\"1822\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"LEIRFJORD\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TRØNDELAG\",\"fylkesnummer\":\"50\",\"kommune\":\"LEKA\",\"kommunenummer\":\"5052\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"LEKA\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"LESJA\",\"kommunenummer\":\"3432\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"LESJA\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TRØNDELAG\",\"fylkesnummer\":\"50\",\"kommune\":\"LEVANGER\",\"kommunenummer\":\"5037\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"LEVANGER\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"BUSKERUD\",\"fylkesnummer\":\"33\",\"kommune\":\"LIER\",\"kommunenummer\":\"3312\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"LIER\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TRØNDELAG\",\"fylkesnummer\":\"50\",\"kommune\":\"LIERNE\",\"kommunenummer\":\"5042\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"LIERNE\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"LILLEHAMMER\",\"kommunenummer\":\"3405\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"LILLEHAMMER\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AGDER\",\"fylkesnummer\":\"42\",\"kommune\":\"LILLESAND\",\"kommunenummer\":\"4215\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"LILLESAND\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AKERSHUS\",\"fylkesnummer\":\"32\",\"kommune\":\"LILLESTRØM\",\"kommunenummer\":\"3205\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"LILLESTRØM\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AGDER\",\"fylkesnummer\":\"42\",\"kommune\":\"LINDESNES\",\"kommunenummer\":\"4205\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"LINDESNES\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"LOM\",\"kommunenummer\":\"3434\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"LOM\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"FINNMARK\",\"fylkesnummer\":\"56\",\"kommune\":\"LOPPA\",\"kommunenummer\":\"5614\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"LOPPA\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"ROGALAND\",\"fylkesnummer\":\"11\",\"kommune\":\"LUND\",\"kommunenummer\":\"1112\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"LUND\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AKERSHUS\",\"fylkesnummer\":\"32\",\"kommune\":\"LUNNER\",\"kommunenummer\":\"3234\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"LUNNER\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"NORDLAND\",\"fylkesnummer\":\"18\",\"kommune\":\"LURØY\",\"kommunenummer\":\"1834\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"LURØY\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTLAND\",\"fylkesnummer\":\"46\",\"kommune\":\"LUSTER\",\"kommunenummer\":\"4644\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"LUSTER\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AGDER\",\"fylkesnummer\":\"42\",\"kommune\":\"LYNGDAL\",\"kommunenummer\":\"4225\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"LYNGDAL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TROMS\",\"fylkesnummer\":\"55\",\"kommune\":\"LYNGEN\",\"kommunenummer\":\"5536\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"LYNGEN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTLAND\",\"fylkesnummer\":\"46\",\"kommune\":\"LÆRDAL\",\"kommunenummer\":\"4642\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"LÆRDAL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"NORDLAND\",\"fylkesnummer\":\"18\",\"kommune\":\"LØDINGEN\",\"kommunenummer\":\"1851\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"LØDINGEN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AKERSHUS\",\"fylkesnummer\":\"32\",\"kommune\":\"LØRENSKOG\",\"kommunenummer\":\"3222\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"LØRENSKOG\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"LØTEN\",\"kommunenummer\":\"3412\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"LØTEN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TRØNDELAG\",\"fylkesnummer\":\"50\",\"kommune\":\"MALVIK\",\"kommunenummer\":\"5031\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"MALVIK\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"ØSTFOLD\",\"fylkesnummer\":\"31\",\"kommune\":\"MARKER\",\"kommunenummer\":\"3122\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"MARKER\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTLAND\",\"fylkesnummer\":\"46\",\"kommune\":\"MASFJORDEN\",\"kommunenummer\":\"4634\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"MASFJORDEN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TRØNDELAG\",\"fylkesnummer\":\"50\",\"kommune\":\"MELHUS\",\"kommunenummer\":\"5028\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"MELHUS\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"NORDLAND\",\"fylkesnummer\":\"18\",\"kommune\":\"MELØY\",\"kommunenummer\":\"1837\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"MELØY\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TRØNDELAG\",\"fylkesnummer\":\"50\",\"kommune\":\"MERÅKER\",\"kommunenummer\":\"5034\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"MERÅKER\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TRØNDELAG\",\"fylkesnummer\":\"50\",\"kommune\":\"MIDTRE GAULDAL\",\"kommunenummer\":\"5027\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"MIDTRE GAULDAL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TELEMARK\",\"fylkesnummer\":\"40\",\"kommune\":\"MIDT-TELEMARK\",\"kommunenummer\":\"4020\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"MIDT-TELEMARK\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTLAND\",\"fylkesnummer\":\"46\",\"kommune\":\"MODALEN\",\"kommunenummer\":\"4629\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"MODALEN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"BUSKERUD\",\"fylkesnummer\":\"33\",\"kommune\":\"MODUM\",\"kommunenummer\":\"3316\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"MODUM\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"MØRE OG ROMSDAL\",\"fylkesnummer\":\"15\",\"kommune\":\"MOLDE\",\"kommunenummer\":\"1506\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"MOLDE\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"NORDLAND\",\"fylkesnummer\":\"18\",\"kommune\":\"MOSKENES\",\"kommunenummer\":\"1874\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"MOSKENES\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"ØSTFOLD\",\"fylkesnummer\":\"31\",\"kommune\":\"MOSS\",\"kommunenummer\":\"3103\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"MOSS\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"MØRE OG ROMSDAL\",\"fylkesnummer\":\"15\",\"kommune\":null,\"kommunenummer\":null,\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"MØRE OG ROMSDAL\",\"type\":\"FYLKE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TROMS\",\"fylkesnummer\":\"55\",\"kommune\":\"MÅLSELV\",\"kommunenummer\":\"5524\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"MÅLSELV\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"FINNMARK\",\"fylkesnummer\":\"56\",\"kommune\":\"MÅSØY\",\"kommunenummer\":\"5618\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"MÅSØY\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TRØNDELAG\",\"fylkesnummer\":\"50\",\"kommune\":\"NAMSOS\",\"kommunenummer\":\"5007\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"NAMSOS\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TRØNDELAG\",\"fylkesnummer\":\"50\",\"kommune\":\"NAMSSKOGAN\",\"kommunenummer\":\"5044\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"NAMSSKOGAN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AKERSHUS\",\"fylkesnummer\":\"32\",\"kommune\":\"NANNESTAD\",\"kommunenummer\":\"3238\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"NANNESTAD\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"NORDLAND\",\"fylkesnummer\":\"18\",\"kommune\":\"NARVIK\",\"kommunenummer\":\"1806\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"NARVIK\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AKERSHUS\",\"fylkesnummer\":\"32\",\"kommune\":\"NES (AKERSHUS)\",\"kommunenummer\":\"3228\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"NES (AKERSHUS)\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"BUSKERUD\",\"fylkesnummer\":\"33\",\"kommune\":\"NESBYEN\",\"kommunenummer\":\"3322\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"NESBYEN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"NORDLAND\",\"fylkesnummer\":\"18\",\"kommune\":\"NESNA\",\"kommunenummer\":\"1828\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"NESNA\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AKERSHUS\",\"fylkesnummer\":\"32\",\"kommune\":\"NESODDEN\",\"kommunenummer\":\"3212\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"NESODDEN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TELEMARK\",\"fylkesnummer\":\"40\",\"kommune\":\"NISSEDAL\",\"kommunenummer\":\"4030\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"NISSEDAL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AKERSHUS\",\"fylkesnummer\":\"32\",\"kommune\":\"NITTEDAL\",\"kommunenummer\":\"3232\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"NITTEDAL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TELEMARK\",\"fylkesnummer\":\"40\",\"kommune\":\"NOME\",\"kommunenummer\":\"4018\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"NOME\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"NORD-AURDAL\",\"kommunenummer\":\"3451\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"NORD-AURDAL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"NORD-FRON\",\"kommunenummer\":\"3436\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"NORD-FRON\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"FINNMARK\",\"fylkesnummer\":\"56\",\"kommune\":\"NORDKAPP\",\"kommunenummer\":\"5620\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"NORDKAPP\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"NORDLAND\",\"fylkesnummer\":\"18\",\"kommune\":null,\"kommunenummer\":null,\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"NORDLAND\",\"type\":\"FYLKE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"NORD-ODAL\",\"kommunenummer\":\"3414\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"NORD-ODAL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AKERSHUS\",\"fylkesnummer\":\"32\",\"kommune\":\"NORDRE FOLLO\",\"kommunenummer\":\"3207\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"NORDRE FOLLO\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TROMS\",\"fylkesnummer\":\"55\",\"kommune\":\"NORDREISA\",\"kommunenummer\":\"5544\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"NORDREISA\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"NORDRE LAND\",\"kommunenummer\":\"3448\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"NORDRE LAND\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"BUSKERUD\",\"fylkesnummer\":\"33\",\"kommune\":\"NORE OG UVDAL\",\"kommunenummer\":\"3338\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"NORE OG UVDAL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TELEMARK\",\"fylkesnummer\":\"40\",\"kommune\":\"NOTODDEN\",\"kommunenummer\":\"4005\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"NOTODDEN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TRØNDELAG\",\"fylkesnummer\":\"50\",\"kommune\":\"NÆRØYSUND\",\"kommunenummer\":\"5060\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"NÆRØYSUND\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TRØNDELAG\",\"fylkesnummer\":\"50\",\"kommune\":\"OPPDAL\",\"kommunenummer\":\"5021\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"OPPDAL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TRØNDELAG\",\"fylkesnummer\":\"50\",\"kommune\":\"ORKLAND\",\"kommunenummer\":\"5059\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ORKLAND\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"OS (INNLANDET)\",\"kommunenummer\":\"3430\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"OS (INNLANDET)\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TRØNDELAG\",\"fylkesnummer\":\"50\",\"kommune\":\"OSEN\",\"kommunenummer\":\"5020\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"OSEN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"OSLO\",\"fylkesnummer\":\"03\",\"kommune\":null,\"kommunenummer\":null,\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"OSLO\",\"type\":\"FYLKE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"OSLO\",\"fylkesnummer\":\"03\",\"kommune\":\"OSLO\",\"kommunenummer\":\"0301\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"OSLO\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTLAND\",\"fylkesnummer\":\"46\",\"kommune\":\"OSTERØY\",\"kommunenummer\":\"4630\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"OSTERØY\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TRØNDELAG\",\"fylkesnummer\":\"50\",\"kommune\":\"OVERHALLA\",\"kommunenummer\":\"5047\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"OVERHALLA\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"FINNMARK\",\"fylkesnummer\":\"56\",\"kommune\":\"PORSANGER PORSÁNGU PORSANKI\",\"kommunenummer\":\"5622\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"PORSANGER PORSÁNGU PORSANKI\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TELEMARK\",\"fylkesnummer\":\"40\",\"kommune\":\"PORSGRUNN\",\"kommunenummer\":\"4001\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"PORSGRUNN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"ØSTFOLD\",\"fylkesnummer\":\"31\",\"kommune\":\"RAKKESTAD\",\"kommunenummer\":\"3120\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"RAKKESTAD\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"NORDLAND\",\"fylkesnummer\":\"18\",\"kommune\":\"RANA\",\"kommunenummer\":\"1833\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"RANA\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"ROGALAND\",\"fylkesnummer\":\"11\",\"kommune\":\"RANDABERG\",\"kommunenummer\":\"1127\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"RANDABERG\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"MØRE OG ROMSDAL\",\"fylkesnummer\":\"15\",\"kommune\":\"RAUMA\",\"kommunenummer\":\"1539\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"RAUMA\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"RENDALEN\",\"kommunenummer\":\"3424\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"RENDALEN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TRØNDELAG\",\"fylkesnummer\":\"50\",\"kommune\":\"RENNEBU\",\"kommunenummer\":\"5022\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"RENNEBU\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TRØNDELAG\",\"fylkesnummer\":\"50\",\"kommune\":\"RINDAL\",\"kommunenummer\":\"5061\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"RINDAL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"RINGEBU\",\"kommunenummer\":\"3439\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"RINGEBU\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"BUSKERUD\",\"fylkesnummer\":\"33\",\"kommune\":\"RINGERIKE\",\"kommunenummer\":\"3305\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"RINGERIKE\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"RINGSAKER\",\"kommunenummer\":\"3411\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"RINGSAKER\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AGDER\",\"fylkesnummer\":\"42\",\"kommune\":\"RISØR\",\"kommunenummer\":\"4201\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"RISØR\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"ROGALAND\",\"fylkesnummer\":\"11\",\"kommune\":null,\"kommunenummer\":null,\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ROGALAND\",\"type\":\"FYLKE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"BUSKERUD\",\"fylkesnummer\":\"33\",\"kommune\":\"ROLLAG\",\"kommunenummer\":\"3336\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ROLLAG\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AKERSHUS\",\"fylkesnummer\":\"32\",\"kommune\":\"RÆLINGEN\",\"kommunenummer\":\"3224\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"RÆLINGEN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"NORDLAND\",\"fylkesnummer\":\"18\",\"kommune\":\"RØDØY\",\"kommunenummer\":\"1836\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"RØDØY\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TRØNDELAG\",\"fylkesnummer\":\"50\",\"kommune\":\"RØROS\",\"kommunenummer\":\"5025\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"RØROS\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"NORDLAND\",\"fylkesnummer\":\"18\",\"kommune\":\"RØST\",\"kommunenummer\":\"1856\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"RØST\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TRØNDELAG\",\"fylkesnummer\":\"50\",\"kommune\":\"RØYRVIK\",\"kommunenummer\":\"5043\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"RØYRVIK\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"ØSTFOLD\",\"fylkesnummer\":\"31\",\"kommune\":\"RÅDE\",\"kommunenummer\":\"3112\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"RÅDE\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TROMS\",\"fylkesnummer\":\"55\",\"kommune\":\"SALANGEN\",\"kommunenummer\":\"5522\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SALANGEN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"NORDLAND\",\"fylkesnummer\":\"18\",\"kommune\":\"SALTDAL\",\"kommunenummer\":\"1840\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SALTDAL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTLAND\",\"fylkesnummer\":\"46\",\"kommune\":\"SAMNANGER\",\"kommunenummer\":\"4623\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SAMNANGER\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"MØRE OG ROMSDAL\",\"fylkesnummer\":\"15\",\"kommune\":\"SANDE (MØRE OG ROMSDAL)\",\"kommunenummer\":\"1514\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SANDE (MØRE OG ROMSDAL)\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTFOLD\",\"fylkesnummer\":\"39\",\"kommune\":\"SANDEFJORD\",\"kommunenummer\":\"3907\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SANDEFJORD\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"ROGALAND\",\"fylkesnummer\":\"11\",\"kommune\":\"SANDNES\",\"kommunenummer\":\"1108\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SANDNES\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"ØSTFOLD\",\"fylkesnummer\":\"31\",\"kommune\":\"SARPSBORG\",\"kommunenummer\":\"3105\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SARPSBORG\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"ROGALAND\",\"fylkesnummer\":\"11\",\"kommune\":\"SAUDA\",\"kommunenummer\":\"1135\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SAUDA\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"SEL\",\"kommunenummer\":\"3437\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SEL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TRØNDELAG\",\"fylkesnummer\":\"50\",\"kommune\":\"SELBU\",\"kommunenummer\":\"5032\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SELBU\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TELEMARK\",\"fylkesnummer\":\"40\",\"kommune\":\"SELJORD\",\"kommunenummer\":\"4022\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SELJORD\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TROMS\",\"fylkesnummer\":\"55\",\"kommune\":\"SENJA\",\"kommunenummer\":\"5530\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SENJA\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"BUSKERUD\",\"fylkesnummer\":\"33\",\"kommune\":\"SIGDAL\",\"kommunenummer\":\"3332\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SIGDAL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TELEMARK\",\"fylkesnummer\":\"40\",\"kommune\":\"SILJAN\",\"kommunenummer\":\"4010\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SILJAN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AGDER\",\"fylkesnummer\":\"42\",\"kommune\":\"SIRDAL\",\"kommunenummer\":\"4228\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SIRDAL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TRØNDELAG\",\"fylkesnummer\":\"50\",\"kommune\":\"SKAUN\",\"kommunenummer\":\"5029\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SKAUN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TELEMARK\",\"fylkesnummer\":\"40\",\"kommune\":\"SKIEN\",\"kommunenummer\":\"4003\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SKIEN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"ØSTFOLD\",\"fylkesnummer\":\"31\",\"kommune\":\"SKIPTVET\",\"kommunenummer\":\"3116\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SKIPTVET\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TROMS\",\"fylkesnummer\":\"55\",\"kommune\":\"SKJERVØY\",\"kommunenummer\":\"5542\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SKJERVØY\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"SKJÅK\",\"kommunenummer\":\"3433\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SKJÅK\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"MØRE OG ROMSDAL\",\"fylkesnummer\":\"15\",\"kommune\":\"SMØLA\",\"kommunenummer\":\"1573\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SMØLA\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TRØNDELAG\",\"fylkesnummer\":\"50\",\"kommune\":\"SNÅSA\",\"kommunenummer\":\"5041\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SNÅSA\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTLAND\",\"fylkesnummer\":\"46\",\"kommune\":\"SOGNDAL\",\"kommunenummer\":\"4640\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SOGNDAL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"ROGALAND\",\"fylkesnummer\":\"11\",\"kommune\":\"SOKNDAL\",\"kommunenummer\":\"1111\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SOKNDAL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"ROGALAND\",\"fylkesnummer\":\"11\",\"kommune\":\"SOLA\",\"kommunenummer\":\"1124\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SOLA\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTLAND\",\"fylkesnummer\":\"46\",\"kommune\":\"SOLUND\",\"kommunenummer\":\"4636\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SOLUND\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"NORDLAND\",\"fylkesnummer\":\"18\",\"kommune\":\"SORTLAND\",\"kommunenummer\":\"1870\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SORTLAND\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTLAND\",\"fylkesnummer\":\"46\",\"kommune\":\"STAD\",\"kommunenummer\":\"4649\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"STAD\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"STANGE\",\"kommunenummer\":\"3413\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"STANGE\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"ROGALAND\",\"fylkesnummer\":\"11\",\"kommune\":\"STAVANGER\",\"kommunenummer\":\"1103\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"STAVANGER\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"NORDLAND\",\"fylkesnummer\":\"18\",\"kommune\":\"STEIGEN\",\"kommunenummer\":\"1848\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"STEIGEN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TRØNDELAG\",\"fylkesnummer\":\"50\",\"kommune\":\"STEINKJER\",\"kommunenummer\":\"5006\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"STEINKJER\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TRØNDELAG\",\"fylkesnummer\":\"50\",\"kommune\":\"STJØRDAL\",\"kommunenummer\":\"5035\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"STJØRDAL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTLAND\",\"fylkesnummer\":\"46\",\"kommune\":\"STORD\",\"kommunenummer\":\"4614\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"STORD\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"STOR-ELVDAL\",\"kommunenummer\":\"3423\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"STOR-ELVDAL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TROMS\",\"fylkesnummer\":\"55\",\"kommune\":\"STORFJORD\",\"kommunenummer\":\"5538\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"STORFJORD\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"ROGALAND\",\"fylkesnummer\":\"11\",\"kommune\":\"STRAND\",\"kommunenummer\":\"1130\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"STRAND\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"MØRE OG ROMSDAL\",\"fylkesnummer\":\"15\",\"kommune\":\"STRANDA\",\"kommunenummer\":\"1525\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"STRANDA\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTLAND\",\"fylkesnummer\":\"46\",\"kommune\":\"STRYN\",\"kommunenummer\":\"4651\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"STRYN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"MØRE OG ROMSDAL\",\"fylkesnummer\":\"15\",\"kommune\":\"SULA\",\"kommunenummer\":\"1531\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SULA\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"ROGALAND\",\"fylkesnummer\":\"11\",\"kommune\":\"SULDAL\",\"kommunenummer\":\"1134\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SULDAL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"MØRE OG ROMSDAL\",\"fylkesnummer\":\"15\",\"kommune\":\"SUNNDAL\",\"kommunenummer\":\"1563\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SUNNDAL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTLAND\",\"fylkesnummer\":\"46\",\"kommune\":\"SUNNFJORD\",\"kommunenummer\":\"4647\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SUNNFJORD\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"MØRE OG ROMSDAL\",\"fylkesnummer\":\"15\",\"kommune\":\"SURNADAL\",\"kommunenummer\":\"1566\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SURNADAL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"SVALBARD\",\"fylkesnummer\":\"21\",\"kommune\":null,\"kommunenummer\":null,\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SVALBARD\",\"type\":\"FYLKE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"SVALBARD\",\"fylkesnummer\":\"21\",\"kommune\":\"SVALBARD\",\"kommunenummer\":\"2100\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SVALBARD\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTLAND\",\"fylkesnummer\":\"46\",\"kommune\":\"SVEIO\",\"kommunenummer\":\"4612\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SVEIO\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"MØRE OG ROMSDAL\",\"fylkesnummer\":\"15\",\"kommune\":\"SYKKYLVEN\",\"kommunenummer\":\"1528\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SYKKYLVEN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"NORDLAND\",\"fylkesnummer\":\"18\",\"kommune\":\"SØMNA\",\"kommunenummer\":\"1812\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SØMNA\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"SØNDRE LAND\",\"kommunenummer\":\"3447\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SØNDRE LAND\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"SØR-AURDAL\",\"kommunenummer\":\"3449\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SØR-AURDAL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"NORDLAND\",\"fylkesnummer\":\"18\",\"kommune\":\"SØRFOLD\",\"kommunenummer\":\"1845\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SØRFOLD\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"SØR-FRON\",\"kommunenummer\":\"3438\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SØR-FRON\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"SØR-ODAL\",\"kommunenummer\":\"3415\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SØR-ODAL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TROMS\",\"fylkesnummer\":\"55\",\"kommune\":\"SØRREISA\",\"kommunenummer\":\"5526\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SØRREISA\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"FINNMARK\",\"fylkesnummer\":\"56\",\"kommune\":\"SØR-VARANGER\",\"kommunenummer\":\"5605\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SØR-VARANGER\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TELEMARK\",\"fylkesnummer\":\"40\",\"kommune\":null,\"kommunenummer\":null,\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"TELEMARK\",\"type\":\"FYLKE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"ROGALAND\",\"fylkesnummer\":\"11\",\"kommune\":\"TIME\",\"kommunenummer\":\"1121\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"TIME\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"MØRE OG ROMSDAL\",\"fylkesnummer\":\"15\",\"kommune\":\"TINGVOLL\",\"kommunenummer\":\"1560\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"TINGVOLL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TELEMARK\",\"fylkesnummer\":\"40\",\"kommune\":\"TINN\",\"kommunenummer\":\"4026\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"TINN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TROMS\",\"fylkesnummer\":\"55\",\"kommune\":\"TJELDSUND\",\"kommunenummer\":\"5512\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"TJELDSUND\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TELEMARK\",\"fylkesnummer\":\"40\",\"kommune\":\"TOKKE\",\"kommunenummer\":\"4034\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"TOKKE\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"TOLGA\",\"kommunenummer\":\"3426\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"TOLGA\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TROMS\",\"fylkesnummer\":\"55\",\"kommune\":null,\"kommunenummer\":null,\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"TROMS\",\"type\":\"FYLKE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TROMS\",\"fylkesnummer\":\"55\",\"kommune\":\"TROMSØ\",\"kommunenummer\":\"5501\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"TROMSØ\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TRØNDELAG\",\"fylkesnummer\":\"50\",\"kommune\":\"TRONDHEIM\",\"kommunenummer\":\"5001\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"TRONDHEIM\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"TRYSIL\",\"kommunenummer\":\"3421\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"TRYSIL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"NORDLAND\",\"fylkesnummer\":\"18\",\"kommune\":\"TRÆNA\",\"kommunenummer\":\"1835\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"TRÆNA\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TRØNDELAG\",\"fylkesnummer\":\"50\",\"kommune\":null,\"kommunenummer\":null,\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"TRØNDELAG\",\"type\":\"FYLKE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AGDER\",\"fylkesnummer\":\"42\",\"kommune\":\"TVEDESTRAND\",\"kommunenummer\":\"4213\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"TVEDESTRAND\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TRØNDELAG\",\"fylkesnummer\":\"50\",\"kommune\":\"TYDAL\",\"kommunenummer\":\"5033\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"TYDAL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"TYNSET\",\"kommunenummer\":\"3427\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"TYNSET\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTLAND\",\"fylkesnummer\":\"46\",\"kommune\":\"TYSNES\",\"kommunenummer\":\"4616\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"TYSNES\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"ROGALAND\",\"fylkesnummer\":\"11\",\"kommune\":\"TYSVÆR\",\"kommunenummer\":\"1146\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"TYSVÆR\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTFOLD\",\"fylkesnummer\":\"39\",\"kommune\":\"TØNSBERG\",\"kommunenummer\":\"3905\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"TØNSBERG\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AKERSHUS\",\"fylkesnummer\":\"32\",\"kommune\":\"ULLENSAKER\",\"kommunenummer\":\"3209\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ULLENSAKER\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTLAND\",\"fylkesnummer\":\"46\",\"kommune\":\"ULLENSVANG\",\"kommunenummer\":\"4618\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ULLENSVANG\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"MØRE OG ROMSDAL\",\"fylkesnummer\":\"15\",\"kommune\":\"ULSTEIN\",\"kommunenummer\":\"1516\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ULSTEIN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTLAND\",\"fylkesnummer\":\"46\",\"kommune\":\"ULVIK\",\"kommunenummer\":\"4620\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ULVIK\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"FINNMARK\",\"fylkesnummer\":\"56\",\"kommune\":\"UNJARGGA NESSEBY\",\"kommunenummer\":\"5636\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"UNJARGGA NESSEBY\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"ROGALAND\",\"fylkesnummer\":\"11\",\"kommune\":\"UTSIRA\",\"kommunenummer\":\"1151\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"UTSIRA\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"FINNMARK\",\"fylkesnummer\":\"56\",\"kommune\":\"VADSØ\",\"kommunenummer\":\"5607\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"VADSØ\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTLAND\",\"fylkesnummer\":\"46\",\"kommune\":\"VAKSDAL\",\"kommunenummer\":\"4628\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"VAKSDAL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AGDER\",\"fylkesnummer\":\"42\",\"kommune\":\"VALLE\",\"kommunenummer\":\"4221\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"VALLE\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"VANG\",\"kommunenummer\":\"3454\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"VANG\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"MØRE OG ROMSDAL\",\"fylkesnummer\":\"15\",\"kommune\":\"VANYLVEN\",\"kommunenummer\":\"1511\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"VANYLVEN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"FINNMARK\",\"fylkesnummer\":\"56\",\"kommune\":\"VARDØ\",\"kommunenummer\":\"5634\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"VARDØ\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"NORDLAND\",\"fylkesnummer\":\"18\",\"kommune\":\"VEFSN\",\"kommunenummer\":\"1824\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"VEFSN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"NORDLAND\",\"fylkesnummer\":\"18\",\"kommune\":\"VEGA\",\"kommunenummer\":\"1815\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"VEGA\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AGDER\",\"fylkesnummer\":\"42\",\"kommune\":\"VEGÅRSHEI\",\"kommunenummer\":\"4212\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"VEGÅRSHEI\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AGDER\",\"fylkesnummer\":\"42\",\"kommune\":\"VENNESLA\",\"kommunenummer\":\"4223\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"VENNESLA\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TRØNDELAG\",\"fylkesnummer\":\"50\",\"kommune\":\"VERDAL\",\"kommunenummer\":\"5038\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"VERDAL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AKERSHUS\",\"fylkesnummer\":\"32\",\"kommune\":\"VESTBY\",\"kommunenummer\":\"3216\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"VESTBY\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTFOLD\",\"fylkesnummer\":\"39\",\"kommune\":null,\"kommunenummer\":null,\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"VESTFOLD\",\"type\":\"FYLKE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTLAND\",\"fylkesnummer\":\"46\",\"kommune\":null,\"kommunenummer\":null,\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"VESTLAND\",\"type\":\"FYLKE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"MØRE OG ROMSDAL\",\"fylkesnummer\":\"15\",\"kommune\":\"VESTNES\",\"kommunenummer\":\"1535\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"VESTNES\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"VESTRE SLIDRE\",\"kommunenummer\":\"3452\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"VESTRE SLIDRE\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"VESTRE TOTEN\",\"kommunenummer\":\"3443\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"VESTRE TOTEN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"NORDLAND\",\"fylkesnummer\":\"18\",\"kommune\":\"VESTVÅGØY\",\"kommunenummer\":\"1860\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"VESTVÅGØY\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"NORDLAND\",\"fylkesnummer\":\"18\",\"kommune\":\"VEVELSTAD\",\"kommunenummer\":\"1816\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"VEVELSTAD\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTLAND\",\"fylkesnummer\":\"46\",\"kommune\":\"VIK\",\"kommunenummer\":\"4639\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"VIK\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"ROGALAND\",\"fylkesnummer\":\"11\",\"kommune\":\"VINDAFJORD\",\"kommunenummer\":\"1160\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"VINDAFJORD\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TELEMARK\",\"fylkesnummer\":\"40\",\"kommune\":\"VINJE\",\"kommunenummer\":\"4036\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"VINJE\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"MØRE OG ROMSDAL\",\"fylkesnummer\":\"15\",\"kommune\":\"VOLDA\",\"kommunenummer\":\"1577\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"VOLDA\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTLAND\",\"fylkesnummer\":\"46\",\"kommune\":\"VOSS\",\"kommunenummer\":\"4621\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"VOSS\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"NORDLAND\",\"fylkesnummer\":\"18\",\"kommune\":\"VÆRØY\",\"kommunenummer\":\"1857\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"VÆRØY\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"NORDLAND\",\"fylkesnummer\":\"18\",\"kommune\":\"VÅGAN\",\"kommunenummer\":\"1865\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"VÅGAN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"VÅGÅ\",\"kommunenummer\":\"3435\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"VÅGÅ\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"VÅLER (INNLANDET)\",\"kommunenummer\":\"3419\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"VÅLER (INNLANDET)\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"ØSTFOLD\",\"fylkesnummer\":\"31\",\"kommune\":\"VÅLER (ØSTFOLD)\",\"kommunenummer\":\"3114\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"VÅLER (ØSTFOLD)\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"NORDLAND\",\"fylkesnummer\":\"18\",\"kommune\":\"ØKSNES\",\"kommunenummer\":\"1868\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ØKSNES\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TRØNDELAG\",\"fylkesnummer\":\"50\",\"kommune\":\"ØRLAND\",\"kommunenummer\":\"5057\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ØRLAND\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"MØRE OG ROMSDAL\",\"fylkesnummer\":\"15\",\"kommune\":\"ØRSTA\",\"kommunenummer\":\"1520\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ØRSTA\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"ØSTFOLD\",\"fylkesnummer\":\"31\",\"kommune\":null,\"kommunenummer\":null,\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ØSTFOLD\",\"type\":\"FYLKE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"ØSTRE TOTEN\",\"kommunenummer\":\"3442\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ØSTRE TOTEN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"BUSKERUD\",\"fylkesnummer\":\"33\",\"kommune\":\"ØVRE EIKER\",\"kommunenummer\":\"3314\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ØVRE EIKER\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"ØYER\",\"kommunenummer\":\"3440\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ØYER\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTLAND\",\"fylkesnummer\":\"46\",\"kommune\":\"ØYGARDEN\",\"kommunenummer\":\"4626\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ØYGARDEN\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"ØYSTRE SLIDRE\",\"kommunenummer\":\"3453\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ØYSTRE SLIDRE\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"TRØNDELAG\",\"fylkesnummer\":\"50\",\"kommune\":\"ÅFJORD\",\"kommunenummer\":\"5058\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ÅFJORD\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"BUSKERUD\",\"fylkesnummer\":\"33\",\"kommune\":\"ÅL\",\"kommunenummer\":\"3328\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ÅL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"MØRE OG ROMSDAL\",\"fylkesnummer\":\"15\",\"kommune\":\"ÅLESUND\",\"kommunenummer\":\"1508\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ÅLESUND\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AGDER\",\"fylkesnummer\":\"42\",\"kommune\":\"ÅMLI\",\"kommunenummer\":\"4217\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ÅMLI\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"ÅMOT\",\"kommunenummer\":\"3422\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ÅMOT\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"VESTLAND\",\"fylkesnummer\":\"46\",\"kommune\":\"ÅRDAL\",\"kommunenummer\":\"4643\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ÅRDAL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AKERSHUS\",\"fylkesnummer\":\"32\",\"kommune\":\"ÅS\",\"kommunenummer\":\"3218\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ÅS\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"AGDER\",\"fylkesnummer\":\"42\",\"kommune\":\"ÅSERAL\",\"kommunenummer\":\"4224\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ÅSERAL\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":\"INNLANDET\",\"fylkesnummer\":\"34\",\"kommune\":\"ÅSNES\",\"kommunenummer\":\"3418\",\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ÅSNES\",\"type\":\"KOMMUNE\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"AFGHANISTAN\",\"postnummer\":null,\"poststed\":null},\"navn\":\"AFGHANISTAN\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"ALBANIA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ALBANIA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"ALGERIE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ALGERIE\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"AMERIKANSK SAMOA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"AMERIKANSK SAMOA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"ANDORRA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ANDORRA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"ANGOLA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ANGOLA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"ANGUILLA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ANGUILLA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"ANTARKTIKA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ANTARKTIKA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"ANTIGUA OG BARBUDA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ANTIGUA OG BARBUDA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"ARGENTINA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ARGENTINA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"ARMENIA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ARMENIA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"ARUBA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ARUBA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"ASERBAJDSJAN\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ASERBAJDSJAN\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"AUSTRALIA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"AUSTRALIA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"BAHAMAS\",\"postnummer\":null,\"poststed\":null},\"navn\":\"BAHAMAS\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"BAHRAIN\",\"postnummer\":null,\"poststed\":null},\"navn\":\"BAHRAIN\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"BANGLADESH\",\"postnummer\":null,\"poststed\":null},\"navn\":\"BANGLADESH\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"BARBADOS\",\"postnummer\":null,\"poststed\":null},\"navn\":\"BARBADOS\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"BELARUS\",\"postnummer\":null,\"poststed\":null},\"navn\":\"BELARUS\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"BELGIA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"BELGIA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"BELIZE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"BELIZE\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"BENIN\",\"postnummer\":null,\"poststed\":null},\"navn\":\"BENIN\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"BERMUDA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"BERMUDA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"BHUTAN\",\"postnummer\":null,\"poststed\":null},\"navn\":\"BHUTAN\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"BOLIVIA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"BOLIVIA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"BONAIRE, SINT EUSTATIUS OG SABA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"BONAIRE, SINT EUSTATIUS OG SABA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"BOSNIA-HERCEGOVINA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"BOSNIA-HERCEGOVINA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"BOTSWANA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"BOTSWANA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"BOUVETØYA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"BOUVETØYA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"BRASIL\",\"postnummer\":null,\"poststed\":null},\"navn\":\"BRASIL\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"BRUNEI\",\"postnummer\":null,\"poststed\":null},\"navn\":\"BRUNEI\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"BULGARIA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"BULGARIA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"BURKINA FASO\",\"postnummer\":null,\"poststed\":null},\"navn\":\"BURKINA FASO\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"BURUNDI\",\"postnummer\":null,\"poststed\":null},\"navn\":\"BURUNDI\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"CANADA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"CANADA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"CAYMANØYENE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"CAYMANØYENE\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"CHILE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"CHILE\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"CHRISTMASØYA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"CHRISTMASØYA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"COLOMBIA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"COLOMBIA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"COOKØYENE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"COOKØYENE\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"COSTA RICA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"COSTA RICA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"CUBA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"CUBA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"CURAÇAO\",\"postnummer\":null,\"poststed\":null},\"navn\":\"CURAÇAO\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"DANMARK\",\"postnummer\":null,\"poststed\":null},\"navn\":\"DANMARK\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"DE FORENTE ARABISKE EMIRATER\",\"postnummer\":null,\"poststed\":null},\"navn\":\"DE FORENTE ARABISKE EMIRATER\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"DE FRANSKE SØRTERRITORIER\",\"postnummer\":null,\"poststed\":null},\"navn\":\"DE FRANSKE SØRTERRITORIER\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"DEN DOMINIKANSKE REPUBLIKK\",\"postnummer\":null,\"poststed\":null},\"navn\":\"DEN DOMINIKANSKE REPUBLIKK\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"DEN SENTRALAFRIKANSKE REPUBLIKK\",\"postnummer\":null,\"poststed\":null},\"navn\":\"DEN SENTRALAFRIKANSKE REPUBLIKK\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"DE PALESTINSKE TERRITORIENE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"DE PALESTINSKE TERRITORIENE\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"DET BRITISKE TERRITORIET I INDIAHAVET\",\"postnummer\":null,\"poststed\":null},\"navn\":\"DET BRITISKE TERRITORIET I INDIAHAVET\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"DJIBOUTI\",\"postnummer\":null,\"poststed\":null},\"navn\":\"DJIBOUTI\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"DOMINICA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"DOMINICA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"ECUADOR\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ECUADOR\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"EGYPT\",\"postnummer\":null,\"poststed\":null},\"navn\":\"EGYPT\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"EKVATORIAL-GUINEA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"EKVATORIAL-GUINEA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"ELFENBENSKYSTEN\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ELFENBENSKYSTEN\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"EL SALVADOR\",\"postnummer\":null,\"poststed\":null},\"navn\":\"EL SALVADOR\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"ERITREA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ERITREA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"ESTLAND\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ESTLAND\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"ESWATINI\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ESWATINI\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"ETIOPIA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ETIOPIA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"FALKLANDSØYENE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"FALKLANDSØYENE\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"FIJI\",\"postnummer\":null,\"poststed\":null},\"navn\":\"FIJI\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"FILIPPINENE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"FILIPPINENE\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"FINLAND\",\"postnummer\":null,\"poststed\":null},\"navn\":\"FINLAND\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"FRANKRIKE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"FRANKRIKE\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"FRANSK GUYANA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"FRANSK GUYANA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"FRANSK POLYNESIA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"FRANSK POLYNESIA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"FÆRØYENE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"FÆRØYENE\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"GABON\",\"postnummer\":null,\"poststed\":null},\"navn\":\"GABON\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"GAMBIA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"GAMBIA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"GEORGIA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"GEORGIA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"GHANA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"GHANA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"GIBRALTAR\",\"postnummer\":null,\"poststed\":null},\"navn\":\"GIBRALTAR\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"GRENADA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"GRENADA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"GRØNLAND\",\"postnummer\":null,\"poststed\":null},\"navn\":\"GRØNLAND\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"GUADELOUPE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"GUADELOUPE\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"GUAM\",\"postnummer\":null,\"poststed\":null},\"navn\":\"GUAM\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"GUATEMALA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"GUATEMALA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"GUERNSEY\",\"postnummer\":null,\"poststed\":null},\"navn\":\"GUERNSEY\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"GUINEA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"GUINEA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"GUINEA-BISSAU\",\"postnummer\":null,\"poststed\":null},\"navn\":\"GUINEA-BISSAU\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"GUYANA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"GUYANA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"HAITI\",\"postnummer\":null,\"poststed\":null},\"navn\":\"HAITI\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"HEARD- OG MCDONALDØYENE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"HEARD- OG MCDONALDØYENE\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"HELLAS\",\"postnummer\":null,\"poststed\":null},\"navn\":\"HELLAS\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"HONDURAS\",\"postnummer\":null,\"poststed\":null},\"navn\":\"HONDURAS\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"HONGKONG\",\"postnummer\":null,\"poststed\":null},\"navn\":\"HONGKONG\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"INDIA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"INDIA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"INDONESIA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"INDONESIA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"IRAK\",\"postnummer\":null,\"poststed\":null},\"navn\":\"IRAK\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"IRAN\",\"postnummer\":null,\"poststed\":null},\"navn\":\"IRAN\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"IRLAND\",\"postnummer\":null,\"poststed\":null},\"navn\":\"IRLAND\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"ISLAND\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ISLAND\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"ISRAEL\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ISRAEL\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"ITALIA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ITALIA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"JAMAICA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"JAMAICA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"JAPAN\",\"postnummer\":null,\"poststed\":null},\"navn\":\"JAPAN\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"JEMEN\",\"postnummer\":null,\"poststed\":null},\"navn\":\"JEMEN\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"JERSEY\",\"postnummer\":null,\"poststed\":null},\"navn\":\"JERSEY\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"JOMFRUØYENE, DE AMERIKANSKE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"JOMFRUØYENE, DE AMERIKANSKE\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"JOMFRUØYENE, DE BRITISKE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"JOMFRUØYENE, DE BRITISKE\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"JORDAN\",\"postnummer\":null,\"poststed\":null},\"navn\":\"JORDAN\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"KAMBODSJA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"KAMBODSJA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"KAMERUN\",\"postnummer\":null,\"poststed\":null},\"navn\":\"KAMERUN\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"KAPP VERDE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"KAPP VERDE\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"KASAKHSTAN\",\"postnummer\":null,\"poststed\":null},\"navn\":\"KASAKHSTAN\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"KENYA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"KENYA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"KINA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"KINA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"KIRGISISTAN\",\"postnummer\":null,\"poststed\":null},\"navn\":\"KIRGISISTAN\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"KIRIBATI\",\"postnummer\":null,\"poststed\":null},\"navn\":\"KIRIBATI\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"KOKOSØYENE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"KOKOSØYENE\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"KOMORENE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"KOMORENE\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"KONGO, DEN DEMOKRATISKE REPUBLIKKEN\",\"postnummer\":null,\"poststed\":null},\"navn\":\"KONGO, DEN DEMOKRATISKE REPUBLIKKEN\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"KONGO, REPUBLIKKEN\",\"postnummer\":null,\"poststed\":null},\"navn\":\"KONGO, REPUBLIKKEN\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"KROATIA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"KROATIA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"KUWAIT\",\"postnummer\":null,\"poststed\":null},\"navn\":\"KUWAIT\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"KYPROS\",\"postnummer\":null,\"poststed\":null},\"navn\":\"KYPROS\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"LAOS\",\"postnummer\":null,\"poststed\":null},\"navn\":\"LAOS\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"LATVIA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"LATVIA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"LESOTHO\",\"postnummer\":null,\"poststed\":null},\"navn\":\"LESOTHO\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"LIBANON\",\"postnummer\":null,\"poststed\":null},\"navn\":\"LIBANON\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"LIBERIA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"LIBERIA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"LIBYA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"LIBYA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"LIECHTENSTEIN\",\"postnummer\":null,\"poststed\":null},\"navn\":\"LIECHTENSTEIN\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"LITAUEN\",\"postnummer\":null,\"poststed\":null},\"navn\":\"LITAUEN\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"LUXEMBOURG\",\"postnummer\":null,\"poststed\":null},\"navn\":\"LUXEMBOURG\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"MACAO\",\"postnummer\":null,\"poststed\":null},\"navn\":\"MACAO\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"MADAGASKAR\",\"postnummer\":null,\"poststed\":null},\"navn\":\"MADAGASKAR\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"MALAWI\",\"postnummer\":null,\"poststed\":null},\"navn\":\"MALAWI\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"MALAYSIA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"MALAYSIA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"MALDIVENE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"MALDIVENE\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"MALI\",\"postnummer\":null,\"poststed\":null},\"navn\":\"MALI\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"MALTA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"MALTA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"MAN\",\"postnummer\":null,\"poststed\":null},\"navn\":\"MAN\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"MAROKKO\",\"postnummer\":null,\"poststed\":null},\"navn\":\"MAROKKO\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"MARSHALLØYENE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"MARSHALLØYENE\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"MARTINIQUE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"MARTINIQUE\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"MAURITANIA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"MAURITANIA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"MAURITIUS\",\"postnummer\":null,\"poststed\":null},\"navn\":\"MAURITIUS\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"MAYOTTE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"MAYOTTE\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"MEXICO\",\"postnummer\":null,\"poststed\":null},\"navn\":\"MEXICO\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"MIKRONESIAFØDERASJONEN\",\"postnummer\":null,\"poststed\":null},\"navn\":\"MIKRONESIAFØDERASJONEN\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"MOLDOVA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"MOLDOVA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"MONACO\",\"postnummer\":null,\"poststed\":null},\"navn\":\"MONACO\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"MONGOLIA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"MONGOLIA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"MONTENEGRO\",\"postnummer\":null,\"poststed\":null},\"navn\":\"MONTENEGRO\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"MONTSERRAT\",\"postnummer\":null,\"poststed\":null},\"navn\":\"MONTSERRAT\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"MOSAMBIK\",\"postnummer\":null,\"poststed\":null},\"navn\":\"MOSAMBIK\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"MYANMAR\",\"postnummer\":null,\"poststed\":null},\"navn\":\"MYANMAR\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"NAMIBIA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"NAMIBIA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"NAURU\",\"postnummer\":null,\"poststed\":null},\"navn\":\"NAURU\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"NEDERLAND\",\"postnummer\":null,\"poststed\":null},\"navn\":\"NEDERLAND\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"NEPAL\",\"postnummer\":null,\"poststed\":null},\"navn\":\"NEPAL\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"NEW ZEALAND\",\"postnummer\":null,\"poststed\":null},\"navn\":\"NEW ZEALAND\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"NICARAGUA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"NICARAGUA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"NIGER\",\"postnummer\":null,\"poststed\":null},\"navn\":\"NIGER\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"NIGERIA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"NIGERIA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"NIUE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"NIUE\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"NORD-KOREA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"NORD-KOREA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"NORD-MAKEDONIA, REPUBLIKKEN\",\"postnummer\":null,\"poststed\":null},\"navn\":\"NORD-MAKEDONIA, REPUBLIKKEN\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"NORD-MARIANENE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"NORD-MARIANENE\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"NORFOLKØYA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"NORFOLKØYA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"NORGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"NORGE\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"NY-CALEDONIA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"NY-CALEDONIA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"OMAN\",\"postnummer\":null,\"poststed\":null},\"navn\":\"OMAN\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"PAKISTAN\",\"postnummer\":null,\"poststed\":null},\"navn\":\"PAKISTAN\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"PALAU\",\"postnummer\":null,\"poststed\":null},\"navn\":\"PALAU\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"PANAMA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"PANAMA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"PAPUA NY-GUINEA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"PAPUA NY-GUINEA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"PARAGUAY\",\"postnummer\":null,\"poststed\":null},\"navn\":\"PARAGUAY\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"PERU\",\"postnummer\":null,\"poststed\":null},\"navn\":\"PERU\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"PITCAIRNØYENE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"PITCAIRNØYENE\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"POLEN\",\"postnummer\":null,\"poststed\":null},\"navn\":\"POLEN\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"PORTUGAL\",\"postnummer\":null,\"poststed\":null},\"navn\":\"PORTUGAL\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"PUERTO RICO\",\"postnummer\":null,\"poststed\":null},\"navn\":\"PUERTO RICO\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"QATAR\",\"postnummer\":null,\"poststed\":null},\"navn\":\"QATAR\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"RÉUNION\",\"postnummer\":null,\"poststed\":null},\"navn\":\"RÉUNION\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"ROMANIA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ROMANIA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"RUSSLAND\",\"postnummer\":null,\"poststed\":null},\"navn\":\"RUSSLAND\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"RWANDA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"RWANDA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"SAINT-BARTHÉLEMY\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SAINT-BARTHÉLEMY\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"SAINT KITTS OG NEVIS\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SAINT KITTS OG NEVIS\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"SAINT LUCIA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SAINT LUCIA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"SAINT-MARTIN\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SAINT-MARTIN\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"SAINT-PIERRE OG MIQUELON\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SAINT-PIERRE OG MIQUELON\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"SAINT VINCENT OG GRENADINENE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SAINT VINCENT OG GRENADINENE\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"SALOMONØYENE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SALOMONØYENE\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"SAMOA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SAMOA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"SAN MARINO\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SAN MARINO\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"SÃO TOMÉ OG PRÍNCIPE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SÃO TOMÉ OG PRÍNCIPE\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"SAUDI-ARABIA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SAUDI-ARABIA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"SENEGAL\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SENEGAL\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"SERBIA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SERBIA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"SEYCHELLENE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SEYCHELLENE\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"SIERRA LEONE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SIERRA LEONE\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"SINGAPORE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SINGAPORE\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"SINT MAARTEN\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SINT MAARTEN\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"SLOVAKIA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SLOVAKIA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"SLOVENIA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SLOVENIA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"SOMALIA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SOMALIA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"SPANIA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SPANIA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"SRI LANKA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SRI LANKA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"ST. HELENA, ASCENSION OG TRISTAN DA CUNHA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ST. HELENA, ASCENSION OG TRISTAN DA CUNHA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"STORBRITANNIA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"STORBRITANNIA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"SUDAN\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SUDAN\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"SURINAM\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SURINAM\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"SVALBARD OG JAN MAYEN\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SVALBARD OG JAN MAYEN\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"SVEITS\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SVEITS\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"SVERIGE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SVERIGE\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"SYRIA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SYRIA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"SØR-AFRIKA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SØR-AFRIKA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"SØR-GEORGIA OG SØR-SANDWICHØYENE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SØR-GEORGIA OG SØR-SANDWICHØYENE\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"SØR-KOREA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SØR-KOREA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"SØR-SUDAN\",\"postnummer\":null,\"poststed\":null},\"navn\":\"SØR-SUDAN\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"TADSJIKISTAN\",\"postnummer\":null,\"poststed\":null},\"navn\":\"TADSJIKISTAN\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"TAIWAN\",\"postnummer\":null,\"poststed\":null},\"navn\":\"TAIWAN\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"TANZANIA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"TANZANIA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"THAILAND\",\"postnummer\":null,\"poststed\":null},\"navn\":\"THAILAND\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"TOGO\",\"postnummer\":null,\"poststed\":null},\"navn\":\"TOGO\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"TOKELAU\",\"postnummer\":null,\"poststed\":null},\"navn\":\"TOKELAU\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"TONGA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"TONGA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"TRINIDAD OG TOBAGO\",\"postnummer\":null,\"poststed\":null},\"navn\":\"TRINIDAD OG TOBAGO\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"TSJAD\",\"postnummer\":null,\"poststed\":null},\"navn\":\"TSJAD\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"TSJEKKIA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"TSJEKKIA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"TUNISIA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"TUNISIA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"TURKMENISTAN\",\"postnummer\":null,\"poststed\":null},\"navn\":\"TURKMENISTAN\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"TURKS- OG CAICOSØYENE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"TURKS- OG CAICOSØYENE\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"TUVALU\",\"postnummer\":null,\"poststed\":null},\"navn\":\"TUVALU\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"TYRKIA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"TYRKIA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"TYSKLAND\",\"postnummer\":null,\"poststed\":null},\"navn\":\"TYSKLAND\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"UGANDA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"UGANDA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"UKRAINA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"UKRAINA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"UNGARN\",\"postnummer\":null,\"poststed\":null},\"navn\":\"UNGARN\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"URUGUAY\",\"postnummer\":null,\"poststed\":null},\"navn\":\"URUGUAY\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"USA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"USA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"USAS YTRE SMÅØYER\",\"postnummer\":null,\"poststed\":null},\"navn\":\"USAS YTRE SMÅØYER\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"USBEKISTAN\",\"postnummer\":null,\"poststed\":null},\"navn\":\"USBEKISTAN\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"VANUATU\",\"postnummer\":null,\"poststed\":null},\"navn\":\"VANUATU\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"VATIKANSTATEN\",\"postnummer\":null,\"poststed\":null},\"navn\":\"VATIKANSTATEN\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"VENEZUELA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"VENEZUELA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"VEST-SAHARA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"VEST-SAHARA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"VIETNAM\",\"postnummer\":null,\"poststed\":null},\"navn\":\"VIETNAM\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"WALLIS- OG FUTUNAØYENE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"WALLIS- OG FUTUNAØYENE\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"ZAMBIA\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ZAMBIA\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"ZIMBABWE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ZIMBABWE\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"ØSTERRIKE\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ØSTERRIKE\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"ØST-TIMOR\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ØST-TIMOR\",\"type\":\"LAND\"},{\"lokasjon\":{\"adresse\":null,\"fylke\":null,\"fylkesnummer\":null,\"kommune\":null,\"kommunenummer\":null,\"land\":\"ÅLAND\",\"postnummer\":null,\"poststed\":null},\"navn\":\"ÅLAND\",\"type\":\"LAND\"}]"));}),
"[project]/app/api/pam-geografi/typehead/lokasjoner/usePamGeografi.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GeografiType",
    ()=>GeografiType,
    "pamGeografiMSWHandler",
    ()=>pamGeografiMSWHandler,
    "usePamGeografi",
    ()=>usePamGeografi
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$pam$2d$geografi$2f$typehead$2f$lokasjoner$2f$lokasjoner$2e$mock$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/app/api/pam-geografi/typehead/lokasjoner/lokasjoner.mock.json (json)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRGet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/useSWRGet.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/http.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/HttpResponse.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
/**
 * Endepunkt /usePamGeografi
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zod@4.0.17/node_modules/zod/v4/classic/external.js [app-client] (ecmascript) <export * as z>");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
const pamGeografiEndepunkt = '/api/pam-geografi/typehead/lokasjoner';
var GeografiType = /*#__PURE__*/ function(GeografiType) {
    GeografiType["KOMMUNE"] = "KOMMUNE";
    GeografiType["LAND"] = "LAND";
    GeografiType["FYLKE"] = "FYLKE";
    return GeografiType;
}({});
const PamGeografiSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    navn: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].nativeEnum(GeografiType),
    lokasjon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
        adresse: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
        postnummer: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
        poststed: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
        fylke: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
        fylkesnummer: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
        kommune: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
        kommunenummer: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
        land: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable()
    })
});
const PamGeografiSchemaDTO = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(PamGeografiSchema);
_c = PamGeografiSchemaDTO;
const usePamGeografi = ()=>{
    _s();
    const hook = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRGet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSWRGet"])(pamGeografiEndepunkt, PamGeografiSchemaDTO);
    const filteredData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "usePamGeografi.useMemo[filteredData]": ()=>{
            return hook.data?.filter({
                "usePamGeografi.useMemo[filteredData]": (pamGeografi)=>pamGeografi.type !== "LAND" || pamGeografi.type === "LAND" && pamGeografi.navn?.toUpperCase() === 'NORGE'
            }["usePamGeografi.useMemo[filteredData]"]);
        }
    }["usePamGeografi.useMemo[filteredData]"], [
        hook.data
    ]);
    return {
        ...hook,
        data: filteredData
    };
};
_s(usePamGeografi, "SV2xj1cPdpfhZEJ7oohcynalD6k=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRGet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSWRGet"]
    ];
});
const pamGeografiMSWHandler = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].get(pamGeografiEndepunkt, ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$pam$2d$geografi$2f$typehead$2f$lokasjoner$2f$lokasjoner$2e$mock$2e$json__$28$json$29$__["default"]));
var _c;
__turbopack_context__.k.register(_c, "PamGeografiSchemaDTO");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/stillings-sok/elastic-search/queries/geografi-query.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "geografiQuery",
    ()=>geografiQuery
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$pam$2d$geografi$2f$typehead$2f$lokasjoner$2f$usePamGeografi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/pam-geografi/typehead/lokasjoner/usePamGeografi.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$fylkeOgKommuneMapping$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/util/fylkeOgKommuneMapping.ts [app-client] (ecmascript)");
;
;
const geografiQuery = (params, esBuilder)=>{
    if (params.geografiData && params.filter.fylker?.length > 0 || params.filter.kommuner?.length > 0) {
        const valgteFylker = params.geografiData?.filter((geografi)=>geografi.type === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$pam$2d$geografi$2f$typehead$2f$lokasjoner$2f$usePamGeografi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GeografiType"].FYLKE).filter((fylke)=>fylke.lokasjon.fylkesnummer && params.filter?.fylker.includes(fylke.lokasjon.fylkesnummer)) ?? [];
        const valgteKommuner = params.geografiData?.filter((geografi)=>geografi.type === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$pam$2d$geografi$2f$typehead$2f$lokasjoner$2f$usePamGeografi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GeografiType"].KOMMUNE).filter((kommune)=>{
            const kommuneErValgt = kommune.lokasjon.kommunenummer && params.filter?.kommuner.includes(kommune.lokasjon.kommunenummer);
            return kommuneErValgt;
        }) ?? [];
        const kommunerDerKunFylkeErValgt = valgteFylker.filter((fylke)=>fylke.type === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$pam$2d$geografi$2f$typehead$2f$lokasjoner$2f$usePamGeografi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GeografiType"].FYLKE && fylke.lokasjon.fylkesnummer && !valgteKommuner.some((k)=>k.lokasjon.fylkesnummer === fylke.lokasjon.fylkesnummer)).flatMap((fylke)=>params.geografiData?.filter((g)=>g.lokasjon.fylkesnummer === fylke.lokasjon.fylkesnummer && g.type === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$pam$2d$geografi$2f$typehead$2f$lokasjoner$2f$usePamGeografi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GeografiType"].KOMMUNE) ?? []);
        const fylkerUtenValgteKommuner = valgteFylker.filter((fylke)=>fylke.lokasjon.fylkesnummer && !valgteKommuner.some((k)=>k.lokasjon.fylkesnummer === fylke.lokasjon.fylkesnummer));
        const valgteFylkerOgKommuner = [
            ...fylkerUtenValgteKommuner,
            ...valgteKommuner,
            ...kommunerDerKunFylkeErValgt
        ];
        const fylkeSøk = valgteFylkerOgKommuner.filter((f)=>f.type === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$pam$2d$geografi$2f$typehead$2f$lokasjoner$2f$usePamGeografi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GeografiType"].FYLKE);
        const fylker = valgteFylkerOgKommuner.filter((f)=>f.type === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$pam$2d$geografi$2f$typehead$2f$lokasjoner$2f$usePamGeografi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GeografiType"].FYLKE);
        if (fylker.length === 0 && valgteFylkerOgKommuner.filter((kommune)=>kommune.type === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$pam$2d$geografi$2f$typehead$2f$lokasjoner$2f$usePamGeografi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GeografiType"].KOMMUNE).length === 0) return;
        const kommunerInkludertGamleKoder = valgteFylkerOgKommuner.filter((kommune)=>kommune.type === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$pam$2d$geografi$2f$typehead$2f$lokasjoner$2f$usePamGeografi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GeografiType"].KOMMUNE).flatMap((kommune)=>{
            const ekstraSteder = kommune.lokasjon.kommunenummer && __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$fylkeOgKommuneMapping$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stedmappingFraNyttNummer"].get(kommune.lokasjon.kommunenummer)?.map((sted)=>{
                return sted.nummer;
            });
            return [
                kommune.lokasjon.kommunenummer,
                ...ekstraSteder || []
            ];
        });
        const fylkerInkludertGamleNavn = new Set([
            ...fylkeSøk
        ].flatMap((fylke)=>{
            const ekstraNavn = __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$fylkeOgKommuneMapping$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stedmappingFraNyttNavn"].get((0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$fylkeOgKommuneMapping$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formaterStedsnavn"])(fylke.navn))?.map((sted)=>sted.navn.toUpperCase()) || [];
            return [
                fylke.navn,
                ...ekstraNavn
            ];
        }));
        const shouldFylker = fylkerInkludertGamleNavn.size === 0 ? [] : [
            {
                terms: {
                    'stilling.locations.county.keyword': Array.from(fylkerInkludertGamleNavn).map((fylke)=>fylke.toUpperCase())
                }
            }
        ];
        const shouldKommuner = kommunerInkludertGamleKoder.length === 0 ? [] : [
            {
                terms: {
                    'stilling.locations.municipalCode': kommunerInkludertGamleKoder
                }
            }
        ];
        // Legg til nested geografi-query
        esBuilder.addFilter({
            nested: {
                path: 'stilling.locations',
                query: {
                    bool: {
                        should: [
                            ...shouldFylker,
                            ...shouldKommuner
                        ],
                        minimum_should_match: 1
                    }
                }
            }
        });
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/stillings-sok/elastic-search/queries/inkludering-query.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "inkluderingQuery",
    ()=>inkluderingQuery
]);
const inkluderingQuery = (params, esBuilder)=>{
    if (params.filter.inkludering && params.filter.inkludering.length > 0) {
        esBuilder.addFilter({
            terms: {
                'stilling.properties.tags': params.filter.inkludering
            }
        });
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/stillings-sok/elastic-search/queries/kategori-query.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "kategoriQuery",
    ()=>kategoriQuery
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$stilling$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/_ui/stilling-typer.ts [app-client] (ecmascript)");
;
const kategoriQuery = (params, esBuilder)=>{
    const kategori = params.filter.kategori;
    // Hvis kun jobbmesse er valgt
    if (kategori.includes(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$stilling$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Stillingskategori"].Jobbmesse)) {
        esBuilder.addBoolFilter({
            should: [
                {
                    term: {
                        'stillingsinfo.stillingskategori': 'JOBBMESSE'
                    }
                }
            ],
            minimum_should_match: 1
        });
    }
    // Hvis kun stilling er valgt (ikke jobbmesse)
    if (kategori.includes(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$stilling$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Stillingskategori"].Stilling) && !kategori.includes(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_ui$2f$stilling$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Stillingskategori"].Jobbmesse)) {
        esBuilder.addBoolFilter({
            must_not: [
                {
                    term: {
                        'stillingsinfo.stillingskategori': 'ARBEIDSTRENING'
                    }
                },
                {
                    term: {
                        'stillingsinfo.stillingskategori': 'JOBBMESSE'
                    }
                }
            ]
        });
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/stillings-sok/elastic-search/queries/portefølje-query.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "esPortefølje",
    ()=>esPortefølje
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_util$2f$stillingss$f8$k$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/_util/stillingssøk-typer.ts [app-client] (ecmascript)");
;
const esPortefølje = (params, esBuilder)=>{
    // Fjern arbeidstrening og formidling
    if (!params.formidlinger) {
        esBuilder.addBoolFilter({
            must_not: [
                {
                    term: {
                        'stillingsinfo.stillingskategori': 'ARBEIDSTRENING'
                    }
                },
                {
                    term: {
                        'stillingsinfo.stillingskategori': 'FORMIDLING'
                    }
                }
            ]
        });
    } else {
        esBuilder.addMust('stillingsinfo.stillingskategori', 'FORMIDLING');
    }
    if (params.filter.portefølje === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_util$2f$stillingss$f8$k$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StillingsSøkPortefølje"].INTERN) {
        // Viser kun stillinger med stillingsinfo (har kandidatliste)
        esBuilder.addFilter({
            exists: {
                field: 'stillingsinfo'
            }
        });
        //Viser kun stillinger som er eller har blitt publisert:
        esBuilder.addBoolFilter({
            must_not: [
                {
                    term: {
                        'stilling.status': 'REJECTED'
                    }
                },
                {
                    term: {
                        'stilling.status': 'DELETED'
                    }
                }
            ],
            must: [
                {
                    exists: {
                        field: 'stilling.publishedByAdmin'
                    }
                },
                {
                    range: {
                        'stilling.published': {
                            lte: 'now/d'
                        }
                    }
                }
            ]
        });
    } else if (params.filter.portefølje === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_util$2f$stillingss$f8$k$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StillingsSøkPortefølje"].VIS_MINE) {
        // Validerer at navIdent finnes og ikke er tom
        if (params.navIdent) {
            esBuilder.addBoolFilter({
                must_not: [
                    {
                        term: {
                            'stilling.status': 'REJECTED'
                        }
                    },
                    {
                        term: {
                            'stilling.status': 'DELETED'
                        }
                    }
                ]
            });
            esBuilder.addBoolFilter({
                should: [
                    {
                        term: {
                            'stilling.administration.navIdent': params.navIdent
                        }
                    },
                    {
                        term: {
                            'stillingsinfo.eierNavident': params.navIdent
                        }
                    }
                ],
                minimum_should_match: 1
            });
        }
    } else if (params.filter.portefølje === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_util$2f$stillingss$f8$k$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StillingsSøkPortefølje"].MITT_KONTOR) {
        // Validerer at eierNavKontorEnhetId finnes og ikke er tom
        if (params.eierNavKontorEnhetId) {
            esBuilder.addFilter({
                term: {
                    'stillingsinfo.eierNavKontorEnhetId': params.eierNavKontorEnhetId
                }
            });
        }
        // Ekskluder "Ikke publisert" og "Avbrutt" statuser fra Mitt kontor søkeresultater
        esBuilder.addBoolFilter({
            must_not: [
                // Ekskluder "Ikke publisert" (INACTIVE uten publishedByAdmin)
                {
                    bool: {
                        must: [
                            {
                                term: {
                                    'stilling.status': 'INACTIVE'
                                }
                            }
                        ],
                        must_not: [
                            {
                                exists: {
                                    field: 'stilling.publishedByAdmin'
                                }
                            }
                        ]
                    }
                },
                // Ekskluder "Avbrutt" (DELETED)
                {
                    term: {
                        'stilling.status': 'DELETED'
                    }
                }
            ]
        });
    } else if (params.filter.portefølje === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_util$2f$stillingss$f8$k$2d$typer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StillingsSøkPortefølje"].ARBEIDSPLASSEN_NO) {
        esBuilder.addFilter({
            term: {
                'stilling.privacy': 'SHOW_ALL'
            }
        });
        esBuilder.addBoolFilter({
            must_not: [
                {
                    term: {
                        'stilling.source': 'DIR'
                    }
                }
            ]
        });
        if (!params.filter.utenOppdrag) {
            esBuilder.addFilter({
                exists: {
                    field: 'stillingsinfo'
                }
            });
        } else {
            esBuilder.addBoolFilter({
                must_not: [
                    {
                        term: {
                            'stilling.status': 'REJECTED'
                        }
                    },
                    {
                        term: {
                            'stilling.status': 'DELETED'
                        }
                    }
                ],
                must: [
                    {
                        term: {
                            'stilling.administration.status': 'DONE'
                        }
                    },
                    {
                        exists: {
                            field: 'stilling.publishedByAdmin'
                        }
                    },
                    {
                        range: {
                            'stilling.published': {
                                lte: 'now/d'
                            }
                        }
                    }
                ]
            });
        }
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/stillings-sok/elastic-search/queries/sortering-query.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "sorteringQuery",
    ()=>sorteringQuery
]);
const sorteringQuery = (params, esBuilder)=>{
    const sortering = params.filter.sortering;
    const sorteringsalternativer = {
        publisert: [
            {
                'stilling.published': {
                    order: 'desc'
                }
            }
        ],
        utløpsdato: [
            {
                'stilling.expires': {
                    order: 'asc'
                }
            }
        ],
        relevans: []
    };
    // Hvis ingen sortering er spesifisert, bruk 'publisert' som default
    const sorteringsNøkkel = sortering || 'publisert';
    const valgtSortering = sorteringsalternativer[sorteringsNøkkel] || sorteringsalternativer.publisert;
    if (valgtSortering && valgtSortering.length > 0) {
        esBuilder.setSorting(valgtSortering);
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/stillings-sok/elastic-search/queries/status-query.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "statusQuery",
    ()=>statusQuery
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_util$2f$stillingInfoUtil$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/_util/stillingInfoUtil.ts [app-client] (ecmascript)");
;
// Hjelper-funksjon for å lage publisert-kriterier
const getPublisertKriterier = ()=>[
        {
            term: {
                'stilling.administration.status': 'DONE'
            }
        },
        {
            exists: {
                field: 'stilling.publishedByAdmin'
            }
        },
        {
            range: {
                'stilling.published': {
                    lte: 'now/d'
                }
            }
        }
    ];
const alleStillinger = (esBuilder)=>{
    // Legg til bool-query med must_not for REJECTED/DELETED og must for publisert-kriterier
    esBuilder.addBoolFilter({
        must_not: [
            {
                term: {
                    'stilling.status': 'REJECTED'
                }
            },
            {
                term: {
                    'stilling.status': 'DELETED'
                }
            }
        ],
        must: getPublisertKriterier()
    });
};
const statusQuery = (params, esBuilder)=>{
    const statuserFraFilter = params.filter.statuser;
    const harArbeidsgiverrettetRolle = params.harArbeidsgiverrettetRolle ?? false;
    const skalTvingeKunApen = !params.formidlinger && !harArbeidsgiverrettetRolle;
    // Veiledere uten arbeidsgiverrettet rolle skal bare se åpne stillinger, uavhengig av URL-parametre.
    const valgteStatuser = skalTvingeKunApen ? [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_util$2f$stillingInfoUtil$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VisningsStatus"].ApenForSokere
    ] : statuserFraFilter;
    const ingenFiltreValgt = valgteStatuser.length === 0;
    const alleFiltreValgt = valgteStatuser.length === Object.values(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_util$2f$stillingInfoUtil$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VisningsStatus"]).length;
    // Baseline: alle publiserte stillinger (ekskl REJECTED/DELETED) i hovedquery slik at aggregasjoner ALLTID baserer seg på hele settet
    if (!params.navIdent) {
        alleStillinger(esBuilder);
    }
    // Ingen valgte statuser:
    //  - formidlinger=true: la være å snevre inn (alle baseline-publiserte formidlinger skal vises)
    //  - ellers: match_none for å unngå forvirrende tom baseline for intern søk der vi forventer minst én status
    if (ingenFiltreValgt) {
        // if (!params.formidlinger) {
        //   esBuilder.setPostFilter({ match_none: {} });
        // }
        return;
    }
    // Alle statuser valgt => ingen innsnevring; behold baseline uten post_filter.
    if (alleFiltreValgt) {
        return;
    }
    // Bygg post_filter for de valgte statusene — påvirker kun hits, ikke aggregasjoner
    const postFilterShould = [];
    // Mapping til visningsStatus kriterier:
    // Åpen for søkere: stilling.status=ACTIVE AND publishedByAdmin exists AND published exists AND administration.status=DONE
    if (valgteStatuser.includes(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_util$2f$stillingInfoUtil$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VisningsStatus"].ApenForSokere)) {
        postFilterShould.push({
            bool: {
                must: [
                    {
                        term: {
                            'stilling.status': 'ACTIVE'
                        }
                    },
                    {
                        term: {
                            'stilling.administration.status': 'DONE'
                        }
                    },
                    {
                        exists: {
                            field: 'stilling.publishedByAdmin'
                        }
                    },
                    {
                        range: {
                            'stilling.published': {
                                lte: 'now/d'
                            }
                        }
                    }
                ],
                must_not: [
                    {
                        term: {
                            'stilling.status': 'REJECTED'
                        }
                    },
                    {
                        term: {
                            'stilling.status': 'DELETED'
                        }
                    }
                ]
            }
        });
    }
    // Fullført (tidligere stoppet): stilling.status=STOPPED + publiseringskriterier
    if (valgteStatuser.includes(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_util$2f$stillingInfoUtil$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VisningsStatus"].Fullfort)) {
        postFilterShould.push({
            bool: {
                must: [
                    {
                        term: {
                            'stilling.status': 'STOPPED'
                        }
                    },
                    {
                        term: {
                            'stilling.administration.status': 'DONE'
                        }
                    },
                    {
                        exists: {
                            field: 'stilling.publishedByAdmin'
                        }
                    },
                    {
                        range: {
                            'stilling.published': {
                                lte: 'now/d'
                            }
                        }
                    }
                ],
                must_not: [
                    {
                        term: {
                            'stilling.status': 'REJECTED'
                        }
                    },
                    {
                        term: {
                            'stilling.status': 'DELETED'
                        }
                    }
                ]
            }
        });
    }
    // Utløpt - Stengt for søkere: stilling.status=INACTIVE + expires < today + publiseringskriterier
    if (valgteStatuser.includes(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_util$2f$stillingInfoUtil$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VisningsStatus"].UtloptStengtForSokere)) {
        postFilterShould.push({
            bool: {
                must: [
                    {
                        term: {
                            'stilling.status': 'INACTIVE'
                        }
                    },
                    {
                        range: {
                            'stilling.expires': {
                                lt: 'now/d'
                            }
                        }
                    },
                    {
                        exists: {
                            field: 'stilling.publishedByAdmin'
                        }
                    },
                    {
                        range: {
                            'stilling.published': {
                                lte: 'now/d'
                            }
                        }
                    }
                ],
                must_not: [
                    {
                        term: {
                            'stilling.status': 'REJECTED'
                        }
                    },
                    {
                        term: {
                            'stilling.status': 'DELETED'
                        }
                    }
                ]
            }
        });
    }
    if (valgteStatuser.includes(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_util$2f$stillingInfoUtil$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VisningsStatus"].StengtForSokere)) {
        postFilterShould.push({
            bool: {
                must: [
                    {
                        term: {
                            'stilling.status': 'INACTIVE'
                        }
                    },
                    {
                        exists: {
                            field: 'stilling.publishedByAdmin'
                        }
                    },
                    {
                        range: {
                            'stilling.published': {
                                lte: 'now/d'
                            }
                        }
                    }
                ],
                must_not: [
                    {
                        range: {
                            'stilling.expires': {
                                lt: 'now/d'
                            }
                        }
                    },
                    {
                        term: {
                            'stilling.status': 'REJECTED'
                        }
                    },
                    {
                        term: {
                            'stilling.status': 'DELETED'
                        }
                    }
                ]
            }
        });
    }
    if (valgteStatuser.includes(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_util$2f$stillingInfoUtil$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VisningsStatus"].IkkePublisert)) {
        postFilterShould.push({
            bool: {
                must: [
                    {
                        term: {
                            'stilling.status': 'INACTIVE'
                        }
                    }
                ],
                must_not: [
                    {
                        exists: {
                            field: 'stilling.publishedByAdmin'
                        }
                    },
                    {
                        term: {
                            'stilling.status': 'REJECTED'
                        }
                    },
                    {
                        term: {
                            'stilling.status': 'DELETED'
                        }
                    }
                ]
            }
        });
    }
    if (valgteStatuser.includes(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_util$2f$stillingInfoUtil$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VisningsStatus"].Slettet)) {
        postFilterShould.push({
            term: {
                'stilling.status': 'DELETED'
            }
        });
    }
    if (postFilterShould.length > 0) {
        esBuilder.setPostFilter({
            bool: {
                should: postFilterShould,
                minimum_should_match: 1
            }
        });
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/stillings-sok/opprettElasticSearchQuery.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "opprettElasticSearchAggregeringsQuery",
    ()=>opprettElasticSearchAggregeringsQuery,
    "opprettElasticSearchTreffQuery",
    ()=>opprettElasticSearchTreffQuery
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$elastic$2d$search$2f$elasticSearchQueryBuilder$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/stillings-sok/elastic-search/elasticSearchQueryBuilder.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$elastic$2d$search$2f$queries$2f$fritekst$2d$query$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/stillings-sok/elastic-search/queries/fritekst-query.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$elastic$2d$search$2f$queries$2f$geografi$2d$query$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/stillings-sok/elastic-search/queries/geografi-query.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$elastic$2d$search$2f$queries$2f$inkludering$2d$query$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/stillings-sok/elastic-search/queries/inkludering-query.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$elastic$2d$search$2f$queries$2f$kategori$2d$query$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/stillings-sok/elastic-search/queries/kategori-query.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$elastic$2d$search$2f$queries$2f$portef$f8$lje$2d$query$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/stillings-sok/elastic-search/queries/portefølje-query.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$elastic$2d$search$2f$queries$2f$sortering$2d$query$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/stillings-sok/elastic-search/queries/sortering-query.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$elastic$2d$search$2f$queries$2f$status$2d$query$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/stillings-sok/elastic-search/queries/status-query.ts [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
function opprettElasticSearchTreffQuery(params) {
    const esBuilder = new __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$elastic$2d$search$2f$elasticSearchQueryBuilder$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ElasticSearchQueryBuilder"]();
    // Gjenbruker samme filterlogikk som tidligere
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$elastic$2d$search$2f$queries$2f$portef$f8$lje$2d$query$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["esPortefølje"])(params, esBuilder);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$elastic$2d$search$2f$queries$2f$fritekst$2d$query$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fritekstQuery"])(params, esBuilder);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$elastic$2d$search$2f$queries$2f$status$2d$query$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["statusQuery"])(params, esBuilder);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$elastic$2d$search$2f$queries$2f$kategori$2d$query$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["kategoriQuery"])(params, esBuilder);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$elastic$2d$search$2f$queries$2f$geografi$2d$query$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["geografiQuery"])(params, esBuilder);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$elastic$2d$search$2f$queries$2f$sortering$2d$query$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sorteringQuery"])(params, esBuilder);
    if (params.filter.inkludering.length > 0 || params.filter.inkluderingUnderkategori.length > 0) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$elastic$2d$search$2f$queries$2f$inkludering$2d$query$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["inkluderingQuery"])(params, esBuilder);
    }
    const from = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$elastic$2d$search$2f$elasticSearchQueryBuilder$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["regnUtFørsteTreffFra"])(params.filter.side, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$elastic$2d$search$2f$elasticSearchQueryBuilder$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["maksAntallTreffPerSøk"]);
    return esBuilder.build(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$elastic$2d$search$2f$elasticSearchQueryBuilder$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["maksAntallTreffPerSøk"], from);
}
function opprettElasticSearchAggregeringsQuery(params) {
    const esBuilder = new __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$elastic$2d$search$2f$elasticSearchQueryBuilder$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ElasticSearchQueryBuilder"]();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$elastic$2d$search$2f$queries$2f$portef$f8$lje$2d$query$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["esPortefølje"])(params, esBuilder);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$elastic$2d$search$2f$queries$2f$fritekst$2d$query$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fritekstQuery"])(params, esBuilder);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$elastic$2d$search$2f$queries$2f$status$2d$query$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["statusQuery"])(params, esBuilder);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$elastic$2d$search$2f$queries$2f$kategori$2d$query$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["kategoriQuery"])(params, esBuilder);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$elastic$2d$search$2f$queries$2f$geografi$2d$query$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["geografiQuery"])(params, esBuilder);
    // sortering er irrelevant for aggregering – utelates bevisst
    if (params.filter.inkludering.length > 0 || params.filter.inkluderingUnderkategori.length > 0) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$elastic$2d$search$2f$queries$2f$inkludering$2d$query$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["inkluderingQuery"])(params, esBuilder);
    }
    esBuilder.setStandardAggregation(params.navIdent, params.eierNavKontorEnhetId, params.filter.fritekst, {
        formidlinger: params.formidlinger,
        utenOppdrag: params.filter.utenOppdrag,
        includePortfolioInCounts: true
    });
    // size=0 for kun aggregeringer
    return esBuilder.build(0, 0);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/stillings-sok/schema/stillingPropertiesSchema.zod.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ESStillingPropertiesSchema",
    ()=>ESStillingPropertiesSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zod@4.0.17/node_modules/zod/v4/classic/external.js [app-client] (ecmascript) <export * as z>");
;
const ESSearchTagSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    label: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    score: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number()
});
const ESOntologyJobtitleSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    konseptId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number(),
    label: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    styrk08: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string()
});
const ESStillingPropertiesSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    adtext: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullish(),
    sourceurl: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullish(),
    applicationdue: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullish(),
    applicationemail: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullish(),
    applicationmail: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullish(),
    applicationlabel: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].union([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number()
    ]).nullish(),
    applicationurl: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullish(),
    employer: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].union([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number()
    ]).nullish(),
    employerdescription: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].union([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number()
    ]).nullish(),
    employerhomepage: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullish(),
    engagementtype: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullish(),
    extent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullish(),
    occupation: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullish(),
    positioncount: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number().nullish(),
    salary: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].union([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number(),
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string()
    ]).nullish(),
    starttime: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullish(),
    role: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullish(),
    sector: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullish(),
    location: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].union([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number()
    ]).nullish(),
    externalref: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].union([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number()
    ]).nullish(),
    jobtitle: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].union([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number()
    ]).nullish(),
    keywords: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullish().nullable(),
    sourcecreated: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullish(),
    sourceupdated: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullish(),
    logomain: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullish(),
    logolisting: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullish(),
    author: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullish(),
    address: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].union([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number()
    ]).nullish(),
    industry: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullish(),
    nace2: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any().nullish(),
    searchtags: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(ESSearchTagSchema).nullish(),
    searchtagsai: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string()).nullish(),
    classification_styrk08_score: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number().nullish(),
    classification_input_source: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullish(),
    classification_styrk08_code: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].union([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number(),
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string()
    ]).nullish(),
    classification_esco_code: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullish(),
    categories: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any()).nullish(),
    euresflagg: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].union([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].boolean()
    ]).nullish(),
    hasInterestform: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].union([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].boolean(),
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number()
    ]).nullish(),
    remote: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullish(),
    workLanguage: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].union([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string())
    ]).nullish(),
    finnSource: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullish(),
    adtextFormat: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullish(),
    tags: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string()).nullish(),
    ontologyJobtitle: ESOntologyJobtitleSchema.nullish(),
    workschedule: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].union([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string())
    ]).nullish(),
    workhours: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].union([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string())
    ]).nullish(),
    workday: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].union([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string())
    ]).nullish(),
    facebookpage: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullish(),
    contactperson: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullish(),
    contactpersontitle: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullish(),
    contactpersonemail: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullish(),
    contactpersonphone: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullish(),
    linkedinpage: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullish(),
    jobpercentage: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].union([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number()
    ]).nullish(),
    jobpercentagerange: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullish(),
    jobarrangement: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullish(),
    twitteraddress: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullish(),
    admintags: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullish(),
    arbeidsplassenoccupation: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullish(),
    needDriversLicense: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].boolean().nullish(),
    experience: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullish(),
    copyOfExistingAd: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullish(),
    under18: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullish(),
    education: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string()).nullish(),
    certificate: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullish(),
    expertise: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullish(),
    practice: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullish(),
    hardrequirements: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any().nullish(),
    softrequirements: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any().nullish(),
    personalattributes: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any().nullish(),
    _approvedby: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullish(),
    _noorgnr: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].union([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].boolean()
    ]).nullish(),
    _providerid: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].union([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number()
    ]).nullish(),
    _versionid: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number().nullish(),
    _score: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any().nullish(),
    _scoretotal: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number().nullish()
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/stilling/rekrutteringsbistandstilling/[slug]/stilling.dto.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "KategoriSchema",
    ()=>KategoriSchema,
    "LocationSchema",
    ()=>LocationSchema,
    "StillingDataSchema",
    ()=>StillingDataSchema,
    "StillingSchemaDTO",
    ()=>StillingSchemaDTO,
    "StillingsinfoSchema",
    ()=>StillingsinfoSchema,
    "propertiesSchema",
    ()=>propertiesSchema,
    "searchtagSchema",
    ()=>searchtagSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zod@4.0.17/node_modules/zod/v4/classic/external.js [app-client] (ecmascript) <export * as z>");
;
const searchtagSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    label: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    score: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number()
});
const propertiesSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    jobarrangement: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable(),
    employerhomepage: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable(),
    facebookpage: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable(),
    linkedinpage: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable(),
    twitteraddress: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable(),
    jobpercentage: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable(),
    jobpercentagerange: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable(),
    extent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable(),
    applicationdue: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable(),
    jobtitle: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any().optional().nullable(),
    keywords: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable(),
    positioncount: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].union([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number().optional().nullable(),
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable()
    ]),
    engagementtype: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable(),
    classification_styrk08_score: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].union([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number().optional().nullable(),
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable()
    ]),
    employerdescription: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].union([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional()
    ]),
    adtext: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable(),
    classification_styrk08_code: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any().optional().nullable(),
    sourceurl: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable(),
    searchtags: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].union([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(searchtagSchema).optional().nullable(),
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any(),
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable()
    ]),
    applicationurl: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable(),
    classification_esco_code: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable(),
    classification_input_source: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable(),
    sector: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable(),
    workLanguage: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable(),
    salary: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any().nullable().optional(),
    industry: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable(),
    starttime: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable(),
    tags: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any().nullable().optional(),
    workhours: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any().nullable().optional(),
    workday: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any().nullable().optional(),
    applicationemail: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullish()
}).nullable();
/// ZOD Schema fra https://github.com/navikt/rekrutteringsbistand-stilling-api/blob/master/src/main/kotlin/no/nav/rekrutteringsbistand/api/stilling/domene.kt
const LocalDateTimeSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(); // Assuming LocalDateTime is represented as a string in JSON
const AdministrationSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    id: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number().optional().nullable(),
    status: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable(),
    comments: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable(),
    reportee: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable(),
    remarks: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string()).optional().nullable(),
    navIdent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable()
});
const MediaSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    mediaLink: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    filename: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable()
});
const ContactSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    name: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    email: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    phone: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    // role: z.string().nullable(),
    title: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable()
});
const LocationSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    address: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable(),
    postalCode: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable(),
    city: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable(),
    county: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable(),
    // countyCode: z.string().nullable(), // Filtreres bort backend
    municipal: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable(),
    municipalCode: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable(),
    country: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable()
});
const LocationListSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(LocationSchema);
_c = LocationListSchema;
const ArbeidsgiverPropertiesSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    nace2: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable()
});
const ArbeidsgiverSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    id: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number().nullable(),
    uuid: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    created: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    createdBy: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    updated: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    updatedBy: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    mediaList: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(MediaSchema).nullable(),
    contactList: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(ContactSchema).nullable(),
    location: LocationSchema.nullable(),
    locationList: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(LocationSchema).nullable(),
    properties: ArbeidsgiverPropertiesSchema.nullable(),
    name: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    orgnr: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    status: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    parentOrgnr: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    publicName: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    deactivated: LocalDateTimeSchema.nullable(),
    orgform: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    employees: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number().nullable()
});
const KategoriSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    id: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number().nullable(),
    code: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    categoryType: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    name: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    description: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    parentId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number().nullable()
});
const StillingSchemaDTO = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    annonsenr: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable(),
    uuid: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    created: LocalDateTimeSchema,
    createdBy: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    updated: LocalDateTimeSchema,
    updatedBy: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    title: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    status: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable(),
    administration: AdministrationSchema.nullable(),
    mediaList: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(MediaSchema).nullable(),
    contactList: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(ContactSchema).nullable(),
    privacy: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    source: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    medium: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    reference: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    published: LocalDateTimeSchema.nullable(),
    expires: LocalDateTimeSchema.nullable(),
    employer: ArbeidsgiverSchema.nullable(),
    location: LocationSchema.nullable(),
    locationList: LocationListSchema.nullable(),
    categoryList: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(KategoriSchema).nullable(),
    properties: propertiesSchema.nullable(),
    publishedByAdmin: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    businessName: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    firstPublished: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].boolean().nullable(),
    deactivatedByExpiry: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].boolean().nullable(),
    activationOnPublishingDate: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].boolean().nullable(),
    versjon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].int().optional().nullable()
});
const StillingskategoriEnum = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].enum([
    'STILLING',
    'JOBBMESSE',
    'FORMIDLING'
]);
const StillingsinfoSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    stillingsid: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional(),
    stillingsinfoid: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional(),
    eierNavKontorEnhetId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable(),
    eierNavident: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable(),
    eierNavn: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable(),
    stillingskategori: StillingskategoriEnum.optional().nullable()
});
const StillingDataSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    stillingsinfo: StillingsinfoSchema.nullable().optional(),
    stilling: StillingSchemaDTO
});
var _c;
__turbopack_context__.k.register(_c, "LocationListSchema");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/stillings-sok/schema/stillingSchema.zod.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ESStillingSchema",
    ()=>ESStillingSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$schema$2f$stillingPropertiesSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/stillings-sok/schema/stillingPropertiesSchema.zod.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stilling$2f$rekrutteringsbistandstilling$2f5b$slug$5d2f$stilling$2e$dto$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/stilling/rekrutteringsbistandstilling/[slug]/stilling.dto.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zod@4.0.17/node_modules/zod/v4/classic/external.js [app-client] (ecmascript) <export * as z>");
;
;
;
const ContactSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    name: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable(),
    role: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable(),
    title: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable(),
    email: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable(),
    phone: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable()
});
const ESAdministrationSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    status: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    remarks: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string()),
    comments: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable(),
    reportee: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    navIdent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string()
});
const ESEmployerSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    name: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    publicName: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable(),
    orgnr: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    parentOrgnr: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    orgform: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable()
});
const ESStyrkCategorySchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    styrkCode: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable(),
    name: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string()
});
const ESStillingSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    tittel: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    uuid: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    annonsenr: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    status: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    privacy: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    published: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    publishedByAdmin: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    expires: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    created: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    updated: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    employer: ESEmployerSchema.optional().nullable(),
    categories: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(ESStyrkCategorySchema),
    source: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    medium: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    businessName: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    locations: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stilling$2f$rekrutteringsbistandstilling$2f5b$slug$5d2f$stilling$2e$dto$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LocationSchema"]),
    reference: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    administration: ESAdministrationSchema.optional(),
    properties: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$schema$2f$stillingPropertiesSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ESStillingPropertiesSchema"].optional(),
    contacts: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(ContactSchema)
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/stillings-sok/schema/rekrutteringsbistandStillingSchema.zod.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RekrutteringsbistandStillingSchema",
    ()=>RekrutteringsbistandStillingSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$schema$2f$stillingSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/stillings-sok/schema/stillingSchema.zod.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stilling$2f$rekrutteringsbistandstilling$2f5b$slug$5d2f$stilling$2e$dto$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/stilling/rekrutteringsbistandstilling/[slug]/stilling.dto.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zod@4.0.17/node_modules/zod/v4/classic/external.js [app-client] (ecmascript) <export * as z>");
;
;
;
const RekrutteringsbistandStillingSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    stilling: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$schema$2f$stillingSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ESStillingSchema"],
    stillingsinfo: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stilling$2f$rekrutteringsbistandstilling$2f5b$slug$5d2f$stilling$2e$dto$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StillingsinfoSchema"].optional().nullable()
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/stillings-sok/schema/stillingsSøkSchema.zod.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ESStillingsSøkSchema",
    ()=>ESStillingsSøkSchema,
    "hitSchema",
    ()=>hitSchema,
    "hitsSchema",
    ()=>hitsSchema,
    "shardsSchema",
    ()=>shardsSchema,
    "totalSchema",
    ()=>totalSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$schema$2f$rekrutteringsbistandStillingSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/stillings-sok/schema/rekrutteringsbistandStillingSchema.zod.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zod@4.0.17/node_modules/zod/v4/classic/external.js [app-client] (ecmascript) <export * as z>");
;
;
const shardsSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    total: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number(),
    successful: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number(),
    skipped: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number(),
    failed: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number()
});
const totalSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    value: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number(),
    relation: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string()
});
const hitSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    _index: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    _type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional().nullable(),
    _id: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    _score: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any(),
    _source: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$schema$2f$rekrutteringsbistandStillingSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RekrutteringsbistandStillingSchema"],
    sort: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number())
});
const hitsSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    total: totalSchema,
    max_score: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any(),
    hits: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(hitSchema)
});
const ESStillingsSøkSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    took: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number(),
    timed_out: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].boolean(),
    _shards: shardsSchema,
    hits: hitsSchema
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/stillings-sok/schema/stillingsSokCombinedSchema.zod.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "StillingsSokAntallSchema",
    ()=>StillingsSokAntallSchema,
    "StillingsSokCombinedSchema",
    ()=>StillingsSokCombinedSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$schema$2f$stillingsS$f8$kSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/stillings-sok/schema/stillingsSøkSchema.zod.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zod@4.0.17/node_modules/zod/v4/classic/external.js [app-client] (ecmascript) <export * as z>");
;
;
// Gjenbruker hits-delen fra eksisterende schema
const hitsOnlySchema = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$schema$2f$stillingsS$f8$kSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ESStillingsSøkSchema"].pick({
    hits: true
});
const StillingsSokAntallSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    visningsStatusBuckets: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
        key: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
        count: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number()
    })).optional(),
    kategoriBuckets: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
        stilling: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number().optional(),
        jobbmesse: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number().optional()
    }).optional(),
    geografi: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
        fylker: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
            key: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
            count: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number()
        })).optional(),
        kommuner: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
            key: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
            count: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number()
        })).optional()
    }).optional()
});
const StillingsSokCombinedSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    hits: hitsOnlySchema.shape.hits,
    antall: StillingsSokAntallSchema,
    tookTreff: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number().optional().nullable(),
    tookAggs: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number().optional().nullable()
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/useSWRPost.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useSWRPost",
    ()=>useSWRPost
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/fetcher.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$swr$40$2$2e$3$2e$8_react$40$19$2e$2$2e$1$2f$node_modules$2f$swr$2f$dist$2f$index$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/swr@2.3.8_react@19.2.1/node_modules/swr/dist/index/index.mjs [app-client] (ecmascript) <locals>");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
function useSWRPost(endpoint, schema, body, config) {
    _s();
    // Lag en unik cache-nøkkel ved å kombinere endepunkt med stringifisert body
    // Hvis body er null, bruk null som nøkkel for å forhindre fetching
    const cacheKey = body ? [
        endpoint,
        JSON.stringify(body)
    ] : null;
    const fetcher = ()=>body && endpoint ? config?.elastic ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["postApiWithSchemaEs"])(schema)({
            url: endpoint,
            body
        }) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["postApiWithSchema"])(schema)({
            url: endpoint,
            body,
            options: config?.fetchOptions
        }) : null;
    const { nonImmutable, ...swrConfig } = config || {};
    // Slå sammen konfigurasjon med immutable-innstillinger
    // (deaktiver revalidering) med mindre nonImmutable er true
    const finalConfig = nonImmutable ? swrConfig : {
        revalidateIfStale: false,
        revalidateOnFocus: false,
        revalidateOnReconnect: false,
        ...swrConfig
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$swr$40$2$2e$3$2e$8_react$40$19$2e$2$2e$1$2f$node_modules$2f$swr$2f$dist$2f$index$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"])(cacheKey, fetcher, finalConfig);
}
_s(useSWRPost, "7xERTuQa/rCStZtEZdi0LgBAmUk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$swr$40$2$2e$3$2e$8_react$40$19$2e$2$2e$1$2f$node_modules$2f$swr$2f$dist$2f$index$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/stillings-sok/useStillingssøk.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "stillingssøkMSWHandler",
    ()=>stillingssøkMSWHandler,
    "useStillingssøk",
    ()=>useStillingssøk
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.4_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwright+test@1.57.0_react-dom@19._dcdshnipcape54hhdzpkwzexoe/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$byggKombinertQuery$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/stillings-sok/byggKombinertQuery.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$mocks$2f$mockStillingss$f8$k$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/stillings-sok/mocks/mockStillingssøk.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$opprettElasticSearchQuery$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/stillings-sok/opprettElasticSearchQuery.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$schema$2f$stillingsSokCombinedSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/stillings-sok/schema/stillingsSokCombinedSchema.zod.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/api-routes.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$pam$2d$geografi$2f$typehead$2f$lokasjoner$2f$usePamGeografi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/pam-geografi/typehead/lokasjoner/usePamGeografi.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRPost$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/useSWRPost.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$tilgangskontroll$2f$roller$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/tilgangskontroll/roller.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$ApplikasjonContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/providers/ApplikasjonContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/http.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/HttpResponse.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$passthrough$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/passthrough.mjs [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
/**
 * Endepunkt /stilling
 */ const stillingsSokBase = `${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StillingsSøkAPI"].internUrl}`;
const useStillingssøk = ({ filter, eierNavKontorEnhetId, navIdent, formidlinger, finnStillingerForKandidat })=>{
    _s();
    const geografiData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$pam$2d$geografi$2f$typehead$2f$lokasjoner$2f$usePamGeografi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePamGeografi"])();
    const { harRolle } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$ApplikasjonContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useApplikasjonContext"])();
    const harArbeidsgiverrettetRolle = harRolle([
        __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$tilgangskontroll$2f$roller$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Roller"].AD_GRUPPE_REKRUTTERINGSBISTAND_ARBEIDSGIVERRETTET
    ]);
    const treffPayload = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$opprettElasticSearchQuery$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["opprettElasticSearchTreffQuery"])({
        filter,
        eierNavKontorEnhetId,
        navIdent,
        geografiData: geografiData.data,
        formidlinger,
        finnStillingerForKandidat,
        harArbeidsgiverrettetRolle
    });
    const aggsPayload = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$opprettElasticSearchQuery$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["opprettElasticSearchAggregeringsQuery"])({
        filter: {
            ...filter,
            side: 1
        },
        eierNavKontorEnhetId,
        navIdent,
        geografiData: geografiData.data,
        formidlinger,
        finnStillingerForKandidat,
        harArbeidsgiverrettetRolle
    });
    const mergedQuery = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$byggKombinertQuery$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["byggKombinertQuery"])(treffPayload, aggsPayload);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRPost$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSWRPost"])(geografiData.isLoading ? null : stillingsSokBase, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$schema$2f$stillingsSokCombinedSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StillingsSokCombinedSchema"], mergedQuery);
};
_s(useStillingssøk, "N9iBbsKTTRhOCtj2at/eWOm4rmw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$pam$2d$geografi$2f$typehead$2f$lokasjoner$2f$usePamGeografi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePamGeografi"],
        __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$ApplikasjonContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useApplikasjonContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRPost$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSWRPost"]
    ];
});
const stillingssøkMSWHandler = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].post(stillingsSokBase, async ({ request })=>{
    if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$4_$40$babel$2b$core$40$7$2e$28$2e$6_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$57$2e$0_react$2d$dom$40$19$2e$_dcdshnipcape54hhdzpkwzexoe$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_STILLING_ES_MOCK === 'true') {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$passthrough$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["passthrough"])(); // slipper igjennom til ekte backend
    }
    const body = await request.json();
    // Formidlingssøk har must-filter med stillingskategori=FORMIDLING i query,
    // mens stillingssøk har must_not med FORMIDLING i query.
    // Sjekker kun query-noden (ikke aggs som alltid inneholder begge).
    const queryStr = JSON.stringify(body.query ?? {});
    const erFormidling = queryStr.includes('"stillingsinfo.stillingskategori":"FORMIDLING"') && !queryStr.includes('"stillingsinfo.stillingskategori":"ARBEIDSTRENING"');
    const mock = erFormidling ? __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$mocks$2f$mockStillingss$f8$k$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mockEtterregistreringssøk"] : __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stillings$2d$sok$2f$mocks$2f$mockStillingss$f8$k$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mockStillingssøk"];
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json({
        hits: mock.hits,
        antall: {
            status: {
                publisert: 0,
                utløpt: 0,
                stoppet: 0
            }
        }
    });
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/kandidat-sok/useKandidatStillingssøk.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "kandidatStillingssøkDTOSchema",
    ()=>kandidatStillingssøkDTOSchema,
    "kandidatStillingssøkMSWHandler",
    ()=>kandidatStillingssøkMSWHandler,
    "useKandidatStillingssøk",
    ()=>useKandidatStillingssøk
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/api-routes.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRPost$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/useSWRPost.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$mocks$2f$kandidat$2e$mock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/mocks/kandidat.mock.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/http.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/HttpResponse.mjs [app-client] (ecmascript)");
/**
 * Endepunkt /useKandidatStillingssøk
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zod@4.0.17/node_modules/zod/v4/classic/external.js [app-client] (ecmascript) <export * as z>");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
const kandidatStillingssøkEndepunkt = `${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatSøkAPI"].internUrl}/kandidat-stillingssok`;
const yrkeJobbonskeSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    styrkBeskrivelse: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    sokeTitler: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string()),
    primaertJobbonske: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].boolean(),
    styrkKode: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable()
});
const geografiJobbonskeSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    geografiKodeTekst: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    geografiKode: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string()
});
const kandidatStillingssøkDTOSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    yrkeJobbonskerObj: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(yrkeJobbonskeSchema),
    geografiJobbonsker: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(geografiJobbonskeSchema),
    kommunenummerstring: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    kommuneNavn: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable()
});
const useKandidatStillingssøk = (kandidatId)=>{
    _s();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRPost$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSWRPost"])(kandidatId ? kandidatStillingssøkEndepunkt : null, kandidatStillingssøkDTOSchema, {
        kandidatnr: kandidatId
    }, {
        elastic: true
    });
};
_s(useKandidatStillingssøk, "qvvxhpf+S/HwXAta7LPSJ0w8fTs=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRPost$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSWRPost"]
    ];
});
const kandidatStillingssøkMSWHandler = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].post(kandidatStillingssøkEndepunkt, async ({ request })=>{
    const raw = await request.json().catch(()=>undefined);
    const kandidatnr = raw?.kandidatnr;
    if (!kandidatnr) return new Response(null, {
        status: 400
    });
    if (kandidatnr === 'utenTilgang') {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json({
            yrkeJobbonskerObj: [],
            geografiJobbonsker: [],
            kommunenummerstring: null,
            kommuneNavn: null
        });
    }
    const parts = kandidatnr.split('-');
    const seed = parseInt(parts[parts.length - 1], 10);
    const stillingssokData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$mocks$2f$kandidat$2e$mock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSingleKandidatStillingssøk"])(seed);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json({
        hits: {
            hits: [
                {
                    _source: stillingssokData
                }
            ]
        }
    });
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/stilling/standardsok/settStandardsøk.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "setNyttStandardsøk",
    ()=>setNyttStandardsøk
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stilling$2f$standardsok$2f$useBrukersStandards$f8$k$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/stilling/standardsok/useBrukersStandardsøk.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/fetcher.ts [app-client] (ecmascript)");
;
;
const setNyttStandardsøk = (søk)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["putApi"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stilling$2f$standardsok$2f$useBrukersStandards$f8$k$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["brukerStandardSøkEndepunkt"], {
        søk
    });
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/kandidat-sok/schema/annenErfaringSchema.zod.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AnnenErfaringSchema",
    ()=>AnnenErfaringSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zod@4.0.17/node_modules/zod/v4/classic/external.js [app-client] (ecmascript) <export * as z>");
;
const AnnenErfaringSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    fraDato: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    tilDato: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    beskrivelse: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    rolle: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional()
});
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/kandidat-sok/schema/ansettelsesformJobbonskerSchema.zod.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AnsettelsesformJobbonskerSchema",
    ()=>AnsettelsesformJobbonskerSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zod@4.0.17/node_modules/zod/v4/classic/external.js [app-client] (ecmascript) <export * as z>");
;
const AnsettelsesformJobbonskerSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    ansettelsesformKode: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    ansettelsesformKodeTekst: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional()
});
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/kandidat-sok/schema/arbeidsdagerJobbonskerSchema.zod.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ArbeidsdagerJobbonskerSchema",
    ()=>ArbeidsdagerJobbonskerSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zod@4.0.17/node_modules/zod/v4/classic/external.js [app-client] (ecmascript) <export * as z>");
;
const ArbeidsdagerJobbonskerSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    arbeidsdagerKode: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    arbeidsdagerKodeTekst: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional()
});
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/kandidat-sok/schema/arbeidstidJobbonskerSchema.zod.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ArbeidstidJobbonskerSchema",
    ()=>ArbeidstidJobbonskerSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zod@4.0.17/node_modules/zod/v4/classic/external.js [app-client] (ecmascript) <export * as z>");
;
const ArbeidstidJobbonskerSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    arbeidstidKode: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    arbeidstidKodeTekst: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional()
});
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/kandidat-sok/schema/arbeidstidsordningJobbonskerShema.zod.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ArbeidstidsordningJobbonskerSchema",
    ()=>ArbeidstidsordningJobbonskerSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zod@4.0.17/node_modules/zod/v4/classic/external.js [app-client] (ecmascript) <export * as z>");
;
const ArbeidstidsordningJobbonskerSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    arbeidstidsordningKode: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    arbeidstidsordningKodeTekst: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional()
});
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/kandidat-sok/schema/fagdokumentasjonSchema.zod.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FagdokumentasjonSchema",
    ()=>FagdokumentasjonSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zod@4.0.17/node_modules/zod/v4/classic/external.js [app-client] (ecmascript) <export * as z>");
;
const FagdokumentasjonSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    tittel: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    beskrivelse: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional()
});
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/kandidat-sok/schema/forerkortSchema.zod.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ForerkortSchema",
    ()=>ForerkortSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zod@4.0.17/node_modules/zod/v4/classic/external.js [app-client] (ecmascript) <export * as z>");
;
const ForerkortSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    fraDato: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    tilDato: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    forerkortKode: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    forerkortKodeKlasse: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    alternativKlasse: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    utsteder: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional()
});
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/kandidat-sok/schema/geografiJobbonskerSchema.zod.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GeografiJobbonskerSchema",
    ()=>GeografiJobbonskerSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zod@4.0.17/node_modules/zod/v4/classic/external.js [app-client] (ecmascript) <export * as z>");
;
const GeografiJobbonskerSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    geografiKodeTekst: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    geografiKode: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional()
});
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/kandidat-sok/schema/godkjenningSchema.zod.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GodkjenningSchema",
    ()=>GodkjenningSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zod@4.0.17/node_modules/zod/v4/classic/external.js [app-client] (ecmascript) <export * as z>");
;
const GodkjenningSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    tittel: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    utsteder: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    gjennomfoert: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    utloeper: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    konseptId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional()
});
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/kandidat-sok/schema/kompetanseSchema.zod.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "KompetanseSchema",
    ()=>KompetanseSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zod@4.0.17/node_modules/zod/v4/classic/external.js [app-client] (ecmascript) <export * as z>");
;
const KompetanseSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    fraDato: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    kompKode: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    kompKodeNavn: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    sokeNavn: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string()).nullable().optional(),
    alternativtNavn: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    beskrivelse: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional()
});
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/kandidat-sok/schema/kursSchema.zod.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "KursSchema",
    ()=>KursSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zod@4.0.17/node_modules/zod/v4/classic/external.js [app-client] (ecmascript) <export * as z>");
;
const KursSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    fraDato: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    tilDato: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    tittel: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    arrangor: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    omfangEnhet: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    omfangVerdi: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number().nullable().optional(),
    beskrivelse: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional()
});
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/kandidat-sok/schema/omfangJobbonskerSchema.zod.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "OmfangJobbonskerSchema",
    ()=>OmfangJobbonskerSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zod@4.0.17/node_modules/zod/v4/classic/external.js [app-client] (ecmascript) <export * as z>");
;
const OmfangJobbonskerSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    omfangKode: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    omfangKodeTekst: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional()
});
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/kandidat-sok/schema/samletKompetanseSchema.zod.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SamletKompetanseSchema",
    ()=>SamletKompetanseSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zod@4.0.17/node_modules/zod/v4/classic/external.js [app-client] (ecmascript) <export * as z>");
;
const SamletKompetanseSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    samletKompetanseTekst: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional()
});
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/kandidat-sok/schema/sertifikatSchema.zod.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SertifikatSchema",
    ()=>SertifikatSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zod@4.0.17/node_modules/zod/v4/classic/external.js [app-client] (ecmascript) <export * as z>");
;
const SertifikatSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    fraDato: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    tilDato: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    sertifikatKode: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    sertifikatKodeNavn: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    alternativtNavn: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    utsteder: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional()
});
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/kandidat-sok/schema/sprakSchema.zod.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SprakSchema",
    ()=>SprakSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zod@4.0.17/node_modules/zod/v4/classic/external.js [app-client] (ecmascript) <export * as z>");
;
const SprakSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    fraDato: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    sprakKode: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    sprakKodeTekst: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    alternativTekst: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    beskrivelse: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    ferdighetMuntlig: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    ferdighetSkriftlig: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional()
});
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/kandidat-sok/schema/utdanningSchema.zod.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "UtdanningSchema",
    ()=>UtdanningSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zod@4.0.17/node_modules/zod/v4/classic/external.js [app-client] (ecmascript) <export * as z>");
;
const UtdanningSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    fraDato: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    tilDato: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    utdannelsessted: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    nusKode: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    nusKodeGrad: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    alternativGrad: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    yrkestatus: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    beskrivelse: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional()
});
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/kandidat-sok/schema/vervSchema.zod.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "VervSchema",
    ()=>VervSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zod@4.0.17/node_modules/zod/v4/classic/external.js [app-client] (ecmascript) <export * as z>");
;
const VervSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    fraDato: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    tilDato: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    organisasjon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    tittel: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional()
});
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/kandidat-sok/schema/yrkejobbOnskerSchema.zod.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "YrkejobbOnskerSchema",
    ()=>YrkejobbOnskerSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zod@4.0.17/node_modules/zod/v4/classic/external.js [app-client] (ecmascript) <export * as z>");
;
const YrkejobbOnskerSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    styrkKode: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    styrkBeskrivelse: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    sokeTitler: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string()).optional().default([]),
    primaertJobbonske: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].boolean().optional().default(false)
});
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/kandidat-sok/schema/yrkesErfaringSchema.zod.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "YrkesErfaringSchema",
    ()=>YrkesErfaringSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zod@4.0.17/node_modules/zod/v4/classic/external.js [app-client] (ecmascript) <export * as z>");
;
const YrkesErfaringSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    fraDato: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    tilDato: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    arbeidsgiver: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    styrkKode: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    styrkKode4Siffer: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    styrkKode3Siffer: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    stillingstittel: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    stillingstitlerForTypeahead: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string()).nullable().optional(),
    alternativStillingstittel: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    styrkKodeStillingstittel: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    sokeTitler: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string()).nullable().optional(),
    organisasjonsnummer: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    naceKode: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    yrkeserfaringManeder: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number().optional().default(0),
    utelukketForFremtiden: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].boolean().nullable().optional(),
    beskrivelse: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    sted: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional()
});
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/kandidat-sok/schema/cvSchema.zod.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "KandidatDataSchema",
    ()=>KandidatDataSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2d$sok$2f$schema$2f$annenErfaringSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/kandidat-sok/schema/annenErfaringSchema.zod.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2d$sok$2f$schema$2f$ansettelsesformJobbonskerSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/kandidat-sok/schema/ansettelsesformJobbonskerSchema.zod.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2d$sok$2f$schema$2f$arbeidsdagerJobbonskerSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/kandidat-sok/schema/arbeidsdagerJobbonskerSchema.zod.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2d$sok$2f$schema$2f$arbeidstidJobbonskerSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/kandidat-sok/schema/arbeidstidJobbonskerSchema.zod.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2d$sok$2f$schema$2f$arbeidstidsordningJobbonskerShema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/kandidat-sok/schema/arbeidstidsordningJobbonskerShema.zod.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2d$sok$2f$schema$2f$fagdokumentasjonSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/kandidat-sok/schema/fagdokumentasjonSchema.zod.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2d$sok$2f$schema$2f$forerkortSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/kandidat-sok/schema/forerkortSchema.zod.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2d$sok$2f$schema$2f$geografiJobbonskerSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/kandidat-sok/schema/geografiJobbonskerSchema.zod.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2d$sok$2f$schema$2f$godkjenningSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/kandidat-sok/schema/godkjenningSchema.zod.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2d$sok$2f$schema$2f$kompetanseSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/kandidat-sok/schema/kompetanseSchema.zod.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2d$sok$2f$schema$2f$kursSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/kandidat-sok/schema/kursSchema.zod.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2d$sok$2f$schema$2f$omfangJobbonskerSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/kandidat-sok/schema/omfangJobbonskerSchema.zod.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2d$sok$2f$schema$2f$samletKompetanseSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/kandidat-sok/schema/samletKompetanseSchema.zod.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2d$sok$2f$schema$2f$sertifikatSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/kandidat-sok/schema/sertifikatSchema.zod.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2d$sok$2f$schema$2f$sprakSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/kandidat-sok/schema/sprakSchema.zod.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2d$sok$2f$schema$2f$utdanningSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/kandidat-sok/schema/utdanningSchema.zod.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2d$sok$2f$schema$2f$vervSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/kandidat-sok/schema/vervSchema.zod.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2d$sok$2f$schema$2f$yrkejobbOnskerSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/kandidat-sok/schema/yrkejobbOnskerSchema.zod.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2d$sok$2f$schema$2f$yrkesErfaringSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/kandidat-sok/schema/yrkesErfaringSchema.zod.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$kandidat$2f$_ui$2f$innsatsgrupper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/kandidat/_ui/innsatsgrupper.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zod@4.0.17/node_modules/zod/v4/classic/external.js [app-client] (ecmascript) <export * as z>");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const KandidatDataSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    fritekst: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    aktorId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    fodselsnummer: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    fornavn: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    etternavn: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    fodselsdato: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    fodselsdatoErDnr: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].boolean().nullable().optional(),
    formidlingsgruppekode: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    epostadresse: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    mobiltelefon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    harKontaktinformasjon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].boolean().optional().default(false),
    telefon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    statsborgerskap: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    kandidatnr: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    arenaKandidatnr: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    beskrivelse: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    samtykkeStatus: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    samtykkeDato: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    adresselinje1: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    adresselinje2: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    adresselinje3: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    postnummer: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    poststed: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    landkode: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    kommunenummer: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number().nullable().optional(),
    kommunenummerkw: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number().nullable().optional(),
    kommunenummerstring: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    fylkeNavn: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    kommuneNavn: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    disponererBil: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].boolean().nullable().optional(),
    tidsstempel: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    doed: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].boolean().nullable().optional(),
    frKode: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    innsatsgruppe: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].nativeEnum(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$kandidat$2f$_ui$2f$innsatsgrupper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Innsatsgruppe"]).optional(),
    orgenhet: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    navkontor: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    fritattKandidatsok: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].boolean().nullable().optional(),
    fritattAgKandidatsok: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].boolean().nullable().optional(),
    utdanning: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2d$sok$2f$schema$2f$utdanningSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UtdanningSchema"]).nullable().optional(),
    fagdokumentasjon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2d$sok$2f$schema$2f$fagdokumentasjonSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FagdokumentasjonSchema"]).nullable().optional(),
    yrkeserfaring: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2d$sok$2f$schema$2f$yrkesErfaringSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["YrkesErfaringSchema"]).nullable().optional(),
    kompetanseObj: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2d$sok$2f$schema$2f$kompetanseSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KompetanseSchema"]).nullable().optional(),
    annenerfaringObj: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2d$sok$2f$schema$2f$annenErfaringSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnnenErfaringSchema"]).nullable().optional(),
    sertifikatObj: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2d$sok$2f$schema$2f$sertifikatSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SertifikatSchema"]).nullable().optional(),
    forerkort: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2d$sok$2f$schema$2f$forerkortSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ForerkortSchema"]).nullable().optional(),
    sprak: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2d$sok$2f$schema$2f$sprakSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SprakSchema"]).nullable().optional(),
    kursObj: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2d$sok$2f$schema$2f$kursSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KursSchema"]).nullable().optional(),
    vervObj: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2d$sok$2f$schema$2f$vervSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VervSchema"]).nullable().optional(),
    geografiJobbonsker: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2d$sok$2f$schema$2f$geografiJobbonskerSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GeografiJobbonskerSchema"]).nullable().optional(),
    yrkeJobbonskerObj: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2d$sok$2f$schema$2f$yrkejobbOnskerSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["YrkejobbOnskerSchema"]).nullable().optional(),
    omfangJobbonskerObj: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2d$sok$2f$schema$2f$omfangJobbonskerSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OmfangJobbonskerSchema"]).nullable().optional(),
    ansettelsesformJobbonskerObj: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2d$sok$2f$schema$2f$ansettelsesformJobbonskerSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnsettelsesformJobbonskerSchema"]).nullable().optional(),
    arbeidstidsordningJobbonskerObj: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2d$sok$2f$schema$2f$arbeidstidsordningJobbonskerShema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ArbeidstidsordningJobbonskerSchema"]).nullable().optional(),
    arbeidsdagerJobbonskerObj: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2d$sok$2f$schema$2f$arbeidsdagerJobbonskerSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ArbeidsdagerJobbonskerSchema"]).nullable().optional(),
    arbeidstidJobbonskerObj: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2d$sok$2f$schema$2f$arbeidstidJobbonskerSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ArbeidstidJobbonskerSchema"]).nullable().optional(),
    samletKompetanseObj: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2d$sok$2f$schema$2f$samletKompetanseSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SamletKompetanseSchema"]).nullable().optional(),
    totalLengdeYrkeserfaring: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number().optional().default(0),
    synligForArbeidsgiverSok: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].boolean().nullable().optional(),
    synligForVeilederSok: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].boolean().optional(),
    oppstartKode: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    veileder: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    veilederIdent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    veilederVisningsnavn: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    veilederEpost: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    godkjenninger: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2d$sok$2f$schema$2f$godkjenningSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GodkjenningSchema"]).nullable().optional()
});
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/kandidat-sok/useKandidatinformasjon.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "kandidatinformasjonMSWHandler",
    ()=>kandidatinformasjonMSWHandler,
    "useKandidatinformasjon",
    ()=>useKandidatinformasjon
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2d$sok$2f$schema$2f$cvSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/kandidat-sok/schema/cvSchema.zod.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/api-routes.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRPost$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/useSWRPost.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$mocks$2f$kandidat$2e$mock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/mocks/kandidat.mock.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/http.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/HttpResponse.mjs [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
const kandidatinformasjonEndepunkt = `${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatSøkAPI"].internUrl}/lookup-cv`;
const useKandidatinformasjon = (kandidatnr)=>{
    _s();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRPost$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSWRPost"])(kandidatnr ? kandidatinformasjonEndepunkt : null, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2d$sok$2f$schema$2f$cvSchema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatDataSchema"], kandidatnr ? {
        kandidatnr
    } : null, {
        elastic: true
    });
};
_s(useKandidatinformasjon, "qvvxhpf+S/HwXAta7LPSJ0w8fTs=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRPost$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSWRPost"]
    ];
});
const kandidatinformasjonMSWHandler = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].post(kandidatinformasjonEndepunkt, async ({ request })=>{
    const raw = await request.json().catch(()=>undefined);
    const kandidatnr = raw?.kandidatnr;
    if (!kandidatnr) return new Response(null, {
        status: 400
    });
    if (kandidatnr === 'kandidat-aktorId-3') {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json({
            hits: {
                hits: []
            }
        });
    }
    const parts = kandidatnr.split('-');
    const seed = parseInt(parts[parts.length - 1], 10);
    const kandidatData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$mocks$2f$kandidat$2e$mock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSingleKandidatDataSchema"])(seed);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json({
        hits: {
            hits: [
                {
                    _source: kandidatData
                }
            ]
        }
    });
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/kandidat/useKandidatlisteInfo.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "kandidatlisteInfoEndepunkt",
    ()=>kandidatlisteInfoEndepunkt,
    "kandidatlisteInfoMSWHandler",
    ()=>kandidatlisteInfoMSWHandler,
    "useKandidatlisteInfo",
    ()=>useKandidatlisteInfo
]);
/**
 * Endepunkt /useKandidatlisteInfo
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/api-routes.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRGet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/useSWRGet.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/http.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/HttpResponse.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zod@4.0.17/node_modules/zod/v4/classic/external.js [app-client] (ecmascript) <export * as z>");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
const kandidatlisteInfoEndepunkt = (stillingsId)=>`${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatAPI"].internUrl}/veileder/stilling/${stillingsId}/kandidatlisteinfo`;
const KandidatlisteInfoSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    kandidatlisteId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    antallKandidater: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number(),
    kandidatlisteStatus: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string()
});
const useKandidatlisteInfo = (stillingsId)=>{
    _s();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRGet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSWRGet"])(stillingsId ? kandidatlisteInfoEndepunkt(stillingsId) : null, KandidatlisteInfoSchema, {
        errorRetryCount: 3,
        errorRetryInterval: 3000,
        revalidateOnFocus: false,
        dedupingInterval: 2000,
        fetchOptions: {
            skjulFeilmelding: true
        }
    });
};
_s(useKandidatlisteInfo, "K4Y6k2WDwBHXduaV5Y5moFGSmko=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRGet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSWRGet"]
    ];
});
const kandidatlisteInfoMSWHandler = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].get(kandidatlisteInfoEndepunkt('*'), ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json({
        kandidatlisteId: 'kandidatlisteId',
        antallKandidater: 10,
        kandidatlisteStatus: 'ÅPEN'
    }));
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/stilling/rekrutteringsbistandstilling/[slug]/useStilling.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "stillingEndepunkt",
    ()=>stillingEndepunkt,
    "stillingMSWHandlers",
    ()=>stillingMSWHandlers,
    "useStilling",
    ()=>useStilling
]);
/**
 * Endepunkt /useStilling
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stilling$2f$rekrutteringsbistandstilling$2f5b$slug$5d2f$mocks$2f$stillingMock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/stilling/rekrutteringsbistandstilling/[slug]/mocks/stillingMock.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stilling$2f$rekrutteringsbistandstilling$2f5b$slug$5d2f$stilling$2e$dto$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/stilling/rekrutteringsbistandstilling/[slug]/stilling.dto.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/api-routes.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRGet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/useSWRGet.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/http.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/HttpResponse.mjs [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
const stillingEndepunkt = (stillingsId)=>`${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StillingAPI"].internUrl}/rekrutteringsbistandstilling/${stillingsId}`;
const useStilling = (stillingsId)=>{
    _s();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRGet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSWRGet"])(stillingsId ? stillingEndepunkt(stillingsId) : null, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stilling$2f$rekrutteringsbistandstilling$2f5b$slug$5d2f$stilling$2e$dto$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StillingDataSchema"], {
        revalidateOnFocus: false
    });
};
_s(useStilling, "K4Y6k2WDwBHXduaV5Y5moFGSmko=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRGet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSWRGet"]
    ];
});
const stillingMSWHandlers = [
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].get(stillingEndepunkt('nyStilling'), ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stilling$2f$rekrutteringsbistandstilling$2f5b$slug$5d2f$mocks$2f$stillingMock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["nyStillingMock"])),
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].get(stillingEndepunkt('internStilling'), ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stilling$2f$rekrutteringsbistandstilling$2f5b$slug$5d2f$mocks$2f$stillingMock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["internStillingMock"])),
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].get(stillingEndepunkt('minStilling'), ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stilling$2f$rekrutteringsbistandstilling$2f5b$slug$5d2f$mocks$2f$stillingMock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mockMinStilling"])),
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].get(stillingEndepunkt('minFormidling'), ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stilling$2f$rekrutteringsbistandstilling$2f5b$slug$5d2f$mocks$2f$stillingMock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mockFormidling"])),
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].get(stillingEndepunkt('eksternStilling'), ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stilling$2f$rekrutteringsbistandstilling$2f5b$slug$5d2f$mocks$2f$stillingMock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mockEksternStilling"])),
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].get(stillingEndepunkt('minEksternStilling'), ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stilling$2f$rekrutteringsbistandstilling$2f5b$slug$5d2f$mocks$2f$stillingMock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mockMinEksternStilling"])),
    // 6 konsistente tilstander
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].get(stillingEndepunkt('publisertStilling'), ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stilling$2f$rekrutteringsbistandstilling$2f5b$slug$5d2f$mocks$2f$stillingMock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mockPublisertStilling"])),
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].get(stillingEndepunkt('publisertEksternStilling'), ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stilling$2f$rekrutteringsbistandstilling$2f5b$slug$5d2f$mocks$2f$stillingMock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mockPublisertEksternStilling"])),
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].get(stillingEndepunkt('utloptStilling'), ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stilling$2f$rekrutteringsbistandstilling$2f5b$slug$5d2f$mocks$2f$stillingMock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mockUtløptStilling"])),
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].get(stillingEndepunkt('stengtStilling'), ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stilling$2f$rekrutteringsbistandstilling$2f5b$slug$5d2f$mocks$2f$stillingMock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mockStengtForSøkereStilling"])),
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].get(stillingEndepunkt('slettetStilling'), ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stilling$2f$rekrutteringsbistandstilling$2f5b$slug$5d2f$mocks$2f$stillingMock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mockSlettetStilling"])),
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].get(stillingEndepunkt('fullfortStilling'), ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stilling$2f$rekrutteringsbistandstilling$2f5b$slug$5d2f$mocks$2f$stillingMock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mockFullførtStilling"])),
    // StillingsBanner-spesifikke mocks
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].get(stillingEndepunkt('bannerForlengOppdrag'), ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stilling$2f$rekrutteringsbistandstilling$2f5b$slug$5d2f$mocks$2f$stillingMock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mockBannerForlengOppdrag"])),
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].get(stillingEndepunkt('bannerApneSokeforslag'), ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stilling$2f$rekrutteringsbistandstilling$2f5b$slug$5d2f$mocks$2f$stillingMock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mockBannerÅpneSøkeforslag"])),
    // Fullført-banner states
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].get(stillingEndepunkt('fullfortBesattLast'), ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stilling$2f$rekrutteringsbistandstilling$2f5b$slug$5d2f$mocks$2f$stillingMock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mockFullførtBesattLåst"])),
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].get(stillingEndepunkt('fullfortIkkeBesattIkkeLast'), ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stilling$2f$rekrutteringsbistandstilling$2f5b$slug$5d2f$mocks$2f$stillingMock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mockFullførtIkkeBesattIkkeLåst"])),
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].get(stillingEndepunkt('fullfortIkkeBesattLast'), ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stilling$2f$rekrutteringsbistandstilling$2f5b$slug$5d2f$mocks$2f$stillingMock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mockFullførtIkkeBesattLåst"])),
    // Utkast
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].get(stillingEndepunkt('utkastStilling'), ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stilling$2f$rekrutteringsbistandstilling$2f5b$slug$5d2f$mocks$2f$stillingMock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mockUtkastStilling"])),
    // Ikke publisert
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].get(stillingEndepunkt('ikkePublisertStilling'), ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stilling$2f$rekrutteringsbistandstilling$2f5b$slug$5d2f$mocks$2f$stillingMock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mockIkkePublisertStilling"])),
    // Etterregistrering
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].get(stillingEndepunkt('etterregistrering'), ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stilling$2f$rekrutteringsbistandstilling$2f5b$slug$5d2f$mocks$2f$stillingMock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mockEtterregistreringFormidling"])),
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].get(stillingEndepunkt('etterregistreringApen'), ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stilling$2f$rekrutteringsbistandstilling$2f5b$slug$5d2f$mocks$2f$stillingMock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mockEtterregistreringFormidlingÅpen"])),
    // Jobbmesse
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].get(stillingEndepunkt('jobbmesse'), ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stilling$2f$rekrutteringsbistandstilling$2f5b$slug$5d2f$mocks$2f$stillingMock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mockJobbmesse"])),
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].get(stillingEndepunkt('baseStilling'), ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stilling$2f$rekrutteringsbistandstilling$2f5b$slug$5d2f$mocks$2f$stillingMock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mockBaseStilling"])),
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].get(stillingEndepunkt('*'), ({ params })=>{
        const slug = params.slug;
        const kjenteSlugs = [
            'nyStilling',
            'internStilling',
            'minStilling',
            'minFormidling',
            'eksternStilling',
            'minEksternStilling',
            'publisertStilling',
            'publisertEksternStilling',
            'utloptStilling',
            'stengtStilling',
            'slettetStilling',
            'fullfortStilling',
            'bannerForlengOppdrag',
            'bannerApneSokeforslag',
            'fullfortBesattLast',
            'fullfortIkkeBesattIkkeLast',
            'fullfortIkkeBesattLast',
            'utkastStilling',
            'ikkePublisertStilling',
            'etterregistrering',
            'etterregistreringApen',
            'jobbmesse',
            'baseStilling'
        ];
        if (kjenteSlugs.includes(slug)) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stilling$2f$rekrutteringsbistandstilling$2f5b$slug$5d2f$mocks$2f$stillingMock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mockBaseStilling"]);
        }
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json({
            timestamp: new Date().toISOString(),
            status: 500,
            error: 'Internal Server Error',
            path: `/rekrutteringsbistandstilling/${slug}`
        }, {
            status: 500
        });
    })
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/kandidat-sok/leggTilKandidat.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "leggTilKandidatEndepunkt",
    ()=>leggTilKandidatEndepunkt,
    "leggTilKandidater",
    ()=>leggTilKandidater
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/api-routes.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/fetcher.ts [app-client] (ecmascript)");
;
;
const leggTilKandidatEndepunkt = (stillingsId)=>`${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatAPI"].internUrl}/veileder/stilling/${stillingsId}/kandidatliste/kandidater`;
const leggTilKandidater = async (kandidater, stillingsId)=>{
    const kandidaterArray = kandidater.map((kandidatnr)=>({
            kandidatnr
        }));
    return await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["postApi"])(leggTilKandidatEndepunkt(stillingsId), kandidaterArray);
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/kandidat/schema.zod.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Kandidatlistestatus",
    ()=>Kandidatlistestatus,
    "kandidatHistorikkSchema",
    ()=>kandidatHistorikkSchema,
    "kandidatlisteSchema",
    ()=>kandidatlisteSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/KandidatTyper.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zod@4.0.17/node_modules/zod/v4/classic/external.js [app-client] (ecmascript) <export * as z>");
;
;
var Kandidatlistestatus = /*#__PURE__*/ function(Kandidatlistestatus) {
    Kandidatlistestatus["Åpen"] = "ÅPEN";
    Kandidatlistestatus["Lukket"] = "LUKKET";
    return Kandidatlistestatus;
}({});
const utfallsendringerSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    utfall: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    registrertAvIdent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    tidspunkt: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    sendtTilArbeidsgiversKandidatliste: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].boolean()
});
const usynligKandidaterSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    id: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    fornavn: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    mellomnavn: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    etternavn: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    utfall: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    lagtTilAvIdent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    lagtTilAvNavn: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    lagtTilTidspunkt: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    arkivert: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].boolean(),
    arkivertAvIdent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    arkivertAvNavn: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    arkivertTidspunkt: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable()
});
const kandidaterSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    kandidatId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    kandidatnr: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    status: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].nativeEnum(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InternKandidatstatus"]),
    lagtTilTidspunkt: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    lagtTilAv: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
        ident: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
        navn: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string()
    }),
    fornavn: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    etternavn: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    fodselsdato: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    fodselsnr: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    utfall: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    telefon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    epost: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    innsatsgruppe: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    antallNotater: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number(),
    arkivert: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].boolean(),
    arkivertTidspunkt: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    arkivertAv: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
        ident: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
        navn: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string()
    }).nullable(),
    aktørid: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    utfallsendringer: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(utfallsendringerSchema)
});
const kandidatlisteSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    kandidatlisteId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    tittel: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    organisasjonReferanse: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    organisasjonNavn: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    stillingId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    opprettetAv: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
        ident: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
        navn: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string()
    }),
    opprettetTidspunkt: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    kandidater: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(kandidaterSchema),
    kanEditere: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].boolean(),
    erEier: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].boolean(),
    kanSlette: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    formidlingerAvUsynligKandidat: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(usynligKandidaterSchema),
    status: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    antallStillinger: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number(),
    stillingskategori: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string()
});
const kandidatHistorikkSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    kandidatnr: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    fornavn: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    etternavn: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    lagtTilTidspunkt: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    lagtTilAvIdent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    lagtTilAvEpost: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    lagtTilAvNavn: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    status: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].nativeEnum(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InternKandidatstatus"]),
    utfall: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    uuid: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    tittel: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    organisasjonReferanse: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    organisasjonNavn: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    stillingId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    slettet: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].boolean(),
    utfallsendringer: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
        utfall: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
        registrertAvIdent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
        tidspunkt: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
        sendtTilArbeidsgiversKandidatliste: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].boolean()
    })),
    stillingskategori: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    opprettetAvIdent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    erMaskert: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].boolean().optional().nullable()
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/kandidat/useKandidatlisteForEier.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "kandidatlisteEndepunkt",
    ()=>kandidatlisteEndepunkt,
    "kandidatlisteMSWHandler",
    ()=>kandidatlisteMSWHandler,
    "useKandidatlisteForEier",
    ()=>useKandidatlisteForEier
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2f$schema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/kandidat/schema.zod.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/api-routes.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRGet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/useSWRGet.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/[stillingsId]/kandidatliste/KandidatTyper.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$mocks$2f$kandidatliste$2e$mock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/mocks/kandidatliste.mock.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/http.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/HttpResponse.mjs [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
const kandidatlisteEndepunkt = (stillingsId)=>stillingsId ? `${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatAPI"].internUrl}/veileder/stilling/${stillingsId}/kandidatliste` : null;
const useKandidatlisteForEier = (stillingsData, erEier)=>{
    _s();
    const kanHenteKandidatliste = Boolean(erEier && stillingsData?.stilling.uuid && stillingsData?.stilling?.publishedByAdmin);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRGet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSWRGet"])(kanHenteKandidatliste ? kandidatlisteEndepunkt(stillingsData?.stilling.uuid) : null, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2f$schema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["kandidatlisteSchema"], {
        // Unngå uendelig retry ved 404-feil
        shouldRetryOnError: {
            "useKandidatlisteForEier.useSWRGet": (error)=>{
                // Ikke retry ved 404-feil (kandidatliste slettet)
                if (error?.status === 404) return false;
                // Ikke retry ved andre client-feil (4xx)
                return !(error?.status >= 400 && error?.status < 500);
            }
        }["useKandidatlisteForEier.useSWRGet"],
        errorRetryCount: 2,
        errorRetryInterval: 5000,
        fetchOptions: {
            skjulFeilmelding: true
        }
    });
};
_s(useKandidatlisteForEier, "K4Y6k2WDwBHXduaV5Y5moFGSmko=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRGet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSWRGet"]
    ];
});
const kandidatlisteMSWHandler = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].get(`${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatAPI"].internUrl}/veileder/stilling/*/kandidatliste`, ({ params })=>{
    const stillingsId = typeof params === 'object' && '0' in params ? String(params['0']) : '';
    // Fullført-banner: besatt (minst én med FATT_JOBBEN)
    if (stillingsId === 'fullfortBesattLast') {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json({
            ...__TURBOPACK__imported__module__$5b$project$5d2f$mocks$2f$kandidatliste$2e$mock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mockKandidatliste"],
            kandidater: __TURBOPACK__imported__module__$5b$project$5d2f$mocks$2f$kandidatliste$2e$mock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mockKandidatliste"].kandidater.map((k, i)=>i === 0 ? {
                    ...k,
                    utfall: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatutfallTyper"].FATT_JOBBEN,
                    arkivert: false
                } : {
                    ...k,
                    utfall: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatutfallTyper"].IKKE_PRESENTERT
                })
        });
    }
    // Fullført-banner: ikke besatt (ingen med FATT_JOBBEN)
    if (stillingsId === 'fullfortIkkeBesattIkkeLast' || stillingsId === 'fullfortIkkeBesattLast') {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json({
            ...__TURBOPACK__imported__module__$5b$project$5d2f$mocks$2f$kandidatliste$2e$mock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mockKandidatliste"],
            kandidater: __TURBOPACK__imported__module__$5b$project$5d2f$mocks$2f$kandidatliste$2e$mock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mockKandidatliste"].kandidater.map((k)=>({
                    ...k,
                    utfall: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatutfallTyper"].IKKE_PRESENTERT
                })),
            formidlingerAvUsynligKandidat: __TURBOPACK__imported__module__$5b$project$5d2f$mocks$2f$kandidatliste$2e$mock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mockKandidatliste"].formidlingerAvUsynligKandidat.map((k)=>({
                    ...k,
                    utfall: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f5b$stillingsId$5d2f$kandidatliste$2f$KandidatTyper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatutfallTyper"].IKKE_PRESENTERT
                }))
        });
    }
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json(__TURBOPACK__imported__module__$5b$project$5d2f$mocks$2f$kandidatliste$2e$mock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mockKandidatliste"]);
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/stilling/oppdater-stilling/oppdaterStilling.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "oppdaterStilling",
    ()=>oppdaterStilling,
    "oppdaterStillingEndepunkt",
    ()=>oppdaterStillingEndepunkt,
    "oppdaterStillingMSWHandler",
    ()=>oppdaterStillingMSWHandler
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/fetcher.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stilling$2f$rekrutteringsbistandstilling$2f5b$slug$5d2f$mocks$2f$stillingMock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/stilling/rekrutteringsbistandstilling/[slug]/mocks/stillingMock.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_util$2f$normaliserStillingProperties$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stilling/_util/normaliserStillingProperties.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/http.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/HttpResponse.mjs [app-client] (ecmascript)");
;
;
;
;
const oppdaterStillingEndepunkt = '/api/stilling/oppdater-stilling';
const oppdaterStilling = (stillingsData, brukerInfo)=>{
    // Sentral normalisering (Map<String,String> backend-kontrakt)
    const sanitizedProperties = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stilling$2f$_util$2f$normaliserStillingProperties$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normaliserPropertiesTilStrenger"])(stillingsData.stilling?.properties);
    let body = {
        ...stillingsData,
        stilling: {
            ...stillingsData.stilling,
            // Overstyr properties med normaliserte verdier hvis de finnes
            ...sanitizedProperties ? {
                properties: sanitizedProperties
            } : {},
            administration: {
                ...stillingsData.stilling.administration,
                navIdent: brukerInfo.eierNavident ?? null,
                reportee: brukerInfo.eierNavn ?? null
            }
        }
    };
    if (stillingsData.stillingsinfo) {
        body = {
            ...body,
            stillingsinfo: {
                ...stillingsData.stillingsinfo,
                eierNavident: brukerInfo.eierNavident ?? null,
                eierNavn: brukerInfo.eierNavn ?? null,
                eierNavKontorEnhetId: brukerInfo.eierNavKontorEnhetId ?? null
            }
        };
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["putApi"])(oppdaterStillingEndepunkt, body);
};
const oppdaterStillingMSWHandler = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].put(oppdaterStillingEndepunkt, async ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$stilling$2f$rekrutteringsbistandstilling$2f5b$slug$5d2f$mocks$2f$stillingMock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mockBaseStilling"]));
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/kandidat/setKandidatlisteStatus.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "setKandidatlisteStatus",
    ()=>setKandidatlisteStatus,
    "setKandidatlisteStatusMSWHandler",
    ()=>setKandidatlisteStatusMSWHandler
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/api-routes.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/fetcher.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$rekbisError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/util/rekbisError.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/http.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/HttpResponse.mjs [app-client] (ecmascript)");
;
;
;
;
const kandidatlisteStatusEndepunkt = (kandidatlisteId)=>`${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatAPI"].internUrl}/veileder/kandidatlister/${kandidatlisteId}/status`;
const setKandidatlisteStatus = async (kandidatlisteId, status)=>{
    try {
        const response = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["putApi"])(kandidatlisteStatusEndepunkt(kandidatlisteId), {
            status
        });
        return response.data;
    } catch  {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$rekbisError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RekbisError"]({
            message: 'Klarte ikke å sette kandidatliste status'
        });
    }
};
const setKandidatlisteStatusMSWHandler = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].put(`${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatAPI"].internUrl}/veileder/kandidatlister/*/status`, ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json({
        status: 'ok'
    }));
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/kandidat/formidleKandidat.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "formidleUsynligKandidat",
    ()=>formidleUsynligKandidat,
    "formidleUsynligKandidatEndepunkt",
    ()=>formidleUsynligKandidatEndepunkt,
    "formidleUsynligKandidatMSWHandler",
    ()=>formidleUsynligKandidatMSWHandler
]);
/**
 * Endepunkt /useEndreKandidatUtfall
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/api-routes.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/fetcher.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/http.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/HttpResponse.mjs [app-client] (ecmascript)");
'use client';
;
;
;
const formidleUsynligKandidatEndepunkt = (kandidatlisteId)=>`${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatAPI"].internUrl}/veileder/kandidatlister/${kandidatlisteId}/formidlingeravusynligkandidat`;
const formidleUsynligKandidat = (kandidatlisteId, formidletKandidat)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["postApi"])(formidleUsynligKandidatEndepunkt(kandidatlisteId), formidletKandidat);
};
const formidleUsynligKandidatMSWHandler = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].post(formidleUsynligKandidatEndepunkt(':kandidatlisteId'), ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json({
        message: 'Kandidaten er formidlet'
    }));
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/synlighet/evaluering/useSynlighetsevaluering.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "KravTilKandidaten",
    ()=>KravTilKandidaten,
    "KravTilVeileder",
    ()=>KravTilVeileder,
    "KriterieUtenforNoensKontroll",
    ()=>KriterieUtenforNoensKontroll,
    "SynlighetsevalueringSchema",
    ()=>SynlighetsevalueringSchema,
    "SynlighetskriterieSchema",
    ()=>SynlighetskriterieSchema,
    "synlighetsevalueringMSWHandler",
    ()=>synlighetsevalueringMSWHandler,
    "useSynlighetsevaluering",
    ()=>useSynlighetsevaluering
]);
/**
 * Endepunkt /useSynlighetsevaluering
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/api-routes.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRPost$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/useSWRPost.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/http.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/HttpResponse.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zod@4.0.17/node_modules/zod/v4/classic/external.js [app-client] (ecmascript) <export * as z>");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
const SynlighetsevalueringEndepunkt = `${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SynlighetsevalueringAPI"].internUrl}/evaluering`;
var KriterieUtenforNoensKontroll = /*#__PURE__*/ function(KriterieUtenforNoensKontroll) {
    KriterieUtenforNoensKontroll["ErIkkeSperretAnsatt"] = "erIkkeSperretAnsatt";
    KriterieUtenforNoensKontroll["ErIkkeDød"] = "erIkkeDoed";
    return KriterieUtenforNoensKontroll;
}({});
var KravTilKandidaten = /*#__PURE__*/ function(KravTilKandidaten) {
    KravTilKandidaten["HarAktivCv"] = "harAktivCv";
    KravTilKandidaten["HarJobbprofil"] = "harJobbprofil";
    KravTilKandidaten["ErUnderOppfølging"] = "erUnderOppfoelging";
    return KravTilKandidaten;
}({});
var KravTilVeileder = /*#__PURE__*/ function(KravTilVeileder) {
    KravTilVeileder["ErArbeidssøker"] = "erArbeidssøker";
    return KravTilVeileder;
}({});
const ikkeVisSynlighetskriterier = [
    'harRiktigFormidlingsgruppe',
    'erFerdigBeregnet'
];
const EkstraSynlighetskriterierSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].enum(ikkeVisSynlighetskriterier);
const SynlighetskriterieSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].union([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].nativeEnum(KriterieUtenforNoensKontroll),
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].nativeEnum(KravTilKandidaten),
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].nativeEnum(KravTilVeileder),
    EkstraSynlighetskriterierSchema
]);
const SynlighetsevalueringSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].record(SynlighetskriterieSchema, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].boolean().nullish());
_c = SynlighetsevalueringSchema;
const useSynlighetsevaluering = (fødselsnummer)=>{
    _s();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRPost$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSWRPost"])(fødselsnummer ? SynlighetsevalueringEndepunkt : null, SynlighetsevalueringSchema, fødselsnummer ? {
        fnr: fødselsnummer
    } : null);
};
_s(useSynlighetsevaluering, "qvvxhpf+S/HwXAta7LPSJ0w8fTs=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRPost$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSWRPost"]
    ];
});
const synlighetsevalueringMSWHandler = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].post(SynlighetsevalueringEndepunkt, ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json({
        harAktivCv: false,
        harJobbprofil: false,
        erUnderOppfoelging: false,
        erArbeidssøker: false,
        erIkkeSperretAnsatt: true,
        erIkkeDoed: true,
        erFerdigBeregnet: true
    }));
var _c;
__turbopack_context__.k.register(_c, "SynlighetsevalueringSchema");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/kandidat-sok/useArenaKandidatnr.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "KandidatKilde",
    ()=>KandidatKilde,
    "arenaKandidatnrMSWHandler",
    ()=>arenaKandidatnrMSWHandler,
    "arenaKandidatnrSchema",
    ()=>arenaKandidatnrSchema,
    "hentArenaKandidatnrEndepunkt",
    ()=>hentArenaKandidatnrEndepunkt,
    "useArenaKandidatnr",
    ()=>useArenaKandidatnr
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/api-routes.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRPost$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/useSWRPost.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$mocks$2f$kandidat$2e$mock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/mocks/kandidat.mock.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/http.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/HttpResponse.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zod@4.0.17/node_modules/zod/v4/classic/external.js [app-client] (ecmascript) <export * as z>");
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
var KandidatKilde = /*#__PURE__*/ function(KandidatKilde) {
    KandidatKilde["REKRUTTERINGSBISTAND"] = "REKRUTTERINGSBISTAND";
    KandidatKilde["PDL"] = "PDL";
    return KandidatKilde;
}({});
const hentArenaKandidatnrEndepunkt = `${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatSøkAPI"].internUrl}/arena-kandidatnr`;
const arenaKandidatnrSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    arenaKandidatnr: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable()
});
const useArenaKandidatnr = (fødselsnummer)=>{
    _s();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRPost$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSWRPost"])(fødselsnummer ? hentArenaKandidatnrEndepunkt : null, arenaKandidatnrSchema, fødselsnummer ? {
        fodselsnummer: fødselsnummer
    } : null, {
        fetchOptions: {
            skjulFeilmelding: [
                404,
                403
            ]
        }
    });
};
_s(useArenaKandidatnr, "qvvxhpf+S/HwXAta7LPSJ0w8fTs=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRPost$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSWRPost"]
    ];
});
const arenaKandidatnrMSWHandler = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].post(hentArenaKandidatnrEndepunkt, async ({ request })=>{
    const raw = await request.json().catch(()=>undefined);
    const fodselsnummer = raw?.fodselsnummer;
    if (!fodselsnummer) return new Response(null, {
        status: 400
    });
    if (fodselsnummer === '16828397901') {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json({
            arenaKandidatnr: null
        });
    }
    if (fodselsnummer === '16828397900') {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json({
            arenaKandidatnr: 'test-arena-kandidatnr'
        });
    }
    const parts = fodselsnummer.split('-');
    if (parts.length >= 3) {
        const seed = parseInt(parts[parts.length - 1], 10);
        if (!isNaN(seed)) {
            const kandidatData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$mocks$2f$kandidat$2e$mock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSingleKandidatDataSchema"])(seed);
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json({
                arenaKandidatnr: kandidatData.arenaKandidatnr
            });
        }
    }
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json(null);
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/kandidat-sok/useKandidatNavn.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "KandidatKilde",
    ()=>KandidatKilde,
    "hentNavnEndepunkt",
    ()=>hentNavnEndepunkt,
    "kandidatNavnMSWHandler",
    ()=>kandidatNavnMSWHandler,
    "navnSchema",
    ()=>navnSchema,
    "useKandidatNavn",
    ()=>useKandidatNavn
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/api-routes.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRPost$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/useSWRPost.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$mocks$2f$kandidat$2e$mock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/mocks/kandidat.mock.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/http.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/HttpResponse.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zod@4.0.17/node_modules/zod/v4/classic/external.js [app-client] (ecmascript) <export * as z>");
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
var KandidatKilde = /*#__PURE__*/ function(KandidatKilde) {
    KandidatKilde["REKRUTTERINGSBISTAND"] = "REKRUTTERINGSBISTAND";
    KandidatKilde["PDL"] = "PDL";
    return KandidatKilde;
}({});
const hentNavnEndepunkt = `${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatSøkAPI"].internUrl}/navn`;
const navnSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    fornavn: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    etternavn: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    kilde: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].nativeEnum(KandidatKilde)
});
const useKandidatNavn = (fødselsnummer)=>{
    _s();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRPost$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSWRPost"])(fødselsnummer ? hentNavnEndepunkt : null, navnSchema, fødselsnummer ? {
        fodselsnummer: fødselsnummer
    } : null, {
        fetchOptions: {
            skjulFeilmelding: [
                404,
                403
            ]
        }
    });
};
_s(useKandidatNavn, "qvvxhpf+S/HwXAta7LPSJ0w8fTs=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRPost$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSWRPost"]
    ];
});
const kandidatNavnMSWHandler = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].post(hentNavnEndepunkt, async ({ request })=>{
    const raw = await request.json().catch(()=>undefined);
    const fodselsnummer = raw?.fodselsnummer;
    if (!fodselsnummer) {
        return new Response(null, {
            status: 400
        });
    }
    switch(fodselsnummer){
        case '16828397900':
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json({
                fornavn: 'TestFornavn',
                etternavn: 'TestEtternavn',
                kilde: "REKRUTTERINGSBISTAND"
            });
        case '30081879652':
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json({
                fornavn: 'Usynlig',
                etternavn: 'Kandidat',
                kilde: "PDL"
            });
        case '26040282334':
            return new Response(null, {
                status: 403
            });
        case '22034609946':
            return new Response(null, {
                status: 404
            });
        default:
            {
                const parts = fodselsnummer?.split('-');
                if (parts && parts.length >= 3) {
                    const seedString = parts[parts.length - 1];
                    const seed = parseInt(seedString, 10);
                    if (!isNaN(seed)) {
                        const kandidatData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$mocks$2f$kandidat$2e$mock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSingleKandidatDataSchema"])(seed);
                        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json({
                            fornavn: kandidatData.fornavn,
                            etternavn: kandidatData.etternavn,
                            kilde: "REKRUTTERINGSBISTAND"
                        });
                    }
                }
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json({
                    fornavn: 'Heldig',
                    etternavn: 'Tomat',
                    kilde: "REKRUTTERINGSBISTAND"
                });
            }
    }
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/stilling/rekrutteringsbistandstilling/[slug]/slett-stilling.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "slettStilling",
    ()=>slettStilling
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/api-routes.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/fetcher.ts [app-client] (ecmascript)");
;
;
const slettStillingEndepunkt = (stillingsId)=>`${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StillingAPI"].internUrl}/rekrutteringsbistandstilling/${stillingsId}`;
async function slettStilling(stillingsId) {
    return await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteApi"])(slettStillingEndepunkt(stillingsId));
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/stilling/opprett-stillingsinfo/opprett-stillingsinfo.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "opprettStillingsinfo",
    ()=>opprettStillingsinfo
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/fetcher.ts [app-client] (ecmascript)");
;
const opprettStillingsinfoEndepunkt = `/api/stilling/opprett-stillingsinfo`;
const opprettStillingsinfo = async (data)=>{
    const response = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["putApi"])(opprettStillingsinfoEndepunkt, data);
    return response.json();
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/stilling/rekrutteringsbistandstilling/kopier/[slug]/kopierStilling.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "kopierStilling",
    ()=>kopierStilling
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/api-routes.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/fetcher.ts [app-client] (ecmascript)");
;
;
const kopierStilling = async (stillingId)=>{
    return await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["postApi"])(`${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StillingAPI"].internUrl}/rekrutteringsbistandstilling/kopier/${stillingId}`, {});
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/stilling/overta-eierskap/overtaEierskap.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "overtaEierskap",
    ()=>overtaEierskap
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/api-routes.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/fetcher.ts [app-client] (ecmascript)");
;
;
const overtaEierskap = async (stillingsinfo)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["putApi"])(`${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StillingAPI"].internUrl}/overta-eierskap`, stillingsinfo);
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/kandidat/endreKandidatUtfall.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "endreUtfallForUsynligKandidat",
    ()=>endreUtfallForUsynligKandidat,
    "endreUtfallKandidat",
    ()=>endreUtfallKandidat
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/api-routes.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/fetcher.ts [app-client] (ecmascript)");
;
;
const endreUtfallUsynligKandidatEndepunkt = (kandidatlisteId, formidlingsId)=>`${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatAPI"].internUrl}/veileder/kandidatlister/${kandidatlisteId}/formidlingeravusynligkandidat/${formidlingsId}/utfall`;
const endreUtfallKandidatEndepunkt = (kandidatlisteId, kandidatnr)=>`${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatAPI"].internUrl}/veileder/kandidatlister/${kandidatlisteId}/kandidater/${kandidatnr}/utfall`;
const endreUtfallForUsynligKandidat = async (kandidatlisteId, formidlingId, utfall, navKontor)=>await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["putApi"])(endreUtfallUsynligKandidatEndepunkt(kandidatlisteId, formidlingId), {
        body: JSON.stringify({
            utfall,
            navKontor
        })
    });
const endreUtfallKandidat = async (utfall, navKontor, kandidatlisteId, kandidatnr)=>await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["putApi"])(endreUtfallKandidatEndepunkt(kandidatlisteId, kandidatnr), {
        utfall,
        navKontor
    });
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/kandidatvarsel/hentMeldingsmaler.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "meldingsmalerRekrutteringstreffMSWHandler",
    ()=>meldingsmalerRekrutteringstreffMSWHandler,
    "meldingsmalerStillingMSWHandler",
    ()=>meldingsmalerStillingMSWHandler,
    "useHentMeldingsmaler",
    ()=>useHentMeldingsmaler,
    "useHentRekrutteringstreffMeldingsmaler",
    ()=>useHentRekrutteringstreffMeldingsmaler
]);
/**
 * Endepunkt /api/meldingsmal
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/api-routes.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRGet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/useSWRGet.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/http.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/HttpResponse.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zod@4.0.17/node_modules/zod/index.js [app-client] (ecmascript) <locals>");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
;
;
;
;
const hentStillingMeldingsmalerEndepunkt = `${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatvarselAPI"].internUrl}/meldingsmal/stilling`;
const hentRekrutteringstreffMeldingsmalerEndepunkt = `${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatvarselAPI"].internUrl}/meldingsmal/rekrutteringstreff`;
const MeldingSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"].object({
    smsTekst: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"].string(),
    epostTittel: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"].string(),
    epostHtmlBody: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"].string()
});
const MeldingsmalerDTOSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"].object({
    vurdertSomAktuell: MeldingSchema,
    passendeStilling: MeldingSchema,
    passendeJobbarrangement: MeldingSchema
});
const RekrutteringstreffMeldingsmalerDTOSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"].object({
    kandidatInvitertTreff: MeldingSchema,
    kandidatInvitertTreffEndret: MeldingSchema
});
const useHentMeldingsmaler = ()=>{
    _s();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRGet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSWRGet"])(hentStillingMeldingsmalerEndepunkt, MeldingsmalerDTOSchema);
};
_s(useHentMeldingsmaler, "K4Y6k2WDwBHXduaV5Y5moFGSmko=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRGet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSWRGet"]
    ];
});
const useHentRekrutteringstreffMeldingsmaler = ()=>{
    _s1();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRGet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSWRGet"])(hentRekrutteringstreffMeldingsmalerEndepunkt, RekrutteringstreffMeldingsmalerDTOSchema);
};
_s1(useHentRekrutteringstreffMeldingsmaler, "K4Y6k2WDwBHXduaV5Y5moFGSmko=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRGet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSWRGet"]
    ];
});
const hentMeldingsmalerStillingMock = {
    vurdertSomAktuell: {
        smsTekst: 'Hei! Vi har vurdert at kompetansen din kan passe til en stilling. Logg inn på Nav for å se stillingen. Vennlig hilsen Nav',
        epostTittel: 'Stilling som kan passe for deg?',
        epostHtmlBody: '<!DOCTYPE html><html><head><title>Melding</title></head><body><p>Hei!</p><p>Vi har vurdert at kompetansen din kan passe til en stilling. Logg inn på Nav for å se stillingen.</p><p>Vennlig hilsen</p><p>Nav</p></body></html>'
    },
    passendeStilling: {
        smsTekst: 'Hei! Vi har funnet en stilling som kan passe deg. Logg inn på Nav for å se stillingen. Vennlig hilsen Nav',
        epostTittel: 'Stilling som kan passe for deg?',
        epostHtmlBody: '<!DOCTYPE html><html><head><title>Melding</title></head><body><p>Hei!</p><p>Vi har funnet en stilling som kanskje kan passe for deg. Logg inn på Nav for å se stillingen.</p><p>Vennlig hilsen</p><p>Nav</p></body></html>'
    },
    passendeJobbarrangement: {
        smsTekst: 'Hei! Vi har funnet et jobbarrangement som kanskje passer for deg. Logg inn på Nav for å se arrangementet. Vennlig hilsen Nav',
        epostTittel: 'Jobbarrangement',
        epostHtmlBody: '<!DOCTYPE html><html><head><title>Melding</title></head><body><p>Hei!</p><p>Vi har funnet et jobbarrangement som kanskje passer for deg. Logg inn på Nav for å se arrangementet.</p><p>Vennlig hilsen</p><p>Nav</p></body></html>'
    }
};
const hentRekrutteringstreffMeldingsmalerMock = {
    kandidatInvitertTreff: {
        smsTekst: 'Hei! Du er invitert til et treff der du kan møte arbeidsgivere. Logg inn på Nav for å melde deg på. Vennlig hilsen Nav',
        epostTittel: 'Invitasjon til å treffe arbeidsgivere',
        epostHtmlBody: '<!DOCTYPE html><html><head><title>Melding</title></head><body><p>Hei! Du er invitert til et treff der du kan møte arbeidsgivere. Logg inn på Nav for å melde deg på.</p><p>Vennlig hilsen</p><p>Nav</p></body></html>'
    },
    kandidatInvitertTreffEndret: {
        smsTekst: 'Det har skjedd endringer på et treff med arbeidsgivere som du er invitert til:\n\n{{ENDRINGER}}\n\nLogg inn på Nav for mer informasjon.\n\nVennlig hilsen Nav',
        epostTittel: 'Endringer på treff du er invitert til',
        epostHtmlBody: '<!DOCTYPE html><html><head><title>Melding</title></head><body><p>Det har skjedd endringer på et treff med arbeidsgivere som du er invitert til:</p><p>{{ENDRINGER}}</p><p>Logg inn på Nav for mer informasjon.</p><p>Vennlig hilsen</p><p>Nav</p></body></html>'
    }
};
const meldingsmalerStillingMSWHandler = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].get(hentStillingMeldingsmalerEndepunkt, ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json(hentMeldingsmalerStillingMock));
const meldingsmalerRekrutteringstreffMSWHandler = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].get(hentRekrutteringstreffMeldingsmalerEndepunkt, ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json(hentRekrutteringstreffMeldingsmalerMock));
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/kandidatvarsel/kandidatvarsel.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BeskjedEksternStatus",
    ()=>BeskjedEksternStatus,
    "EksternKanal",
    ()=>EksternKanal,
    "Meldingsmal",
    ()=>Meldingsmal,
    "MinsideStatus",
    ()=>MinsideStatus,
    "kandidatvarselMSWHandler",
    ()=>kandidatvarselMSWHandler,
    "usePostSmsTilKandidater",
    ()=>usePostSmsTilKandidater,
    "useSendtKandidatmelding",
    ()=>useSendtKandidatmelding,
    "useSmserForKandidat",
    ()=>useSmserForKandidat,
    "useSmserForStilling",
    ()=>useSmserForStilling
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/api-routes.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/fetcher.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRGet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/useSWRGet.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRPost$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/useSWRPost.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$rekbisError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/util/rekbisError.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/http.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/HttpResponse.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$swr$40$2$2e$3$2e$8_react$40$19$2e$2$2e$1$2f$node_modules$2f$swr$2f$dist$2f$_internal$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/swr@2.3.8_react@19.2.1/node_modules/swr/dist/_internal/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zod@4.0.17/node_modules/zod/v4/classic/external.js [app-client] (ecmascript) <export * as z>");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature(), _s3 = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
const varselStillingEndepunkt = (stillingId)=>{
    if (stillingId === undefined) throw new __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$rekbisError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RekbisError"]({
        message: 'stillingId === undefined'
    });
    return `${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatvarselAPI"].internUrl}/varsler/stilling/${stillingId}`;
};
const varselQueryEndepunkt = `${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatvarselAPI"].internUrl}/varsler/query`;
var Meldingsmal = /*#__PURE__*/ function(Meldingsmal) {
    Meldingsmal["VurdertSomAktuell"] = "VURDERT_SOM_AKTUELL";
    Meldingsmal["FunnetPassendeStilling"] = "PASSENDE_STILLING";
    Meldingsmal["Jobbarrangement"] = "PASSENDE_JOBBARRANGEMENT";
    return Meldingsmal;
}({});
var MinsideStatus = /*#__PURE__*/ function(MinsideStatus) {
    /** Det kommer ingen beskjed på min side, fordi varselet ble
   * opprettet før vi hadde minside-integrasjon. */ MinsideStatus["IKKE_BESTILT"] = "IKKE_BESTILT";
    /** Vi jobber med å få opprettet beskjeden  på minside. */ MinsideStatus["UNDER_UTSENDING"] = "UNDER_UTSENDING";
    /** Minside har bekreftet av de har opprettet beskjeden. */ MinsideStatus["OPPRETTET"] = "OPPRETTET";
    /** Beskjeden er slettet og ikke lenger synlig for bruker eller saksbehandler. */ MinsideStatus["SLETTET"] = "SLETTET";
    return MinsideStatus;
}({});
const MinsideStatusSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal("IKKE_BESTILT").or(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal("UNDER_UTSENDING")).or(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal("OPPRETTET")).or(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal("SLETTET"));
var BeskjedEksternStatus = /*#__PURE__*/ function(BeskjedEksternStatus) {
    /** Vi jobber med å sende ut eksternt varsel. Status er ikke avklart enda. */ BeskjedEksternStatus["UNDER_UTSENDING"] = "UNDER_UTSENDING";
    /** Vi har fått bekreftet at en SMS er sendt. */ BeskjedEksternStatus["VELLYKKET_SMS"] = "VELLYKKET_SMS";
    /** Vi har fått bekreftet at en e-post er sendt. */ BeskjedEksternStatus["VELLYKKET_EPOST"] = "VELLYKKET_EPOST";
    /** Varsling er ferdigstilt*/ BeskjedEksternStatus["FERDIGSTILT"] = "FERDIGSTILT";
    /** Det skjedde en feil, og vi vil ikke prøve å sende varselet igjen. */ BeskjedEksternStatus["FEIL"] = "FEIL";
    return BeskjedEksternStatus;
}({});
var EksternKanal = /*#__PURE__*/ function(EksternKanal) {
    EksternKanal["SMS"] = "SMS";
    EksternKanal["EPOST"] = "EPOST";
    return EksternKanal;
}({});
const EksternStatusSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal("UNDER_UTSENDING").or(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal("VELLYKKET_SMS")).or(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal("VELLYKKET_EPOST")).or(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal("FERDIGSTILT")).or(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal("FEIL"));
const EksternKanalSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal(null).or(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal("SMS")).or(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal("EPOST"));
const SmsSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    id: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    opprettet: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    mottakerFnr: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    stillingId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    avsenderNavident: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    minsideStatus: MinsideStatusSchema,
    eksternStatus: EksternStatusSchema,
    eksternFeilmelding: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    eksternKanal: EksternKanalSchema
}).partial({
    eksternFeilmelding: true
});
const SmsArraySchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(SmsSchema);
_c = SmsArraySchema;
const useSmserForStilling = (stillingId)=>{
    _s();
    const { data, mutate: originalMutate, ...rest } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRGet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSWRGet"])(stillingId ? varselStillingEndepunkt(stillingId) : null, SmsArraySchema, {
        refreshInterval: 20000,
        nonImmutable: true
    });
    // Transform array til Record<string, Sms>
    const smser = data ? data.reduce((acc, sms)=>{
        acc[sms.mottakerFnr] = sms;
        return acc;
    }, {}) : undefined;
    return {
        ...rest,
        data: smser,
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        mutate: originalMutate
    };
};
_s(useSmserForStilling, "ev4bgFXC/SJ365ofjAdBXQNAtvI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRGet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSWRGet"]
    ];
});
const useSmserForKandidat = ({ fnr })=>{
    _s1();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRPost$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSWRPost"])(typeof fnr === 'string' ? varselQueryEndepunkt : null, SmsArraySchema, typeof fnr === 'string' ? {
        fnr
    } : null);
};
_s1(useSmserForKandidat, "qvvxhpf+S/HwXAta7LPSJ0w8fTs=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRPost$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSWRPost"]
    ];
});
const usePostSmsTilKandidater = ()=>{
    _s2();
    const { mutate } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$swr$40$2$2e$3$2e$8_react$40$19$2e$2$2e$1$2f$node_modules$2f$swr$2f$dist$2f$_internal$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useSWRConfig"])();
    return async ({ stillingId, mal, fnr })=>{
        const response = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["postApi"])(varselStillingEndepunkt(stillingId), {
            mal,
            fnr
        });
        // Oppdater cache for både stilling og kandidat-spørringer
        await Promise.all([
            mutate(varselStillingEndepunkt(stillingId)),
            mutate((key)=>Array.isArray(key) && key[0] === varselQueryEndepunkt)
        ]);
        return response;
    };
};
_s2(usePostSmsTilKandidater, "w7mJuBRh6/8ZKf7ydxbwCvwINsM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$swr$40$2$2e$3$2e$8_react$40$19$2e$2$2e$1$2f$node_modules$2f$swr$2f$dist$2f$_internal$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useSWRConfig"]
    ];
});
const useSendtKandidatmelding = (kandidatensFnr, stillingId, stillingskategori)=>{
    _s3();
    const erFormidling = stillingskategori === 'FORMIDLING';
    const { data: smser } = useSmserForStilling(erFormidling ? null : stillingId);
    if (typeof kandidatensFnr === 'string' && smser !== undefined) {
        return smser[kandidatensFnr];
    }
    return undefined;
};
_s3(useSendtKandidatmelding, "6EI2cPluKUBZWeNrL7mngnX3qVQ=", false, function() {
    return [
        useSmserForStilling
    ];
});
const smsExampleMock = [
    {
        id: 'A69',
        opprettet: '2024-11-22T15:02:25.197824',
        stillingId: '81d763bd-5858-4479-9113-1d8bcdd4b1f4',
        mottakerFnr: '13898799837',
        avsenderNavident: 'Z994886',
        minsideStatus: 'OPPRETTET',
        eksternStatus: 'FEIL',
        eksternFeilmelding: 'person_ikke_funnet',
        eksternKanal: null
    },
    {
        id: 'A71',
        opprettet: '2024-11-22T15:10:49.650041',
        stillingId: '81d763bd-5858-4479-9113-1d8bcdd4b1f4',
        mottakerFnr: '02518046937',
        avsenderNavident: 'Z994886',
        minsideStatus: 'OPPRETTET',
        eksternStatus: 'FEIL',
        eksternFeilmelding: 'person_ikke_funnet',
        eksternKanal: null
    },
    {
        id: 'A68',
        opprettet: '2024-11-22T14:58:45.995817',
        stillingId: '81d763bd-5858-4479-9113-1d8bcdd4b1f4',
        mottakerFnr: '16847496766',
        avsenderNavident: 'Z994886',
        minsideStatus: 'OPPRETTET',
        eksternStatus: 'FEIL',
        eksternFeilmelding: 'person_ikke_funnet',
        eksternKanal: null
    },
    {
        id: 'A70',
        opprettet: '2024-11-22T15:02:55.871186',
        stillingId: '81d763bd-5858-4479-9113-1d8bcdd4b1f4',
        mottakerFnr: '17838298621',
        avsenderNavident: 'Z994886',
        minsideStatus: 'OPPRETTET',
        eksternStatus: 'FEIL',
        eksternFeilmelding: 'person_ikke_funnet',
        eksternKanal: null
    },
    {
        id: 'A112',
        opprettet: '2025-02-07T13:11:03.489174',
        stillingId: '81d763bd-5858-4479-9113-1d8bcdd4b1f4',
        mottakerFnr: '29528910708',
        avsenderNavident: 'Z994886',
        minsideStatus: 'OPPRETTET',
        eksternStatus: 'FEIL',
        eksternFeilmelding: 'person_ikke_funnet',
        eksternKanal: null
    },
    {
        id: 'A107',
        opprettet: '2025-02-04T15:22:08.340198',
        stillingId: '81d763bd-5858-4479-9113-1d8bcdd4b1f4',
        mottakerFnr: '28869099653',
        avsenderNavident: 'Z993141',
        minsideStatus: 'OPPRETTET',
        eksternStatus: 'FEIL',
        eksternFeilmelding: 'person_ikke_funnet',
        eksternKanal: null
    },
    {
        id: 'A113',
        opprettet: '2025-02-07T13:11:11.095482',
        stillingId: '81d763bd-5858-4479-9113-1d8bcdd4b1f4',
        mottakerFnr: '04479208765',
        avsenderNavident: 'Z994886',
        minsideStatus: 'OPPRETTET',
        eksternStatus: 'FEIL',
        eksternFeilmelding: 'person_ikke_funnet',
        eksternKanal: null
    },
    {
        id: 'A114',
        opprettet: '2025-02-07T13:11:17.706953',
        stillingId: '81d763bd-5858-4479-9113-1d8bcdd4b1f4',
        mottakerFnr: '17418940123',
        avsenderNavident: 'Z994886',
        minsideStatus: 'OPPRETTET',
        eksternStatus: 'FEIL',
        eksternFeilmelding: 'person_ikke_funnet',
        eksternKanal: null
    },
    {
        id: 'A115',
        opprettet: '2025-02-07T13:11:28.071744',
        stillingId: '81d763bd-5858-4479-9113-1d8bcdd4b1f4',
        mottakerFnr: '07476508902',
        avsenderNavident: 'Z994886',
        minsideStatus: 'OPPRETTET',
        eksternStatus: 'FEIL',
        eksternFeilmelding: 'person_ikke_funnet',
        eksternKanal: null
    },
    {
        id: 'A116',
        opprettet: '2025-02-07T13:11:38.16235',
        stillingId: '81d763bd-5858-4479-9113-1d8bcdd4b1f4',
        mottakerFnr: '21506801084',
        avsenderNavident: 'Z994886',
        minsideStatus: 'OPPRETTET',
        eksternStatus: 'FEIL',
        eksternFeilmelding: 'person_ikke_funnet',
        eksternKanal: null
    }
];
const kandidatvarselMSWHandler = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].get(varselStillingEndepunkt('*'), ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json(smsExampleMock));
var _c;
__turbopack_context__.k.register(_c, "SmsArraySchema");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/kandidat/endreKandidatStatus.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "endreKandidatStatus",
    ()=>endreKandidatStatus
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/api-routes.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/fetcher.ts [app-client] (ecmascript)");
;
;
const endreKandidatStatus = async (kandidatlisteId, kandidatnr, status)=>{
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["putApi"])(`${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatAPI"].internUrl}/veileder/kandidatlister/${kandidatlisteId}/kandidater/${kandidatnr}/status`, {
        status
    });
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/foresporsel-om-deling-av-cv/foresporsler/[...slug]/useForespurteOmDelingAvCv.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "foresporselOmDelingAvCVMSWHandler",
    ()=>foresporselOmDelingAvCVMSWHandler,
    "useForespurteOmDelingAvCv",
    ()=>useForespurteOmDelingAvCv
]);
/**
 * Endepunkt /useForespurteOmDelingAvCv
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/api-routes.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRGet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/useSWRGet.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$mocks$2f$forespurteOmDelingAvCv$2e$mock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/mocks/forespurteOmDelingAvCv.mock.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/http.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/HttpResponse.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zod@4.0.17/node_modules/zod/v4/classic/external.js [app-client] (ecmascript) <export * as z>");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
const ForespurteOmDelingAvCvEndepunkt = (stillingsId)=>{
    return `${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ForespørselDelingAvCvAPI"].internUrl}/foresporsler/${stillingsId}`;
};
_c = ForespurteOmDelingAvCvEndepunkt;
const forespørselSvar = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    harSvartJa: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].boolean(),
    svarTidspunkt: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    svartAv: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
        ident: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
        identType: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string()
    })
});
const ForespurtOmDelingSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    aktørId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    stillingsId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    deltStatus: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    deltTidspunkt: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    deltAv: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    svarfrist: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    tilstand: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    svar: forespørselSvar.nullable(),
    begrunnelseForAtAktivitetIkkeBleOpprettet: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable().optional(),
    navKontor: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string()
});
const forespurteOmDelingAvCvSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].record(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(ForespurtOmDelingSchema));
const useForespurteOmDelingAvCv = (stillingsId)=>{
    _s();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRGet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSWRGet"])(ForespurteOmDelingAvCvEndepunkt(stillingsId), forespurteOmDelingAvCvSchema, {
        refreshInterval: 20000
    });
};
_s(useForespurteOmDelingAvCv, "K4Y6k2WDwBHXduaV5Y5moFGSmko=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRGet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSWRGet"]
    ];
});
const foresporselOmDelingAvCVMSWHandler = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].get(ForespurteOmDelingAvCvEndepunkt('*'), ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json((0, __TURBOPACK__imported__module__$5b$project$5d2f$mocks$2f$forespurteOmDelingAvCv$2e$mock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateMockForespurteOmDelingAvCv"])()));
var _c;
__turbopack_context__.k.register(_c, "ForespurteOmDelingAvCvEndepunkt");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/kandidat/postDelMedArbeidsgiver.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "postDelMedArbeidsgiver",
    ()=>postDelMedArbeidsgiver
]);
/**
 * Endepunkt /useDelMedArbeidsgiver
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/api-routes.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/fetcher.ts [app-client] (ecmascript)");
'use client';
;
;
const delMedArbeidsgiverEndepunkt = (kandidatlisteId)=>`${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatAPI"].internUrl}/veileder/kandidatlister/${kandidatlisteId}/deltekandidater`;
const postDelMedArbeidsgiver = async (props)=>await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["postApi"])(delMedArbeidsgiverEndepunkt(props.kandidatlisteId), {
        epostMottakere: props.mailadresser,
        epostTekst: '',
        kandidater: props.kandidatnummerListe,
        navKontor: props.navKontor
    });
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/foresporsel-om-deling-av-cv/foresporsler/forespørselOmDelingAvCv.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "sendForespørselOmDelingAvCv",
    ()=>sendForespørselOmDelingAvCv,
    "sendNyForespørselOmDelingAvCv",
    ()=>sendNyForespørselOmDelingAvCv
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/api-routes.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/fetcher.ts [app-client] (ecmascript)");
;
;
const sendForespørselOmDelingAvCv = async (forespørsel)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["postApi"])(`${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ForespørselDelingAvCvAPI"].internUrl}/foresporsler`, forespørsel);
};
const sendNyForespørselOmDelingAvCv = async (aktørId, forespørsel)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["postApi"])(`${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ForespørselDelingAvCvAPI"].internUrl}/foresporsler/kandidat/${aktørId}`, forespørsel);
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/kandidat/useKandidatListeoversikt.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "kandidatlisteoversiktMSWHandler",
    ()=>kandidatlisteoversiktMSWHandler,
    "useKandidatListeoversikt",
    ()=>useKandidatListeoversikt
]);
/**
 * Endepunkt /useKandidatListeoversikt
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2f$schema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/kandidat/schema.zod.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/api-routes.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRGet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/useSWRGet.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/http.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/HttpResponse.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zod@4.0.17/node_modules/zod/v4/classic/external.js [app-client] (ecmascript) <export * as z>");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
const kandidatListeoversiktEndepunkt = (kandidatId)=>`${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatAPI"].internUrl}/veileder/kandidater/${kandidatId}/listeoversikt`;
// ?inkluderSlettede=true er et valg som ikke er tatt hensyn til her.
const KandidatListeoversiktSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$kandidat$2f$schema$2e$zod$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["kandidatHistorikkSchema"]);
const useKandidatListeoversikt = (kandidatId)=>{
    _s();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRGet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSWRGet"])(kandidatId ? kandidatListeoversiktEndepunkt(kandidatId) : null, KandidatListeoversiktSchema);
};
_s(useKandidatListeoversikt, "K4Y6k2WDwBHXduaV5Y5moFGSmko=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRGet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSWRGet"]
    ];
});
const kandidatlisteoversiktMSWHandler = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].get(`${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatAPI"].internUrl}/veileder/kandidater/*/listeoversikt`, ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json([
        {
            kandidatnr: 'PAM012t1avh27',
            fornavn: 'Våken',
            etternavn: 'Gravemaskin',
            lagtTilTidspunkt: '2024-06-17T13:58:25.213',
            lagtTilAvIdent: 'Z993141',
            lagtTilAvEpost: 'F_Z993141.E_Z993141@trygdeetaten.no',
            lagtTilAvNavn: 'F_Z993141 E_Z993141',
            status: 'VURDERES',
            utfall: 'IKKE_PRESENTERT',
            uuid: '21a78e8f-7a5f-4753-87eb-e9a5ceb5929e',
            tittel: 'Jobbmesse',
            organisasjonReferanse: null,
            organisasjonNavn: 'ALFABETISK PLUTSELIG KATT OVERSKRIFT',
            stillingId: null,
            slettet: false,
            utfallsendringer: [],
            stillingskategori: null,
            opprettetAvIdent: 'Z994440',
            erMaskert: true
        },
        {
            kandidatnr: 'PAM012t1avh27',
            fornavn: 'Våken',
            etternavn: 'Gravemaskin',
            lagtTilTidspunkt: '2024-06-13T17:17:31.918',
            lagtTilAvIdent: 'Z993141',
            lagtTilAvEpost: 'F_Z993141.E_Z993141@trygdeetaten.no',
            lagtTilAvNavn: 'F_Z993141 E_Z993141',
            status: 'VURDERES',
            utfall: 'FATT_JOBBEN',
            uuid: 'ab576819-dd6d-4b6e-a158-e800ee723324',
            tittel: 'Kandidatliste',
            organisasjonReferanse: null,
            organisasjonNavn: 'BARMHJERTIG EFFEKTIV TIGER AS',
            stillingId: null,
            slettet: false,
            utfallsendringer: [
                {
                    utfall: 'FATT_JOBBEN',
                    registrertAvIdent: 'Z993141',
                    tidspunkt: '2024-06-13T17:36:46.437',
                    sendtTilArbeidsgiversKandidatliste: false
                },
                {
                    utfall: 'PRESENTERT',
                    registrertAvIdent: 'Z993141',
                    tidspunkt: '2024-06-13T17:36:44.608',
                    sendtTilArbeidsgiversKandidatliste: false
                },
                {
                    utfall: 'IKKE_PRESENTERT',
                    registrertAvIdent: 'Z993141',
                    tidspunkt: '2024-06-13T17:36:41.746',
                    sendtTilArbeidsgiversKandidatliste: false
                },
                {
                    utfall: 'PRESENTERT',
                    registrertAvIdent: 'Z993141',
                    tidspunkt: '2024-06-13T17:36:39.019',
                    sendtTilArbeidsgiversKandidatliste: false
                },
                {
                    utfall: 'FATT_JOBBEN',
                    registrertAvIdent: 'Z993141',
                    tidspunkt: '2024-06-13T17:20:35.265',
                    sendtTilArbeidsgiversKandidatliste: false
                },
                {
                    utfall: 'PRESENTERT',
                    registrertAvIdent: 'Z993141',
                    tidspunkt: '2024-06-13T17:20:35.265',
                    sendtTilArbeidsgiversKandidatliste: false
                }
            ],
            stillingskategori: null,
            opprettetAvIdent: 'Z994440',
            erMaskert: true
        },
        {
            kandidatnr: 'PAM012t1avh27',
            fornavn: 'Våken',
            etternavn: 'Gravemaskin',
            lagtTilTidspunkt: '2024-06-19T15:36:02.978',
            lagtTilAvIdent: 'Z993141',
            lagtTilAvEpost: 'F_Z993141.E_Z993141@trygdeetaten.no',
            lagtTilAvNavn: 'F_Z993141 E_Z993141',
            status: 'VURDERES',
            utfall: 'IKKE_PRESENTERT',
            uuid: 'bf3d8d1e-ee9b-4635-af9d-84e9df136a43',
            tittel: null,
            organisasjonReferanse: null,
            organisasjonNavn: null,
            stillingId: '4dbcfa50-e5f5-4100-be23-8267bfea2056',
            slettet: false,
            utfallsendringer: [],
            stillingskategori: 'STILLING',
            opprettetAvIdent: 'Z993141',
            erMaskert: false
        },
        {
            kandidatnr: 'PAM012t1avh27',
            fornavn: 'Våken',
            etternavn: 'Gravemaskin',
            lagtTilTidspunkt: '2024-06-26T14:03:11.486',
            lagtTilAvIdent: 'Z993141',
            lagtTilAvEpost: 'F_Z993141.E_Z993141@trygdeetaten.no',
            lagtTilAvNavn: 'F_Z993141 E_Z993141',
            status: 'VURDERES',
            utfall: 'IKKE_PRESENTERT',
            uuid: 'adc68669-392e-45aa-ab9c-4b3cf460525c',
            tittel: null,
            organisasjonReferanse: null,
            organisasjonNavn: null,
            stillingId: 'd6eacf78-a79f-4db4-8007-3ef804a58aec',
            slettet: false,
            utfallsendringer: [],
            stillingskategori: 'STILLING',
            opprettetAvIdent: 'Z993141',
            erMaskert: false
        },
        {
            kandidatnr: 'PAM012t1avh27',
            fornavn: 'Våken',
            etternavn: 'Gravemaskin',
            lagtTilTidspunkt: '2024-06-26T14:45:48.682',
            lagtTilAvIdent: 'Z993141',
            lagtTilAvEpost: 'F_Z993141.E_Z993141@trygdeetaten.no',
            lagtTilAvNavn: 'F_Z993141 E_Z993141',
            status: 'VURDERES',
            utfall: 'IKKE_PRESENTERT',
            uuid: '8fb55c1a-f647-40e1-8bbe-a35d0801760a',
            tittel: null,
            organisasjonReferanse: null,
            organisasjonNavn: null,
            stillingId: '93aedbda-9f35-4a9f-881c-29b154c74e10',
            slettet: false,
            utfallsendringer: [],
            stillingskategori: 'STILLING',
            opprettetAvIdent: 'Z993141',
            erMaskert: false
        },
        {
            kandidatnr: 'PAM012t1avh27',
            fornavn: 'Våken',
            etternavn: 'Gravemaskin',
            lagtTilTidspunkt: '2024-06-21T14:50:20.138',
            lagtTilAvIdent: 'Z993141',
            lagtTilAvEpost: 'F_Z993141.E_Z993141@trygdeetaten.no',
            lagtTilAvNavn: 'F_Z993141 E_Z993141',
            status: 'VURDERES',
            utfall: 'IKKE_PRESENTERT',
            uuid: 'aa31c933-350f-4c08-8e3f-3d5b22b8e14c',
            tittel: null,
            organisasjonReferanse: '312328712',
            organisasjonNavn: 'OMTENKSOM LOJAL STRUTS PLC',
            stillingId: '71344525-ad9c-4e37-b4e7-265c19b889b4',
            slettet: false,
            utfallsendringer: [],
            stillingskategori: 'FORMIDLING',
            opprettetAvIdent: 'Z993141',
            erMaskert: false
        },
        {
            kandidatnr: 'PAM012t1avh27',
            fornavn: 'Våken',
            etternavn: 'Gravemaskin',
            lagtTilTidspunkt: '2024-06-26T15:05:44.786',
            lagtTilAvIdent: 'Z993141',
            lagtTilAvEpost: 'F_Z993141.E_Z993141@trygdeetaten.no',
            lagtTilAvNavn: 'F_Z993141 E_Z993141',
            status: 'AKTUELL',
            utfall: 'IKKE_PRESENTERT',
            uuid: '7e5ac9c3-122e-4184-a9dc-688912efdae7',
            tittel: null,
            organisasjonReferanse: null,
            organisasjonNavn: null,
            stillingId: 'fbef62ad-f217-4f74-bb1d-e1b790e82430',
            slettet: false,
            utfallsendringer: [],
            stillingskategori: 'STILLING',
            opprettetAvIdent: 'Z993141',
            erMaskert: false
        },
        {
            kandidatnr: 'PAM012t1avh27',
            fornavn: 'Våken',
            etternavn: 'Gravemaskin',
            lagtTilTidspunkt: '2024-06-27T08:44:19.315',
            lagtTilAvIdent: 'Z993141',
            lagtTilAvEpost: 'F_Z993141.E_Z993141@trygdeetaten.no',
            lagtTilAvNavn: 'F_Z993141 E_Z993141',
            status: 'VURDERES',
            utfall: 'IKKE_PRESENTERT',
            uuid: '1aaec870-b24b-41b1-8818-e46080d312b5',
            tittel: null,
            organisasjonReferanse: null,
            organisasjonNavn: null,
            stillingId: '239f6f8d-b0b5-4b5e-b97c-d38ee2dff612',
            slettet: false,
            utfallsendringer: [],
            stillingskategori: 'STILLING',
            opprettetAvIdent: 'Z993141',
            erMaskert: false
        },
        {
            kandidatnr: 'PAM012t1avh27',
            fornavn: 'Våken',
            etternavn: 'Gravemaskin',
            lagtTilTidspunkt: '2024-06-27T11:37:41.129',
            lagtTilAvIdent: 'Z993141',
            lagtTilAvEpost: 'F_Z993141.E_Z993141@trygdeetaten.no',
            lagtTilAvNavn: 'F_Z993141 E_Z993141',
            status: 'VURDERES',
            utfall: 'IKKE_PRESENTERT',
            uuid: '077bba8f-ae51-41fb-ac8e-0917c5df1876',
            tittel: null,
            organisasjonReferanse: null,
            organisasjonNavn: null,
            stillingId: '7ee10191-5882-4e63-8b44-29211bcb8449',
            slettet: false,
            utfallsendringer: [],
            stillingskategori: 'STILLING',
            opprettetAvIdent: 'Z993141',
            erMaskert: false
        },
        {
            kandidatnr: 'PAM012t1avh27',
            fornavn: 'Våken',
            etternavn: 'Gravemaskin',
            lagtTilTidspunkt: '2024-06-28T09:52:36.725',
            lagtTilAvIdent: 'Z993141',
            lagtTilAvEpost: 'F_Z993141.E_Z993141@trygdeetaten.no',
            lagtTilAvNavn: 'F_Z993141 E_Z993141',
            status: 'VURDERES',
            utfall: 'PRESENTERT',
            uuid: '1739053d-28e1-4120-9808-77d70add772f',
            tittel: null,
            organisasjonReferanse: '315414822',
            organisasjonNavn: 'ALFABETISK PLUTSELIG KATT OVERSKRIFT',
            stillingId: '44142941-1fff-401f-8072-98889d9c41d4',
            slettet: false,
            utfallsendringer: [
                {
                    utfall: 'PRESENTERT',
                    registrertAvIdent: 'Z993141',
                    tidspunkt: '2024-06-28T09:53:03.974',
                    sendtTilArbeidsgiversKandidatliste: false
                }
            ],
            stillingskategori: 'STILLING',
            opprettetAvIdent: 'Z993141',
            erMaskert: false
        },
        {
            kandidatnr: 'PAM012t1avh27',
            fornavn: 'Våken',
            etternavn: 'Gravemaskin',
            lagtTilTidspunkt: '2024-06-28T12:46:29.068',
            lagtTilAvIdent: 'Z993141',
            lagtTilAvEpost: 'F_Z993141.E_Z993141@trygdeetaten.no',
            lagtTilAvNavn: 'F_Z993141 E_Z993141',
            status: 'VURDERES',
            utfall: 'IKKE_PRESENTERT',
            uuid: 'c95906bc-71bd-42af-95d4-ce507566616c',
            tittel: null,
            organisasjonReferanse: null,
            organisasjonNavn: null,
            stillingId: '33485624-9a1f-4eeb-a762-b6e701dcfd35',
            slettet: false,
            utfallsendringer: [],
            stillingskategori: 'STILLING',
            opprettetAvIdent: 'Z993141',
            erMaskert: false
        },
        {
            kandidatnr: 'PAM012t1avh27',
            fornavn: 'Våken',
            etternavn: 'Gravemaskin',
            lagtTilTidspunkt: '2024-06-28T13:07:26.741',
            lagtTilAvIdent: 'Z993141',
            lagtTilAvEpost: 'F_Z993141.E_Z993141@trygdeetaten.no',
            lagtTilAvNavn: 'F_Z993141 E_Z993141',
            status: 'VURDERES',
            utfall: 'IKKE_PRESENTERT',
            uuid: 'bb5e9527-74e2-4802-847f-304638e2809f',
            tittel: null,
            organisasjonReferanse: null,
            organisasjonNavn: null,
            stillingId: 'ccee19fc-360d-4396-a503-c0f1b4c2ca1f',
            slettet: false,
            utfallsendringer: [],
            stillingskategori: 'STILLING',
            opprettetAvIdent: 'Z993141',
            erMaskert: false
        },
        {
            kandidatnr: 'PAM012t1avh27',
            fornavn: 'Våken',
            etternavn: 'Gravemaskin',
            lagtTilTidspunkt: '2024-07-01T10:28:23.588',
            lagtTilAvIdent: 'Z993141',
            lagtTilAvEpost: 'F_Z993141.E_Z993141@trygdeetaten.no',
            lagtTilAvNavn: 'F_Z993141 E_Z993141',
            status: 'VURDERES',
            utfall: 'IKKE_PRESENTERT',
            uuid: 'f8608785-a3fc-4d91-8856-400ef97241ea',
            tittel: null,
            organisasjonReferanse: null,
            organisasjonNavn: null,
            stillingId: '9853deb9-7d25-408f-b70c-c0a8aa4bb65d',
            slettet: false,
            utfallsendringer: [],
            stillingskategori: 'STILLING',
            opprettetAvIdent: 'Z993141',
            erMaskert: false
        },
        {
            kandidatnr: 'PAM012t1avh27',
            fornavn: 'Våken',
            etternavn: 'Gravemaskin',
            lagtTilTidspunkt: '2024-07-09T13:31:13.004',
            lagtTilAvIdent: 'Z993141',
            lagtTilAvEpost: 'F_Z993141.E_Z993141@trygdeetaten.no',
            lagtTilAvNavn: 'F_Z993141 E_Z993141',
            status: 'VURDERES',
            utfall: 'IKKE_PRESENTERT',
            uuid: 'ac28ca8c-171c-40d2-b870-d302097cfaea',
            tittel: 'Kandidatliste',
            organisasjonReferanse: null,
            organisasjonNavn: 'ORDKNAPP BLOMSTRETE TIGER AS',
            stillingId: null,
            slettet: false,
            utfallsendringer: [],
            stillingskategori: null,
            opprettetAvIdent: 'Z994092',
            erMaskert: true
        },
        {
            kandidatnr: 'PAM012t1avh27',
            fornavn: 'Våken',
            etternavn: 'Gravemaskin',
            lagtTilTidspunkt: '2024-07-09T13:42:26.252',
            lagtTilAvIdent: 'Z993141',
            lagtTilAvEpost: 'F_Z993141.E_Z993141@trygdeetaten.no',
            lagtTilAvNavn: 'F_Z993141 E_Z993141',
            status: 'VURDERES',
            utfall: 'IKKE_PRESENTERT',
            uuid: '92e59ecd-c9dd-478a-adeb-c10ca3bc0982',
            tittel: null,
            organisasjonReferanse: '315090334',
            organisasjonNavn: 'STRENG KRITISK TIGER AS',
            stillingId: '9a22ee86-dbef-4496-b498-e47e6817a4f0',
            slettet: false,
            utfallsendringer: [],
            stillingskategori: 'JOBBMESSE',
            opprettetAvIdent: 'Z993141',
            erMaskert: false
        },
        {
            kandidatnr: 'PAM012t1avh27',
            fornavn: 'Våken',
            etternavn: 'Gravemaskin',
            lagtTilTidspunkt: '2024-07-09T14:04:07.089',
            lagtTilAvIdent: 'Z993141',
            lagtTilAvEpost: 'F_Z993141.E_Z993141@trygdeetaten.no',
            lagtTilAvNavn: 'F_Z993141 E_Z993141',
            status: 'VURDERES',
            utfall: 'IKKE_PRESENTERT',
            uuid: 'b9eef66e-6f6c-40ef-a040-fd15f8a3fca7',
            tittel: null,
            organisasjonReferanse: '312328712',
            organisasjonNavn: 'OMTENKSOM LOJAL STRUTS PLC',
            stillingId: '8fa424d9-df37-439e-a0f6-60ec756aab96',
            slettet: false,
            utfallsendringer: [],
            stillingskategori: 'JOBBMESSE',
            opprettetAvIdent: 'Z993141',
            erMaskert: false
        },
        {
            kandidatnr: 'PAM012t1avh27',
            fornavn: 'Våken',
            etternavn: 'Gravemaskin',
            lagtTilTidspunkt: '2024-07-10T12:00:42.447',
            lagtTilAvIdent: 'Z993141',
            lagtTilAvEpost: 'F_Z993141.E_Z993141@trygdeetaten.no',
            lagtTilAvNavn: 'F_Z993141 E_Z993141',
            status: 'VURDERES',
            utfall: 'IKKE_PRESENTERT',
            uuid: '84610b0c-5497-4748-abed-d1e1067d3b36',
            tittel: 'Kandidatliste',
            organisasjonReferanse: null,
            organisasjonNavn: 'TESTUDO',
            stillingId: null,
            slettet: false,
            utfallsendringer: [],
            stillingskategori: null,
            opprettetAvIdent: 'Z994440',
            erMaskert: true
        },
        {
            kandidatnr: 'PAM012t1avh27',
            fornavn: 'Våken',
            etternavn: 'Gravemaskin',
            lagtTilTidspunkt: '2024-07-10T12:19:56.952',
            lagtTilAvIdent: 'Z993141',
            lagtTilAvEpost: 'F_Z993141.E_Z993141@trygdeetaten.no',
            lagtTilAvNavn: 'F_Z993141 E_Z993141',
            status: 'VURDERES',
            utfall: 'IKKE_PRESENTERT',
            uuid: '491c132c-7e91-445e-a4e7-ce3f8ac01bc0',
            tittel: null,
            organisasjonReferanse: '312113341',
            organisasjonNavn: 'ORDKNAPP BLOMSTRETE TIGER AS',
            stillingId: '0c8fc967-888c-4c0c-8bb8-6a77ef0658ad',
            slettet: false,
            utfallsendringer: [],
            stillingskategori: 'STILLING',
            opprettetAvIdent: 'Z993141',
            erMaskert: false
        },
        {
            kandidatnr: 'PAM012t1avh27',
            fornavn: 'Våken',
            etternavn: 'Gravemaskin',
            lagtTilTidspunkt: '2024-07-10T13:55:50.239',
            lagtTilAvIdent: 'Z993141',
            lagtTilAvEpost: 'F_Z993141.E_Z993141@trygdeetaten.no',
            lagtTilAvNavn: 'F_Z993141 E_Z993141',
            status: 'VURDERES',
            utfall: 'IKKE_PRESENTERT',
            uuid: 'c1d0596e-6c6b-4308-8b30-e5ef388134e5',
            tittel: null,
            organisasjonReferanse: '312328712',
            organisasjonNavn: 'OMTENKSOM LOJAL STRUTS PLC',
            stillingId: '2ebc0910-b374-4239-bf52-a5f0095477ef',
            slettet: false,
            utfallsendringer: [],
            stillingskategori: 'JOBBMESSE',
            opprettetAvIdent: 'Z993141',
            erMaskert: false
        },
        {
            kandidatnr: 'PAM012t1avh27',
            fornavn: 'Våken',
            etternavn: 'Gravemaskin',
            lagtTilTidspunkt: '2024-08-06T12:37:29.362',
            lagtTilAvIdent: 'Z993141',
            lagtTilAvEpost: 'F_Z993141.E_Z993141@trygdeetaten.no',
            lagtTilAvNavn: 'F_Z993141 E_Z993141',
            status: 'VURDERES',
            utfall: 'IKKE_PRESENTERT',
            uuid: '0cb4821b-b2e2-4fce-b8f0-836d5b9a0dea',
            tittel: 'Jobbmesse',
            organisasjonReferanse: null,
            organisasjonNavn: 'OMTENKSOM LOJAL STRUTS PLC',
            stillingId: null,
            slettet: false,
            utfallsendringer: [],
            stillingskategori: null,
            opprettetAvIdent: 'Z994440',
            erMaskert: true
        },
        {
            kandidatnr: 'PAM012t1avh27',
            fornavn: 'Våken',
            etternavn: 'Gravemaskin',
            lagtTilTidspunkt: '2024-08-16T13:29:28.356',
            lagtTilAvIdent: 'Z993098',
            lagtTilAvEpost: 'F_Z993098.E_Z993098@trygdeetaten.no',
            lagtTilAvNavn: 'F_Z993098 E_Z993098',
            status: 'VURDERES',
            utfall: 'IKKE_PRESENTERT',
            uuid: '8082f5aa-b348-4e90-b0c9-de91cbb2e33a',
            tittel: null,
            organisasjonReferanse: '919817402',
            organisasjonNavn: 'LAVANGSNES WUNDERKAMMER AS',
            stillingId: '1028fae9-33ad-40a6-9960-a498093d5301',
            slettet: false,
            utfallsendringer: [],
            stillingskategori: null,
            opprettetAvIdent: 'Z993141',
            erMaskert: false
        },
        {
            kandidatnr: 'PAM012t1avh27',
            fornavn: 'Våken',
            etternavn: 'Gravemaskin',
            lagtTilTidspunkt: '2024-09-10T12:13:42.294',
            lagtTilAvIdent: 'Z993141',
            lagtTilAvEpost: 'F_Z993141.E_Z993141@trygdeetaten.no',
            lagtTilAvNavn: 'F_Z993141 E_Z993141',
            status: 'VURDERES',
            utfall: 'FATT_JOBBEN',
            uuid: '461ffbf1-92f9-4d55-a37f-60c9c364f76c',
            tittel: null,
            organisasjonReferanse: '315090334',
            organisasjonNavn: 'STRENG KRITISK TIGER AS',
            stillingId: 'cd217cb1-1ea4-498f-b463-09e95eb74bb1',
            slettet: false,
            utfallsendringer: [
                {
                    utfall: 'FATT_JOBBEN',
                    registrertAvIdent: 'Z993141',
                    tidspunkt: '2024-09-11T10:53:01.484',
                    sendtTilArbeidsgiversKandidatliste: false
                },
                {
                    utfall: 'PRESENTERT',
                    registrertAvIdent: 'Z993141',
                    tidspunkt: '2024-09-11T10:53:01.484',
                    sendtTilArbeidsgiversKandidatliste: false
                }
            ],
            stillingskategori: 'FORMIDLING',
            opprettetAvIdent: 'Z993141',
            erMaskert: false
        },
        {
            kandidatnr: 'PAM012t1avh27',
            fornavn: 'Våken',
            etternavn: 'Gravemaskin',
            lagtTilTidspunkt: '2024-08-20T08:29:47.536',
            lagtTilAvIdent: 'Z994886',
            lagtTilAvEpost: 'F_Z994886.E_Z994886@trygdeetaten.no',
            lagtTilAvNavn: 'F_Z994886 E_Z994886',
            status: 'VURDERES',
            utfall: 'FATT_JOBBEN',
            uuid: '5ad6707c-44bb-49ad-9ba0-57565bbee227',
            tittel: null,
            organisasjonReferanse: '312328712',
            organisasjonNavn: 'OMTENKSOM LOJAL STRUTS PLC',
            stillingId: '79c79661-e52c-420c-a12c-f76839cdbaab',
            slettet: false,
            utfallsendringer: [
                {
                    utfall: 'FATT_JOBBEN',
                    registrertAvIdent: 'Z993141',
                    tidspunkt: '2024-09-11T10:58:42.055',
                    sendtTilArbeidsgiversKandidatliste: false
                },
                {
                    utfall: 'PRESENTERT',
                    registrertAvIdent: 'Z993141',
                    tidspunkt: '2024-09-11T10:58:42.055',
                    sendtTilArbeidsgiversKandidatliste: false
                }
            ],
            stillingskategori: 'STILLING',
            opprettetAvIdent: 'Z993141',
            erMaskert: false
        },
        {
            kandidatnr: 'PAM012t1avh27',
            fornavn: 'Våken',
            etternavn: 'Gravemaskin',
            lagtTilTidspunkt: '2024-09-03T09:46:16.056',
            lagtTilAvIdent: 'Z993141',
            lagtTilAvEpost: 'F_Z993141.E_Z993141@trygdeetaten.no',
            lagtTilAvNavn: 'F_Z993141 E_Z993141',
            status: 'VURDERES',
            utfall: 'FATT_JOBBEN',
            uuid: '1dc22d22-d80d-41e4-acc2-5ab93e7c9404',
            tittel: null,
            organisasjonReferanse: '312113341',
            organisasjonNavn: 'ORDKNAPP BLOMSTRETE TIGER AS',
            stillingId: 'abc2e1f4-fe5b-4d8d-96b8-75db2245ce22',
            slettet: false,
            utfallsendringer: [
                {
                    utfall: 'FATT_JOBBEN',
                    registrertAvIdent: 'Z993141',
                    tidspunkt: '2024-10-10T14:37:01.088',
                    sendtTilArbeidsgiversKandidatliste: false
                },
                {
                    utfall: 'PRESENTERT',
                    registrertAvIdent: 'Z993141',
                    tidspunkt: '2024-10-10T14:37:01.088',
                    sendtTilArbeidsgiversKandidatliste: false
                },
                {
                    utfall: 'IKKE_PRESENTERT',
                    registrertAvIdent: 'Z993141',
                    tidspunkt: '2024-09-12T13:18:40.473',
                    sendtTilArbeidsgiversKandidatliste: false
                },
                {
                    utfall: 'PRESENTERT',
                    registrertAvIdent: 'Z993141',
                    tidspunkt: '2024-09-12T13:17:25.731',
                    sendtTilArbeidsgiversKandidatliste: false
                },
                {
                    utfall: 'FATT_JOBBEN',
                    registrertAvIdent: 'Z993141',
                    tidspunkt: '2024-09-12T13:17:16.769',
                    sendtTilArbeidsgiversKandidatliste: false
                },
                {
                    utfall: 'PRESENTERT',
                    registrertAvIdent: 'Z993141',
                    tidspunkt: '2024-09-12T13:16:39.907',
                    sendtTilArbeidsgiversKandidatliste: true
                }
            ],
            stillingskategori: 'STILLING',
            opprettetAvIdent: 'Z993141',
            erMaskert: false
        },
        {
            kandidatnr: 'PAM012t1avh27',
            fornavn: 'Våken',
            etternavn: 'Gravemaskin',
            lagtTilTidspunkt: '2024-09-17T15:35:50.54',
            lagtTilAvIdent: 'Z993141',
            lagtTilAvEpost: 'F_Z993141.E_Z993141@trygdeetaten.no',
            lagtTilAvNavn: 'F_Z993141 E_Z993141',
            status: 'VURDERES',
            utfall: 'IKKE_PRESENTERT',
            uuid: '6356678f-a927-4839-bc53-56342e5c97c7',
            tittel: 'Kandidatliste',
            organisasjonReferanse: null,
            organisasjonNavn: 'ORDKNAPP BLOMSTRETE TIGER AS',
            stillingId: null,
            slettet: false,
            utfallsendringer: [
                {
                    utfall: 'IKKE_PRESENTERT',
                    registrertAvIdent: 'Z993141',
                    tidspunkt: '2024-09-17T15:36:55.169',
                    sendtTilArbeidsgiversKandidatliste: false
                },
                {
                    utfall: 'FATT_JOBBEN',
                    registrertAvIdent: 'Z993141',
                    tidspunkt: '2024-09-17T15:35:50.766',
                    sendtTilArbeidsgiversKandidatliste: false
                }
            ],
            stillingskategori: null,
            opprettetAvIdent: 'Z994440',
            erMaskert: true
        },
        {
            kandidatnr: 'PAM012t1avh27',
            fornavn: 'Våken',
            etternavn: 'Gravemaskin',
            lagtTilTidspunkt: '2024-09-19T12:07:41.49',
            lagtTilAvIdent: 'Z993098',
            lagtTilAvEpost: 'F_Z993098.E_Z993098@trygdeetaten.no',
            lagtTilAvNavn: 'F_Z993098 E_Z993098',
            status: 'VURDERES',
            utfall: 'IKKE_PRESENTERT',
            uuid: '53971017-415b-4291-88dc-da4f899f08af',
            tittel: 'Kandidatliste',
            organisasjonReferanse: null,
            organisasjonNavn: 'OMTENKSOM LOJAL STRUTS PLC',
            stillingId: null,
            slettet: false,
            utfallsendringer: [
                {
                    utfall: 'IKKE_PRESENTERT',
                    registrertAvIdent: 'Z993098',
                    tidspunkt: '2024-09-19T12:08:31.314',
                    sendtTilArbeidsgiversKandidatliste: false
                },
                {
                    utfall: 'FATT_JOBBEN',
                    registrertAvIdent: 'Z993098',
                    tidspunkt: '2024-09-19T12:08:21.122',
                    sendtTilArbeidsgiversKandidatliste: false
                }
            ],
            stillingskategori: null,
            opprettetAvIdent: 'Z993098',
            erMaskert: true
        },
        {
            kandidatnr: 'PAM012t1avh27',
            fornavn: 'Våken',
            etternavn: 'Gravemaskin',
            lagtTilTidspunkt: '2024-09-13T09:40:40.232',
            lagtTilAvIdent: 'Z993141',
            lagtTilAvEpost: 'F_Z993141.E_Z993141@trygdeetaten.no',
            lagtTilAvNavn: 'F_Z993141 E_Z993141',
            status: 'VURDERES',
            utfall: 'PRESENTERT',
            uuid: '779e8c60-5c32-4c7c-b600-48abb9df4c2c',
            tittel: null,
            organisasjonReferanse: '315090334',
            organisasjonNavn: 'STRENG KRITISK TIGER AS',
            stillingId: '8ad24298-9d46-4bc2-9e47-ad91b2b1b6b0',
            slettet: false,
            utfallsendringer: [
                {
                    utfall: 'PRESENTERT',
                    registrertAvIdent: 'Z993141',
                    tidspunkt: '2024-12-18T15:50:29.046',
                    sendtTilArbeidsgiversKandidatliste: false
                },
                {
                    utfall: 'FATT_JOBBEN',
                    registrertAvIdent: 'Z993141',
                    tidspunkt: '2024-09-13T12:56:05.429',
                    sendtTilArbeidsgiversKandidatliste: false
                },
                {
                    utfall: 'PRESENTERT',
                    registrertAvIdent: 'Z993141',
                    tidspunkt: '2024-09-13T12:54:09.026',
                    sendtTilArbeidsgiversKandidatliste: true
                }
            ],
            stillingskategori: 'STILLING',
            opprettetAvIdent: 'Z993141',
            erMaskert: false
        },
        {
            kandidatnr: 'PAM012t1avh27',
            fornavn: 'Våken',
            etternavn: 'Gravemaskin',
            lagtTilTidspunkt: '2024-11-12T16:34:12.911',
            lagtTilAvIdent: 'Z993141',
            lagtTilAvEpost: 'F_Z993141.E_Z993141@trygdeetaten.no',
            lagtTilAvNavn: 'F_Z993141 E_Z993141',
            status: 'VURDERES',
            utfall: 'IKKE_PRESENTERT',
            uuid: '9d41b7c5-c192-43cc-9810-12ff14b71c9b',
            tittel: null,
            organisasjonReferanse: '312328712',
            organisasjonNavn: 'OMTENKSOM LOJAL STRUTS PLC',
            stillingId: '293daff1-ca1d-42f7-9895-41c69d8c8d5e',
            slettet: false,
            utfallsendringer: [],
            stillingskategori: 'STILLING',
            opprettetAvIdent: 'Z993141',
            erMaskert: false
        },
        {
            kandidatnr: 'PAM012t1avh27',
            fornavn: 'Våken',
            etternavn: 'Gravemaskin',
            lagtTilTidspunkt: '2024-12-11T12:57:17.324',
            lagtTilAvIdent: 'Z993141',
            lagtTilAvEpost: 'F_Z993141.E_Z993141@trygdeetaten.no',
            lagtTilAvNavn: 'F_Z993141 E_Z993141',
            status: 'VURDERES',
            utfall: 'IKKE_PRESENTERT',
            uuid: '4c936f0e-8230-460f-b466-0a94902ced94',
            tittel: null,
            organisasjonReferanse: null,
            organisasjonNavn: null,
            stillingId: 'f8121b3a-e4fc-4e95-941b-21dd3a9a315b',
            slettet: false,
            utfallsendringer: [],
            stillingskategori: 'STILLING',
            opprettetAvIdent: 'Z993141',
            erMaskert: false
        },
        {
            kandidatnr: 'PAM012t1avh27',
            fornavn: 'Våken',
            etternavn: 'Gravemaskin',
            lagtTilTidspunkt: '2024-12-12T13:01:45.104',
            lagtTilAvIdent: 'Z993141',
            lagtTilAvEpost: 'F_Z993141.E_Z993141@trygdeetaten.no',
            lagtTilAvNavn: 'F_Z993141 E_Z993141',
            status: 'VURDERES',
            utfall: 'IKKE_PRESENTERT',
            uuid: '7437d79d-ab1d-4ba1-84c6-134c8fe1f31c',
            tittel: null,
            organisasjonReferanse: null,
            organisasjonNavn: null,
            stillingId: '9beffac3-9e98-4aee-a73e-bbd8922b7474',
            slettet: false,
            utfallsendringer: [],
            stillingskategori: 'STILLING',
            opprettetAvIdent: 'Z993141',
            erMaskert: false
        }
    ]));
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/kandidat/slettCvFraArbeidsgiver.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "slettCvFraArbeidsgiversKandidatliste",
    ()=>slettCvFraArbeidsgiversKandidatliste
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/api-routes.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/fetcher.ts [app-client] (ecmascript)");
;
;
const slettCvFraArbeidsgiversKandidatliste = async (kandidatlisteId, kandidatnummer, navKontor)=>{
    return await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["putApi"])(`${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatAPI"].internUrl}/veileder/kandidat/arbeidsgiverliste/${kandidatlisteId}/${kandidatnummer}`, {
        navKontor: navKontor
    });
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/kandidat/useMineKandidatlister.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "mineKandidatlisterMSWHandler",
    ()=>mineKandidatlisterMSWHandler,
    "useMineKandidatlister",
    ()=>useMineKandidatlister
]);
/**
 * Endepunkt /useMineKandidatlister
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/api-routes.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRGet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/useSWRGet.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/http.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/HttpResponse.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zod@4.0.17/node_modules/zod/v4/classic/external.js [app-client] (ecmascript) <export * as z>");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
const mineKandidatlisterEndepunkt = (pageNumber)=>`${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatAPI"].internUrl}/veileder/kandidatlister?pagesize=8${pageNumber && pageNumber > 1 ? `&pagenumber=${pageNumber}` : ''}`;
const MinKandidatListeSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    kandidatlisteId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    tittel: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    organisasjonReferanse: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    organisasjonNavn: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    stillingId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    opprettetAv: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
        ident: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
        navn: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string()
    }),
    opprettetTidspunkt: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    antallKandidater: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number(),
    kanEditere: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].boolean(),
    erEier: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].boolean(),
    kanSlette: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    antallUsynligeKandidater: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number(),
    status: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    antallStillinger: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number(),
    stillingskategori: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string()
});
const MineKandidatlisterSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    liste: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(MinKandidatListeSchema),
    antall: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number()
});
const useMineKandidatlister = (pageNumber)=>{
    _s();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRGet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSWRGet"])(mineKandidatlisterEndepunkt(pageNumber), MineKandidatlisterSchema);
};
_s(useMineKandidatlister, "K4Y6k2WDwBHXduaV5Y5moFGSmko=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRGet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSWRGet"]
    ];
});
const mineKandidatlisterMSWHandler = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].get(`${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KandidatAPI"].internUrl}/veileder/kandidatlister`, ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json({
        liste: [
            {
                kandidatlisteId: '4e61831a-38e0-4d5b-ab0c-ffda4a0aa729',
                tittel: 'Stilling tittel 1',
                organisasjonReferanse: '824391122',
                organisasjonNavn: 'TEST.NO',
                stillingId: '3d0a4bec-f7b0-434b-a22e-d681504124e7',
                opprettetAv: {
                    ident: 'TestIdent',
                    navn: 'F_993141 E_993141'
                },
                opprettetTidspunkt: '2025-02-18T14:55:47.305',
                antallKandidater: 0,
                kanEditere: true,
                erEier: true,
                kanSlette: 'HAR_STILLING',
                antallUsynligeKandidater: 0,
                status: 'ÅPEN',
                antallStillinger: 1,
                stillingskategori: 'FORMIDLING'
            }
        ],
        antall: 88
    }));
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/rekrutteringstreff/[...slug]/jobbsøkere/mutations.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "jobbsøkerSlettMSWHandler",
    ()=>jobbsøkerSlettMSWHandler,
    "opprettJobbsøkere",
    ()=>opprettJobbsøkere,
    "slettJobbsøker",
    ()=>slettJobbsøker
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/api-routes.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/fetcher.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/http.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/HttpResponse.mjs [app-client] (ecmascript)");
'use client';
;
;
;
const rekrutteringstreffJobbsøkereEndepunkt = (id)=>`${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RekrutteringstreffAPI"].internUrl}/${id}/jobbsoker`;
const opprettJobbsøkere = (id, kandidater)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["postApi"])(rekrutteringstreffJobbsøkereEndepunkt(id), kandidater);
const slettJobbsøkerEndepunkt = (rekrutteringstreffId, jobbsøkerId)=>`${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RekrutteringstreffAPI"].internUrl}/${rekrutteringstreffId}/jobbsoker/${jobbsøkerId}/slett`;
const slettJobbsøker = (rekrutteringstreffId, jobbsøkerId)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteApi"])(slettJobbsøkerEndepunkt(rekrutteringstreffId, jobbsøkerId));
const jobbsøkerSlettMSWHandler = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].delete(`${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RekrutteringstreffAPI"].internUrl}/:id1/jobbsoker/:id2/slett`, ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json({
        success: true
    }));
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/rekrutteringstreff/[...slug]/jobbsøkere/jobbsøkereMock.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "jobbsøkereMock",
    ()=>jobbsøkereMock
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$rekrutteringstreff$2f$_types$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/rekrutteringstreff/_types/constants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$YQYVFZYE$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__n__as__Faker$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@faker-js+faker@9.9.0/node_modules/@faker-js/faker/dist/chunk-YQYVFZYE.js [app-client] (ecmascript) <export n as Faker>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$ALYSO3IW$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a__as__en_NG$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@faker-js+faker@9.9.0/node_modules/@faker-js/faker/dist/chunk-ALYSO3IW.js [app-client] (ecmascript) <export a as en_NG>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a__as__nb_NO$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@faker-js+faker@9.9.0/node_modules/@faker-js/faker/dist/chunk-RHFAIXC4.js [app-client] (ecmascript) <export a as nb_NO>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nav$2d$faker$40$3$2e$2$2e$4$2f$node_modules$2f$nav$2d$faker$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/nav-faker@3.2.4/node_modules/nav-faker/dist/index.js [app-client] (ecmascript)");
;
;
;
const faker = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$YQYVFZYE$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__n__as__Faker$3e$__["Faker"]({
    locale: [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$RHFAIXC4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a__as__nb_NO$3e$__["nb_NO"]
    ]
});
const fakerEN = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$YQYVFZYE$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__n__as__Faker$3e$__["Faker"]({
    locale: [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$faker$2d$js$2b$faker$40$9$2e$9$2e$0$2f$node_modules$2f40$faker$2d$js$2f$faker$2f$dist$2f$chunk$2d$ALYSO3IW$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a__as__en_NG$3e$__["en_NG"]
    ]
});
const jobbsøkerMock = ()=>{
    const baseDate = new Date();
    return {
        personTreffId: faker.string.uuid(),
        fødselsnummer: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nav$2d$faker$40$3$2e$2$2e$4$2f$node_modules$2f$nav$2d$faker$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].personIdentifikator.fødselsnummer(),
        fornavn: faker.person.firstName(),
        etternavn: faker.person.lastName(),
        navkontor: faker.helpers.arrayElement([
            'Nav Grorud',
            'Nav Bærum',
            'Nav Kongsberg'
        ]),
        veilederNavn: faker.person.firstName() + ' ' + fakerEN.person.lastName(),
        veilederNavIdent: faker.string.alpha(1).toUpperCase() + faker.string.numeric(6),
        status: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$rekrutteringstreff$2f$_types$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["JobbsøkerStatus"].LAGT_TIL,
        hendelser: [
            {
                id: faker.string.uuid(),
                tidspunkt: new Date(baseDate.getTime()).toISOString(),
                hendelsestype: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$rekrutteringstreff$2f$_types$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["JobbsøkerHendelsestype"].OPPRETTET,
                opprettetAvAktørType: 'ARRANGØR',
                aktørIdentifikasjon: 'testperson',
                hendelseData: null
            },
            {
                id: faker.string.uuid(),
                tidspunkt: new Date(baseDate.getTime() + 1000).toISOString(),
                hendelsestype: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$rekrutteringstreff$2f$_types$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["JobbsøkerHendelsestype"].INVITERT,
                opprettetAvAktørType: 'ARRANGØR',
                aktørIdentifikasjon: 'testperson',
                hendelseData: null
            },
            {
                id: faker.string.uuid(),
                tidspunkt: new Date(baseDate.getTime() + 2000).toISOString(),
                hendelsestype: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$rekrutteringstreff$2f$_types$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["JobbsøkerHendelsestype"].SVART_JA_TIL_INVITASJON,
                opprettetAvAktørType: 'ARRANGØR',
                aktørIdentifikasjon: 'testperson',
                hendelseData: null
            }
        ]
    };
};
const jobbsøkerMedMinsideSvarMock = ()=>{
    const baseDate = new Date();
    const fnr = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nav$2d$faker$40$3$2e$2$2e$4$2f$node_modules$2f$nav$2d$faker$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].personIdentifikator.fødselsnummer();
    return {
        personTreffId: faker.string.uuid(),
        fødselsnummer: fnr,
        fornavn: faker.person.firstName(),
        etternavn: faker.person.lastName(),
        navkontor: faker.helpers.arrayElement([
            'Nav Grorud',
            'Nav Bærum',
            'Nav Kongsberg'
        ]),
        veilederNavn: faker.person.firstName() + ' ' + fakerEN.person.lastName(),
        veilederNavIdent: faker.string.alpha(1).toUpperCase() + faker.string.numeric(6),
        status: 'INVITERT',
        hendelser: [
            {
                id: faker.string.uuid(),
                tidspunkt: new Date(baseDate.getTime()).toISOString(),
                hendelsestype: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$rekrutteringstreff$2f$_types$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["JobbsøkerHendelsestype"].OPPRETTET,
                opprettetAvAktørType: 'ARRANGØR',
                aktørIdentifikasjon: 'testperson',
                hendelseData: null
            },
            {
                id: faker.string.uuid(),
                tidspunkt: new Date(baseDate.getTime() + 1000).toISOString(),
                hendelsestype: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$rekrutteringstreff$2f$_types$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["JobbsøkerHendelsestype"].INVITERT,
                opprettetAvAktørType: 'ARRANGØR',
                aktørIdentifikasjon: 'testperson',
                hendelseData: null
            },
            {
                id: faker.string.uuid(),
                tidspunkt: new Date(baseDate.getTime() + 2000).toISOString(),
                hendelsestype: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$rekrutteringstreff$2f$_types$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["JobbsøkerHendelsestype"].MOTTATT_SVAR_FRA_MINSIDE,
                opprettetAvAktørType: 'SYSTEM',
                aktørIdentifikasjon: null,
                hendelseData: {
                    varselId: faker.string.uuid(),
                    avsenderReferanseId: faker.string.uuid(),
                    fnr: fnr,
                    eksternStatus: 'SENDT',
                    minsideStatus: 'AKTIV',
                    opprettet: new Date(baseDate.getTime() + 1500).toISOString(),
                    avsenderNavident: 'Z123456',
                    eksternFeilmelding: null,
                    eksternKanal: 'SMS',
                    mal: 'KANDIDAT_INVITERT_TREFF',
                    flettedata: null
                }
            },
            {
                id: faker.string.uuid(),
                tidspunkt: new Date(baseDate.getTime() + 5000).toISOString(),
                hendelsestype: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$rekrutteringstreff$2f$_types$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["JobbsøkerHendelsestype"].MOTTATT_SVAR_FRA_MINSIDE,
                opprettetAvAktørType: 'SYSTEM',
                aktørIdentifikasjon: null,
                hendelseData: {
                    varselId: faker.string.uuid(),
                    avsenderReferanseId: faker.string.uuid(),
                    fnr: fnr,
                    eksternStatus: 'SENDT',
                    minsideStatus: 'AKTIV',
                    opprettet: new Date(baseDate.getTime() + 4500).toISOString(),
                    avsenderNavident: 'Z123456',
                    eksternFeilmelding: null,
                    eksternKanal: 'SMS',
                    mal: 'KANDIDAT_INVITERT_TREFF_ENDRET',
                    flettedata: [
                        'tidspunkt',
                        'sted'
                    ]
                }
            }
        ]
    };
};
const jobbsøkerMedAvlystOgMinsideSvarMock = ()=>{
    const baseDate = new Date();
    const fnr = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$nav$2d$faker$40$3$2e$2$2e$4$2f$node_modules$2f$nav$2d$faker$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].personIdentifikator.fødselsnummer();
    return {
        personTreffId: faker.string.uuid(),
        fødselsnummer: fnr,
        fornavn: faker.person.firstName(),
        etternavn: faker.person.lastName(),
        navkontor: faker.helpers.arrayElement([
            'Nav Grorud',
            'Nav Bærum',
            'Nav Kongsberg'
        ]),
        veilederNavn: faker.person.firstName() + ' ' + fakerEN.person.lastName(),
        veilederNavIdent: faker.string.alpha(1).toUpperCase() + faker.string.numeric(6),
        status: 'SVART_JA',
        hendelser: [
            {
                id: faker.string.uuid(),
                tidspunkt: new Date(baseDate.getTime()).toISOString(),
                hendelsestype: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$rekrutteringstreff$2f$_types$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["JobbsøkerHendelsestype"].OPPRETTET,
                opprettetAvAktørType: 'ARRANGØR',
                aktørIdentifikasjon: 'testperson',
                hendelseData: null
            },
            {
                id: faker.string.uuid(),
                tidspunkt: new Date(baseDate.getTime() + 1000).toISOString(),
                hendelsestype: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$rekrutteringstreff$2f$_types$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["JobbsøkerHendelsestype"].INVITERT,
                opprettetAvAktørType: 'ARRANGØR',
                aktørIdentifikasjon: 'testperson',
                hendelseData: null
            },
            {
                id: faker.string.uuid(),
                tidspunkt: new Date(baseDate.getTime() + 2000).toISOString(),
                hendelsestype: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$rekrutteringstreff$2f$_types$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["JobbsøkerHendelsestype"].SVART_JA_TIL_INVITASJON,
                opprettetAvAktørType: 'JOBBSØKER',
                aktørIdentifikasjon: '12345678910',
                hendelseData: null
            },
            {
                id: faker.string.uuid(),
                tidspunkt: new Date(baseDate.getTime() + 3000).toISOString(),
                hendelsestype: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$rekrutteringstreff$2f$_types$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["JobbsøkerHendelsestype"].SVART_JA_TREFF_AVLYST,
                opprettetAvAktørType: 'SYSTEM',
                aktørIdentifikasjon: 'SYSTEM',
                hendelseData: null
            },
            {
                id: faker.string.uuid(),
                tidspunkt: new Date(baseDate.getTime() + 4000).toISOString(),
                hendelsestype: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$rekrutteringstreff$2f$_types$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["JobbsøkerHendelsestype"].MOTTATT_SVAR_FRA_MINSIDE,
                opprettetAvAktørType: 'SYSTEM',
                aktørIdentifikasjon: null,
                hendelseData: {
                    varselId: faker.string.uuid(),
                    avsenderReferanseId: faker.string.uuid(),
                    fnr: fnr,
                    eksternStatus: 'SENDT',
                    minsideStatus: 'AKTIV',
                    opprettet: new Date(baseDate.getTime() + 3500).toISOString(),
                    avsenderNavident: 'Z123456',
                    eksternFeilmelding: null,
                    eksternKanal: 'SMS',
                    mal: 'KANDIDAT_INVITERT_TREFF',
                    flettedata: null
                }
            },
            {
                id: faker.string.uuid(),
                tidspunkt: new Date(baseDate.getTime() + 5000).toISOString(),
                hendelsestype: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$rekrutteringstreff$2f$_types$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["JobbsøkerHendelsestype"].MOTTATT_SVAR_FRA_MINSIDE,
                opprettetAvAktørType: 'SYSTEM',
                aktørIdentifikasjon: null,
                hendelseData: {
                    varselId: faker.string.uuid(),
                    avsenderReferanseId: faker.string.uuid(),
                    fnr: fnr,
                    eksternStatus: 'SENDT',
                    minsideStatus: 'AKTIV',
                    opprettet: new Date(baseDate.getTime() + 3500).toISOString(),
                    avsenderNavident: 'Z123456',
                    eksternFeilmelding: null,
                    eksternKanal: 'SMS',
                    mal: 'KANDIDAT_INVITERT_TREFF_AVLYST',
                    flettedata: null
                }
            }
        ]
    };
};
const jobbsøkereMock = ()=>({
        jobbsøkere: [
            jobbsøkerMock(),
            jobbsøkerMedMinsideSvarMock(),
            jobbsøkerMedAvlystOgMinsideSvarMock()
        ],
        antallSynlige: 3,
        antallSkjulte: 1,
        antallSlettede: 0
    });
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/rekrutteringstreff/[...slug]/rekrutteringstreffMock.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "rekrutteringstreffMock",
    ()=>rekrutteringstreffMock,
    "rekrutteringstreffMockPerStatus",
    ()=>rekrutteringstreffMockPerStatus
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$rekrutteringstreff$2f$_types$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/rekrutteringstreff/_types/constants.ts [app-client] (ecmascript)");
;
const baseTreff = {
    id: 'd6a587cd-8797-4b9a-a68b-575373f16d65',
    tittel: 'Treff med navn',
    beskrivelse: null,
    fraTid: '2025-11-01T08:00:00+02:00',
    tilTid: '2025-11-01T10:00:00+02:00',
    svarfrist: '2025-11-01T07:00:00+02:00',
    gateadresse: 'Malmøgata 1',
    postnummer: '5555',
    poststed: 'Kristiansand S',
    kommune: 'Kristiansand',
    kommunenummer: '4204',
    fylke: 'Agder',
    fylkesnummer: '42',
    status: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$rekrutteringstreff$2f$_types$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RekrutteringstreffStatus"].UTKAST,
    opprettetAvPersonNavident: 'A123456',
    opprettetAvNavkontorEnhetId: '0318',
    opprettetAvTidspunkt: '2025-10-08T09:35:42+02:00',
    antallArbeidsgivere: 3,
    antallJobbsøkere: 4,
    eiere: [
        'A123456',
        'B654321',
        'C654321',
        'TestIdent'
    ],
    sistEndret: '2025-10-11T10:37:28+02:00',
    sistEndretAv: 'A123456'
};
const rekrutteringstreffMockPerStatus = {
    [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$rekrutteringstreff$2f$_types$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RekrutteringstreffStatus"].UTKAST]: {
        ...baseTreff,
        id: 'utkast',
        tittel: 'Rekrutteringstreff – utkast',
        beskrivelse: 'Et utkast som ikke er publisert ennå.',
        fraTid: null,
        tilTid: null,
        svarfrist: null,
        gateadresse: null,
        postnummer: null,
        poststed: null,
        kommune: null,
        kommunenummer: null,
        fylke: null,
        fylkesnummer: null,
        status: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$rekrutteringstreff$2f$_types$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RekrutteringstreffStatus"].UTKAST,
        antallArbeidsgivere: 0,
        antallJobbsøkere: 0
    },
    [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$rekrutteringstreff$2f$_types$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RekrutteringstreffStatus"].PUBLISERT]: {
        ...baseTreff,
        id: 'publisert',
        tittel: 'Rekrutteringstreff i Kristiansand',
        beskrivelse: 'Møt arbeidsgivere innen bygg og anlegg. Alle jobbsøkere er velkommen!',
        status: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$rekrutteringstreff$2f$_types$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RekrutteringstreffStatus"].PUBLISERT,
        antallArbeidsgivere: 5,
        antallJobbsøkere: 12
    },
    [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$rekrutteringstreff$2f$_types$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RekrutteringstreffStatus"].FULLFØRT]: {
        ...baseTreff,
        id: 'fullfort',
        tittel: 'Gjennomført treff – restaurant og hotell',
        beskrivelse: 'Treffet ble gjennomført med godt oppmøte.',
        fraTid: '2025-09-15T09:00:00+02:00',
        tilTid: '2025-09-15T12:00:00+02:00',
        svarfrist: '2025-09-14T23:59:00+02:00',
        status: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$rekrutteringstreff$2f$_types$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RekrutteringstreffStatus"].FULLFØRT,
        antallArbeidsgivere: 4,
        antallJobbsøkere: 18,
        opprettetAvTidspunkt: '2025-08-20T10:00:00+02:00',
        sistEndret: '2025-09-15T13:00:00+02:00'
    },
    [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$rekrutteringstreff$2f$_types$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RekrutteringstreffStatus"].AVLYST]: {
        ...baseTreff,
        id: 'avlyst',
        tittel: 'Avlyst treff – transport og logistikk',
        beskrivelse: 'Treffet ble avlyst grunnet manglende påmeldinger.',
        fraTid: '2025-10-20T10:00:00+02:00',
        tilTid: '2025-10-20T13:00:00+02:00',
        svarfrist: '2025-10-19T23:59:00+02:00',
        status: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$rekrutteringstreff$2f$_types$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RekrutteringstreffStatus"].AVLYST,
        antallArbeidsgivere: 1,
        antallJobbsøkere: 0,
        opprettetAvTidspunkt: '2025-09-25T08:00:00+02:00',
        sistEndret: '2025-10-18T14:30:00+02:00'
    },
    [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$rekrutteringstreff$2f$_types$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RekrutteringstreffStatus"].SLETTET]: {
        ...baseTreff,
        id: 'slettet',
        tittel: 'Slettet treff – duplikat',
        beskrivelse: 'Ble opprettet ved en feil og deretter slettet.',
        fraTid: null,
        tilTid: null,
        svarfrist: null,
        gateadresse: null,
        postnummer: null,
        poststed: null,
        kommune: null,
        kommunenummer: null,
        fylke: null,
        fylkesnummer: null,
        status: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$rekrutteringstreff$2f$_types$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RekrutteringstreffStatus"].SLETTET,
        antallArbeidsgivere: 0,
        antallJobbsøkere: 0,
        opprettetAvTidspunkt: '2025-10-01T11:00:00+02:00',
        sistEndret: '2025-10-01T11:05:00+02:00'
    }
};
const rekrutteringstreffMock = (id)=>{
    const mockFraStatus = Object.values(rekrutteringstreffMockPerStatus).find((m)=>m.id === id);
    if (mockFraStatus) return mockFraStatus;
    if (id === '1231-1234-1234-1234') {
        return rekrutteringstreffMockPerStatus[__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$rekrutteringstreff$2f$_types$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RekrutteringstreffStatus"].UTKAST];
    }
    return rekrutteringstreffMockPerStatus[__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$rekrutteringstreff$2f$_types$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RekrutteringstreffStatus"].PUBLISERT];
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/rekrutteringstreff/oversikt/useRekrutteringstreffOversiktMock.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "rekrutteringstreffOversiktMock",
    ()=>rekrutteringstreffOversiktMock
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$rekrutteringstreff$2f5b2e2e2e$slug$5d2f$rekrutteringstreffMock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/rekrutteringstreff/[...slug]/rekrutteringstreffMock.ts [app-client] (ecmascript)");
;
const rekrutteringstreffOversiktMock = Object.values(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$rekrutteringstreff$2f5b2e2e2e$slug$5d2f$rekrutteringstreffMock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rekrutteringstreffMockPerStatus"]).map(({ id, tittel, beskrivelse, fraTid, tilTid, gateadresse, postnummer, poststed, status, opprettetAvPersonNavident, opprettetAvNavkontorEnhetId, opprettetAvTidspunkt, antallArbeidsgivere, antallJobbsøkere })=>({
        id,
        tittel,
        beskrivelse,
        fraTid,
        tilTid,
        gateadresse,
        postnummer,
        poststed,
        status,
        opprettetAvPersonNavident,
        opprettetAvNavkontorEnhetId,
        opprettetAvTidspunkt,
        antallArbeidsgivere: antallArbeidsgivere ?? 0,
        antallJobbsøkere: antallJobbsøkere ?? 0
    }));
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/rekrutteringstreff/oversikt/useRekrutteringstreffOversikt.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RekrutteringstreffOversiktSchema",
    ()=>RekrutteringstreffOversiktSchema,
    "RekrutteringstreffStatusEnum",
    ()=>RekrutteringstreffStatusEnum,
    "rekrutteringstreffOversiktEndepunkt",
    ()=>rekrutteringstreffOversiktEndepunkt,
    "rekrutteringstreffOversiktMSWHandler",
    ()=>rekrutteringstreffOversiktMSWHandler,
    "useRekrutteringstreffOversikt",
    ()=>useRekrutteringstreffOversikt
]);
/**
 * Endepunkt /useRekrutteringstreffOversikt
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$rekrutteringstreff$2f$oversikt$2f$useRekrutteringstreffOversiktMock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/rekrutteringstreff/oversikt/useRekrutteringstreffOversiktMock.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/api-routes.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRGet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/useSWRGet.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$rekrutteringstreff$2f$_types$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/rekrutteringstreff/_types/constants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/http.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/HttpResponse.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zod@4.0.17/node_modules/zod/v4/classic/external.js [app-client] (ecmascript) <export * as z>");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
const rekrutteringstreffOversiktEndepunkt = ()=>`${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RekrutteringstreffAPI"].internUrl}`;
const RekrutteringstreffStatusEnum = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].enum(_c = Object.values(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$rekrutteringstreff$2f$_types$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RekrutteringstreffStatus"]));
_c1 = RekrutteringstreffStatusEnum;
const RekrutteringstreffSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    id: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    tittel: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    beskrivelse: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    fraTid: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    tilTid: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    gateadresse: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    postnummer: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    poststed: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    status: RekrutteringstreffStatusEnum,
    opprettetAvPersonNavident: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    opprettetAvNavkontorEnhetId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    opprettetAvTidspunkt: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    antallArbeidsgivere: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].int(),
    antallJobbsøkere: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].int()
});
const RekrutteringstreffOversiktSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(RekrutteringstreffSchema);
_c2 = RekrutteringstreffOversiktSchema;
const useRekrutteringstreffOversikt = ()=>{
    _s();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRGet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSWRGet"])(rekrutteringstreffOversiktEndepunkt(), RekrutteringstreffOversiktSchema);
};
_s(useRekrutteringstreffOversikt, "K4Y6k2WDwBHXduaV5Y5moFGSmko=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRGet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSWRGet"]
    ];
});
const rekrutteringstreffOversiktMSWHandler = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].get(`${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RekrutteringstreffAPI"].internUrl}`, ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$rekrutteringstreff$2f$oversikt$2f$useRekrutteringstreffOversiktMock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rekrutteringstreffOversiktMock"]));
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "RekrutteringstreffStatusEnum$z.enum");
__turbopack_context__.k.register(_c1, "RekrutteringstreffStatusEnum");
__turbopack_context__.k.register(_c2, "RekrutteringstreffOversiktSchema");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/rekrutteringstreff/[...slug]/useRekrutteringstreff.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HendelseSchema",
    ()=>HendelseSchema,
    "MinsideVarselSvarDataSchema",
    ()=>MinsideVarselSvarDataSchema,
    "RekrutteringstreffBaseSchema",
    ()=>RekrutteringstreffBaseSchema,
    "RekrutteringstreffUtenHendelserSchema",
    ()=>RekrutteringstreffUtenHendelserSchema,
    "RekrutteringstreffendringerSchema",
    ()=>RekrutteringstreffendringerSchema,
    "parseHendelseData",
    ()=>parseHendelseData,
    "rekrutteringstreffMSWHandler",
    ()=>rekrutteringstreffMSWHandler,
    "useRekrutteringstreff",
    ()=>useRekrutteringstreff
]);
/**
 * Endepunkt /useRekrutteringstreff
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/api-routes.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$rekrutteringstreff$2f5b2e2e2e$slug$5d2f$rekrutteringstreffMock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/rekrutteringstreff/[...slug]/rekrutteringstreffMock.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$rekrutteringstreff$2f$oversikt$2f$useRekrutteringstreffOversikt$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/rekrutteringstreff/oversikt/useRekrutteringstreffOversikt.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRGet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/useSWRGet.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/http.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/HttpResponse.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zod@4.0.17/node_modules/zod/v4/classic/external.js [app-client] (ecmascript) <export * as z>");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
const rekrutteringstreffEndepunkt = (id)=>`${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RekrutteringstreffAPI"].internUrl}/${id}`;
const MinsideVarselSvarDataSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    varselId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    avsenderReferanseId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    fnr: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    eksternStatus: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    minsideStatus: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    opprettet: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    avsenderNavident: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    eksternFeilmelding: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    eksternKanal: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    mal: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    flettedata: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string()).nullable()
});
const EndringsfeltSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    gammelVerdi: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    nyVerdi: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    skalVarsle: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].boolean()
}).nullable();
const RekrutteringstreffendringerSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    navn: EndringsfeltSchema,
    sted: EndringsfeltSchema,
    tidspunkt: EndringsfeltSchema,
    svarfrist: EndringsfeltSchema,
    introduksjon: EndringsfeltSchema
});
const parseHendelseData = (hendelsestype, data)=>{
    if (data == null) return null;
    switch(hendelsestype){
        case 'MOTTATT_SVAR_FRA_MINSIDE':
            return MinsideVarselSvarDataSchema.parse(data);
        case 'TREFF_ENDRET_ETTER_PUBLISERING_NOTIFIKASJON':
            return RekrutteringstreffendringerSchema.parse(data);
        default:
            return null;
    }
};
const HendelseRawSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    id: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    tidspunkt: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    hendelsestype: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    opprettetAvAktørType: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    aktørIdentifikasjon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    hendelseData: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].unknown().nullable().optional()
});
const HendelseSchema = HendelseRawSchema.transform(_c = (h)=>({
        ...h,
        hendelseData: parseHendelseData(h.hendelsestype, h.hendelseData)
    }));
_c1 = HendelseSchema;
const RekrutteringstreffBaseSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    id: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    tittel: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    beskrivelse: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    fraTid: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    tilTid: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    svarfrist: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    gateadresse: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    postnummer: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    poststed: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    kommune: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    kommunenummer: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    fylke: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    fylkesnummer: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    status: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$rekrutteringstreff$2f$oversikt$2f$useRekrutteringstreffOversikt$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RekrutteringstreffStatusEnum"],
    opprettetAvPersonNavident: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    opprettetAvNavkontorEnhetId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    opprettetAvTidspunkt: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    antallArbeidsgivere: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].int().nullable(),
    antallJobbsøkere: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].int().nullable(),
    eiere: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string()),
    sistEndret: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    sistEndretAv: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string()
});
const RekrutteringstreffUtenHendelserSchema = RekrutteringstreffBaseSchema;
const useRekrutteringstreff = (id)=>{
    _s();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRGet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSWRGet"])(id ? rekrutteringstreffEndepunkt(id) : null, RekrutteringstreffBaseSchema);
};
_s(useRekrutteringstreff, "K4Y6k2WDwBHXduaV5Y5moFGSmko=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRGet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSWRGet"]
    ];
});
const rekrutteringstreffMSWHandler = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].get(`${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RekrutteringstreffAPI"].internUrl}/:id`, ({ params })=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json((0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$rekrutteringstreff$2f5b2e2e2e$slug$5d2f$rekrutteringstreffMock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rekrutteringstreffMock"])(params.id)));
var _c, _c1;
__turbopack_context__.k.register(_c, "HendelseSchema$HendelseRawSchema.transform");
__turbopack_context__.k.register(_c1, "HendelseSchema");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/rekrutteringstreff/[...slug]/jobbsøkere/useJobbsøkere.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "JobbsøkerSchema",
    ()=>JobbsøkerSchema,
    "JobbsøkerStatusEnum",
    ()=>JobbsøkerStatusEnum,
    "JobbsøkereResponseSchema",
    ()=>JobbsøkereResponseSchema,
    "JobbsøkereSchema",
    ()=>JobbsøkereSchema,
    "jobbsøkereEndepunkt",
    ()=>jobbsøkereEndepunkt,
    "jobbsøkereMSWHandler",
    ()=>jobbsøkereMSWHandler,
    "useJobbsøkere",
    ()=>useJobbsøkere
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$rekrutteringstreff$2f5b2e2e2e$slug$5d2f$jobbs$f8$kere$2f$jobbs$f8$kereMock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/rekrutteringstreff/[...slug]/jobbsøkere/jobbsøkereMock.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/api-routes.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$rekrutteringstreff$2f5b2e2e2e$slug$5d2f$useRekrutteringstreff$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/rekrutteringstreff/[...slug]/useRekrutteringstreff.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRGet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/useSWRGet.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$rekrutteringstreff$2f$_types$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/rekrutteringstreff/_types/constants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$tilgangskontroll$2f$roller$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/tilgangskontroll/roller.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$ApplikasjonContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/providers/ApplikasjonContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/http.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/HttpResponse.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zod@4.0.17/node_modules/zod/v4/classic/external.js [app-client] (ecmascript) <export * as z>");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
const JobbsøkerStatusEnum = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].enum(_c = Object.values(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$rekrutteringstreff$2f$_types$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["JobbsøkerStatus"]));
_c1 = JobbsøkerStatusEnum;
const JobbsøkerSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    personTreffId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    fødselsnummer: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    fornavn: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    etternavn: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    navkontor: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    veilederNavn: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    veilederNavIdent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
    status: JobbsøkerStatusEnum,
    hendelser: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$rekrutteringstreff$2f5b2e2e2e$slug$5d2f$useRekrutteringstreff$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HendelseSchema"])
});
const JobbsøkereSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(JobbsøkerSchema);
_c2 = JobbsøkereSchema;
const JobbsøkereResponseSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    jobbsøkere: JobbsøkereSchema,
    antallSynlige: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number(),
    antallSkjulte: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number(),
    antallSlettede: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$0$2e$17$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number()
});
const jobbsøkereEndepunkt = (id)=>`${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RekrutteringstreffAPI"].internUrl}/${id}/jobbsoker`;
const useJobbsøkere = (id, refreshInterval)=>{
    _s();
    const applikasjonskontekst = (0, __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$ApplikasjonContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useApplikasjonContext"])();
    const eiere = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$rekrutteringstreff$2f5b2e2e2e$slug$5d2f$useRekrutteringstreff$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRekrutteringstreff"])(id)?.data?.eiere;
    const kanHenteJobbsøkere = eiere?.includes(applikasjonskontekst.brukerData.ident) || applikasjonskontekst.harRolle([
        __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$tilgangskontroll$2f$roller$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Roller"].AD_GRUPPE_REKRUTTERINGSBISTAND_UTVIKLER
    ]);
    const key = id ? jobbsøkereEndepunkt(id) : null;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRGet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSWRGet"])(kanHenteJobbsøkere ? key : null, JobbsøkereResponseSchema, {
        nonImmutable: !!refreshInterval,
        refreshInterval
    });
};
_s(useJobbsøkere, "TILGNwSHEKXtf6NQEqZqjTJXIb8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$providers$2f$ApplikasjonContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useApplikasjonContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$rekrutteringstreff$2f5b2e2e2e$slug$5d2f$useRekrutteringstreff$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRekrutteringstreff"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRGet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSWRGet"]
    ];
});
const jobbsøkereMSWHandler = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].get(`${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RekrutteringstreffAPI"].internUrl}/:rekrutteringstreffId/jobbsoker`, ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json((0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$rekrutteringstreff$2f5b2e2e2e$slug$5d2f$jobbs$f8$kere$2f$jobbs$f8$kereMock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jobbsøkereMock"])()));
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "JobbsøkerStatusEnum$z.enum");
__turbopack_context__.k.register(_c1, "JobbsøkerStatusEnum");
__turbopack_context__.k.register(_c2, "JobbsøkereSchema");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/rekrutteringstreff/mittkontor/useRekrutteringstreffMittKontorMock.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "rekrutteringstreffMittKontorMock",
    ()=>rekrutteringstreffMittKontorMock
]);
const rekrutteringstreffMittKontorMock = [
    {
        id: 'e8b697cd-9898-5b0a-b79b-686484f27e76',
        tittel: 'Mitt Lokalt jobbtreff',
        beskrivelse: 'Jobbtreff for mitt kontor',
        fraTid: '2026-02-20T09:00:00+01:00',
        tilTid: '2026-02-20T12:00:00+01:00',
        gateadresse: 'Storgata 10',
        postnummer: '0182',
        poststed: 'Oslo',
        status: 'UTKAST',
        opprettetAvPersonNavident: 'A123456',
        opprettetAvNavkontorEnhetId: '0318',
        opprettetAvTidspunkt: '2026-01-15T10:00:00+01:00',
        antallArbeidsgivere: 2,
        antallJobbsøkere: 8
    },
    {
        id: 'f9c798de-0909-6c1b-c80c-797595g38f87',
        tittel: 'Mitt Vårjobbtreff',
        beskrivelse: 'Beskrivelse av vårjobbtreff',
        fraTid: '2026-03-15T10:00:00+01:00',
        tilTid: '2026-03-15T14:00:00+01:00',
        gateadresse: 'Parkveien 5',
        postnummer: '0182',
        poststed: 'Oslo',
        status: 'PUBLISERT',
        opprettetAvPersonNavident: 'A123456',
        opprettetAvNavkontorEnhetId: '0318',
        opprettetAvTidspunkt: '2026-01-20T14:00:00+01:00',
        antallArbeidsgivere: 4,
        antallJobbsøkere: 12
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/rekrutteringstreff/mittkontor/useRekrutteringstreffMittKontor.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "rekrutteringstreffMittKontorEndepunkt",
    ()=>rekrutteringstreffMittKontorEndepunkt,
    "rekrutteringstreffMittKontorMSWHandler",
    ()=>rekrutteringstreffMittKontorMSWHandler,
    "useRekrutteringstreffMittKontor",
    ()=>useRekrutteringstreffMittKontor
]);
/**
 * Endepunkt /rekrutteringstreff/mittkontor
 * Returnerer rekrutteringstreff for brukerens kontor
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$rekrutteringstreff$2f$mittkontor$2f$useRekrutteringstreffMittKontorMock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/rekrutteringstreff/mittkontor/useRekrutteringstreffMittKontorMock.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/api-routes.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$rekrutteringstreff$2f$oversikt$2f$useRekrutteringstreffOversikt$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/rekrutteringstreff/oversikt/useRekrutteringstreffOversikt.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRGet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/useSWRGet.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/http.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/msw@2.12.7_@types+node@24.10.9_typescript@5.9.3/node_modules/msw/lib/core/HttpResponse.mjs [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
const rekrutteringstreffMittKontorEndepunkt = ()=>`${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RekrutteringstreffAPI"].internUrl}/mittkontor`;
const useRekrutteringstreffMittKontor = ()=>{
    _s();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRGet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSWRGet"])(rekrutteringstreffMittKontorEndepunkt(), __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$rekrutteringstreff$2f$oversikt$2f$useRekrutteringstreffOversikt$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RekrutteringstreffOversiktSchema"]);
};
_s(useRekrutteringstreffMittKontor, "K4Y6k2WDwBHXduaV5Y5moFGSmko=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$useSWRGet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSWRGet"]
    ];
});
const rekrutteringstreffMittKontorMSWHandler = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$http$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["http"].get(`${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$api$2d$routes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RekrutteringstreffAPI"].internUrl}/mittkontor`, ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$msw$40$2$2e$12$2e$7_$40$types$2b$node$40$24$2e$10$2e$9_typescript$40$5$2e$9$2e$3$2f$node_modules$2f$msw$2f$lib$2f$core$2f$HttpResponse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpResponse"].json(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$rekrutteringstreff$2f$mittkontor$2f$useRekrutteringstreffMittKontorMock$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rekrutteringstreffMittKontorMock"]));
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=app_api_2e750764._.js.map